let Predicates = [HasStdExtXIsaac, IsRV32] in {
class RVInst_CUSTOM16<dag outs, dag ins> : Instruction, Sched<[]> {
    // General
    let Namespace = "RISCV";
    let DecoderNamespace = "XIsaac";
    let Size = 4;
    bits<32> SoftFail = 0;
    bits<32> Inst;

    // Operands
    bits<5> rd;
    bits<5> rs1;

    // Attributes
    let hasSideEffects = 1;
    let mayLoad = 0;
    let mayStore = 0;
    let isTerminator = 0;

    // Encoding

    let Inst{31} = 0b1;

    let Inst{30} = 0b0;

    let Inst{29} = 0b0;

    let Inst{28} = 0b1;

    let Inst{27} = 0b1;

    let Inst{26} = 0b1;

    let Inst{25} = 0b0;

    let Inst{24} = 0b0;

    let Inst{23} = 0b0;

    let Inst{22} = 0b0;

    let Inst{21} = 0b0;

    let Inst{20} = 0b0;

    let Inst{19-15} = rs1;

    let Inst{14} = 0b0;

    let Inst{13} = 0b1;

    let Inst{12} = 0b0;

    let Inst{11-7} = rd;

    let Inst{6} = 0b0;

    let Inst{5} = 0b0;

    let Inst{4} = 0b0;

    let Inst{3} = 0b1;

    let Inst{2} = 0b0;

    let Inst{1} = 0b1;

    let Inst{0} = 0b1;

    dag OutOperandList = outs;
    dag InOperandList = ins;

    // Assembly
    let AsmString = "custom16\t$rd, $rs1";

}
def CUSTOM16 : RVInst_CUSTOM16<(outs GPR:$rd), (ins GPR:$rs1)>;

}