let Predicates = [HasStdExtXIsaac, IsRV32] in {
class RVInst_CUSTOM21<dag outs, dag ins> : Instruction, Sched<[]> {
    // General
    let Namespace = "RISCV";
    let DecoderNamespace = "XIsaac";
    let Size = 4;
    bits<32> SoftFail = 0;
    bits<32> Inst;

    // Operands
    bits<5> rd;
    bits<5> rs1;
    bits<5> rs2;
    bits<4> uimm4;

    // Attributes
    let hasSideEffects = 1;
    let mayLoad = 0;
    let mayStore = 0;
    let isTerminator = 0;

    // Encoding

    let Inst{31} = 0b1;

    let Inst{30} = 0b0;

    let Inst{29} = 0b1;

    let Inst{28-25} = uimm4;

    let Inst{24-20} = rs2;

    let Inst{19-15} = rs1;

    let Inst{14} = 0b1;

    let Inst{13} = 0b0;

    let Inst{12} = 0b0;

    let Inst{11-7} = rd;

    let Inst{6} = 0b0;

    let Inst{5} = 0b0;

    let Inst{4} = 0b0;

    let Inst{3} = 0b1;

    let Inst{2} = 0b0;

    let Inst{1} = 0b1;

    let Inst{0} = 0b1;

    dag OutOperandList = outs;
    dag InOperandList = ins;

    // Assembly
    let AsmString = "custom21\t$rd, $rs1, $rs2, $uimm4";

}
def CUSTOM21 : RVInst_CUSTOM21<(outs GPR:$rd), (ins GPR:$rs1, GPR:$rs2, seal5_uimm4:$uimm4)>;

}