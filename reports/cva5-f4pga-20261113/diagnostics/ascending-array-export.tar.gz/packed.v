module pipeline(input clk,rst,request, output done);
reg[0:1] valid;
always @(posedge clk) if(rst)valid<=2'b00;
else begin valid[0]<=request;valid[1]<=valid[0];end
assign done=valid[1];
endmodule
