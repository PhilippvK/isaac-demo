 

// SystemVerilog file 
 
module SCAL (
    // Interface to the ISAX Module
    
    
    
    // Interface to the Core
    
    
    input clk_i,
    input rst_i

    
);
// Declare local signals


// Logic


endmodule





