/*
 * Copyright © 2022 Carsten Heinz
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

module cva5_wrapper
    import cva5_config::*;
    import l2_config_and_types::*;
    import riscv_types::*;
    import cva5_types::*;
    import scaiev_types::*;
 (
	input logic clk,
	input logic rst,

	output wire [31:0] instruction_bram_addr,
	output wire        instruction_bram_en,
	output wire [3:0]  instruction_bram_we,
	output wire [31:0] instruction_bram_din,
	input  wire [31:0] instruction_bram_dout,

	output wire [31:0] data_bram_addr,
	output wire        data_bram_en,
	output wire [3:0]  data_bram_we,
	output wire [31:0] data_bram_din,
	input  wire [31:0] data_bram_dout,

	// AXI Bus
	// AXI Write Channels
	output wire                            m_axi_awvalid,
	input  wire                            m_axi_awready,
	output wire [5:0]                      m_axi_awid,
	output wire [31:0]                     m_axi_awaddr,
	//~ output wire [3:0]                      m_axi_awregion,
	output wire [7:0]                      m_axi_awlen,
	output wire [2:0]                      m_axi_awsize,
	output wire [1:0]                      m_axi_awburst,
	//~ output wire                            m_axi_awlock,
	output wire [3:0]                      m_axi_awcache,
	//~ output wire [2:0]                      m_axi_awprot,
	//~ output wire [3:0]                      m_axi_awqos,

	output wire                            m_axi_wvalid,
	input  wire                            m_axi_wready,
	output wire [31:0]                     m_axi_wdata,
	output wire [3:0]                      m_axi_wstrb,
	output wire                            m_axi_wlast,

	input  wire                            m_axi_bvalid,
	output wire                            m_axi_bready,
	input  wire [1:0]                      m_axi_bresp,
	input  wire [5:0]                      m_axi_bid,

	// AXI Read Channels
	output wire                            m_axi_arvalid,
	input  wire                            m_axi_arready,
	output wire [5:0]                      m_axi_arid,
	output wire [31:0]                     m_axi_araddr,
	//~ output wire [3:0]                      m_axi_arregion,
	output wire [7:0]                      m_axi_arlen,
	output wire [2:0]                      m_axi_arsize,
	output wire [1:0]                      m_axi_arburst,
	//~ output wire                            m_axi_arlock,
	output wire [3:0]                      m_axi_arcache,
	//~ output wire [2:0]                      m_axi_arprot,
	//~ output wire [3:0]                      m_axi_arqos,

	input  wire                            m_axi_rvalid,
	output wire                            m_axi_rready,
	input  wire [5:0]                      m_axi_rid,
	input  wire [31:0]                     m_axi_rdata,
	input  wire [1:0]                      m_axi_rresp,
	input  wire                            m_axi_rlast,

	// AXI Cache
	// AXI Write Channels
	output wire                            axi_awvalid,
	input  wire                            axi_awready,
	output wire [5:0]                      axi_awid,
	output wire [31:0]                     axi_awaddr,
	//~ output wire [3:0]                      axi_awregion,
	output wire [7:0]                      axi_awlen,
	output wire [2:0]                      axi_awsize,
	output wire [1:0]                      axi_awburst,
	//~ output wire                            axi_awlock,
	output wire [3:0]                      axi_awcache,
	output wire [2:0]                      axi_awprot,
	//~ output wire [3:0]                      axi_awqos,

	output wire                            axi_wvalid,
	input  wire                            axi_wready,
	output wire [31:0]                     axi_wdata,
	output wire [3:0]                      axi_wstrb,
	output wire                            axi_wlast,

	input  wire                            axi_bvalid,
	output wire                            axi_bready,
	input  wire [1:0]                      axi_bresp,
	input  wire [5:0]                      axi_bid,

	// AXI Read Channels
	output wire                            axi_arvalid,
	input  wire                            axi_arready,
	output wire [5:0]                      axi_arid,
	output wire [31:0]                     axi_araddr,
	//~ output wire [3:0]                      axi_arregion,
	output wire [7:0]                      axi_arlen,
	output wire [2:0]                      axi_arsize,
	output wire [1:0]                      axi_arburst,
	//~ output wire                            axi_arlock,
	output wire [3:0]                      axi_arcache,
	output wire [2:0]                      axi_arprot,
	//~ output wire [3:0]                      axi_arqos,

	input  wire                            axi_rvalid,
	output wire                            axi_rready,
	input  wire [5:0]                      axi_rid,
	input  wire [31:0]                     axi_rdata,
	input  wire [1:0]                      axi_rresp,
	input  wire                            axi_rlast,

	input logic timer_interrupt,
	input logic interrupt
, input logic  WrRD_validReq_3_i,// ISAX

input logic  RdMem_addr_valid_3_i,// ISAX

output logic  RdFlush_1_o,// ISAX

output logic  RdFlush_3_o,// ISAX

output logic  RdFlush_2_o,// ISAX

output logic [32 -1 : 0] RdRD_2_o,// ISAX

input logic [32 -1 : 0] WrRD_3_i,// ISAX

output logic  RdStall_1_o,// ISAX

output logic  RdStall_2_o,// ISAX

output logic  RdStall_3_o,// ISAX

output logic [32 -1 : 0] RdInstr_1_o,// ISAX

output logic [32 -1 : 0] RdInstr_2_o,// ISAX

output logic [32 -1 : 0] RdInstr_3_o,// ISAX

input logic  RdMem_validReq_3_i,// ISAX

output logic [32 -1 : 0] RdRS1_3_o,// ISAX

output logic [32 -1 : 0] RdRS1_2_o,// ISAX

output logic [32 -1 : 0] RdRS2_2_o,// ISAX

output logic [32 -1 : 0] RdRS2_3_o,// ISAX

output logic [32 -1 : 0] RdMem_3_o,// ISAX

input logic [32 -1 : 0] RdMem_addr_3_i,// ISAX

output logic  RdInStageValid_1_o,// ISAX

output logic  RdInStageValid_2_o,// ISAX

output logic  RdInStageValid_3_o,// ISAX

input logic [3 -1 : 0] RdMem_size_3_i,// ISAX

input logic  RdIValid_CUSTOM17_2_i,// ISAX

input logic  RdAnyValid_CUSTOM17_3_i,// ISAX

input logic  RdIValid_CUSTOM78_2_i,// ISAX

input logic  RdAnyValid_CUSTOM78_3_i,// ISAX

input logic  RdIValid_CUSTOM44_2_i,// ISAX

input logic  RdAnyValid_CUSTOM44_3_i,// ISAX

input logic  RdIValid_CUSTOM43_2_i,// ISAX

input logic  RdAnyValid_CUSTOM43_3_i,// ISAX

input logic  RdIValid_CUSTOM76_2_i,// ISAX

input logic  RdAnyValid_CUSTOM76_3_i,// ISAX

input logic  RdIValid_CUSTOM53_1_i,// ISAX

input logic  RdIValid_CUSTOM52_1_i,// ISAX

input logic  RdIValid_CUSTOM51_1_i,// ISAX

input logic  RdIValid_CUSTOM50_1_i,// ISAX

input logic  RdIValid_CUSTOM59_1_i,// ISAX

input logic  RdIValid_CUSTOM58_1_i,// ISAX

input logic  RdIValid_CUSTOM57_1_i,// ISAX

input logic  RdIValid_CUSTOM56_1_i,// ISAX

input logic  RdIValid_CUSTOM55_1_i,// ISAX

input logic  RdIValid_CUSTOM54_1_i,// ISAX

input logic  RdIValid_CUSTOM115_1_i,// ISAX

input logic  RdIValid_CUSTOM113_1_i,// ISAX

input logic  RdIValid_CUSTOM114_1_i,// ISAX

input logic  RdIValid_CUSTOM111_1_i,// ISAX

input logic  RdIValid_CUSTOM112_1_i,// ISAX

input logic  RdIValid_CUSTOM64_1_i,// ISAX

input logic  RdIValid_CUSTOM63_1_i,// ISAX

input logic  RdIValid_CUSTOM62_1_i,// ISAX

input logic  RdIValid_CUSTOM61_1_i,// ISAX

input logic  RdIValid_CUSTOM60_1_i,// ISAX

input logic  RdIValid_CUSTOM69_1_i,// ISAX

input logic  RdIValid_CUSTOM68_1_i,// ISAX

input logic  RdIValid_CUSTOM67_1_i,// ISAX

input logic  RdIValid_CUSTOM66_1_i,// ISAX

input logic  RdIValid_CUSTOM65_1_i,// ISAX

input logic  RdIValid_CUSTOM31_1_i,// ISAX

input logic  RdIValid_CUSTOM30_1_i,// ISAX

input logic  RdIValid_CUSTOM39_1_i,// ISAX

input logic  RdIValid_CUSTOM38_1_i,// ISAX

input logic  RdIValid_CUSTOM37_1_i,// ISAX

input logic  RdIValid_CUSTOM36_1_i,// ISAX

input logic  RdIValid_CUSTOM35_1_i,// ISAX

input logic  RdIValid_CUSTOM34_1_i,// ISAX

input logic  RdIValid_CUSTOM33_1_i,// ISAX

input logic  RdIValid_CUSTOM32_1_i,// ISAX

input logic  RdIValid_CUSTOM42_1_i,// ISAX

input logic  RdIValid_CUSTOM41_1_i,// ISAX

input logic  RdIValid_CUSTOM40_1_i,// ISAX

input logic  RdIValid_CUSTOM49_1_i,// ISAX

input logic  RdIValid_CUSTOM48_1_i,// ISAX

input logic  RdIValid_CUSTOM47_1_i,// ISAX

input logic  RdIValid_CUSTOM46_1_i,// ISAX

input logic  RdIValid_CUSTOM45_1_i,// ISAX

input logic  RdIValid_CUSTOM44_1_i,// ISAX

input logic  RdIValid_CUSTOM43_1_i,// ISAX

input logic  RdIValid_CUSTOM97_1_i,// ISAX

input logic  RdIValid_CUSTOM96_1_i,// ISAX

input logic  RdIValid_CUSTOM95_1_i,// ISAX

input logic  RdIValid_CUSTOM94_1_i,// ISAX

input logic  RdIValid_CUSTOM93_1_i,// ISAX

input logic  RdIValid_CUSTOM92_1_i,// ISAX

input logic  RdIValid_CUSTOM91_1_i,// ISAX

input logic  RdIValid_CUSTOM90_1_i,// ISAX

input logic  RdIValid_CUSTOM17_1_i,// ISAX

input logic  RdIValid_CUSTOM16_1_i,// ISAX

input logic  RdIValid_CUSTOM15_1_i,// ISAX

input logic  RdIValid_CUSTOM14_1_i,// ISAX

input logic  RdIValid_CUSTOM13_1_i,// ISAX

input logic  RdIValid_CUSTOM12_1_i,// ISAX

input logic  RdIValid_CUSTOM11_1_i,// ISAX

input logic  RdIValid_CUSTOM99_1_i,// ISAX

input logic  RdIValid_CUSTOM10_1_i,// ISAX

input logic  RdIValid_CUSTOM98_1_i,// ISAX

input logic  RdIValid_CUSTOM19_1_i,// ISAX

input logic  RdIValid_CUSTOM18_1_i,// ISAX

input logic  RdIValid_CUSTOM20_1_i,// ISAX

input logic  RdIValid_CUSTOM28_1_i,// ISAX

input logic  RdIValid_CUSTOM27_1_i,// ISAX

input logic  RdIValid_CUSTOM26_1_i,// ISAX

input logic  RdIValid_CUSTOM25_1_i,// ISAX

input logic  RdIValid_CUSTOM24_1_i,// ISAX

input logic  RdIValid_CUSTOM23_1_i,// ISAX

input logic  RdIValid_CUSTOM22_1_i,// ISAX

input logic  RdIValid_CUSTOM21_1_i,// ISAX

input logic  RdIValid_CUSTOM29_1_i,// ISAX

input logic  RdIValid_CUSTOM106_1_i,// ISAX

input logic  RdIValid_CUSTOM107_1_i,// ISAX

input logic  RdIValid_CUSTOM104_1_i,// ISAX

input logic  RdIValid_CUSTOM105_1_i,// ISAX

input logic  RdIValid_CUSTOM102_1_i,// ISAX

input logic  RdIValid_CUSTOM103_1_i,// ISAX

input logic  RdIValid_CUSTOM100_1_i,// ISAX

input logic  RdIValid_CUSTOM101_1_i,// ISAX

input logic  RdIValid_CUSTOM75_1_i,// ISAX

input logic  RdIValid_CUSTOM74_1_i,// ISAX

input logic  RdIValid_CUSTOM73_1_i,// ISAX

input logic  RdIValid_CUSTOM72_1_i,// ISAX

input logic  RdIValid_CUSTOM71_1_i,// ISAX

input logic  RdIValid_CUSTOM70_1_i,// ISAX

input logic  RdIValid_CUSTOM108_1_i,// ISAX

input logic  RdIValid_CUSTOM109_1_i,// ISAX

input logic  RdIValid_CUSTOM79_1_i,// ISAX

input logic  RdIValid_CUSTOM78_1_i,// ISAX

input logic  RdIValid_CUSTOM77_1_i,// ISAX

input logic  RdIValid_CUSTOM76_1_i,// ISAX

input logic  RdIValid_CUSTOM0_1_i,// ISAX

input logic  RdIValid_CUSTOM110_1_i,// ISAX

input logic  RdIValid_CUSTOM7_1_i,// ISAX

input logic  RdIValid_CUSTOM8_1_i,// ISAX

input logic  RdIValid_CUSTOM5_1_i,// ISAX

input logic  RdIValid_CUSTOM6_1_i,// ISAX

input logic  RdIValid_CUSTOM3_1_i,// ISAX

input logic  RdIValid_CUSTOM4_1_i,// ISAX

input logic  RdIValid_CUSTOM1_1_i,// ISAX

input logic  RdIValid_CUSTOM2_1_i,// ISAX

input logic  RdIValid_CUSTOM86_1_i,// ISAX

input logic  RdIValid_CUSTOM85_1_i,// ISAX

input logic  RdIValid_CUSTOM84_1_i,// ISAX

input logic  RdIValid_CUSTOM83_1_i,// ISAX

input logic  RdIValid_CUSTOM82_1_i,// ISAX

input logic  RdIValid_CUSTOM81_1_i,// ISAX

input logic  RdIValid_CUSTOM9_1_i,// ISAX

input logic  RdIValid_CUSTOM80_1_i,// ISAX

input logic  RdIValid_CUSTOM89_1_i,// ISAX

input logic  RdIValid_CUSTOM88_1_i,// ISAX

input logic  RdIValid_CUSTOM87_1_i,// ISAX

output logic  RdPipeInto_stage_executesv1_2_o,// ISAX

output logic  RdPipeInto_stage_executecva_2_o,// ISAX

output logic  glueToSCAL_IValid_cond_all_1_o,// ISAX

output logic  glueToSCAL_IValid_cond_all_2_o,// ISAX

output logic  glueToSCAL_IValid_cond_all_3_o,// ISAX

output logic [13 -1 : 0] glueToSCAL_WrRD_spawn_addr_2_o,// ISAX

output logic [13 -1 : 0] glueToSCAL_WrRD_spawn_addr_1_o// ISAX

);

local_memory_interface instruction_bram();
assign instruction_bram_addr = {instruction_bram.addr[29:0],2'b0};
assign instruction_bram_en = instruction_bram.en;
assign instruction_bram_we = instruction_bram.be;
assign instruction_bram_din = instruction_bram.data_in;
assign instruction_bram.data_out = instruction_bram_dout;

local_memory_interface data_bram();
assign data_bram_addr = {data_bram.addr[29:0],2'b0};
assign data_bram_en = data_bram.en;
assign data_bram_we = data_bram.be;
assign data_bram_din = data_bram.data_in;
assign data_bram.data_out = data_bram_dout;

axi_interface m_axi();
assign m_axi_awvalid = m_axi.awvalid;
assign m_axi.awready = m_axi_awready;
assign m_axi_awid = m_axi.awid;
assign m_axi_awaddr = m_axi.awaddr;
assign m_axi_awlen = m_axi.awlen;
assign m_axi_awsize = m_axi.awsize;
assign m_axi_awburst = m_axi.awburst;
assign m_axi_awcache = m_axi.awcache;

assign m_axi_wvalid = m_axi.wvalid;
assign m_axi.wready = m_axi_wready;
assign m_axi_wdata = m_axi.wdata;
assign m_axi_wstrb = m_axi.wstrb;
assign m_axi_wlast = m_axi.wlast;

assign m_axi.bvalid = m_axi_bvalid;
assign m_axi_bready = m_axi.bready;
assign m_axi.bresp = m_axi_bresp;
assign m_axi.bid = m_axi_bid;

assign m_axi_arvalid = m_axi.arvalid;
assign m_axi.arready = m_axi_arready;
assign m_axi_arid = m_axi.arid;
assign m_axi_araddr = m_axi.araddr;
assign m_axi_arlen = m_axi.arlen;
assign m_axi_arsize = m_axi.arsize;
assign m_axi_arburst = m_axi.arburst;
assign m_axi_arcache = m_axi.arcache;

assign m_axi.rvalid = m_axi_rvalid;
assign m_axi_rready = m_axi.rready;
assign m_axi.rid = m_axi_rid;
assign m_axi.rdata = m_axi_rdata;
assign m_axi.rresp = m_axi_rresp;
assign m_axi.rlast = m_axi_rlast;

assign axi_awid = 0;

avalon_interface m_avalon();
wishbone_interface dwishbone();
wishbone_interface iwishbone();

l2_requester_interface l2[L2_NUM_PORTS-1:0]();
assign l2[1].request_push = 0;
assign l2[1].wr_data_push = 0;
assign l2[1].inv_ack = l2[1].inv_valid;
assign l2[1].rd_data_ack = l2[1].rd_data_valid;

l2_memory_interface arb_mem();

trace_outputs_t tr;

interrupt_t m_interrupt;
assign m_interrupt.software = 1'b0;
assign m_interrupt.timer = timer_interrupt;
assign m_interrupt.external = interrupt;

scaiev_interface scaiev();

cva5 cva5 (
	.clk(clk),
	.rst(rst),

	.instruction_bram(instruction_bram),
	.data_bram(data_bram),

	.m_axi(m_axi),
	.m_avalon(m_avalon),
	.dwishbone(dwishbone),
	.iwishbone(iwishbone),
	.l2(l2[0]),
	
	.tr(tr),

	.scaiev(scaiev),

	.s_interrupt(0),
	.m_interrupt(m_interrupt)
);

l2_arbiter l2_arb (
	.clk(clk),
	.rst(rst),
	.request(l2),
	.mem(arb_mem)
);

axi_to_arb l2_to_mem (
	.clk(clk),
	.rst(rst),
	.l2(arb_mem),
	.* // e.g. axi_*
);

scaiev_glue scaiev_glue (
	.clk(clk),
	.rst(rst),
	
	.scaiev(scaiev)
, .WrRD_validReq_3_i ( WrRD_validReq_3_i),

.RdMem_addr_valid_3_i ( RdMem_addr_valid_3_i),

.RdFlush_1_o ( RdFlush_1_o),

.RdFlush_3_o ( RdFlush_3_o),

.RdFlush_2_o ( RdFlush_2_o),

.RdRD_2_o ( RdRD_2_o),

.WrRD_3_i ( WrRD_3_i),

.RdStall_1_o ( RdStall_1_o),

.RdStall_2_o ( RdStall_2_o),

.RdStall_3_o ( RdStall_3_o),

.RdInstr_1_o ( RdInstr_1_o),

.RdInstr_2_o ( RdInstr_2_o),

.RdInstr_3_o ( RdInstr_3_o),

.RdMem_validReq_3_i ( RdMem_validReq_3_i),

.RdRS1_3_o ( RdRS1_3_o),

.RdRS1_2_o ( RdRS1_2_o),

.RdRS2_2_o ( RdRS2_2_o),

.RdRS2_3_o ( RdRS2_3_o),

.RdMem_3_o ( RdMem_3_o),

.RdMem_addr_3_i ( RdMem_addr_3_i),

.RdInStageValid_1_o ( RdInStageValid_1_o),

.RdInStageValid_2_o ( RdInStageValid_2_o),

.RdInStageValid_3_o ( RdInStageValid_3_o),

.RdMem_size_3_i ( RdMem_size_3_i),

.RdIValid_CUSTOM17_2_i ( RdIValid_CUSTOM17_2_i),

.RdAnyValid_CUSTOM17_3_i ( RdAnyValid_CUSTOM17_3_i),

.RdIValid_CUSTOM78_2_i ( RdIValid_CUSTOM78_2_i),

.RdAnyValid_CUSTOM78_3_i ( RdAnyValid_CUSTOM78_3_i),

.RdIValid_CUSTOM44_2_i ( RdIValid_CUSTOM44_2_i),

.RdAnyValid_CUSTOM44_3_i ( RdAnyValid_CUSTOM44_3_i),

.RdIValid_CUSTOM43_2_i ( RdIValid_CUSTOM43_2_i),

.RdAnyValid_CUSTOM43_3_i ( RdAnyValid_CUSTOM43_3_i),

.RdIValid_CUSTOM76_2_i ( RdIValid_CUSTOM76_2_i),

.RdAnyValid_CUSTOM76_3_i ( RdAnyValid_CUSTOM76_3_i),

.RdIValid_CUSTOM53_1_i ( RdIValid_CUSTOM53_1_i),

.RdIValid_CUSTOM52_1_i ( RdIValid_CUSTOM52_1_i),

.RdIValid_CUSTOM51_1_i ( RdIValid_CUSTOM51_1_i),

.RdIValid_CUSTOM50_1_i ( RdIValid_CUSTOM50_1_i),

.RdIValid_CUSTOM59_1_i ( RdIValid_CUSTOM59_1_i),

.RdIValid_CUSTOM58_1_i ( RdIValid_CUSTOM58_1_i),

.RdIValid_CUSTOM57_1_i ( RdIValid_CUSTOM57_1_i),

.RdIValid_CUSTOM56_1_i ( RdIValid_CUSTOM56_1_i),

.RdIValid_CUSTOM55_1_i ( RdIValid_CUSTOM55_1_i),

.RdIValid_CUSTOM54_1_i ( RdIValid_CUSTOM54_1_i),

.RdIValid_CUSTOM115_1_i ( RdIValid_CUSTOM115_1_i),

.RdIValid_CUSTOM113_1_i ( RdIValid_CUSTOM113_1_i),

.RdIValid_CUSTOM114_1_i ( RdIValid_CUSTOM114_1_i),

.RdIValid_CUSTOM111_1_i ( RdIValid_CUSTOM111_1_i),

.RdIValid_CUSTOM112_1_i ( RdIValid_CUSTOM112_1_i),

.RdIValid_CUSTOM64_1_i ( RdIValid_CUSTOM64_1_i),

.RdIValid_CUSTOM63_1_i ( RdIValid_CUSTOM63_1_i),

.RdIValid_CUSTOM62_1_i ( RdIValid_CUSTOM62_1_i),

.RdIValid_CUSTOM61_1_i ( RdIValid_CUSTOM61_1_i),

.RdIValid_CUSTOM60_1_i ( RdIValid_CUSTOM60_1_i),

.RdIValid_CUSTOM69_1_i ( RdIValid_CUSTOM69_1_i),

.RdIValid_CUSTOM68_1_i ( RdIValid_CUSTOM68_1_i),

.RdIValid_CUSTOM67_1_i ( RdIValid_CUSTOM67_1_i),

.RdIValid_CUSTOM66_1_i ( RdIValid_CUSTOM66_1_i),

.RdIValid_CUSTOM65_1_i ( RdIValid_CUSTOM65_1_i),

.RdIValid_CUSTOM31_1_i ( RdIValid_CUSTOM31_1_i),

.RdIValid_CUSTOM30_1_i ( RdIValid_CUSTOM30_1_i),

.RdIValid_CUSTOM39_1_i ( RdIValid_CUSTOM39_1_i),

.RdIValid_CUSTOM38_1_i ( RdIValid_CUSTOM38_1_i),

.RdIValid_CUSTOM37_1_i ( RdIValid_CUSTOM37_1_i),

.RdIValid_CUSTOM36_1_i ( RdIValid_CUSTOM36_1_i),

.RdIValid_CUSTOM35_1_i ( RdIValid_CUSTOM35_1_i),

.RdIValid_CUSTOM34_1_i ( RdIValid_CUSTOM34_1_i),

.RdIValid_CUSTOM33_1_i ( RdIValid_CUSTOM33_1_i),

.RdIValid_CUSTOM32_1_i ( RdIValid_CUSTOM32_1_i),

.RdIValid_CUSTOM42_1_i ( RdIValid_CUSTOM42_1_i),

.RdIValid_CUSTOM41_1_i ( RdIValid_CUSTOM41_1_i),

.RdIValid_CUSTOM40_1_i ( RdIValid_CUSTOM40_1_i),

.RdIValid_CUSTOM49_1_i ( RdIValid_CUSTOM49_1_i),

.RdIValid_CUSTOM48_1_i ( RdIValid_CUSTOM48_1_i),

.RdIValid_CUSTOM47_1_i ( RdIValid_CUSTOM47_1_i),

.RdIValid_CUSTOM46_1_i ( RdIValid_CUSTOM46_1_i),

.RdIValid_CUSTOM45_1_i ( RdIValid_CUSTOM45_1_i),

.RdIValid_CUSTOM44_1_i ( RdIValid_CUSTOM44_1_i),

.RdIValid_CUSTOM43_1_i ( RdIValid_CUSTOM43_1_i),

.RdIValid_CUSTOM97_1_i ( RdIValid_CUSTOM97_1_i),

.RdIValid_CUSTOM96_1_i ( RdIValid_CUSTOM96_1_i),

.RdIValid_CUSTOM95_1_i ( RdIValid_CUSTOM95_1_i),

.RdIValid_CUSTOM94_1_i ( RdIValid_CUSTOM94_1_i),

.RdIValid_CUSTOM93_1_i ( RdIValid_CUSTOM93_1_i),

.RdIValid_CUSTOM92_1_i ( RdIValid_CUSTOM92_1_i),

.RdIValid_CUSTOM91_1_i ( RdIValid_CUSTOM91_1_i),

.RdIValid_CUSTOM90_1_i ( RdIValid_CUSTOM90_1_i),

.RdIValid_CUSTOM17_1_i ( RdIValid_CUSTOM17_1_i),

.RdIValid_CUSTOM16_1_i ( RdIValid_CUSTOM16_1_i),

.RdIValid_CUSTOM15_1_i ( RdIValid_CUSTOM15_1_i),

.RdIValid_CUSTOM14_1_i ( RdIValid_CUSTOM14_1_i),

.RdIValid_CUSTOM13_1_i ( RdIValid_CUSTOM13_1_i),

.RdIValid_CUSTOM12_1_i ( RdIValid_CUSTOM12_1_i),

.RdIValid_CUSTOM11_1_i ( RdIValid_CUSTOM11_1_i),

.RdIValid_CUSTOM99_1_i ( RdIValid_CUSTOM99_1_i),

.RdIValid_CUSTOM10_1_i ( RdIValid_CUSTOM10_1_i),

.RdIValid_CUSTOM98_1_i ( RdIValid_CUSTOM98_1_i),

.RdIValid_CUSTOM19_1_i ( RdIValid_CUSTOM19_1_i),

.RdIValid_CUSTOM18_1_i ( RdIValid_CUSTOM18_1_i),

.RdIValid_CUSTOM20_1_i ( RdIValid_CUSTOM20_1_i),

.RdIValid_CUSTOM28_1_i ( RdIValid_CUSTOM28_1_i),

.RdIValid_CUSTOM27_1_i ( RdIValid_CUSTOM27_1_i),

.RdIValid_CUSTOM26_1_i ( RdIValid_CUSTOM26_1_i),

.RdIValid_CUSTOM25_1_i ( RdIValid_CUSTOM25_1_i),

.RdIValid_CUSTOM24_1_i ( RdIValid_CUSTOM24_1_i),

.RdIValid_CUSTOM23_1_i ( RdIValid_CUSTOM23_1_i),

.RdIValid_CUSTOM22_1_i ( RdIValid_CUSTOM22_1_i),

.RdIValid_CUSTOM21_1_i ( RdIValid_CUSTOM21_1_i),

.RdIValid_CUSTOM29_1_i ( RdIValid_CUSTOM29_1_i),

.RdIValid_CUSTOM106_1_i ( RdIValid_CUSTOM106_1_i),

.RdIValid_CUSTOM107_1_i ( RdIValid_CUSTOM107_1_i),

.RdIValid_CUSTOM104_1_i ( RdIValid_CUSTOM104_1_i),

.RdIValid_CUSTOM105_1_i ( RdIValid_CUSTOM105_1_i),

.RdIValid_CUSTOM102_1_i ( RdIValid_CUSTOM102_1_i),

.RdIValid_CUSTOM103_1_i ( RdIValid_CUSTOM103_1_i),

.RdIValid_CUSTOM100_1_i ( RdIValid_CUSTOM100_1_i),

.RdIValid_CUSTOM101_1_i ( RdIValid_CUSTOM101_1_i),

.RdIValid_CUSTOM75_1_i ( RdIValid_CUSTOM75_1_i),

.RdIValid_CUSTOM74_1_i ( RdIValid_CUSTOM74_1_i),

.RdIValid_CUSTOM73_1_i ( RdIValid_CUSTOM73_1_i),

.RdIValid_CUSTOM72_1_i ( RdIValid_CUSTOM72_1_i),

.RdIValid_CUSTOM71_1_i ( RdIValid_CUSTOM71_1_i),

.RdIValid_CUSTOM70_1_i ( RdIValid_CUSTOM70_1_i),

.RdIValid_CUSTOM108_1_i ( RdIValid_CUSTOM108_1_i),

.RdIValid_CUSTOM109_1_i ( RdIValid_CUSTOM109_1_i),

.RdIValid_CUSTOM79_1_i ( RdIValid_CUSTOM79_1_i),

.RdIValid_CUSTOM78_1_i ( RdIValid_CUSTOM78_1_i),

.RdIValid_CUSTOM77_1_i ( RdIValid_CUSTOM77_1_i),

.RdIValid_CUSTOM76_1_i ( RdIValid_CUSTOM76_1_i),

.RdIValid_CUSTOM0_1_i ( RdIValid_CUSTOM0_1_i),

.RdIValid_CUSTOM110_1_i ( RdIValid_CUSTOM110_1_i),

.RdIValid_CUSTOM7_1_i ( RdIValid_CUSTOM7_1_i),

.RdIValid_CUSTOM8_1_i ( RdIValid_CUSTOM8_1_i),

.RdIValid_CUSTOM5_1_i ( RdIValid_CUSTOM5_1_i),

.RdIValid_CUSTOM6_1_i ( RdIValid_CUSTOM6_1_i),

.RdIValid_CUSTOM3_1_i ( RdIValid_CUSTOM3_1_i),

.RdIValid_CUSTOM4_1_i ( RdIValid_CUSTOM4_1_i),

.RdIValid_CUSTOM1_1_i ( RdIValid_CUSTOM1_1_i),

.RdIValid_CUSTOM2_1_i ( RdIValid_CUSTOM2_1_i),

.RdIValid_CUSTOM86_1_i ( RdIValid_CUSTOM86_1_i),

.RdIValid_CUSTOM85_1_i ( RdIValid_CUSTOM85_1_i),

.RdIValid_CUSTOM84_1_i ( RdIValid_CUSTOM84_1_i),

.RdIValid_CUSTOM83_1_i ( RdIValid_CUSTOM83_1_i),

.RdIValid_CUSTOM82_1_i ( RdIValid_CUSTOM82_1_i),

.RdIValid_CUSTOM81_1_i ( RdIValid_CUSTOM81_1_i),

.RdIValid_CUSTOM9_1_i ( RdIValid_CUSTOM9_1_i),

.RdIValid_CUSTOM80_1_i ( RdIValid_CUSTOM80_1_i),

.RdIValid_CUSTOM89_1_i ( RdIValid_CUSTOM89_1_i),

.RdIValid_CUSTOM88_1_i ( RdIValid_CUSTOM88_1_i),

.RdIValid_CUSTOM87_1_i ( RdIValid_CUSTOM87_1_i),

.RdPipeInto_stage_executesv1_2_o ( RdPipeInto_stage_executesv1_2_o),

.RdPipeInto_stage_executecva_2_o ( RdPipeInto_stage_executecva_2_o),

.glueToSCAL_IValid_cond_all_1_o ( glueToSCAL_IValid_cond_all_1_o),

.glueToSCAL_IValid_cond_all_2_o ( glueToSCAL_IValid_cond_all_2_o),

.glueToSCAL_IValid_cond_all_3_o ( glueToSCAL_IValid_cond_all_3_o),

.glueToSCAL_WrRD_spawn_addr_2_o ( glueToSCAL_WrRD_spawn_addr_2_o),

.glueToSCAL_WrRD_spawn_addr_1_o ( glueToSCAL_WrRD_spawn_addr_1_o)

);

endmodule
