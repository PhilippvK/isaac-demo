/*
 * Copyright © 2022 Carsten Heinz
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

module cva5_wrapper_verilog (
	input wire clk,
	input wire rst,

	// (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 instruction_bram CLK" *)
	// output wire        instruction_bram_clk,
	// (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 instruction_bram RST" *)
	// output wire        instruction_bram_rst,
	(* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 instruction_bram ADDR" *)
	output wire [29:0] instruction_bram_addr,
	(* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 instruction_bram EN" *)
	output wire        instruction_bram_en,
	(* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 instruction_bram WE" *)
	output wire [3:0]  instruction_bram_we,
	(* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 instruction_bram DIN" *)
	output wire [31:0] instruction_bram_din,
	(* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 instruction_bram DOUT" *)
	input  wire [31:0] instruction_bram_dout,

	// (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 data_bram CLK" *)
	// output wire        data_bram_clk,
	// (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 data_bram RST" *)
	// output wire        data_bram_rst,
	(* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 data_bram ADDR" *)
	output wire [29:0] data_bram_addr,
	(* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 data_bram EN" *)
	output wire        data_bram_en,
	(* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 data_bram WE" *)
	output wire [3:0]  data_bram_we,
	(* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 data_bram DIN" *)
	output wire [31:0] data_bram_din,
	(* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 data_bram DOUT" *)
	input  wire [31:0] data_bram_dout,

	// AXI Bus
	// AXI Write Channels
	output wire                            m_axi_awvalid,
	input  wire                            m_axi_awready,
	//~ output wire [5:0]                      m_axi_awid,
	output wire [31:0]                     m_axi_awaddr,
	//~ output wire [3:0]                      m_axi_awregion,
	output wire [7:0]                      m_axi_awlen,
	output wire [2:0]                      m_axi_awsize,
	output wire [1:0]                      m_axi_awburst,
	//~ output wire                            m_axi_awlock,
	output wire [3:0]                      m_axi_awcache,
	//~ output wire [2:0]                      m_axi_awprot,
	//~ output wire [3:0]                      m_axi_awqos,

	output wire                            m_axi_wvalid,
	input  wire                            m_axi_wready,
	output wire [31:0]                     m_axi_wdata,
	output wire [3:0]                      m_axi_wstrb,
	output wire                            m_axi_wlast,

	input  wire                            m_axi_bvalid,
	output wire                            m_axi_bready,
	input  wire [1:0]                      m_axi_bresp,
	//~ input  wire [5:0]                      m_axi_bid,

	// AXI Read Channels
	output wire                            m_axi_arvalid,
	input  wire                            m_axi_arready,
	//~ output wire [5:0]                      m_axi_arid,
	output wire [31:0]                     m_axi_araddr,
	//~ output wire [3:0]                      m_axi_arregion,
	output wire [7:0]                      m_axi_arlen,
	output wire [2:0]                      m_axi_arsize,
	output wire [1:0]                      m_axi_arburst,
	//~ output wire                            m_axi_arlock,
	output wire [3:0]                      m_axi_arcache,
	//~ output wire [2:0]                      m_axi_arprot,
	//~ output wire [3:0]                      m_axi_arqos,

	input  wire                            m_axi_rvalid,
	output wire                            m_axi_rready,
	//~ input  wire [5:0]                      m_axi_rid,
	input  wire [31:0]                     m_axi_rdata,
	input  wire [1:0]                      m_axi_rresp,
	input  wire                            m_axi_rlast,

	// AXI Cache
	// AXI Write Channels
	output wire                            m_axi_cache_awvalid,
	input  wire                            m_axi_cache_awready,
	output wire [5:0]                      m_axi_cache_awid,
	output wire [31:0]                     m_axi_cache_awaddr,
	//~ output wire [3:0]                      m_axi_cache_awregion,
	output wire [7:0]                      m_axi_cache_awlen,
	output wire [2:0]                      m_axi_cache_awsize,
	output wire [1:0]                      m_axi_cache_awburst,
	//~ output wire                            m_axi_cache_awlock,
	output wire [3:0]                      m_axi_cache_awcache,
	output wire [2:0]                      m_axi_cache_awprot,
	//~ output wire [3:0]                      m_axi_cache_awqos,

	output wire                            m_axi_cache_wvalid,
	input  wire                            m_axi_cache_wready,
	output wire [31:0]                     m_axi_cache_wdata,
	output wire [3:0]                      m_axi_cache_wstrb,
	output wire                            m_axi_cache_wlast,

	input  wire                            m_axi_cache_bvalid,
	output wire                            m_axi_cache_bready,
	input  wire [1:0]                      m_axi_cache_bresp,
	input  wire [5:0]                      m_axi_cache_bid,

	// AXI Read Channels
	output wire                            m_axi_cache_arvalid,
	input  wire                            m_axi_cache_arready,
	output wire [5:0]                      m_axi_cache_arid,
	output wire [31:0]                     m_axi_cache_araddr,
	//~ output wire [3:0]                      m_axi_cache_arregion,
	output wire [7:0]                      m_axi_cache_arlen,
	output wire [2:0]                      m_axi_cache_arsize,
	output wire [1:0]                      m_axi_cache_arburst,
	//~ output wire                            m_axi_cache_arlock,
	output wire [3:0]                      m_axi_cache_arcache,
	output wire [2:0]                      m_axi_cache_arprot,
	//~ output wire [3:0]                      m_axi_cache_arqos,

	input  wire                            m_axi_cache_rvalid,
	output wire                            m_axi_cache_rready,
	input  wire [5:0]                      m_axi_cache_rid,
	input  wire [31:0]                     m_axi_cache_rdata,
	input  wire [1:0]                      m_axi_cache_rresp,
	input  wire                            m_axi_cache_rlast
, input wire  WrRD_validReq_3_i,// ISAX

input wire  RdMem_addr_valid_3_i,// ISAX

output wire  RdFlush_1_o,// ISAX

output wire  RdFlush_3_o,// ISAX

output wire  RdFlush_2_o,// ISAX

output wire [32 -1 : 0] RdRD_2_o,// ISAX

input wire [32 -1 : 0] WrRD_3_i,// ISAX

output wire  RdStall_1_o,// ISAX

output wire  RdStall_2_o,// ISAX

output wire  RdStall_3_o,// ISAX

output wire [32 -1 : 0] RdInstr_1_o,// ISAX

output wire [32 -1 : 0] RdInstr_2_o,// ISAX

output wire [32 -1 : 0] RdInstr_3_o,// ISAX

input wire  RdMem_validReq_3_i,// ISAX

output wire [32 -1 : 0] RdRS1_3_o,// ISAX

output wire [32 -1 : 0] RdRS1_2_o,// ISAX

output wire [32 -1 : 0] RdRS2_2_o,// ISAX

output wire [32 -1 : 0] RdRS2_3_o,// ISAX

output wire [32 -1 : 0] RdMem_3_o,// ISAX

input wire [32 -1 : 0] RdMem_addr_3_i,// ISAX

output wire  RdInStageValid_1_o,// ISAX

output wire  RdInStageValid_2_o,// ISAX

output wire  RdInStageValid_3_o,// ISAX

input wire [3 -1 : 0] RdMem_size_3_i,// ISAX

input wire  RdIValid_CUSTOM17_2_i,// ISAX

input wire  RdAnyValid_CUSTOM17_3_i,// ISAX

input wire  RdIValid_CUSTOM78_2_i,// ISAX

input wire  RdAnyValid_CUSTOM78_3_i,// ISAX

input wire  RdIValid_CUSTOM44_2_i,// ISAX

input wire  RdAnyValid_CUSTOM44_3_i,// ISAX

input wire  RdIValid_CUSTOM43_2_i,// ISAX

input wire  RdAnyValid_CUSTOM43_3_i,// ISAX

input wire  RdIValid_CUSTOM76_2_i,// ISAX

input wire  RdAnyValid_CUSTOM76_3_i,// ISAX

input wire  RdIValid_CUSTOM53_1_i,// ISAX

input wire  RdIValid_CUSTOM52_1_i,// ISAX

input wire  RdIValid_CUSTOM51_1_i,// ISAX

input wire  RdIValid_CUSTOM50_1_i,// ISAX

input wire  RdIValid_CUSTOM59_1_i,// ISAX

input wire  RdIValid_CUSTOM58_1_i,// ISAX

input wire  RdIValid_CUSTOM57_1_i,// ISAX

input wire  RdIValid_CUSTOM56_1_i,// ISAX

input wire  RdIValid_CUSTOM55_1_i,// ISAX

input wire  RdIValid_CUSTOM54_1_i,// ISAX

input wire  RdIValid_CUSTOM115_1_i,// ISAX

input wire  RdIValid_CUSTOM113_1_i,// ISAX

input wire  RdIValid_CUSTOM114_1_i,// ISAX

input wire  RdIValid_CUSTOM111_1_i,// ISAX

input wire  RdIValid_CUSTOM112_1_i,// ISAX

input wire  RdIValid_CUSTOM64_1_i,// ISAX

input wire  RdIValid_CUSTOM63_1_i,// ISAX

input wire  RdIValid_CUSTOM62_1_i,// ISAX

input wire  RdIValid_CUSTOM61_1_i,// ISAX

input wire  RdIValid_CUSTOM60_1_i,// ISAX

input wire  RdIValid_CUSTOM69_1_i,// ISAX

input wire  RdIValid_CUSTOM68_1_i,// ISAX

input wire  RdIValid_CUSTOM67_1_i,// ISAX

input wire  RdIValid_CUSTOM66_1_i,// ISAX

input wire  RdIValid_CUSTOM65_1_i,// ISAX

input wire  RdIValid_CUSTOM31_1_i,// ISAX

input wire  RdIValid_CUSTOM30_1_i,// ISAX

input wire  RdIValid_CUSTOM39_1_i,// ISAX

input wire  RdIValid_CUSTOM38_1_i,// ISAX

input wire  RdIValid_CUSTOM37_1_i,// ISAX

input wire  RdIValid_CUSTOM36_1_i,// ISAX

input wire  RdIValid_CUSTOM35_1_i,// ISAX

input wire  RdIValid_CUSTOM34_1_i,// ISAX

input wire  RdIValid_CUSTOM33_1_i,// ISAX

input wire  RdIValid_CUSTOM32_1_i,// ISAX

input wire  RdIValid_CUSTOM42_1_i,// ISAX

input wire  RdIValid_CUSTOM41_1_i,// ISAX

input wire  RdIValid_CUSTOM40_1_i,// ISAX

input wire  RdIValid_CUSTOM49_1_i,// ISAX

input wire  RdIValid_CUSTOM48_1_i,// ISAX

input wire  RdIValid_CUSTOM47_1_i,// ISAX

input wire  RdIValid_CUSTOM46_1_i,// ISAX

input wire  RdIValid_CUSTOM45_1_i,// ISAX

input wire  RdIValid_CUSTOM44_1_i,// ISAX

input wire  RdIValid_CUSTOM43_1_i,// ISAX

input wire  RdIValid_CUSTOM97_1_i,// ISAX

input wire  RdIValid_CUSTOM96_1_i,// ISAX

input wire  RdIValid_CUSTOM95_1_i,// ISAX

input wire  RdIValid_CUSTOM94_1_i,// ISAX

input wire  RdIValid_CUSTOM93_1_i,// ISAX

input wire  RdIValid_CUSTOM92_1_i,// ISAX

input wire  RdIValid_CUSTOM91_1_i,// ISAX

input wire  RdIValid_CUSTOM90_1_i,// ISAX

input wire  RdIValid_CUSTOM17_1_i,// ISAX

input wire  RdIValid_CUSTOM16_1_i,// ISAX

input wire  RdIValid_CUSTOM15_1_i,// ISAX

input wire  RdIValid_CUSTOM14_1_i,// ISAX

input wire  RdIValid_CUSTOM13_1_i,// ISAX

input wire  RdIValid_CUSTOM12_1_i,// ISAX

input wire  RdIValid_CUSTOM11_1_i,// ISAX

input wire  RdIValid_CUSTOM99_1_i,// ISAX

input wire  RdIValid_CUSTOM10_1_i,// ISAX

input wire  RdIValid_CUSTOM98_1_i,// ISAX

input wire  RdIValid_CUSTOM19_1_i,// ISAX

input wire  RdIValid_CUSTOM18_1_i,// ISAX

input wire  RdIValid_CUSTOM20_1_i,// ISAX

input wire  RdIValid_CUSTOM28_1_i,// ISAX

input wire  RdIValid_CUSTOM27_1_i,// ISAX

input wire  RdIValid_CUSTOM26_1_i,// ISAX

input wire  RdIValid_CUSTOM25_1_i,// ISAX

input wire  RdIValid_CUSTOM24_1_i,// ISAX

input wire  RdIValid_CUSTOM23_1_i,// ISAX

input wire  RdIValid_CUSTOM22_1_i,// ISAX

input wire  RdIValid_CUSTOM21_1_i,// ISAX

input wire  RdIValid_CUSTOM29_1_i,// ISAX

input wire  RdIValid_CUSTOM106_1_i,// ISAX

input wire  RdIValid_CUSTOM107_1_i,// ISAX

input wire  RdIValid_CUSTOM104_1_i,// ISAX

input wire  RdIValid_CUSTOM105_1_i,// ISAX

input wire  RdIValid_CUSTOM102_1_i,// ISAX

input wire  RdIValid_CUSTOM103_1_i,// ISAX

input wire  RdIValid_CUSTOM100_1_i,// ISAX

input wire  RdIValid_CUSTOM101_1_i,// ISAX

input wire  RdIValid_CUSTOM75_1_i,// ISAX

input wire  RdIValid_CUSTOM74_1_i,// ISAX

input wire  RdIValid_CUSTOM73_1_i,// ISAX

input wire  RdIValid_CUSTOM72_1_i,// ISAX

input wire  RdIValid_CUSTOM71_1_i,// ISAX

input wire  RdIValid_CUSTOM70_1_i,// ISAX

input wire  RdIValid_CUSTOM108_1_i,// ISAX

input wire  RdIValid_CUSTOM109_1_i,// ISAX

input wire  RdIValid_CUSTOM79_1_i,// ISAX

input wire  RdIValid_CUSTOM78_1_i,// ISAX

input wire  RdIValid_CUSTOM77_1_i,// ISAX

input wire  RdIValid_CUSTOM76_1_i,// ISAX

input wire  RdIValid_CUSTOM0_1_i,// ISAX

input wire  RdIValid_CUSTOM110_1_i,// ISAX

input wire  RdIValid_CUSTOM7_1_i,// ISAX

input wire  RdIValid_CUSTOM8_1_i,// ISAX

input wire  RdIValid_CUSTOM5_1_i,// ISAX

input wire  RdIValid_CUSTOM6_1_i,// ISAX

input wire  RdIValid_CUSTOM3_1_i,// ISAX

input wire  RdIValid_CUSTOM4_1_i,// ISAX

input wire  RdIValid_CUSTOM1_1_i,// ISAX

input wire  RdIValid_CUSTOM2_1_i,// ISAX

input wire  RdIValid_CUSTOM86_1_i,// ISAX

input wire  RdIValid_CUSTOM85_1_i,// ISAX

input wire  RdIValid_CUSTOM84_1_i,// ISAX

input wire  RdIValid_CUSTOM83_1_i,// ISAX

input wire  RdIValid_CUSTOM82_1_i,// ISAX

input wire  RdIValid_CUSTOM81_1_i,// ISAX

input wire  RdIValid_CUSTOM9_1_i,// ISAX

input wire  RdIValid_CUSTOM80_1_i,// ISAX

input wire  RdIValid_CUSTOM89_1_i,// ISAX

input wire  RdIValid_CUSTOM88_1_i,// ISAX

input wire  RdIValid_CUSTOM87_1_i,// ISAX

output wire  RdPipeInto_stage_executesv1_2_o,// ISAX

output wire  RdPipeInto_stage_executecva_2_o,// ISAX

output wire  glueToSCAL_IValid_cond_all_1_o,// ISAX

output wire  glueToSCAL_IValid_cond_all_2_o,// ISAX

output wire  glueToSCAL_IValid_cond_all_3_o// ISAX

);
wire [ 13 -1 : 0 ] glueToSCAL_WrRD_spawn_addr_2_s;

wire [ 13 -1 : 0 ] glueToSCAL_WrRD_spawn_addr_1_s;


assign instruction_bram_clk = clk;
assign instruction_bram_rst = rst;
assign data_bram_clk = clk;
assign data_bram_rst = rst;

wire [5:0]                      m_axi_awid;
wire [5:0]                      m_axi_bid;
wire [5:0]                      m_axi_arid;
wire [5:0]                      m_axi_rid;

wire [31:0] instruction_bram_addr_long;
assign instruction_bram_addr = instruction_bram_addr_long[29:0];

wire [31:0] data_bram_addr_long;
assign data_bram_addr = data_bram_addr_long[29:0];


cva5_wrapper cva5_wrapper (
	.clk(clk),
	.rst(rst),

	// .instruction_bram_addr(instruction_bram_addr),
	.instruction_bram_addr(instruction_bram_addr_long),
	.instruction_bram_en(instruction_bram_en),
	.instruction_bram_we(instruction_bram_we),
	.instruction_bram_din(instruction_bram_din),
	.instruction_bram_dout(instruction_bram_dout),

	// .data_bram_addr(data_bram_addr),
	.data_bram_addr(data_bram_addr_long),
	.data_bram_en(data_bram_en),
	.data_bram_we(data_bram_we),
	.data_bram_din(data_bram_din),
	.data_bram_dout(data_bram_dout),

	// AXI Bus
	.m_axi_awvalid(m_axi_awvalid),
	.m_axi_awready(m_axi_awready),
	.m_axi_awid(m_axi_awid),
	.m_axi_awaddr(m_axi_awaddr),
	//~ .m_axi_awregion(m_axi_awregion),
	.m_axi_awlen(m_axi_awlen),
	.m_axi_awsize(m_axi_awsize),
	.m_axi_awburst(m_axi_awburst),
	//~ .m_axi_awlock(m_axi_awlock),
	.m_axi_awcache(m_axi_awcache),
	//~ .m_axi_awprot(m_axi_awprot),
	//~ .m_axi_awqos(m_axi_awqos),

	.m_axi_wvalid(m_axi_wvalid),
	.m_axi_wready(m_axi_wready),
	.m_axi_wdata(m_axi_wdata),
	.m_axi_wstrb(m_axi_wstrb),
	.m_axi_wlast(m_axi_wlast),

	.m_axi_bvalid(m_axi_bvalid),
	.m_axi_bready(m_axi_bready),
	.m_axi_bresp(m_axi_bresp),
	.m_axi_bid(m_axi_bid),

	.m_axi_arvalid(m_axi_arvalid),
	.m_axi_arready(m_axi_arready),
	.m_axi_arid(m_axi_arid),
	.m_axi_araddr(m_axi_araddr),
	//~ .m_axi_arregion(m_axi_arregion),
	.m_axi_arlen(m_axi_arlen),
	.m_axi_arsize(m_axi_arsize),
	.m_axi_arburst(m_axi_arburst),
	//~ .m_axi_arlock(m_axi_arlock),
	.m_axi_arcache(m_axi_arcache),
	//~ .m_axi_arprot(m_axi_arprot),
	//~ .m_axi_arqos(m_axi_arqos),

	.m_axi_rvalid(m_axi_rvalid),
	.m_axi_rready(m_axi_rready),
	.m_axi_rid(m_axi_rid),
	.m_axi_rdata(m_axi_rdata),
	.m_axi_rresp(m_axi_rresp),
	.m_axi_rlast(m_axi_rlast),

	// AXI Cache
	.axi_awvalid(m_axi_cache_awvalid),
	.axi_awready(m_axi_cache_awready),
	.axi_awid(m_axi_cache_awid),
	.axi_awaddr(m_axi_cache_awaddr),
	//~ .axi_awregion(m_axi_cache_awregion),
	.axi_awlen(m_axi_cache_awlen),
	.axi_awsize(m_axi_cache_awsize),
	.axi_awburst(m_axi_cache_awburst),
	//~ .axi_awlock(m_axi_cache_awlock),
	.axi_awcache(m_axi_cache_awcache),
	.axi_awprot(m_axi_cache_awprot),
	//~ .axi_awqos(m_axi_cache_awqos),

	.axi_wvalid(m_axi_cache_wvalid),
	.axi_wready(m_axi_cache_wready),
	.axi_wdata(m_axi_cache_wdata),
	.axi_wstrb(m_axi_cache_wstrb),
	.axi_wlast(m_axi_cache_wlast),

	.axi_bvalid(m_axi_cache_bvalid),
	.axi_bready(m_axi_cache_bready),
	.axi_bresp(m_axi_cache_bresp),
	.axi_bid(m_axi_cache_bid),

	.axi_arvalid(m_axi_cache_arvalid),
	.axi_arready(m_axi_cache_arready),
	.axi_arid(m_axi_cache_arid),
	.axi_araddr(m_axi_cache_araddr),
	//~ .axi_arregion(m_axi_cache_arregion),
	.axi_arlen(m_axi_cache_arlen),
	.axi_arsize(m_axi_cache_arsize),
	.axi_arburst(m_axi_cache_arburst),
	//~ .axi_arlock(m_axi_cache_arlock),
	.axi_arcache(m_axi_cache_arcache),
	.axi_arprot(m_axi_cache_arprot),
	//~ .axi_arqos(m_axi_cache_arqos),

	.axi_rvalid(m_axi_cache_rvalid),
	.axi_rready(m_axi_cache_rready),
	.axi_rid(m_axi_cache_rid),
	.axi_rdata(m_axi_cache_rdata),
	.axi_rresp(m_axi_cache_rresp),
	.axi_rlast(m_axi_cache_rlast),

	.timer_interrupt(0),
	.interrupt(0)
, .WrRD_validReq_3_i ( WrRD_validReq_3_i),

.RdMem_addr_valid_3_i ( RdMem_addr_valid_3_i),

.RdFlush_1_o ( RdFlush_1_o),

.RdFlush_3_o ( RdFlush_3_o),

.RdFlush_2_o ( RdFlush_2_o),

.RdRD_2_o ( RdRD_2_o),

.WrRD_3_i ( WrRD_3_i),

.RdStall_1_o ( RdStall_1_o),

.RdStall_2_o ( RdStall_2_o),

.RdStall_3_o ( RdStall_3_o),

.RdInstr_1_o ( RdInstr_1_o),

.RdInstr_2_o ( RdInstr_2_o),

.RdInstr_3_o ( RdInstr_3_o),

.RdMem_validReq_3_i ( RdMem_validReq_3_i),

.RdRS1_3_o ( RdRS1_3_o),

.RdRS1_2_o ( RdRS1_2_o),

.RdRS2_2_o ( RdRS2_2_o),

.RdRS2_3_o ( RdRS2_3_o),

.RdMem_3_o ( RdMem_3_o),

.RdMem_addr_3_i ( RdMem_addr_3_i),

.RdInStageValid_1_o ( RdInStageValid_1_o),

.RdInStageValid_2_o ( RdInStageValid_2_o),

.RdInStageValid_3_o ( RdInStageValid_3_o),

.RdMem_size_3_i ( RdMem_size_3_i),

.RdIValid_CUSTOM17_2_i ( RdIValid_CUSTOM17_2_i),

.RdAnyValid_CUSTOM17_3_i ( RdAnyValid_CUSTOM17_3_i),

.RdIValid_CUSTOM78_2_i ( RdIValid_CUSTOM78_2_i),

.RdAnyValid_CUSTOM78_3_i ( RdAnyValid_CUSTOM78_3_i),

.RdIValid_CUSTOM44_2_i ( RdIValid_CUSTOM44_2_i),

.RdAnyValid_CUSTOM44_3_i ( RdAnyValid_CUSTOM44_3_i),

.RdIValid_CUSTOM43_2_i ( RdIValid_CUSTOM43_2_i),

.RdAnyValid_CUSTOM43_3_i ( RdAnyValid_CUSTOM43_3_i),

.RdIValid_CUSTOM76_2_i ( RdIValid_CUSTOM76_2_i),

.RdAnyValid_CUSTOM76_3_i ( RdAnyValid_CUSTOM76_3_i),

.RdIValid_CUSTOM53_1_i ( RdIValid_CUSTOM53_1_i),

.RdIValid_CUSTOM52_1_i ( RdIValid_CUSTOM52_1_i),

.RdIValid_CUSTOM51_1_i ( RdIValid_CUSTOM51_1_i),

.RdIValid_CUSTOM50_1_i ( RdIValid_CUSTOM50_1_i),

.RdIValid_CUSTOM59_1_i ( RdIValid_CUSTOM59_1_i),

.RdIValid_CUSTOM58_1_i ( RdIValid_CUSTOM58_1_i),

.RdIValid_CUSTOM57_1_i ( RdIValid_CUSTOM57_1_i),

.RdIValid_CUSTOM56_1_i ( RdIValid_CUSTOM56_1_i),

.RdIValid_CUSTOM55_1_i ( RdIValid_CUSTOM55_1_i),

.RdIValid_CUSTOM54_1_i ( RdIValid_CUSTOM54_1_i),

.RdIValid_CUSTOM115_1_i ( RdIValid_CUSTOM115_1_i),

.RdIValid_CUSTOM113_1_i ( RdIValid_CUSTOM113_1_i),

.RdIValid_CUSTOM114_1_i ( RdIValid_CUSTOM114_1_i),

.RdIValid_CUSTOM111_1_i ( RdIValid_CUSTOM111_1_i),

.RdIValid_CUSTOM112_1_i ( RdIValid_CUSTOM112_1_i),

.RdIValid_CUSTOM64_1_i ( RdIValid_CUSTOM64_1_i),

.RdIValid_CUSTOM63_1_i ( RdIValid_CUSTOM63_1_i),

.RdIValid_CUSTOM62_1_i ( RdIValid_CUSTOM62_1_i),

.RdIValid_CUSTOM61_1_i ( RdIValid_CUSTOM61_1_i),

.RdIValid_CUSTOM60_1_i ( RdIValid_CUSTOM60_1_i),

.RdIValid_CUSTOM69_1_i ( RdIValid_CUSTOM69_1_i),

.RdIValid_CUSTOM68_1_i ( RdIValid_CUSTOM68_1_i),

.RdIValid_CUSTOM67_1_i ( RdIValid_CUSTOM67_1_i),

.RdIValid_CUSTOM66_1_i ( RdIValid_CUSTOM66_1_i),

.RdIValid_CUSTOM65_1_i ( RdIValid_CUSTOM65_1_i),

.RdIValid_CUSTOM31_1_i ( RdIValid_CUSTOM31_1_i),

.RdIValid_CUSTOM30_1_i ( RdIValid_CUSTOM30_1_i),

.RdIValid_CUSTOM39_1_i ( RdIValid_CUSTOM39_1_i),

.RdIValid_CUSTOM38_1_i ( RdIValid_CUSTOM38_1_i),

.RdIValid_CUSTOM37_1_i ( RdIValid_CUSTOM37_1_i),

.RdIValid_CUSTOM36_1_i ( RdIValid_CUSTOM36_1_i),

.RdIValid_CUSTOM35_1_i ( RdIValid_CUSTOM35_1_i),

.RdIValid_CUSTOM34_1_i ( RdIValid_CUSTOM34_1_i),

.RdIValid_CUSTOM33_1_i ( RdIValid_CUSTOM33_1_i),

.RdIValid_CUSTOM32_1_i ( RdIValid_CUSTOM32_1_i),

.RdIValid_CUSTOM42_1_i ( RdIValid_CUSTOM42_1_i),

.RdIValid_CUSTOM41_1_i ( RdIValid_CUSTOM41_1_i),

.RdIValid_CUSTOM40_1_i ( RdIValid_CUSTOM40_1_i),

.RdIValid_CUSTOM49_1_i ( RdIValid_CUSTOM49_1_i),

.RdIValid_CUSTOM48_1_i ( RdIValid_CUSTOM48_1_i),

.RdIValid_CUSTOM47_1_i ( RdIValid_CUSTOM47_1_i),

.RdIValid_CUSTOM46_1_i ( RdIValid_CUSTOM46_1_i),

.RdIValid_CUSTOM45_1_i ( RdIValid_CUSTOM45_1_i),

.RdIValid_CUSTOM44_1_i ( RdIValid_CUSTOM44_1_i),

.RdIValid_CUSTOM43_1_i ( RdIValid_CUSTOM43_1_i),

.RdIValid_CUSTOM97_1_i ( RdIValid_CUSTOM97_1_i),

.RdIValid_CUSTOM96_1_i ( RdIValid_CUSTOM96_1_i),

.RdIValid_CUSTOM95_1_i ( RdIValid_CUSTOM95_1_i),

.RdIValid_CUSTOM94_1_i ( RdIValid_CUSTOM94_1_i),

.RdIValid_CUSTOM93_1_i ( RdIValid_CUSTOM93_1_i),

.RdIValid_CUSTOM92_1_i ( RdIValid_CUSTOM92_1_i),

.RdIValid_CUSTOM91_1_i ( RdIValid_CUSTOM91_1_i),

.RdIValid_CUSTOM90_1_i ( RdIValid_CUSTOM90_1_i),

.RdIValid_CUSTOM17_1_i ( RdIValid_CUSTOM17_1_i),

.RdIValid_CUSTOM16_1_i ( RdIValid_CUSTOM16_1_i),

.RdIValid_CUSTOM15_1_i ( RdIValid_CUSTOM15_1_i),

.RdIValid_CUSTOM14_1_i ( RdIValid_CUSTOM14_1_i),

.RdIValid_CUSTOM13_1_i ( RdIValid_CUSTOM13_1_i),

.RdIValid_CUSTOM12_1_i ( RdIValid_CUSTOM12_1_i),

.RdIValid_CUSTOM11_1_i ( RdIValid_CUSTOM11_1_i),

.RdIValid_CUSTOM99_1_i ( RdIValid_CUSTOM99_1_i),

.RdIValid_CUSTOM10_1_i ( RdIValid_CUSTOM10_1_i),

.RdIValid_CUSTOM98_1_i ( RdIValid_CUSTOM98_1_i),

.RdIValid_CUSTOM19_1_i ( RdIValid_CUSTOM19_1_i),

.RdIValid_CUSTOM18_1_i ( RdIValid_CUSTOM18_1_i),

.RdIValid_CUSTOM20_1_i ( RdIValid_CUSTOM20_1_i),

.RdIValid_CUSTOM28_1_i ( RdIValid_CUSTOM28_1_i),

.RdIValid_CUSTOM27_1_i ( RdIValid_CUSTOM27_1_i),

.RdIValid_CUSTOM26_1_i ( RdIValid_CUSTOM26_1_i),

.RdIValid_CUSTOM25_1_i ( RdIValid_CUSTOM25_1_i),

.RdIValid_CUSTOM24_1_i ( RdIValid_CUSTOM24_1_i),

.RdIValid_CUSTOM23_1_i ( RdIValid_CUSTOM23_1_i),

.RdIValid_CUSTOM22_1_i ( RdIValid_CUSTOM22_1_i),

.RdIValid_CUSTOM21_1_i ( RdIValid_CUSTOM21_1_i),

.RdIValid_CUSTOM29_1_i ( RdIValid_CUSTOM29_1_i),

.RdIValid_CUSTOM106_1_i ( RdIValid_CUSTOM106_1_i),

.RdIValid_CUSTOM107_1_i ( RdIValid_CUSTOM107_1_i),

.RdIValid_CUSTOM104_1_i ( RdIValid_CUSTOM104_1_i),

.RdIValid_CUSTOM105_1_i ( RdIValid_CUSTOM105_1_i),

.RdIValid_CUSTOM102_1_i ( RdIValid_CUSTOM102_1_i),

.RdIValid_CUSTOM103_1_i ( RdIValid_CUSTOM103_1_i),

.RdIValid_CUSTOM100_1_i ( RdIValid_CUSTOM100_1_i),

.RdIValid_CUSTOM101_1_i ( RdIValid_CUSTOM101_1_i),

.RdIValid_CUSTOM75_1_i ( RdIValid_CUSTOM75_1_i),

.RdIValid_CUSTOM74_1_i ( RdIValid_CUSTOM74_1_i),

.RdIValid_CUSTOM73_1_i ( RdIValid_CUSTOM73_1_i),

.RdIValid_CUSTOM72_1_i ( RdIValid_CUSTOM72_1_i),

.RdIValid_CUSTOM71_1_i ( RdIValid_CUSTOM71_1_i),

.RdIValid_CUSTOM70_1_i ( RdIValid_CUSTOM70_1_i),

.RdIValid_CUSTOM108_1_i ( RdIValid_CUSTOM108_1_i),

.RdIValid_CUSTOM109_1_i ( RdIValid_CUSTOM109_1_i),

.RdIValid_CUSTOM79_1_i ( RdIValid_CUSTOM79_1_i),

.RdIValid_CUSTOM78_1_i ( RdIValid_CUSTOM78_1_i),

.RdIValid_CUSTOM77_1_i ( RdIValid_CUSTOM77_1_i),

.RdIValid_CUSTOM76_1_i ( RdIValid_CUSTOM76_1_i),

.RdIValid_CUSTOM0_1_i ( RdIValid_CUSTOM0_1_i),

.RdIValid_CUSTOM110_1_i ( RdIValid_CUSTOM110_1_i),

.RdIValid_CUSTOM7_1_i ( RdIValid_CUSTOM7_1_i),

.RdIValid_CUSTOM8_1_i ( RdIValid_CUSTOM8_1_i),

.RdIValid_CUSTOM5_1_i ( RdIValid_CUSTOM5_1_i),

.RdIValid_CUSTOM6_1_i ( RdIValid_CUSTOM6_1_i),

.RdIValid_CUSTOM3_1_i ( RdIValid_CUSTOM3_1_i),

.RdIValid_CUSTOM4_1_i ( RdIValid_CUSTOM4_1_i),

.RdIValid_CUSTOM1_1_i ( RdIValid_CUSTOM1_1_i),

.RdIValid_CUSTOM2_1_i ( RdIValid_CUSTOM2_1_i),

.RdIValid_CUSTOM86_1_i ( RdIValid_CUSTOM86_1_i),

.RdIValid_CUSTOM85_1_i ( RdIValid_CUSTOM85_1_i),

.RdIValid_CUSTOM84_1_i ( RdIValid_CUSTOM84_1_i),

.RdIValid_CUSTOM83_1_i ( RdIValid_CUSTOM83_1_i),

.RdIValid_CUSTOM82_1_i ( RdIValid_CUSTOM82_1_i),

.RdIValid_CUSTOM81_1_i ( RdIValid_CUSTOM81_1_i),

.RdIValid_CUSTOM9_1_i ( RdIValid_CUSTOM9_1_i),

.RdIValid_CUSTOM80_1_i ( RdIValid_CUSTOM80_1_i),

.RdIValid_CUSTOM89_1_i ( RdIValid_CUSTOM89_1_i),

.RdIValid_CUSTOM88_1_i ( RdIValid_CUSTOM88_1_i),

.RdIValid_CUSTOM87_1_i ( RdIValid_CUSTOM87_1_i),

.RdPipeInto_stage_executesv1_2_o ( RdPipeInto_stage_executesv1_2_o),

.RdPipeInto_stage_executecva_2_o ( RdPipeInto_stage_executecva_2_o),

.glueToSCAL_IValid_cond_all_1_o ( glueToSCAL_IValid_cond_all_1_o),

.glueToSCAL_IValid_cond_all_2_o ( glueToSCAL_IValid_cond_all_2_o),

.glueToSCAL_IValid_cond_all_3_o ( glueToSCAL_IValid_cond_all_3_o),

.glueToSCAL_WrRD_spawn_addr_2_o ( glueToSCAL_WrRD_spawn_addr_2_s),

.glueToSCAL_WrRD_spawn_addr_1_o ( glueToSCAL_WrRD_spawn_addr_1_s)

);

endmodule
