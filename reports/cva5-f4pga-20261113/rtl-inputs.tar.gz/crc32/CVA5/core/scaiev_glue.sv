//SCAIE-V: Hazard Unit for decoupled instructions.
//Prevents multi-cycle ISAX instructions 

module scaiev_glue
    import cva5_config::*;
    import riscv_types::*;
    import cva5_types::*;
    import scaiev_types::*;
    import scaiev_config::*;

    # (
        parameter cpu_config_t CONFIG = EXAMPLE_CONFIG
    )

    (
        input logic clk,
        input logic rst,

        scaiev_interface.scal scaiev,
        output logic [12:0] WrRD_spawn_issue_addr_o
    , input logic  WrRD_validReq_3_i,// ISAX
    
    input logic  RdMem_addr_valid_3_i,// ISAX
    
    output logic  RdFlush_1_o,// ISAX
    
    output logic  RdFlush_3_o,// ISAX
    
    output logic  RdFlush_2_o,// ISAX
    
    output logic [32 -1 : 0] RdRD_2_o,// ISAX
    
    input logic [32 -1 : 0] WrRD_3_i,// ISAX
    
    output logic  RdStall_1_o,// ISAX
    
    output logic  RdStall_2_o,// ISAX
    
    output logic  RdStall_3_o,// ISAX
    
    output logic [32 -1 : 0] RdInstr_1_o,// ISAX
    
    output logic [32 -1 : 0] RdInstr_2_o,// ISAX
    
    output logic [32 -1 : 0] RdInstr_3_o,// ISAX
    
    input logic  RdMem_validReq_3_i,// ISAX
    
    output logic [32 -1 : 0] RdRS1_3_o,// ISAX
    
    output logic [32 -1 : 0] RdRS1_2_o,// ISAX
    
    output logic [32 -1 : 0] RdRS2_2_o,// ISAX
    
    output logic [32 -1 : 0] RdRS2_3_o,// ISAX
    
    output logic [32 -1 : 0] RdMem_3_o,// ISAX
    
    input logic [32 -1 : 0] RdMem_addr_3_i,// ISAX
    
    output logic  RdInStageValid_1_o,// ISAX
    
    output logic  RdInStageValid_2_o,// ISAX
    
    output logic  RdInStageValid_3_o,// ISAX
    
    input logic [3 -1 : 0] RdMem_size_3_i,// ISAX
    
    input logic  RdIValid_CUSTOM17_2_i,// ISAX
    
    input logic  RdAnyValid_CUSTOM17_3_i,// ISAX
    
    input logic  RdIValid_CUSTOM78_2_i,// ISAX
    
    input logic  RdAnyValid_CUSTOM78_3_i,// ISAX
    
    input logic  RdIValid_CUSTOM44_2_i,// ISAX
    
    input logic  RdAnyValid_CUSTOM44_3_i,// ISAX
    
    input logic  RdIValid_CUSTOM43_2_i,// ISAX
    
    input logic  RdAnyValid_CUSTOM43_3_i,// ISAX
    
    input logic  RdIValid_CUSTOM76_2_i,// ISAX
    
    input logic  RdAnyValid_CUSTOM76_3_i,// ISAX
    
    input logic  RdIValid_CUSTOM53_1_i,// ISAX
    
    input logic  RdIValid_CUSTOM52_1_i,// ISAX
    
    input logic  RdIValid_CUSTOM51_1_i,// ISAX
    
    input logic  RdIValid_CUSTOM50_1_i,// ISAX
    
    input logic  RdIValid_CUSTOM59_1_i,// ISAX
    
    input logic  RdIValid_CUSTOM58_1_i,// ISAX
    
    input logic  RdIValid_CUSTOM57_1_i,// ISAX
    
    input logic  RdIValid_CUSTOM56_1_i,// ISAX
    
    input logic  RdIValid_CUSTOM55_1_i,// ISAX
    
    input logic  RdIValid_CUSTOM54_1_i,// ISAX
    
    input logic  RdIValid_CUSTOM115_1_i,// ISAX
    
    input logic  RdIValid_CUSTOM113_1_i,// ISAX
    
    input logic  RdIValid_CUSTOM114_1_i,// ISAX
    
    input logic  RdIValid_CUSTOM111_1_i,// ISAX
    
    input logic  RdIValid_CUSTOM112_1_i,// ISAX
    
    input logic  RdIValid_CUSTOM64_1_i,// ISAX
    
    input logic  RdIValid_CUSTOM63_1_i,// ISAX
    
    input logic  RdIValid_CUSTOM62_1_i,// ISAX
    
    input logic  RdIValid_CUSTOM61_1_i,// ISAX
    
    input logic  RdIValid_CUSTOM60_1_i,// ISAX
    
    input logic  RdIValid_CUSTOM69_1_i,// ISAX
    
    input logic  RdIValid_CUSTOM68_1_i,// ISAX
    
    input logic  RdIValid_CUSTOM67_1_i,// ISAX
    
    input logic  RdIValid_CUSTOM66_1_i,// ISAX
    
    input logic  RdIValid_CUSTOM65_1_i,// ISAX
    
    input logic  RdIValid_CUSTOM31_1_i,// ISAX
    
    input logic  RdIValid_CUSTOM30_1_i,// ISAX
    
    input logic  RdIValid_CUSTOM39_1_i,// ISAX
    
    input logic  RdIValid_CUSTOM38_1_i,// ISAX
    
    input logic  RdIValid_CUSTOM37_1_i,// ISAX
    
    input logic  RdIValid_CUSTOM36_1_i,// ISAX
    
    input logic  RdIValid_CUSTOM35_1_i,// ISAX
    
    input logic  RdIValid_CUSTOM34_1_i,// ISAX
    
    input logic  RdIValid_CUSTOM33_1_i,// ISAX
    
    input logic  RdIValid_CUSTOM32_1_i,// ISAX
    
    input logic  RdIValid_CUSTOM42_1_i,// ISAX
    
    input logic  RdIValid_CUSTOM41_1_i,// ISAX
    
    input logic  RdIValid_CUSTOM40_1_i,// ISAX
    
    input logic  RdIValid_CUSTOM49_1_i,// ISAX
    
    input logic  RdIValid_CUSTOM48_1_i,// ISAX
    
    input logic  RdIValid_CUSTOM47_1_i,// ISAX
    
    input logic  RdIValid_CUSTOM46_1_i,// ISAX
    
    input logic  RdIValid_CUSTOM45_1_i,// ISAX
    
    input logic  RdIValid_CUSTOM44_1_i,// ISAX
    
    input logic  RdIValid_CUSTOM43_1_i,// ISAX
    
    input logic  RdIValid_CUSTOM97_1_i,// ISAX
    
    input logic  RdIValid_CUSTOM96_1_i,// ISAX
    
    input logic  RdIValid_CUSTOM95_1_i,// ISAX
    
    input logic  RdIValid_CUSTOM94_1_i,// ISAX
    
    input logic  RdIValid_CUSTOM93_1_i,// ISAX
    
    input logic  RdIValid_CUSTOM92_1_i,// ISAX
    
    input logic  RdIValid_CUSTOM91_1_i,// ISAX
    
    input logic  RdIValid_CUSTOM90_1_i,// ISAX
    
    input logic  RdIValid_CUSTOM17_1_i,// ISAX
    
    input logic  RdIValid_CUSTOM16_1_i,// ISAX
    
    input logic  RdIValid_CUSTOM15_1_i,// ISAX
    
    input logic  RdIValid_CUSTOM14_1_i,// ISAX
    
    input logic  RdIValid_CUSTOM13_1_i,// ISAX
    
    input logic  RdIValid_CUSTOM12_1_i,// ISAX
    
    input logic  RdIValid_CUSTOM11_1_i,// ISAX
    
    input logic  RdIValid_CUSTOM99_1_i,// ISAX
    
    input logic  RdIValid_CUSTOM10_1_i,// ISAX
    
    input logic  RdIValid_CUSTOM98_1_i,// ISAX
    
    input logic  RdIValid_CUSTOM19_1_i,// ISAX
    
    input logic  RdIValid_CUSTOM18_1_i,// ISAX
    
    input logic  RdIValid_CUSTOM20_1_i,// ISAX
    
    input logic  RdIValid_CUSTOM28_1_i,// ISAX
    
    input logic  RdIValid_CUSTOM27_1_i,// ISAX
    
    input logic  RdIValid_CUSTOM26_1_i,// ISAX
    
    input logic  RdIValid_CUSTOM25_1_i,// ISAX
    
    input logic  RdIValid_CUSTOM24_1_i,// ISAX
    
    input logic  RdIValid_CUSTOM23_1_i,// ISAX
    
    input logic  RdIValid_CUSTOM22_1_i,// ISAX
    
    input logic  RdIValid_CUSTOM21_1_i,// ISAX
    
    input logic  RdIValid_CUSTOM29_1_i,// ISAX
    
    input logic  RdIValid_CUSTOM106_1_i,// ISAX
    
    input logic  RdIValid_CUSTOM107_1_i,// ISAX
    
    input logic  RdIValid_CUSTOM104_1_i,// ISAX
    
    input logic  RdIValid_CUSTOM105_1_i,// ISAX
    
    input logic  RdIValid_CUSTOM102_1_i,// ISAX
    
    input logic  RdIValid_CUSTOM103_1_i,// ISAX
    
    input logic  RdIValid_CUSTOM100_1_i,// ISAX
    
    input logic  RdIValid_CUSTOM101_1_i,// ISAX
    
    input logic  RdIValid_CUSTOM75_1_i,// ISAX
    
    input logic  RdIValid_CUSTOM74_1_i,// ISAX
    
    input logic  RdIValid_CUSTOM73_1_i,// ISAX
    
    input logic  RdIValid_CUSTOM72_1_i,// ISAX
    
    input logic  RdIValid_CUSTOM71_1_i,// ISAX
    
    input logic  RdIValid_CUSTOM70_1_i,// ISAX
    
    input logic  RdIValid_CUSTOM108_1_i,// ISAX
    
    input logic  RdIValid_CUSTOM109_1_i,// ISAX
    
    input logic  RdIValid_CUSTOM79_1_i,// ISAX
    
    input logic  RdIValid_CUSTOM78_1_i,// ISAX
    
    input logic  RdIValid_CUSTOM77_1_i,// ISAX
    
    input logic  RdIValid_CUSTOM76_1_i,// ISAX
    
    input logic  RdIValid_CUSTOM0_1_i,// ISAX
    
    input logic  RdIValid_CUSTOM110_1_i,// ISAX
    
    input logic  RdIValid_CUSTOM7_1_i,// ISAX
    
    input logic  RdIValid_CUSTOM8_1_i,// ISAX
    
    input logic  RdIValid_CUSTOM5_1_i,// ISAX
    
    input logic  RdIValid_CUSTOM6_1_i,// ISAX
    
    input logic  RdIValid_CUSTOM3_1_i,// ISAX
    
    input logic  RdIValid_CUSTOM4_1_i,// ISAX
    
    input logic  RdIValid_CUSTOM1_1_i,// ISAX
    
    input logic  RdIValid_CUSTOM2_1_i,// ISAX
    
    input logic  RdIValid_CUSTOM86_1_i,// ISAX
    
    input logic  RdIValid_CUSTOM85_1_i,// ISAX
    
    input logic  RdIValid_CUSTOM84_1_i,// ISAX
    
    input logic  RdIValid_CUSTOM83_1_i,// ISAX
    
    input logic  RdIValid_CUSTOM82_1_i,// ISAX
    
    input logic  RdIValid_CUSTOM81_1_i,// ISAX
    
    input logic  RdIValid_CUSTOM9_1_i,// ISAX
    
    input logic  RdIValid_CUSTOM80_1_i,// ISAX
    
    input logic  RdIValid_CUSTOM89_1_i,// ISAX
    
    input logic  RdIValid_CUSTOM88_1_i,// ISAX
    
    input logic  RdIValid_CUSTOM87_1_i,// ISAX
    
    output logic  RdPipeInto_stage_executesv1_2_o,// ISAX
    
    output logic  RdPipeInto_stage_executecva_2_o,// ISAX
    
    output logic  glueToSCAL_IValid_cond_all_1_o,// ISAX
    
    output logic  glueToSCAL_IValid_cond_all_2_o,// ISAX
    
    output logic  glueToSCAL_IValid_cond_all_3_o,// ISAX
    
    output logic [13 -1 : 0] glueToSCAL_WrRD_spawn_addr_2_o,// ISAX
    
    output logic [13 -1 : 0] glueToSCAL_WrRD_spawn_addr_1_o// ISAX
    
    );
    logic decode_wrReg_hold;
    logic decode_rdReg_RD;
    logic decode_isRepeated_RdRD;
    logic issue_isFirst_RdRD;
    logic execute_isFirst_RdRD;
    logic issue_stall_before_mem;
    logic execute_stall_mem;
    logic mem_current_request_waiting;
    logic mem_read_pending;
    logic set_mem_read_pending;
    logic mem_read_regular_pending;
    logic set_mem_read_regular_pending;
    logic fetch_wrPCValid_r;
    logic [31:0] fetch_wrPC_r;
    logic issue_stall_before_cf;
    logic wrPC_after_fetch_valid;
    logic [31:0] wrPC_after_fetch;

    logic hazard_unit_scaiev_decode_stall_set;

    //Indicates if an ISAX instruction has entered decode and is not overridden.
    wire decode_valid_regular = scaiev.decode_valid && !(scaiev.decode_wrReg || scaiev.decode_rdReg);

    //Condition 'is ISAX that will use scaiev.decode_wrReg', to be set correctly by SCAIE-V.
    wire decode_is_isax_decoupled_wb = 0;
    //Condition 'is ISAX that will use scaiev.rf_wrReg in Issue and not flushed/stalled', to be set correctly by SCAIE-V.
    wire issue_is_isax_decoupled_wb = !scaiev.issue_isStalling && !scaiev.issue_stall && (0);
    //Condition 'unlock all registers' (e.g. 'all WrRD_spawn ISAXes killed').
    wire unlock_all_registers = 0;
    //Condition 'inject-based writeback cancelled' (only unlock, don't write)
    logic decode_wrReg_cancel;

    generate if (ENABLE_SCAIEV_REGHAZARD) begin
        
        logic [4:0] rd_last_locked;
        logic rd_inuse_bitmap [32];
        always_ff @(posedge clk) begin
            if (scaiev.issue_isFlushing && rd_last_locked != '0) begin
                //Unlock register that was locked speculatively.
                rd_inuse_bitmap[rd_last_locked] <= 0;
            end
            if (scaiev.issue_isFlushing || scaiev.issue_valid && !scaiev.issue_stall && !scaiev.issue_isStalling) begin
                //Reset speculative lock register ID, as the corresponding decoupled instruction can no longer be flushed.
                rd_last_locked <= '0;
            end
            if (rst || unlock_all_registers) begin
                //Unlock all registers.
                for (int i = 0; i < 32; i=i+1)
                    rd_inuse_bitmap[i] <= 0;
            end
            else if (decode_valid_regular && decode_is_isax_decoupled_wb && scaiev.decode_RD_id != '0
                && !scaiev.decode_stall && !scaiev.decode_flush && !scaiev.decode_isStalling && !scaiev.decode_isFlushing) begin
                //Lock register (speculatively).
                //-> The check for !scaiev.decode_stall ensures that !rd_conflict, i.e. RD is not locked already.
                rd_inuse_bitmap[scaiev.decode_RD_id] <= '1;
                rd_last_locked <= scaiev.decode_RD_id;
            end
            else if ((scaiev.decode_wrReg && !scaiev.decode_stall || decode_wrReg_cancel) && scaiev.decode_wrReg_RD != '0 ) begin
                //Unlock register.
                rd_inuse_bitmap[scaiev.decode_wrReg_RD] <= 0;
            end
        end

        logic rs1_conflict;
        logic rs2_conflict;
        logic rd_as_rs_conflict;
        logic rd_conflict;

        always_comb begin
            rs1_conflict = scaiev.decode_RS1_valid && rd_inuse_bitmap[scaiev.decode_RS1_id]; //Read-after-Write
            rs2_conflict = scaiev.decode_RS2_valid && rd_inuse_bitmap[scaiev.decode_RS2_id]; //Read-after-Write
            rd_as_rs_conflict = scaiev.decode_RD_AS_RS_valid && rd_inuse_bitmap[scaiev.decode_RD_AS_RS_id]; //Read-after-Write
            rd_conflict  = scaiev.decode_RD_valid  && rd_inuse_bitmap[scaiev.decode_RD_id];  //Write-after-Write
            hazard_unit_scaiev_decode_stall_set = decode_valid_regular && (rs1_conflict || rs2_conflict || rd_as_rs_conflict || rd_conflict);
        end
    end
    else begin //!ENABLE_SCAIEV_REGHAZARD
        assign hazard_unit_scaiev_decode_stall_set = 0;
    end endgenerate

    logic explicit_free_reg;
    logic [5:0] explicit_free_reg_addr;

    generate if (ENABLE_DECOUPLED_WRITEBACK && ENABLE_DECOUPLED_WRITEBACK_WAW) begin
        //TODO: isaxkill behaviour
        // -> Instead of plainly zeroing the inuse flag here, also need to free the register in CVA5!
        // -> Need to send a kill command to each ISAX (which interface?)
        // -> Stall isaxkill in Issue until all ISAXes are killed

        //Logic to prevent certain kind of WaW hazard: premature deallocation of decoupled instruction's destination register.
        //-> Later instruction that overrides physical register could finish sooner and free a register that still is to be written to.

        //Indicates whether some ISAX will write the respective physical register.
        //While set, prevent retiring instructions from adding the register to the free FIFO.
        logic [63:0] phys_inuse_by_isax;
        //Indicates whether a logical destination register was prevented from being freed,
        // and still has to be freed by the ISAX on retirement (in addition to the previous register).
        logic [63:0] phys_should_be_freed_by_isax;

        always_ff @(posedge clk) begin
            scaiev.renamer_addtofree_skip = 0;
            if (rst || unlock_all_registers) begin
                explicit_free_reg <= 0;
                explicit_free_reg_addr <= 'X;
                phys_inuse_by_isax <= '0;
                phys_should_be_freed_by_isax <= '0;
            end
            else begin : waw_logic_scope
                logic [63:0] next_phys_inuse_by_isax;
                logic [63:0] next_phys_should_be_freed_by_isax;
                next_phys_inuse_by_isax = phys_inuse_by_isax;
                next_phys_should_be_freed_by_isax = phys_should_be_freed_by_isax;
                
                explicit_free_reg <= explicit_free_reg && !scaiev.rf_ready;
                if (scaiev.rf_wrReg) begin
                    next_phys_inuse_by_isax[scaiev.rf_wrReg_phys_RD] = 1'b0; //Write port A2
                    next_phys_should_be_freed_by_isax[scaiev.rf_wrReg_phys_RD] = 1'b0; //Write port B2
                    if (!scaiev.rf_wrReg_cancel && phys_should_be_freed_by_isax[scaiev.rf_wrReg_phys_RD]) begin //Read port B1
                        // -> Inject register free for scaiev.rf_wrReg_phys_RD (e.g. repeat identical writeback next cycle)
                        explicit_free_reg <= 1;
                        explicit_free_reg_addr <= scaiev.rf_wrReg_phys_RD;
                    end
                end
                
                if (issue_is_isax_decoupled_wb) begin
                    next_phys_inuse_by_isax[scaiev.issue_phys_RD_decoupled] = 1'b1; //Write port A1
                end
                if (phys_inuse_by_isax[scaiev.renamer_addtofree_reg] == 1'b1) begin //Read port A1
                    scaiev.renamer_addtofree_skip = 1'b1;
                    if (scaiev.renamer_addtofree_valid)
                        next_phys_should_be_freed_by_isax[scaiev.renamer_addtofree_reg] = 1'b1; //Write port B1
                end
                phys_inuse_by_isax <= next_phys_inuse_by_isax;
                phys_should_be_freed_by_isax <= next_phys_should_be_freed_by_isax;
            end
        end

    end
    else begin // !(ENABLE_DECOUPLED_WRITEBACK && ENABLE_DECOUPLED_WRITEBACK_WAW)
        assign explicit_free_reg = 0;
        assign explicit_free_reg_addr = '0;
    end endgenerate
    assign WrRD_spawn_issue_addr_o = {scaiev.issue_prev_phys_RD_decoupled, scaiev.issue_phys_RD_decoupled};

    

wire ISAX_wrPCValid_0_s = 0;
wire ISAX_wrPCValid_1_s = 0;
wire ISAX_wrPCValid_2_s = 0;
wire ISAX_wrPCValid_3_s = 0;
assign RdFlush_1_o = scaiev.decode_isFlushing_internal;

assign RdFlush_3_o = 0;

assign RdFlush_2_o = scaiev.issue_isFlushing_internal;

assign RdRD_2_o = scaiev.issue_RD_AS_RS;

assign RdStall_1_o = scaiev.decode_isStalling || hazard_unit_scaiev_decode_stall_set || (decode_rdReg_RD && !decode_isRepeated_RdRD);

assign RdStall_2_o = scaiev.issue_isStalling || scaiev.issue_injectLS_potentiallyValid || scaiev.execute_injectLS_potentiallyValid || issue_stall_before_mem || issue_stall_before_cf || issue_isFirst_RdRD;

assign RdStall_3_o = scaiev.execute_isStalling_reason_core || execute_stall_mem || execute_isFirst_RdRD;

assign RdInstr_1_o = scaiev.decode_Instr;

assign RdInstr_2_o = scaiev.issue_Instr;

assign RdInstr_3_o = scaiev.execute_Instr;

assign RdRS1_3_o = scaiev.execute_RS1;

assign RdRS1_2_o = scaiev.issue_RS1;

assign RdRS2_2_o = scaiev.issue_RS2;

assign RdRS2_3_o = scaiev.execute_RS2;

assign RdInStageValid_1_o = scaiev.decode_valid;

assign RdInStageValid_2_o = scaiev.issue_valid;

assign RdInStageValid_3_o = scaiev.execute_valid;

assign scaiev.decode_isSCAIEV = RdIValid_CUSTOM53_1_i || RdIValid_CUSTOM52_1_i || RdIValid_CUSTOM51_1_i || RdIValid_CUSTOM50_1_i || RdIValid_CUSTOM59_1_i || RdIValid_CUSTOM58_1_i || RdIValid_CUSTOM57_1_i || RdIValid_CUSTOM56_1_i || RdIValid_CUSTOM55_1_i || RdIValid_CUSTOM54_1_i || RdIValid_CUSTOM115_1_i || RdIValid_CUSTOM113_1_i || RdIValid_CUSTOM114_1_i || RdIValid_CUSTOM111_1_i || RdIValid_CUSTOM112_1_i || RdIValid_CUSTOM64_1_i || RdIValid_CUSTOM63_1_i || RdIValid_CUSTOM62_1_i || RdIValid_CUSTOM61_1_i || RdIValid_CUSTOM60_1_i || RdIValid_CUSTOM69_1_i || RdIValid_CUSTOM68_1_i || RdIValid_CUSTOM67_1_i || RdIValid_CUSTOM66_1_i || RdIValid_CUSTOM65_1_i || RdIValid_CUSTOM31_1_i || RdIValid_CUSTOM30_1_i || RdIValid_CUSTOM39_1_i || RdIValid_CUSTOM38_1_i || RdIValid_CUSTOM37_1_i || RdIValid_CUSTOM36_1_i || RdIValid_CUSTOM35_1_i || RdIValid_CUSTOM34_1_i || RdIValid_CUSTOM33_1_i || RdIValid_CUSTOM32_1_i || RdIValid_CUSTOM42_1_i || RdIValid_CUSTOM41_1_i || RdIValid_CUSTOM40_1_i || RdIValid_CUSTOM49_1_i || RdIValid_CUSTOM48_1_i || RdIValid_CUSTOM47_1_i || RdIValid_CUSTOM46_1_i || RdIValid_CUSTOM45_1_i || RdIValid_CUSTOM44_1_i || RdIValid_CUSTOM43_1_i || RdIValid_CUSTOM97_1_i || RdIValid_CUSTOM96_1_i || RdIValid_CUSTOM95_1_i || RdIValid_CUSTOM94_1_i || RdIValid_CUSTOM93_1_i || RdIValid_CUSTOM92_1_i || RdIValid_CUSTOM91_1_i || RdIValid_CUSTOM90_1_i || RdIValid_CUSTOM17_1_i || RdIValid_CUSTOM16_1_i || RdIValid_CUSTOM15_1_i || RdIValid_CUSTOM14_1_i || RdIValid_CUSTOM13_1_i || RdIValid_CUSTOM12_1_i || RdIValid_CUSTOM11_1_i || RdIValid_CUSTOM99_1_i || RdIValid_CUSTOM10_1_i || RdIValid_CUSTOM98_1_i || RdIValid_CUSTOM19_1_i || RdIValid_CUSTOM18_1_i || RdIValid_CUSTOM20_1_i || RdIValid_CUSTOM28_1_i || RdIValid_CUSTOM27_1_i || RdIValid_CUSTOM26_1_i || RdIValid_CUSTOM25_1_i || RdIValid_CUSTOM24_1_i || RdIValid_CUSTOM23_1_i || RdIValid_CUSTOM22_1_i || RdIValid_CUSTOM21_1_i || RdIValid_CUSTOM29_1_i || RdIValid_CUSTOM106_1_i || RdIValid_CUSTOM107_1_i || RdIValid_CUSTOM104_1_i || RdIValid_CUSTOM105_1_i || RdIValid_CUSTOM102_1_i || RdIValid_CUSTOM103_1_i || RdIValid_CUSTOM100_1_i || RdIValid_CUSTOM101_1_i || RdIValid_CUSTOM75_1_i || RdIValid_CUSTOM74_1_i || RdIValid_CUSTOM73_1_i || RdIValid_CUSTOM72_1_i || RdIValid_CUSTOM71_1_i || RdIValid_CUSTOM70_1_i || RdIValid_CUSTOM108_1_i || RdIValid_CUSTOM109_1_i || RdIValid_CUSTOM79_1_i || RdIValid_CUSTOM78_1_i || RdIValid_CUSTOM77_1_i || RdIValid_CUSTOM76_1_i || RdIValid_CUSTOM0_1_i || RdIValid_CUSTOM110_1_i || RdIValid_CUSTOM7_1_i || RdIValid_CUSTOM8_1_i || RdIValid_CUSTOM5_1_i || RdIValid_CUSTOM6_1_i || RdIValid_CUSTOM3_1_i || RdIValid_CUSTOM4_1_i || RdIValid_CUSTOM1_1_i || RdIValid_CUSTOM2_1_i || RdIValid_CUSTOM86_1_i || RdIValid_CUSTOM85_1_i || RdIValid_CUSTOM84_1_i || RdIValid_CUSTOM83_1_i || RdIValid_CUSTOM82_1_i || RdIValid_CUSTOM81_1_i || RdIValid_CUSTOM9_1_i || RdIValid_CUSTOM80_1_i || RdIValid_CUSTOM89_1_i || RdIValid_CUSTOM88_1_i || RdIValid_CUSTOM87_1_i;
assign scaiev.decode_isSCAIEV_stdencoding = 1'b0;
assign scaiev.decode_isSCAIEV_usesRS1 = RdIValid_CUSTOM53_1_i || RdIValid_CUSTOM52_1_i || RdIValid_CUSTOM96_1_i || RdIValid_CUSTOM51_1_i || RdIValid_CUSTOM95_1_i || RdIValid_CUSTOM50_1_i || RdIValid_CUSTOM94_1_i || RdIValid_CUSTOM93_1_i || RdIValid_CUSTOM92_1_i || RdIValid_CUSTOM91_1_i || RdIValid_CUSTOM90_1_i || RdIValid_CUSTOM17_1_i || RdIValid_CUSTOM56_1_i || RdIValid_CUSTOM12_1_i || RdIValid_CUSTOM55_1_i || RdIValid_CUSTOM11_1_i || RdIValid_CUSTOM99_1_i || RdIValid_CUSTOM54_1_i || RdIValid_CUSTOM98_1_i || RdIValid_CUSTOM19_1_i || RdIValid_CUSTOM18_1_i || RdIValid_CUSTOM115_1_i || RdIValid_CUSTOM113_1_i || RdIValid_CUSTOM114_1_i || RdIValid_CUSTOM112_1_i || RdIValid_CUSTOM20_1_i || RdIValid_CUSTOM63_1_i || RdIValid_CUSTOM62_1_i || RdIValid_CUSTOM61_1_i || RdIValid_CUSTOM60_1_i || RdIValid_CUSTOM26_1_i || RdIValid_CUSTOM25_1_i || RdIValid_CUSTOM24_1_i || RdIValid_CUSTOM67_1_i || RdIValid_CUSTOM66_1_i || RdIValid_CUSTOM21_1_i || RdIValid_CUSTOM106_1_i || RdIValid_CUSTOM104_1_i || RdIValid_CUSTOM105_1_i || RdIValid_CUSTOM103_1_i || RdIValid_CUSTOM100_1_i || RdIValid_CUSTOM75_1_i || RdIValid_CUSTOM30_1_i || RdIValid_CUSTOM74_1_i || RdIValid_CUSTOM73_1_i || RdIValid_CUSTOM72_1_i || RdIValid_CUSTOM71_1_i || RdIValid_CUSTOM108_1_i || RdIValid_CUSTOM109_1_i || RdIValid_CUSTOM39_1_i || RdIValid_CUSTOM79_1_i || RdIValid_CUSTOM34_1_i || RdIValid_CUSTOM78_1_i || RdIValid_CUSTOM33_1_i || RdIValid_CUSTOM77_1_i || RdIValid_CUSTOM76_1_i || RdIValid_CUSTOM0_1_i || RdIValid_CUSTOM8_1_i || RdIValid_CUSTOM3_1_i || RdIValid_CUSTOM42_1_i || RdIValid_CUSTOM86_1_i || RdIValid_CUSTOM41_1_i || RdIValid_CUSTOM85_1_i || RdIValid_CUSTOM40_1_i || RdIValid_CUSTOM84_1_i || RdIValid_CUSTOM83_1_i || RdIValid_CUSTOM82_1_i || RdIValid_CUSTOM81_1_i || RdIValid_CUSTOM80_1_i || RdIValid_CUSTOM49_1_i || RdIValid_CUSTOM48_1_i || RdIValid_CUSTOM47_1_i || RdIValid_CUSTOM46_1_i || RdIValid_CUSTOM45_1_i || RdIValid_CUSTOM89_1_i || RdIValid_CUSTOM44_1_i || RdIValid_CUSTOM88_1_i || RdIValid_CUSTOM43_1_i || RdIValid_CUSTOM87_1_i || RdIValid_CUSTOM107_1_i || RdIValid_CUSTOM102_1_i || RdIValid_CUSTOM101_1_i || RdIValid_CUSTOM31_1_i || RdIValid_CUSTOM97_1_i || RdIValid_CUSTOM70_1_i || RdIValid_CUSTOM38_1_i || RdIValid_CUSTOM16_1_i || RdIValid_CUSTOM59_1_i || RdIValid_CUSTOM37_1_i || RdIValid_CUSTOM15_1_i || RdIValid_CUSTOM58_1_i || RdIValid_CUSTOM36_1_i || RdIValid_CUSTOM14_1_i || RdIValid_CUSTOM57_1_i || RdIValid_CUSTOM35_1_i || RdIValid_CUSTOM13_1_i || RdIValid_CUSTOM32_1_i || RdIValid_CUSTOM10_1_i || RdIValid_CUSTOM110_1_i || RdIValid_CUSTOM7_1_i || RdIValid_CUSTOM5_1_i || RdIValid_CUSTOM6_1_i || RdIValid_CUSTOM4_1_i || RdIValid_CUSTOM111_1_i || RdIValid_CUSTOM1_1_i || RdIValid_CUSTOM2_1_i || RdIValid_CUSTOM64_1_i || RdIValid_CUSTOM9_1_i || RdIValid_CUSTOM28_1_i || RdIValid_CUSTOM27_1_i || RdIValid_CUSTOM69_1_i || RdIValid_CUSTOM68_1_i || RdIValid_CUSTOM23_1_i || RdIValid_CUSTOM22_1_i || RdIValid_CUSTOM65_1_i || RdIValid_CUSTOM29_1_i;
assign scaiev.decode_isSCAIEV_usesRS2 = RdIValid_CUSTOM106_1_i || RdIValid_CUSTOM107_1_i || RdIValid_CUSTOM31_1_i || RdIValid_CUSTOM97_1_i || RdIValid_CUSTOM30_1_i || RdIValid_CUSTOM59_1_i || RdIValid_CUSTOM36_1_i || RdIValid_CUSTOM14_1_i || RdIValid_CUSTOM57_1_i || RdIValid_CUSTOM35_1_i || RdIValid_CUSTOM13_1_i || RdIValid_CUSTOM56_1_i || RdIValid_CUSTOM34_1_i || RdIValid_CUSTOM12_1_i || RdIValid_CUSTOM33_1_i || RdIValid_CUSTOM11_1_i || RdIValid_CUSTOM0_1_i || RdIValid_CUSTOM7_1_i || RdIValid_CUSTOM8_1_i || RdIValid_CUSTOM3_1_i || RdIValid_CUSTOM4_1_i || RdIValid_CUSTOM1_1_i || RdIValid_CUSTOM64_1_i || RdIValid_CUSTOM63_1_i || RdIValid_CUSTOM9_1_i || RdIValid_CUSTOM27_1_i || RdIValid_CUSTOM26_1_i || RdIValid_CUSTOM69_1_i || RdIValid_CUSTOM68_1_i || RdIValid_CUSTOM67_1_i || RdIValid_CUSTOM66_1_i || RdIValid_CUSTOM22_1_i || RdIValid_CUSTOM21_1_i || RdIValid_CUSTOM29_1_i || RdIValid_CUSTOM100_1_i || RdIValid_CUSTOM74_1_i || RdIValid_CUSTOM73_1_i || RdIValid_CUSTOM70_1_i || RdIValid_CUSTOM108_1_i || RdIValid_CUSTOM109_1_i || RdIValid_CUSTOM17_1_i || RdIValid_CUSTOM38_1_i || RdIValid_CUSTOM16_1_i || RdIValid_CUSTOM37_1_i || RdIValid_CUSTOM15_1_i || RdIValid_CUSTOM58_1_i || RdIValid_CUSTOM78_1_i || RdIValid_CUSTOM55_1_i || RdIValid_CUSTOM99_1_i || RdIValid_CUSTOM77_1_i || RdIValid_CUSTOM54_1_i || RdIValid_CUSTOM32_1_i || RdIValid_CUSTOM10_1_i || RdIValid_CUSTOM76_1_i || RdIValid_CUSTOM19_1_i || RdIValid_CUSTOM18_1_i || RdIValid_CUSTOM5_1_i || RdIValid_CUSTOM6_1_i || RdIValid_CUSTOM2_1_i || RdIValid_CUSTOM42_1_i || RdIValid_CUSTOM20_1_i || RdIValid_CUSTOM86_1_i || RdIValid_CUSTOM41_1_i || RdIValid_CUSTOM85_1_i || RdIValid_CUSTOM84_1_i || RdIValid_CUSTOM83_1_i || RdIValid_CUSTOM28_1_i || RdIValid_CUSTOM23_1_i || RdIValid_CUSTOM44_1_i || RdIValid_CUSTOM65_1_i || RdIValid_CUSTOM43_1_i;
assign scaiev.decode_isSCAIEV_usesRD_AS_RS = RdIValid_CUSTOM53_1_i || RdIValid_CUSTOM52_1_i || RdIValid_CUSTOM51_1_i || RdIValid_CUSTOM50_1_i || RdIValid_CUSTOM59_1_i || RdIValid_CUSTOM58_1_i || RdIValid_CUSTOM57_1_i || RdIValid_CUSTOM56_1_i || RdIValid_CUSTOM55_1_i || RdIValid_CUSTOM54_1_i || RdIValid_CUSTOM115_1_i || RdIValid_CUSTOM113_1_i || RdIValid_CUSTOM114_1_i || RdIValid_CUSTOM111_1_i || RdIValid_CUSTOM112_1_i || RdIValid_CUSTOM64_1_i || RdIValid_CUSTOM63_1_i || RdIValid_CUSTOM62_1_i || RdIValid_CUSTOM61_1_i || RdIValid_CUSTOM60_1_i || RdIValid_CUSTOM69_1_i || RdIValid_CUSTOM68_1_i || RdIValid_CUSTOM67_1_i || RdIValid_CUSTOM66_1_i || RdIValid_CUSTOM65_1_i || RdIValid_CUSTOM31_1_i || RdIValid_CUSTOM30_1_i || RdIValid_CUSTOM39_1_i || RdIValid_CUSTOM38_1_i || RdIValid_CUSTOM37_1_i || RdIValid_CUSTOM36_1_i || RdIValid_CUSTOM35_1_i || RdIValid_CUSTOM34_1_i || RdIValid_CUSTOM33_1_i || RdIValid_CUSTOM32_1_i || RdIValid_CUSTOM42_1_i || RdIValid_CUSTOM41_1_i || RdIValid_CUSTOM40_1_i || RdIValid_CUSTOM49_1_i || RdIValid_CUSTOM48_1_i || RdIValid_CUSTOM47_1_i || RdIValid_CUSTOM46_1_i || RdIValid_CUSTOM45_1_i || RdIValid_CUSTOM44_1_i || RdIValid_CUSTOM43_1_i || RdIValid_CUSTOM97_1_i || RdIValid_CUSTOM96_1_i || RdIValid_CUSTOM95_1_i || RdIValid_CUSTOM94_1_i || RdIValid_CUSTOM93_1_i || RdIValid_CUSTOM92_1_i || RdIValid_CUSTOM91_1_i || RdIValid_CUSTOM90_1_i || RdIValid_CUSTOM17_1_i || RdIValid_CUSTOM16_1_i || RdIValid_CUSTOM15_1_i || RdIValid_CUSTOM14_1_i || RdIValid_CUSTOM13_1_i || RdIValid_CUSTOM12_1_i || RdIValid_CUSTOM11_1_i || RdIValid_CUSTOM99_1_i || RdIValid_CUSTOM10_1_i || RdIValid_CUSTOM98_1_i || RdIValid_CUSTOM19_1_i || RdIValid_CUSTOM18_1_i || RdIValid_CUSTOM20_1_i || RdIValid_CUSTOM28_1_i || RdIValid_CUSTOM27_1_i || RdIValid_CUSTOM26_1_i || RdIValid_CUSTOM25_1_i || RdIValid_CUSTOM24_1_i || RdIValid_CUSTOM23_1_i || RdIValid_CUSTOM22_1_i || RdIValid_CUSTOM21_1_i || RdIValid_CUSTOM29_1_i || RdIValid_CUSTOM106_1_i || RdIValid_CUSTOM107_1_i || RdIValid_CUSTOM104_1_i || RdIValid_CUSTOM105_1_i || RdIValid_CUSTOM102_1_i || RdIValid_CUSTOM103_1_i || RdIValid_CUSTOM100_1_i || RdIValid_CUSTOM101_1_i || RdIValid_CUSTOM75_1_i || RdIValid_CUSTOM74_1_i || RdIValid_CUSTOM73_1_i || RdIValid_CUSTOM72_1_i || RdIValid_CUSTOM71_1_i || RdIValid_CUSTOM70_1_i || RdIValid_CUSTOM108_1_i || RdIValid_CUSTOM109_1_i || RdIValid_CUSTOM79_1_i || RdIValid_CUSTOM78_1_i || RdIValid_CUSTOM77_1_i || RdIValid_CUSTOM76_1_i || RdIValid_CUSTOM0_1_i || RdIValid_CUSTOM110_1_i || RdIValid_CUSTOM7_1_i || RdIValid_CUSTOM8_1_i || RdIValid_CUSTOM5_1_i || RdIValid_CUSTOM6_1_i || RdIValid_CUSTOM3_1_i || RdIValid_CUSTOM4_1_i || RdIValid_CUSTOM1_1_i || RdIValid_CUSTOM2_1_i || RdIValid_CUSTOM86_1_i || RdIValid_CUSTOM85_1_i || RdIValid_CUSTOM84_1_i || RdIValid_CUSTOM83_1_i || RdIValid_CUSTOM82_1_i || RdIValid_CUSTOM81_1_i || RdIValid_CUSTOM9_1_i || RdIValid_CUSTOM80_1_i || RdIValid_CUSTOM89_1_i || RdIValid_CUSTOM88_1_i || RdIValid_CUSTOM87_1_i;
assign scaiev.decode_isSCAIEV_usesRD = RdIValid_CUSTOM53_1_i || RdIValid_CUSTOM52_1_i || RdIValid_CUSTOM51_1_i || RdIValid_CUSTOM50_1_i || RdIValid_CUSTOM59_1_i || RdIValid_CUSTOM58_1_i || RdIValid_CUSTOM57_1_i || RdIValid_CUSTOM56_1_i || RdIValid_CUSTOM55_1_i || RdIValid_CUSTOM54_1_i || RdIValid_CUSTOM115_1_i || RdIValid_CUSTOM113_1_i || RdIValid_CUSTOM114_1_i || RdIValid_CUSTOM111_1_i || RdIValid_CUSTOM112_1_i || RdIValid_CUSTOM64_1_i || RdIValid_CUSTOM63_1_i || RdIValid_CUSTOM62_1_i || RdIValid_CUSTOM61_1_i || RdIValid_CUSTOM60_1_i || RdIValid_CUSTOM69_1_i || RdIValid_CUSTOM68_1_i || RdIValid_CUSTOM67_1_i || RdIValid_CUSTOM66_1_i || RdIValid_CUSTOM65_1_i || RdIValid_CUSTOM31_1_i || RdIValid_CUSTOM30_1_i || RdIValid_CUSTOM39_1_i || RdIValid_CUSTOM38_1_i || RdIValid_CUSTOM37_1_i || RdIValid_CUSTOM36_1_i || RdIValid_CUSTOM35_1_i || RdIValid_CUSTOM34_1_i || RdIValid_CUSTOM33_1_i || RdIValid_CUSTOM32_1_i || RdIValid_CUSTOM42_1_i || RdIValid_CUSTOM41_1_i || RdIValid_CUSTOM40_1_i || RdIValid_CUSTOM49_1_i || RdIValid_CUSTOM48_1_i || RdIValid_CUSTOM47_1_i || RdIValid_CUSTOM46_1_i || RdIValid_CUSTOM45_1_i || RdIValid_CUSTOM44_1_i || RdIValid_CUSTOM43_1_i || RdIValid_CUSTOM97_1_i || RdIValid_CUSTOM96_1_i || RdIValid_CUSTOM95_1_i || RdIValid_CUSTOM94_1_i || RdIValid_CUSTOM93_1_i || RdIValid_CUSTOM92_1_i || RdIValid_CUSTOM91_1_i || RdIValid_CUSTOM90_1_i || RdIValid_CUSTOM17_1_i || RdIValid_CUSTOM16_1_i || RdIValid_CUSTOM15_1_i || RdIValid_CUSTOM14_1_i || RdIValid_CUSTOM13_1_i || RdIValid_CUSTOM12_1_i || RdIValid_CUSTOM11_1_i || RdIValid_CUSTOM99_1_i || RdIValid_CUSTOM10_1_i || RdIValid_CUSTOM98_1_i || RdIValid_CUSTOM19_1_i || RdIValid_CUSTOM18_1_i || RdIValid_CUSTOM20_1_i || RdIValid_CUSTOM28_1_i || RdIValid_CUSTOM27_1_i || RdIValid_CUSTOM26_1_i || RdIValid_CUSTOM25_1_i || RdIValid_CUSTOM24_1_i || RdIValid_CUSTOM23_1_i || RdIValid_CUSTOM22_1_i || RdIValid_CUSTOM21_1_i || RdIValid_CUSTOM29_1_i || RdIValid_CUSTOM106_1_i || RdIValid_CUSTOM107_1_i || RdIValid_CUSTOM104_1_i || RdIValid_CUSTOM105_1_i || RdIValid_CUSTOM102_1_i || RdIValid_CUSTOM103_1_i || RdIValid_CUSTOM100_1_i || RdIValid_CUSTOM101_1_i || RdIValid_CUSTOM75_1_i || RdIValid_CUSTOM74_1_i || RdIValid_CUSTOM73_1_i || RdIValid_CUSTOM72_1_i || RdIValid_CUSTOM71_1_i || RdIValid_CUSTOM70_1_i || RdIValid_CUSTOM108_1_i || RdIValid_CUSTOM109_1_i || RdIValid_CUSTOM79_1_i || RdIValid_CUSTOM78_1_i || RdIValid_CUSTOM77_1_i || RdIValid_CUSTOM76_1_i || RdIValid_CUSTOM0_1_i || RdIValid_CUSTOM110_1_i || RdIValid_CUSTOM7_1_i || RdIValid_CUSTOM8_1_i || RdIValid_CUSTOM5_1_i || RdIValid_CUSTOM6_1_i || RdIValid_CUSTOM3_1_i || RdIValid_CUSTOM4_1_i || RdIValid_CUSTOM1_1_i || RdIValid_CUSTOM2_1_i || RdIValid_CUSTOM86_1_i || RdIValid_CUSTOM85_1_i || RdIValid_CUSTOM84_1_i || RdIValid_CUSTOM83_1_i || RdIValid_CUSTOM82_1_i || RdIValid_CUSTOM81_1_i || RdIValid_CUSTOM9_1_i || RdIValid_CUSTOM80_1_i || RdIValid_CUSTOM89_1_i || RdIValid_CUSTOM88_1_i || RdIValid_CUSTOM87_1_i;

assign scaiev.decode_isSCAIEV_usesRD_decoupled = 1'b0;

assign glueToSCAL_IValid_cond_all_1_o = scaiev.decode_valid && !scaiev.decode_wrReg && !scaiev.decode_rdReg;
assign glueToSCAL_IValid_cond_all_2_o = scaiev.issue_valid;
assign glueToSCAL_IValid_cond_all_3_o = scaiev.execute_valid;
assign decode_isRepeated_RdRD = 1'b0;
assign decode_rdReg_RD = 1'b0;
assign issue_isFirst_RdRD = 1'b0;
assign execute_isFirst_RdRD = 1'b0;
assign scaiev.decode_repeat_next = 1'b0;
assign scaiev.decode_rdReg = 1'b0;
assign scaiev.decode_rdReg_RS1 = 5'd0;
assign scaiev.decode_rdReg_RS2 = 5'd0;
assign scaiev.decode_skip_wb = 1'b0;
assign scaiev.decode_RS1_override = 1'b0;
assign scaiev.decode_RS2_override = 1'b0;
assign scaiev.decode_RD_AS_RS_override = 1'b0;
assign decode_wrReg_hold = 1'b0;
assign scaiev.fetch_stall = 0;

assign scaiev.decode_stall = hazard_unit_scaiev_decode_stall_set || 0;

assign scaiev.issue_stall = scaiev.issue_injectLS_potentiallyValid || scaiev.execute_injectLS_potentiallyValid || issue_stall_before_mem || issue_stall_before_cf || 0;

assign scaiev.execute_stall = execute_stall_mem || 0;

assign scaiev.execute_flush = 1'b0;

assign scaiev.issue_flush = 1'b0;

assign scaiev.decode_flush = 1'b0;

assign scaiev.fetch_flush = fetch_wrPCValid_r;

always_comb begin
    unique case (1'b1)
        (WrRD_validReq_3_i): begin
            scaiev.execute_wrRD = 1'b1;
            scaiev.execute_wrRD_data = WrRD_3_i;
        end
        default: begin
            scaiev.execute_wrRD = 1'b0;
            scaiev.execute_wrRD_data = 'X;
        end
    endcase
end
assign glueToSCAL_WrRD_spawn_addr_2_o = {scaiev.issue_prev_phys_RD_decoupled, scaiev.issue_phys_RD_decoupled};
assign glueToSCAL_WrRD_spawn_addr_1_o = {scaiev.decode_prev_phys_RD_decoupled, scaiev.decode_phys_RD_decoupled};
always_comb begin
        scaiev.rf_wrReg = 1'b0;
        scaiev.rf_wrReg_cancel = 1'b0;
        scaiev.rf_wrReg_phys_RD = 'X;
        scaiev.rf_wrReg_prev_phys_RD = 'X;
        scaiev.rf_wrReg_data = 'X;
        scaiev.rf_isDecoupledWB = 0;
end
assign scaiev.decode_wrReg = 1'b0;
assign decode_wrReg_cancel = 1'b0;
assign scaiev.decode_wrReg_RD = 5'd0;
assign scaiev.decode_wrReg_data = 32'd0;
always @(posedge clk) begin
	mem_current_request_waiting <= scaiev.execute_injectLS_valid && !scaiev.injectLS_ready;
end
assign issue_stall_before_mem = ((scaiev.issue_isLS || RdIValid_CUSTOM17_2_i || RdIValid_CUSTOM78_2_i || RdIValid_CUSTOM44_2_i || RdIValid_CUSTOM43_2_i || RdIValid_CUSTOM76_2_i) && (RdAnyValid_CUSTOM17_3_i || RdAnyValid_CUSTOM78_3_i || RdAnyValid_CUSTOM44_3_i || RdAnyValid_CUSTOM43_3_i || RdAnyValid_CUSTOM76_3_i)) || 0;
assign execute_stall_mem = ((RdMem_validReq_3_i || (mem_read_pending && !scaiev.execute_injectLS_done) || 0) && (mem_current_request_waiting || 0)) || ((RdMem_validReq_3_i && !mem_read_pending) || (mem_read_pending && !scaiev.execute_injectLS_done)) || 0;
always_ff @(posedge clk) begin
    if (set_mem_read_pending) begin
        mem_read_pending <= 1;
    end
    if (rst || (!set_mem_read_pending && scaiev.execute_injectLS_done)) begin
        mem_read_pending <= 0;
    end
end
assign RdMem_3_o = scaiev.injectLS_readData;
always_comb begin
    set_mem_read_regular_pending = 0;
    if (RdMem_validReq_3_i) begin
        scaiev.execute_injectLS_potentiallyValid = !mem_read_pending;
        scaiev.execute_injectLS_valid = !mem_read_pending;
        scaiev.execute_injectLS_rnw = 1'b1;
        scaiev.execute_injectLS_relaxedOrdering = 1'b0;
        scaiev.execute_injectLS_addr = RdMem_addr_3_i;
        scaiev.execute_injectLS_storeVal = 'X;
        set_mem_read_pending = !mem_read_pending && scaiev.injectLS_ready;
        set_mem_read_regular_pending = set_mem_read_pending;
    end
    else begin
        scaiev.execute_injectLS_potentiallyValid = 1'b0;
        scaiev.execute_injectLS_valid = 1'b0;
        scaiev.execute_injectLS_rnw = 'X;
        scaiev.execute_injectLS_relaxedOrdering = 'X;
        scaiev.execute_injectLS_addr = 'X;
        scaiev.execute_injectLS_storeVal = 'X;
        set_mem_read_pending = 1'b0;
    end
end
assign scaiev.issue_injectLS_potentiallyValid = 1'b0;
assign scaiev.issue_injectLS_valid = 1'b0;
assign scaiev.issue_injectLS_rnw = 1'b0;
assign scaiev.issue_injectLS_relaxedOrdering = 1'b0;
assign scaiev.issue_injectLS_addr = '0;
assign scaiev.issue_injectLS_storeVal = '0;
assign issue_stall_before_cf = 0;
assign fetch_wrPCValid_r = 1'b0;
assign fetch_wrPC_r = 'X;
always_comb begin
    wrPC_after_fetch_valid = fetch_wrPCValid_r;
    wrPC_after_fetch = fetch_wrPC_r;
    scaiev.fetch_wrPCValid = fetch_wrPCValid_r;
    scaiev.fetch_wrPC = fetch_wrPC_r;
end
assign RdPipeInto_stage_executesv1_2_o = scaiev.issue_isSCAIEV;

assign RdPipeInto_stage_executecva_2_o = !scaiev.issue_isSCAIEV;

assign scaiev.execute_deq = 0;
assign scaiev.execute_commitNow = 1'b0;
assign scaiev.execute_commitNow_ID = '0;
assign scaiev.execute_commitNow_expects_rd = 1'b0;
endmodule
