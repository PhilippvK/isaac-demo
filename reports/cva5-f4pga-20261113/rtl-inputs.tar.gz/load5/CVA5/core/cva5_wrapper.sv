/*
 * Copyright © 2022 Carsten Heinz
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

module cva5_wrapper
    import cva5_config::*;
    import l2_config_and_types::*;
    import riscv_types::*;
    import cva5_types::*;
    import scaiev_types::*;
 (
	input logic clk,
	input logic rst,

	output wire [31:0] instruction_bram_addr,
	output wire        instruction_bram_en,
	output wire [3:0]  instruction_bram_we,
	output wire [31:0] instruction_bram_din,
	input  wire [31:0] instruction_bram_dout,

	output wire [31:0] data_bram_addr,
	output wire        data_bram_en,
	output wire [3:0]  data_bram_we,
	output wire [31:0] data_bram_din,
	input  wire [31:0] data_bram_dout,

	// AXI Bus
	// AXI Write Channels
	output wire                            m_axi_awvalid,
	input  wire                            m_axi_awready,
	output wire [5:0]                      m_axi_awid,
	output wire [31:0]                     m_axi_awaddr,
	//~ output wire [3:0]                      m_axi_awregion,
	output wire [7:0]                      m_axi_awlen,
	output wire [2:0]                      m_axi_awsize,
	output wire [1:0]                      m_axi_awburst,
	//~ output wire                            m_axi_awlock,
	output wire [3:0]                      m_axi_awcache,
	//~ output wire [2:0]                      m_axi_awprot,
	//~ output wire [3:0]                      m_axi_awqos,

	output wire                            m_axi_wvalid,
	input  wire                            m_axi_wready,
	output wire [31:0]                     m_axi_wdata,
	output wire [3:0]                      m_axi_wstrb,
	output wire                            m_axi_wlast,

	input  wire                            m_axi_bvalid,
	output wire                            m_axi_bready,
	input  wire [1:0]                      m_axi_bresp,
	input  wire [5:0]                      m_axi_bid,

	// AXI Read Channels
	output wire                            m_axi_arvalid,
	input  wire                            m_axi_arready,
	output wire [5:0]                      m_axi_arid,
	output wire [31:0]                     m_axi_araddr,
	//~ output wire [3:0]                      m_axi_arregion,
	output wire [7:0]                      m_axi_arlen,
	output wire [2:0]                      m_axi_arsize,
	output wire [1:0]                      m_axi_arburst,
	//~ output wire                            m_axi_arlock,
	output wire [3:0]                      m_axi_arcache,
	//~ output wire [2:0]                      m_axi_arprot,
	//~ output wire [3:0]                      m_axi_arqos,

	input  wire                            m_axi_rvalid,
	output wire                            m_axi_rready,
	input  wire [5:0]                      m_axi_rid,
	input  wire [31:0]                     m_axi_rdata,
	input  wire [1:0]                      m_axi_rresp,
	input  wire                            m_axi_rlast,

	// AXI Cache
	// AXI Write Channels
	output wire                            axi_awvalid,
	input  wire                            axi_awready,
	output wire [5:0]                      axi_awid,
	output wire [31:0]                     axi_awaddr,
	//~ output wire [3:0]                      axi_awregion,
	output wire [7:0]                      axi_awlen,
	output wire [2:0]                      axi_awsize,
	output wire [1:0]                      axi_awburst,
	//~ output wire                            axi_awlock,
	output wire [3:0]                      axi_awcache,
	output wire [2:0]                      axi_awprot,
	//~ output wire [3:0]                      axi_awqos,

	output wire                            axi_wvalid,
	input  wire                            axi_wready,
	output wire [31:0]                     axi_wdata,
	output wire [3:0]                      axi_wstrb,
	output wire                            axi_wlast,

	input  wire                            axi_bvalid,
	output wire                            axi_bready,
	input  wire [1:0]                      axi_bresp,
	input  wire [5:0]                      axi_bid,

	// AXI Read Channels
	output wire                            axi_arvalid,
	input  wire                            axi_arready,
	output wire [5:0]                      axi_arid,
	output wire [31:0]                     axi_araddr,
	//~ output wire [3:0]                      axi_arregion,
	output wire [7:0]                      axi_arlen,
	output wire [2:0]                      axi_arsize,
	output wire [1:0]                      axi_arburst,
	//~ output wire                            axi_arlock,
	output wire [3:0]                      axi_arcache,
	output wire [2:0]                      axi_arprot,
	//~ output wire [3:0]                      axi_arqos,

	input  wire                            axi_rvalid,
	output wire                            axi_rready,
	input  wire [5:0]                      axi_rid,
	input  wire [31:0]                     axi_rdata,
	input  wire [1:0]                      axi_rresp,
	input  wire                            axi_rlast,

	input logic timer_interrupt,
	input logic interrupt
, input logic  WrRD_validReq_3_i,// ISAX

input logic  RdMem_addr_valid_3_i,// ISAX

output logic  RdFlush_1_o,// ISAX

output logic  RdFlush_2_o,// ISAX

output logic  RdFlush_3_o,// ISAX

output logic [32 -1 : 0] RdRD_2_o,// ISAX

input logic [32 -1 : 0] WrRD_3_i,// ISAX

output logic  RdStall_1_o,// ISAX

output logic  RdStall_3_o,// ISAX

output logic  RdStall_2_o,// ISAX

output logic [32 -1 : 0] RdInstr_1_o,// ISAX

output logic [32 -1 : 0] RdInstr_3_o,// ISAX

input logic  RdMem_validReq_3_i,// ISAX

output logic [32 -1 : 0] RdRS1_3_o,// ISAX

output logic [32 -1 : 0] RdRS2_3_o,// ISAX

output logic [32 -1 : 0] RdMem_3_o,// ISAX

input logic [32 -1 : 0] RdMem_addr_3_i,// ISAX

output logic  RdInStageValid_1_o,// ISAX

output logic  RdInStageValid_2_o,// ISAX

output logic  RdInStageValid_3_o,// ISAX

input logic [3 -1 : 0] RdMem_size_3_i,// ISAX

input logic  RdIValid_CUSTOM17_2_i,// ISAX

input logic  RdAnyValid_CUSTOM17_3_i,// ISAX

input logic  RdIValid_CUSTOM78_2_i,// ISAX

input logic  RdAnyValid_CUSTOM78_3_i,// ISAX

input logic  RdIValid_CUSTOM44_2_i,// ISAX

input logic  RdAnyValid_CUSTOM44_3_i,// ISAX

input logic  RdIValid_CUSTOM43_2_i,// ISAX

input logic  RdAnyValid_CUSTOM43_3_i,// ISAX

input logic  RdIValid_CUSTOM76_2_i,// ISAX

input logic  RdAnyValid_CUSTOM76_3_i,// ISAX

input logic  RdIValid_CUSTOM17_1_i,// ISAX

input logic  RdIValid_CUSTOM78_1_i,// ISAX

input logic  RdIValid_CUSTOM44_1_i,// ISAX

input logic  RdIValid_CUSTOM43_1_i,// ISAX

input logic  RdIValid_CUSTOM76_1_i,// ISAX

output logic  RdPipeInto_stage_executesv1_2_o,// ISAX

output logic  RdPipeInto_stage_executecva_2_o,// ISAX

output logic  glueToSCAL_IValid_cond_all_1_o,// ISAX

output logic  glueToSCAL_IValid_cond_all_2_o,// ISAX

output logic  glueToSCAL_IValid_cond_all_3_o,// ISAX

output logic [13 -1 : 0] glueToSCAL_WrRD_spawn_addr_2_o,// ISAX

output logic [13 -1 : 0] glueToSCAL_WrRD_spawn_addr_1_o// ISAX

);

local_memory_interface instruction_bram();
assign instruction_bram_addr = {instruction_bram.addr[29:0],2'b0};
assign instruction_bram_en = instruction_bram.en;
assign instruction_bram_we = instruction_bram.be;
assign instruction_bram_din = instruction_bram.data_in;
assign instruction_bram.data_out = instruction_bram_dout;

local_memory_interface data_bram();
assign data_bram_addr = {data_bram.addr[29:0],2'b0};
assign data_bram_en = data_bram.en;
assign data_bram_we = data_bram.be;
assign data_bram_din = data_bram.data_in;
assign data_bram.data_out = data_bram_dout;

axi_interface m_axi();
assign m_axi_awvalid = m_axi.awvalid;
assign m_axi.awready = m_axi_awready;
assign m_axi_awid = m_axi.awid;
assign m_axi_awaddr = m_axi.awaddr;
assign m_axi_awlen = m_axi.awlen;
assign m_axi_awsize = m_axi.awsize;
assign m_axi_awburst = m_axi.awburst;
assign m_axi_awcache = m_axi.awcache;

assign m_axi_wvalid = m_axi.wvalid;
assign m_axi.wready = m_axi_wready;
assign m_axi_wdata = m_axi.wdata;
assign m_axi_wstrb = m_axi.wstrb;
assign m_axi_wlast = m_axi.wlast;

assign m_axi.bvalid = m_axi_bvalid;
assign m_axi_bready = m_axi.bready;
assign m_axi.bresp = m_axi_bresp;
assign m_axi.bid = m_axi_bid;

assign m_axi_arvalid = m_axi.arvalid;
assign m_axi.arready = m_axi_arready;
assign m_axi_arid = m_axi.arid;
assign m_axi_araddr = m_axi.araddr;
assign m_axi_arlen = m_axi.arlen;
assign m_axi_arsize = m_axi.arsize;
assign m_axi_arburst = m_axi.arburst;
assign m_axi_arcache = m_axi.arcache;

assign m_axi.rvalid = m_axi_rvalid;
assign m_axi_rready = m_axi.rready;
assign m_axi.rid = m_axi_rid;
assign m_axi.rdata = m_axi_rdata;
assign m_axi.rresp = m_axi_rresp;
assign m_axi.rlast = m_axi_rlast;

assign axi_awid = 0;

avalon_interface m_avalon();
wishbone_interface dwishbone();
wishbone_interface iwishbone();

l2_requester_interface l2[L2_NUM_PORTS-1:0]();
assign l2[1].request_push = 0;
assign l2[1].wr_data_push = 0;
assign l2[1].inv_ack = l2[1].inv_valid;
assign l2[1].rd_data_ack = l2[1].rd_data_valid;

l2_memory_interface arb_mem();

trace_outputs_t tr;

interrupt_t m_interrupt;
assign m_interrupt.software = 1'b0;
assign m_interrupt.timer = timer_interrupt;
assign m_interrupt.external = interrupt;

scaiev_interface scaiev();

cva5 cva5 (
	.clk(clk),
	.rst(rst),

	.instruction_bram(instruction_bram),
	.data_bram(data_bram),

	.m_axi(m_axi),
	.m_avalon(m_avalon),
	.dwishbone(dwishbone),
	.iwishbone(iwishbone),
	.l2(l2[0]),
	
	.tr(tr),

	.scaiev(scaiev),

	.s_interrupt(0),
	.m_interrupt(m_interrupt)
);

l2_arbiter l2_arb (
	.clk(clk),
	.rst(rst),
	.request(l2),
	.mem(arb_mem)
);

axi_to_arb l2_to_mem (
	.clk(clk),
	.rst(rst),
	.l2(arb_mem),
	.* // e.g. axi_*
);

scaiev_glue scaiev_glue (
	.clk(clk),
	.rst(rst),
	
	.scaiev(scaiev)
, .WrRD_validReq_3_i ( WrRD_validReq_3_i),

.RdMem_addr_valid_3_i ( RdMem_addr_valid_3_i),

.RdFlush_1_o ( RdFlush_1_o),

.RdFlush_2_o ( RdFlush_2_o),

.RdFlush_3_o ( RdFlush_3_o),

.RdRD_2_o ( RdRD_2_o),

.WrRD_3_i ( WrRD_3_i),

.RdStall_1_o ( RdStall_1_o),

.RdStall_3_o ( RdStall_3_o),

.RdStall_2_o ( RdStall_2_o),

.RdInstr_1_o ( RdInstr_1_o),

.RdInstr_3_o ( RdInstr_3_o),

.RdMem_validReq_3_i ( RdMem_validReq_3_i),

.RdRS1_3_o ( RdRS1_3_o),

.RdRS2_3_o ( RdRS2_3_o),

.RdMem_3_o ( RdMem_3_o),

.RdMem_addr_3_i ( RdMem_addr_3_i),

.RdInStageValid_1_o ( RdInStageValid_1_o),

.RdInStageValid_2_o ( RdInStageValid_2_o),

.RdInStageValid_3_o ( RdInStageValid_3_o),

.RdMem_size_3_i ( RdMem_size_3_i),

.RdIValid_CUSTOM17_2_i ( RdIValid_CUSTOM17_2_i),

.RdAnyValid_CUSTOM17_3_i ( RdAnyValid_CUSTOM17_3_i),

.RdIValid_CUSTOM78_2_i ( RdIValid_CUSTOM78_2_i),

.RdAnyValid_CUSTOM78_3_i ( RdAnyValid_CUSTOM78_3_i),

.RdIValid_CUSTOM44_2_i ( RdIValid_CUSTOM44_2_i),

.RdAnyValid_CUSTOM44_3_i ( RdAnyValid_CUSTOM44_3_i),

.RdIValid_CUSTOM43_2_i ( RdIValid_CUSTOM43_2_i),

.RdAnyValid_CUSTOM43_3_i ( RdAnyValid_CUSTOM43_3_i),

.RdIValid_CUSTOM76_2_i ( RdIValid_CUSTOM76_2_i),

.RdAnyValid_CUSTOM76_3_i ( RdAnyValid_CUSTOM76_3_i),

.RdIValid_CUSTOM17_1_i ( RdIValid_CUSTOM17_1_i),

.RdIValid_CUSTOM78_1_i ( RdIValid_CUSTOM78_1_i),

.RdIValid_CUSTOM44_1_i ( RdIValid_CUSTOM44_1_i),

.RdIValid_CUSTOM43_1_i ( RdIValid_CUSTOM43_1_i),

.RdIValid_CUSTOM76_1_i ( RdIValid_CUSTOM76_1_i),

.RdPipeInto_stage_executesv1_2_o ( RdPipeInto_stage_executesv1_2_o),

.RdPipeInto_stage_executecva_2_o ( RdPipeInto_stage_executecva_2_o),

.glueToSCAL_IValid_cond_all_1_o ( glueToSCAL_IValid_cond_all_1_o),

.glueToSCAL_IValid_cond_all_2_o ( glueToSCAL_IValid_cond_all_2_o),

.glueToSCAL_IValid_cond_all_3_o ( glueToSCAL_IValid_cond_all_3_o),

.glueToSCAL_WrRD_spawn_addr_2_o ( glueToSCAL_WrRD_spawn_addr_2_o),

.glueToSCAL_WrRD_spawn_addr_1_o ( glueToSCAL_WrRD_spawn_addr_1_o)

);

endmodule
