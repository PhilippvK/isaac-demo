 

// SystemVerilog file 
 
module SCAL (
    // Interface to the ISAX Module
    
    output [32 -1 : 0] RdMem_3_o,// ISAX
    input  RdMem_validReq_CUSTOM17_3_i,// ISAX
    input [32 -1 : 0] RdMem_addr_CUSTOM17_3_i,// ISAX
    input  RdMem_validReq_CUSTOM78_3_i,// ISAX
    input [32 -1 : 0] RdMem_addr_CUSTOM78_3_i,// ISAX
    input  RdMem_validReq_CUSTOM44_3_i,// ISAX
    input [32 -1 : 0] RdMem_addr_CUSTOM44_3_i,// ISAX
    input  RdMem_validReq_CUSTOM43_3_i,// ISAX
    input [32 -1 : 0] RdMem_addr_CUSTOM43_3_i,// ISAX
    input  RdMem_validReq_CUSTOM76_3_i,// ISAX
    input [32 -1 : 0] RdMem_addr_CUSTOM76_3_i,// ISAX
    output [32 -1 : 0] RdRD_3_o,// ISAX
    input [32 -1 : 0] WrRD_CUSTOM17_3_i,// ISAX
    input [32 -1 : 0] WrRD_CUSTOM78_3_i,// ISAX
    input [32 -1 : 0] WrRD_CUSTOM44_3_i,// ISAX
    input [32 -1 : 0] WrRD_CUSTOM43_3_i,// ISAX
    input [32 -1 : 0] WrRD_CUSTOM76_3_i,// ISAX
    output  RdStall_CUSTOM17_3_o,// ISAX
    output  RdStall_CUSTOM78_3_o,// ISAX
    output  RdStall_CUSTOM44_3_o,// ISAX
    output  RdStall_CUSTOM43_3_o,// ISAX
    output  RdStall_CUSTOM76_3_o,// ISAX
    output [32 -1 : 0] RdInstr_3_o,// ISAX
    output [32 -1 : 0] RdRS1_3_o,// ISAX
    output [32 -1 : 0] RdRS2_3_o,// ISAX
    output  RdIValid_CUSTOM17_1_o,// ISAX
    output  RdIValid_CUSTOM78_1_o,// ISAX
    output  RdIValid_CUSTOM44_1_o,// ISAX
    output  RdIValid_CUSTOM43_1_o,// ISAX
    output  RdIValid_CUSTOM76_1_o,// ISAX
    output  RdIValid_CUSTOM17_3_o,// ISAX
    output  RdIValid_CUSTOM78_3_o,// ISAX
    output  RdIValid_CUSTOM44_3_o,// ISAX
    output  RdIValid_CUSTOM43_3_o,// ISAX
    output  RdIValid_CUSTOM76_3_o,// ISAX

    
    // Interface to the Core
    
    input [32 -1 : 0] RdMem_3_i,// ISAX
    input  RdInStageValid_3_i,// ISAX
    input  RdStall_2_i,// ISAX
    input  RdFlush_3_i,// ISAX
    input  core_RdPipeInto_stage_executesv1_2_i,// ISAX
    input  glueToSCAL_IValid_cond_all_3_i,// ISAX
    input  RdFlush_2_i,// ISAX
    input  RdStall_3_i,// ISAX
    input  RdInStageValid_1_i,// ISAX
    input [32 -1 : 0] RdInstr_1_i,// ISAX
    input  glueToSCAL_IValid_cond_all_1_i,// ISAX
    input  RdInStageValid_2_i,// ISAX
    input  glueToSCAL_IValid_cond_all_2_i,// ISAX
    input  RdFlush_1_i,// ISAX
    input  RdStall_1_i,// ISAX
    output  RdMem_validReq_3_o,// ISAX
    output [32 -1 : 0] RdMem_addr_3_o,// ISAX
    output  RdMem_addr_valid_3_o,// ISAX
    input [32 -1 : 0] RdInstr_3_i,// ISAX
    output [3 -1 : 0] RdMem_size_3_o,// ISAX
    input [32 -1 : 0] RdRD_2_i,// ISAX
    output [32 -1 : 0] WrRD_3_o,// ISAX
    output  WrRD_validReq_3_o,// ISAX
    input [32 -1 : 0] RdRS1_3_i,// ISAX
    input [32 -1 : 0] RdRS2_3_i,// ISAX
    output  core_RdIValid_CUSTOM17_1_o,// ISAX
    output  core_RdIValid_CUSTOM78_1_o,// ISAX
    output  core_RdIValid_CUSTOM44_1_o,// ISAX
    output  core_RdIValid_CUSTOM43_1_o,// ISAX
    output  core_RdIValid_CUSTOM76_1_o,// ISAX
    output  core_RdIValid_CUSTOM17_2_o,// ISAX
    output  core_RdAnyValid_CUSTOM17_3_o,// ISAX
    output  core_RdIValid_CUSTOM78_2_o,// ISAX
    output  core_RdAnyValid_CUSTOM78_3_o,// ISAX
    output  core_RdIValid_CUSTOM44_2_o,// ISAX
    output  core_RdAnyValid_CUSTOM44_3_o,// ISAX
    output  core_RdIValid_CUSTOM43_2_o,// ISAX
    output  core_RdAnyValid_CUSTOM43_3_o,// ISAX
    output  core_RdIValid_CUSTOM76_2_o,// ISAX
    output  core_RdAnyValid_CUSTOM76_3_o,// ISAX
    
    input clk_i,
    input rst_i

    
);
// Declare local signals
//Declarations - RdInStageValidStrategy_RdInStageValid_3(314)
wire RdInStageValid_3_s;
//Declarations - RdInStageValidStrategy_RdInStageValid_1(316)
wire RdInStageValid_1_s;
//Declarations - PipeliningRdIValidStrategy(RdIValid_CUSTOM17_1)(170)
wire RdIValid_CUSTOM17_1_s;
//Declarations - RdInStageValidStrategy_RdInStageValid_2(318)
wire RdInStageValid_2_s;
//Declarations - PipeliningRdIValidStrategy(RdIValid_CUSTOM17_2)(250)
reg  RdIValid_CUSTOM17_2_regpipein;
wire RdIValid_CUSTOM17_2_s;
//Declarations - PipeliningRdIValidStrategy(RdIValid_CUSTOM17_3)(210)
reg  RdIValid_CUSTOM17_3_regpipein;
wire RdIValid_CUSTOM17_3_s;
//Declarations - PipeliningRdIValidStrategy(RdIValid_CUSTOM78_1)(178)
wire RdIValid_CUSTOM78_1_s;
//Declarations - PipeliningRdIValidStrategy(RdIValid_CUSTOM78_2)(258)
reg  RdIValid_CUSTOM78_2_regpipein;
wire RdIValid_CUSTOM78_2_s;
//Declarations - PipeliningRdIValidStrategy(RdIValid_CUSTOM78_3)(218)
reg  RdIValid_CUSTOM78_3_regpipein;
wire RdIValid_CUSTOM78_3_s;
//Declarations - PipeliningRdIValidStrategy(RdIValid_CUSTOM76_1)(202)
wire RdIValid_CUSTOM76_1_s;
//Declarations - PipeliningRdIValidStrategy(RdIValid_CUSTOM76_2)(282)
reg  RdIValid_CUSTOM76_2_regpipein;
wire RdIValid_CUSTOM76_2_s;
//Declarations - PipeliningRdIValidStrategy(RdIValid_CUSTOM76_3)(242)
reg  RdIValid_CUSTOM76_3_regpipein;
wire RdIValid_CUSTOM76_3_s;
//Declarations - PipeliningRdIValidStrategy(RdIValid_CUSTOM43_1)(194)
wire RdIValid_CUSTOM43_1_s;
//Declarations - PipeliningRdIValidStrategy(RdIValid_CUSTOM43_2)(274)
reg  RdIValid_CUSTOM43_2_regpipein;
wire RdIValid_CUSTOM43_2_s;
//Declarations - PipeliningRdIValidStrategy(RdIValid_CUSTOM43_3)(234)
reg  RdIValid_CUSTOM43_3_regpipein;
wire RdIValid_CUSTOM43_3_s;
//Declarations - PipeliningRdIValidStrategy(RdIValid_CUSTOM44_1)(186)
wire RdIValid_CUSTOM44_1_s;
//Declarations - PipeliningRdIValidStrategy(RdIValid_CUSTOM44_2)(266)
reg  RdIValid_CUSTOM44_2_regpipein;
wire RdIValid_CUSTOM44_2_s;
//Declarations - PipeliningRdIValidStrategy(RdIValid_CUSTOM44_3)(226)
reg  RdIValid_CUSTOM44_3_regpipein;
wire RdIValid_CUSTOM44_3_s;
//Declarations - ValidMuxStrategy (RdMem_validReq_3)(293)
reg  RdMem_validReq_3_s;
//Declarations - ValidMuxStrategy (RdMem_addr_3)(294)
reg [ 32 -1 : 0 ] RdMem_addr_3_s;
//Declarations - DefaultValidCancelReqStrategy_RdMem_addr_valid_CUSTOM76_3(392)
wire RdMem_addr_valid_CUSTOM76_3_default_s;
//Declarations - DefaultValidCancelReqStrategy_RdMem_addr_valid_CUSTOM17_3(391)
wire RdMem_addr_valid_CUSTOM17_3_default_s;
//Declarations - DefaultValidCancelReqStrategy_RdMem_addr_valid_CUSTOM44_3(390)
wire RdMem_addr_valid_CUSTOM44_3_default_s;
//Declarations - DefaultValidCancelReqStrategy_RdMem_addr_valid_CUSTOM43_3(389)
wire RdMem_addr_valid_CUSTOM43_3_default_s;
//Declarations - DefaultValidCancelReqStrategy_RdMem_addr_valid_CUSTOM78_3(388)
wire RdMem_addr_valid_CUSTOM78_3_default_s;
//Declarations - ValidMuxStrategy (RdMem_addr_valid_3)(295)
reg  RdMem_addr_valid_3_s;
//Declarations - Triggerable-NodeRegPipelineStrategy||Direct (RdMem_size_3)(387)
wire [3-1:0] RdMem_size_3_default;
//Declarations - ValidMuxStrategy (RdMem_size_3)(296)
reg [ 3 -1 : 0 ] RdMem_size_3_s;
//Declarations - Triggerable-NodeRegPipelineStrategy||Direct (RdRD_3)(305)
reg [ 32 -1 : 0 ] RdRD_3_regpipein;
//Declarations - ValidMuxStrategy (WrRD_3)(297)
reg [ 32 -1 : 0 ] WrRD_3_s;
//Declarations - ValidMuxStrategy (WrRD_validReq_3)(298)
reg  WrRD_validReq_3_s;
//Declarations - StallFlushDeqStrategy (RdStall_CUSTOM17_3)(284)
wire RdStall_CUSTOM17_3_s;
//Declarations - StallFlushDeqStrategy (RdStall_CUSTOM78_3)(286)
wire RdStall_CUSTOM78_3_s;
//Declarations - StallFlushDeqStrategy (RdStall_CUSTOM44_3)(288)
wire RdStall_CUSTOM44_3_s;
//Declarations - StallFlushDeqStrategy (RdStall_CUSTOM43_3)(290)
wire RdStall_CUSTOM43_3_s;
//Declarations - StallFlushDeqStrategy (RdStall_CUSTOM76_3)(292)
wire RdStall_CUSTOM76_3_s;
//Declarations - SpawnRdIValidStrategy_RdAnyValid_CUSTOM17_3(158)
wire RdAnyValid_CUSTOM17_3_internal_s;
//Declarations - SpawnRdIValidStrategy_RdAnyValid_CUSTOM78_3(159)
wire RdAnyValid_CUSTOM78_3_internal_s;
//Declarations - SpawnRdIValidStrategy_RdAnyValid_CUSTOM44_3(160)
wire RdAnyValid_CUSTOM44_3_internal_s;
//Declarations - SpawnRdIValidStrategy_RdAnyValid_CUSTOM43_3(161)
wire RdAnyValid_CUSTOM43_3_internal_s;
//Declarations - SpawnRdIValidStrategy_RdAnyValid_CUSTOM76_3(162)
wire RdAnyValid_CUSTOM76_3_internal_s;


// Logic
//Logic - SCALInputOutputStrategy (RdMem_3)(89)
assign RdMem_3_o = RdMem_3_i;
//Logic - RdInStageValidStrategy_RdInStageValid_3(314)
assign RdInStageValid_3_s = RdInStageValid_3_i;
//Logic - RdInStageValidStrategy_RdInStageValid_1(316)
assign RdInStageValid_1_s = RdInStageValid_1_i;
//Logic - PipeliningRdIValidStrategy(RdIValid_CUSTOM17_1)(170)
assign RdIValid_CUSTOM17_1_s = ((RdInstr_1_i[6 : 0] == 7'b0001011) && (RdInstr_1_i[14 : 12] == 3'b010) && (RdInstr_1_i[31 : 25] == 7'b0111011)) && !RdFlush_1_i && glueToSCAL_IValid_cond_all_1_i && RdInStageValid_1_s;
//Logic - RdInStageValidStrategy_RdInStageValid_2(318)
assign RdInStageValid_2_s = RdInStageValid_2_i;
//Logic - PipeliningRdIValidStrategy(RdIValid_CUSTOM17_2)(250)
always@(posedge clk_i) begin
    if (rst_i)
        RdIValid_CUSTOM17_2_regpipein <= 0;
    else if (!((RdStall_1_i)))
        RdIValid_CUSTOM17_2_regpipein <= ((RdFlush_1_i)) ? 0 : RdIValid_CUSTOM17_1_s;
    else if (!((RdStall_2_i)))
        RdIValid_CUSTOM17_2_regpipein <= 0;
    else if ((RdFlush_2_i))
        RdIValid_CUSTOM17_2_regpipein <= 0;
end
assign RdIValid_CUSTOM17_2_s = RdIValid_CUSTOM17_2_regpipein && !RdFlush_2_i && glueToSCAL_IValid_cond_all_2_i && RdInStageValid_2_s;
//Logic - PipeliningRdIValidStrategy(RdIValid_CUSTOM17_3)(210)
always@(posedge clk_i) begin
    if (rst_i)
        RdIValid_CUSTOM17_3_regpipein <= 0;
    else if (!((RdStall_2_i)) && core_RdPipeInto_stage_executesv1_2_i)
        RdIValid_CUSTOM17_3_regpipein <= ((RdFlush_2_i)) ? 0 : RdIValid_CUSTOM17_2_s;
    else if (!((RdStall_3_i)))
        RdIValid_CUSTOM17_3_regpipein <= 0;
    else if ((RdFlush_3_i))
        RdIValid_CUSTOM17_3_regpipein <= 0;
end
assign RdIValid_CUSTOM17_3_s = RdIValid_CUSTOM17_3_regpipein && !RdFlush_3_i && glueToSCAL_IValid_cond_all_3_i && RdInStageValid_3_s;
//Logic - PipeliningRdIValidStrategy(RdIValid_CUSTOM78_1)(178)
assign RdIValid_CUSTOM78_1_s = ((RdInstr_1_i[6 : 0] == 7'b0001011) && (RdInstr_1_i[14 : 12] == 3'b010) && (RdInstr_1_i[31 : 25] == 7'b0100000)) && !RdFlush_1_i && glueToSCAL_IValid_cond_all_1_i && RdInStageValid_1_s;
//Logic - PipeliningRdIValidStrategy(RdIValid_CUSTOM78_2)(258)
always@(posedge clk_i) begin
    if (rst_i)
        RdIValid_CUSTOM78_2_regpipein <= 0;
    else if (!((RdStall_1_i)))
        RdIValid_CUSTOM78_2_regpipein <= ((RdFlush_1_i)) ? 0 : RdIValid_CUSTOM78_1_s;
    else if (!((RdStall_2_i)))
        RdIValid_CUSTOM78_2_regpipein <= 0;
    else if ((RdFlush_2_i))
        RdIValid_CUSTOM78_2_regpipein <= 0;
end
assign RdIValid_CUSTOM78_2_s = RdIValid_CUSTOM78_2_regpipein && !RdFlush_2_i && glueToSCAL_IValid_cond_all_2_i && RdInStageValid_2_s;
//Logic - PipeliningRdIValidStrategy(RdIValid_CUSTOM78_3)(218)
always@(posedge clk_i) begin
    if (rst_i)
        RdIValid_CUSTOM78_3_regpipein <= 0;
    else if (!((RdStall_2_i)) && core_RdPipeInto_stage_executesv1_2_i)
        RdIValid_CUSTOM78_3_regpipein <= ((RdFlush_2_i)) ? 0 : RdIValid_CUSTOM78_2_s;
    else if (!((RdStall_3_i)))
        RdIValid_CUSTOM78_3_regpipein <= 0;
    else if ((RdFlush_3_i))
        RdIValid_CUSTOM78_3_regpipein <= 0;
end
assign RdIValid_CUSTOM78_3_s = RdIValid_CUSTOM78_3_regpipein && !RdFlush_3_i && glueToSCAL_IValid_cond_all_3_i && RdInStageValid_3_s;
//Logic - PipeliningRdIValidStrategy(RdIValid_CUSTOM76_1)(202)
assign RdIValid_CUSTOM76_1_s = ((RdInstr_1_i[6 : 0] == 7'b0001011) && (RdInstr_1_i[14 : 12] == 3'b010) && (RdInstr_1_i[31 : 25] == 7'b1111111)) && !RdFlush_1_i && glueToSCAL_IValid_cond_all_1_i && RdInStageValid_1_s;
//Logic - PipeliningRdIValidStrategy(RdIValid_CUSTOM76_2)(282)
always@(posedge clk_i) begin
    if (rst_i)
        RdIValid_CUSTOM76_2_regpipein <= 0;
    else if (!((RdStall_1_i)))
        RdIValid_CUSTOM76_2_regpipein <= ((RdFlush_1_i)) ? 0 : RdIValid_CUSTOM76_1_s;
    else if (!((RdStall_2_i)))
        RdIValid_CUSTOM76_2_regpipein <= 0;
    else if ((RdFlush_2_i))
        RdIValid_CUSTOM76_2_regpipein <= 0;
end
assign RdIValid_CUSTOM76_2_s = RdIValid_CUSTOM76_2_regpipein && !RdFlush_2_i && glueToSCAL_IValid_cond_all_2_i && RdInStageValid_2_s;
//Logic - PipeliningRdIValidStrategy(RdIValid_CUSTOM76_3)(242)
always@(posedge clk_i) begin
    if (rst_i)
        RdIValid_CUSTOM76_3_regpipein <= 0;
    else if (!((RdStall_2_i)) && core_RdPipeInto_stage_executesv1_2_i)
        RdIValid_CUSTOM76_3_regpipein <= ((RdFlush_2_i)) ? 0 : RdIValid_CUSTOM76_2_s;
    else if (!((RdStall_3_i)))
        RdIValid_CUSTOM76_3_regpipein <= 0;
    else if ((RdFlush_3_i))
        RdIValid_CUSTOM76_3_regpipein <= 0;
end
assign RdIValid_CUSTOM76_3_s = RdIValid_CUSTOM76_3_regpipein && !RdFlush_3_i && glueToSCAL_IValid_cond_all_3_i && RdInStageValid_3_s;
//Logic - PipeliningRdIValidStrategy(RdIValid_CUSTOM43_1)(194)
assign RdIValid_CUSTOM43_1_s = ((RdInstr_1_i[6 : 0] == 7'b0001011) && (RdInstr_1_i[14 : 12] == 3'b010) && (RdInstr_1_i[31 : 25] == 7'b1111110)) && !RdFlush_1_i && glueToSCAL_IValid_cond_all_1_i && RdInStageValid_1_s;
//Logic - PipeliningRdIValidStrategy(RdIValid_CUSTOM43_2)(274)
always@(posedge clk_i) begin
    if (rst_i)
        RdIValid_CUSTOM43_2_regpipein <= 0;
    else if (!((RdStall_1_i)))
        RdIValid_CUSTOM43_2_regpipein <= ((RdFlush_1_i)) ? 0 : RdIValid_CUSTOM43_1_s;
    else if (!((RdStall_2_i)))
        RdIValid_CUSTOM43_2_regpipein <= 0;
    else if ((RdFlush_2_i))
        RdIValid_CUSTOM43_2_regpipein <= 0;
end
assign RdIValid_CUSTOM43_2_s = RdIValid_CUSTOM43_2_regpipein && !RdFlush_2_i && glueToSCAL_IValid_cond_all_2_i && RdInStageValid_2_s;
//Logic - PipeliningRdIValidStrategy(RdIValid_CUSTOM43_3)(234)
always@(posedge clk_i) begin
    if (rst_i)
        RdIValid_CUSTOM43_3_regpipein <= 0;
    else if (!((RdStall_2_i)) && core_RdPipeInto_stage_executesv1_2_i)
        RdIValid_CUSTOM43_3_regpipein <= ((RdFlush_2_i)) ? 0 : RdIValid_CUSTOM43_2_s;
    else if (!((RdStall_3_i)))
        RdIValid_CUSTOM43_3_regpipein <= 0;
    else if ((RdFlush_3_i))
        RdIValid_CUSTOM43_3_regpipein <= 0;
end
assign RdIValid_CUSTOM43_3_s = RdIValid_CUSTOM43_3_regpipein && !RdFlush_3_i && glueToSCAL_IValid_cond_all_3_i && RdInStageValid_3_s;
//Logic - PipeliningRdIValidStrategy(RdIValid_CUSTOM44_1)(186)
assign RdIValid_CUSTOM44_1_s = ((RdInstr_1_i[6 : 0] == 7'b0001011) && (RdInstr_1_i[14 : 12] == 3'b010) && (RdInstr_1_i[31 : 25] == 7'b1010001)) && !RdFlush_1_i && glueToSCAL_IValid_cond_all_1_i && RdInStageValid_1_s;
//Logic - PipeliningRdIValidStrategy(RdIValid_CUSTOM44_2)(266)
always@(posedge clk_i) begin
    if (rst_i)
        RdIValid_CUSTOM44_2_regpipein <= 0;
    else if (!((RdStall_1_i)))
        RdIValid_CUSTOM44_2_regpipein <= ((RdFlush_1_i)) ? 0 : RdIValid_CUSTOM44_1_s;
    else if (!((RdStall_2_i)))
        RdIValid_CUSTOM44_2_regpipein <= 0;
    else if ((RdFlush_2_i))
        RdIValid_CUSTOM44_2_regpipein <= 0;
end
assign RdIValid_CUSTOM44_2_s = RdIValid_CUSTOM44_2_regpipein && !RdFlush_2_i && glueToSCAL_IValid_cond_all_2_i && RdInStageValid_2_s;
//Logic - PipeliningRdIValidStrategy(RdIValid_CUSTOM44_3)(226)
always@(posedge clk_i) begin
    if (rst_i)
        RdIValid_CUSTOM44_3_regpipein <= 0;
    else if (!((RdStall_2_i)) && core_RdPipeInto_stage_executesv1_2_i)
        RdIValid_CUSTOM44_3_regpipein <= ((RdFlush_2_i)) ? 0 : RdIValid_CUSTOM44_2_s;
    else if (!((RdStall_3_i)))
        RdIValid_CUSTOM44_3_regpipein <= 0;
    else if ((RdFlush_3_i))
        RdIValid_CUSTOM44_3_regpipein <= 0;
end
assign RdIValid_CUSTOM44_3_s = RdIValid_CUSTOM44_3_regpipein && !RdFlush_3_i && glueToSCAL_IValid_cond_all_3_i && RdInStageValid_3_s;
//Logic - ValidMuxStrategy (RdMem_validReq_3)(293)
always_comb begin 
    case(1'b1)
        RdIValid_CUSTOM17_3_s: RdMem_validReq_3_s = RdMem_validReq_CUSTOM17_3_i;
        RdIValid_CUSTOM78_3_s: RdMem_validReq_3_s = RdMem_validReq_CUSTOM78_3_i;
        RdIValid_CUSTOM44_3_s: RdMem_validReq_3_s = RdMem_validReq_CUSTOM44_3_i;
        RdIValid_CUSTOM43_3_s: RdMem_validReq_3_s = RdMem_validReq_CUSTOM43_3_i;
        RdIValid_CUSTOM76_3_s: RdMem_validReq_3_s = RdMem_validReq_CUSTOM76_3_i;
        default: RdMem_validReq_3_s = 0;
    endcase
end
//Logic - SCALInputOutputStrategy (RdMem_validReq_3)(101)
assign RdMem_validReq_3_o = RdMem_validReq_3_s;
//Logic - ValidMuxStrategy (RdMem_addr_3)(294)
always_comb begin 
    case(1'b1)
        RdIValid_CUSTOM17_3_s: RdMem_addr_3_s = RdMem_addr_CUSTOM17_3_i;
        RdIValid_CUSTOM78_3_s: RdMem_addr_3_s = RdMem_addr_CUSTOM78_3_i;
        RdIValid_CUSTOM44_3_s: RdMem_addr_3_s = RdMem_addr_CUSTOM44_3_i;
        RdIValid_CUSTOM43_3_s: RdMem_addr_3_s = RdMem_addr_CUSTOM43_3_i;
        default: RdMem_addr_3_s = RdMem_addr_CUSTOM76_3_i;
    endcase
end
//Logic - SCALInputOutputStrategy (RdMem_addr_3)(102)
assign RdMem_addr_3_o = RdMem_addr_3_s;
//Logic - DefaultValidCancelReqStrategy_RdMem_addr_valid_CUSTOM76_3(392)
assign RdMem_addr_valid_CUSTOM76_3_default_s = RdMem_validReq_CUSTOM76_3_i;
//Logic - DefaultValidCancelReqStrategy_RdMem_addr_valid_CUSTOM17_3(391)
assign RdMem_addr_valid_CUSTOM17_3_default_s = RdMem_validReq_CUSTOM17_3_i;
//Logic - DefaultValidCancelReqStrategy_RdMem_addr_valid_CUSTOM44_3(390)
assign RdMem_addr_valid_CUSTOM44_3_default_s = RdMem_validReq_CUSTOM44_3_i;
//Logic - DefaultValidCancelReqStrategy_RdMem_addr_valid_CUSTOM43_3(389)
assign RdMem_addr_valid_CUSTOM43_3_default_s = RdMem_validReq_CUSTOM43_3_i;
//Logic - DefaultValidCancelReqStrategy_RdMem_addr_valid_CUSTOM78_3(388)
assign RdMem_addr_valid_CUSTOM78_3_default_s = RdMem_validReq_CUSTOM78_3_i;
//Logic - ValidMuxStrategy (RdMem_addr_valid_3)(295)
always_comb begin 
    case(1'b1)
        RdIValid_CUSTOM17_3_s: RdMem_addr_valid_3_s = RdMem_addr_valid_CUSTOM17_3_default_s;
        RdIValid_CUSTOM78_3_s: RdMem_addr_valid_3_s = RdMem_addr_valid_CUSTOM78_3_default_s;
        RdIValid_CUSTOM44_3_s: RdMem_addr_valid_3_s = RdMem_addr_valid_CUSTOM44_3_default_s;
        RdIValid_CUSTOM43_3_s: RdMem_addr_valid_3_s = RdMem_addr_valid_CUSTOM43_3_default_s;
        RdIValid_CUSTOM76_3_s: RdMem_addr_valid_3_s = RdMem_addr_valid_CUSTOM76_3_default_s;
        default: RdMem_addr_valid_3_s = 0;
    endcase
end
//Logic - SCALInputOutputStrategy (RdMem_addr_valid_3)(103)
assign RdMem_addr_valid_3_o = RdMem_addr_valid_3_s;
//Logic - Triggerable-NodeRegPipelineStrategy||Direct (RdMem_size_3)(387)
assign RdMem_size_3_default = RdInstr_3_i[14:12];
//Logic - ValidMuxStrategy (RdMem_size_3)(296)
always_comb begin 
    case(1'b1)
        default: RdMem_size_3_s = RdMem_size_3_default;
    endcase
end
//Logic - SCALInputOutputStrategy (RdMem_size_3)(104)
assign RdMem_size_3_o = RdMem_size_3_s;
//Logic - Triggerable-NodeRegPipelineStrategy||Direct (RdRD_3)(305)
always@(posedge clk_i) begin
    if (rst_i)
        RdRD_3_regpipein <= 0;
    else if (!((RdStall_2_i)) && core_RdPipeInto_stage_executesv1_2_i)
        RdRD_3_regpipein <= RdRD_2_i;
end
//Logic - SCALInputOutputStrategy (RdRD_3)(105)
assign RdRD_3_o = RdRD_3_regpipein;
//Logic - ValidMuxStrategy (WrRD_3)(297)
always_comb begin 
    case(1'b1)
        RdIValid_CUSTOM17_3_s: WrRD_3_s = WrRD_CUSTOM17_3_i;
        RdIValid_CUSTOM78_3_s: WrRD_3_s = WrRD_CUSTOM78_3_i;
        RdIValid_CUSTOM44_3_s: WrRD_3_s = WrRD_CUSTOM44_3_i;
        RdIValid_CUSTOM43_3_s: WrRD_3_s = WrRD_CUSTOM43_3_i;
        default: WrRD_3_s = WrRD_CUSTOM76_3_i;
    endcase
end
//Logic - SCALInputOutputStrategy (WrRD_3)(112)
assign WrRD_3_o = WrRD_3_s;
//Logic - ValidMuxStrategy (WrRD_validReq_3)(298)
always_comb begin 
    case(1'b1)
        RdIValid_CUSTOM17_3_s: WrRD_validReq_3_s = 1;
        RdIValid_CUSTOM78_3_s: WrRD_validReq_3_s = 1;
        RdIValid_CUSTOM44_3_s: WrRD_validReq_3_s = 1;
        RdIValid_CUSTOM43_3_s: WrRD_validReq_3_s = 1;
        RdIValid_CUSTOM76_3_s: WrRD_validReq_3_s = 1;
        default: WrRD_validReq_3_s = 0;
    endcase
end
//Logic - SCALInputOutputStrategy (WrRD_validReq_3)(113)
assign WrRD_validReq_3_o = WrRD_validReq_3_s;
//Logic - StallFlushDeqStrategy (RdStall_CUSTOM17_3)(284)
assign RdStall_CUSTOM17_3_s = (RdStall_3_i);
//Logic - SCALInputOutputStrategy (RdStall_CUSTOM17_3)(114)
assign RdStall_CUSTOM17_3_o = RdStall_CUSTOM17_3_s;
//Logic - StallFlushDeqStrategy (RdStall_CUSTOM78_3)(286)
assign RdStall_CUSTOM78_3_s = (RdStall_3_i);
//Logic - SCALInputOutputStrategy (RdStall_CUSTOM78_3)(115)
assign RdStall_CUSTOM78_3_o = RdStall_CUSTOM78_3_s;
//Logic - StallFlushDeqStrategy (RdStall_CUSTOM44_3)(288)
assign RdStall_CUSTOM44_3_s = (RdStall_3_i);
//Logic - SCALInputOutputStrategy (RdStall_CUSTOM44_3)(116)
assign RdStall_CUSTOM44_3_o = RdStall_CUSTOM44_3_s;
//Logic - StallFlushDeqStrategy (RdStall_CUSTOM43_3)(290)
assign RdStall_CUSTOM43_3_s = (RdStall_3_i);
//Logic - SCALInputOutputStrategy (RdStall_CUSTOM43_3)(117)
assign RdStall_CUSTOM43_3_o = RdStall_CUSTOM43_3_s;
//Logic - StallFlushDeqStrategy (RdStall_CUSTOM76_3)(292)
assign RdStall_CUSTOM76_3_s = (RdStall_3_i);
//Logic - SCALInputOutputStrategy (RdStall_CUSTOM76_3)(118)
assign RdStall_CUSTOM76_3_o = RdStall_CUSTOM76_3_s;
//Logic - SCALInputOutputStrategy (RdInstr_3)(120)
assign RdInstr_3_o = RdInstr_3_i;
//Logic - SCALInputOutputStrategy (RdRS1_3)(122)
assign RdRS1_3_o = RdRS1_3_i;
//Logic - SCALInputOutputStrategy (RdRS2_3)(124)
assign RdRS2_3_o = RdRS2_3_i;
//Logic - SCALInputOutputStrategy (RdIValid_CUSTOM17_1)(126)
assign RdIValid_CUSTOM17_1_o = RdIValid_CUSTOM17_1_s;
//Logic - SCALInputOutputStrategy (RdIValid_CUSTOM17_1)(127)
assign core_RdIValid_CUSTOM17_1_o = RdIValid_CUSTOM17_1_s;
//Logic - SCALInputOutputStrategy (RdIValid_CUSTOM78_1)(128)
assign RdIValid_CUSTOM78_1_o = RdIValid_CUSTOM78_1_s;
//Logic - SCALInputOutputStrategy (RdIValid_CUSTOM78_1)(129)
assign core_RdIValid_CUSTOM78_1_o = RdIValid_CUSTOM78_1_s;
//Logic - SCALInputOutputStrategy (RdIValid_CUSTOM44_1)(130)
assign RdIValid_CUSTOM44_1_o = RdIValid_CUSTOM44_1_s;
//Logic - SCALInputOutputStrategy (RdIValid_CUSTOM44_1)(131)
assign core_RdIValid_CUSTOM44_1_o = RdIValid_CUSTOM44_1_s;
//Logic - SCALInputOutputStrategy (RdIValid_CUSTOM43_1)(132)
assign RdIValid_CUSTOM43_1_o = RdIValid_CUSTOM43_1_s;
//Logic - SCALInputOutputStrategy (RdIValid_CUSTOM43_1)(133)
assign core_RdIValid_CUSTOM43_1_o = RdIValid_CUSTOM43_1_s;
//Logic - SCALInputOutputStrategy (RdIValid_CUSTOM76_1)(134)
assign RdIValid_CUSTOM76_1_o = RdIValid_CUSTOM76_1_s;
//Logic - SCALInputOutputStrategy (RdIValid_CUSTOM76_1)(135)
assign core_RdIValid_CUSTOM76_1_o = RdIValid_CUSTOM76_1_s;
//Logic - SCALInputOutputStrategy (RdIValid_CUSTOM17_3)(136)
assign RdIValid_CUSTOM17_3_o = RdIValid_CUSTOM17_3_s;
//Logic - SCALInputOutputStrategy (RdIValid_CUSTOM78_3)(137)
assign RdIValid_CUSTOM78_3_o = RdIValid_CUSTOM78_3_s;
//Logic - SCALInputOutputStrategy (RdIValid_CUSTOM44_3)(138)
assign RdIValid_CUSTOM44_3_o = RdIValid_CUSTOM44_3_s;
//Logic - SCALInputOutputStrategy (RdIValid_CUSTOM43_3)(139)
assign RdIValid_CUSTOM43_3_o = RdIValid_CUSTOM43_3_s;
//Logic - SCALInputOutputStrategy (RdIValid_CUSTOM76_3)(140)
assign RdIValid_CUSTOM76_3_o = RdIValid_CUSTOM76_3_s;
//Logic - SCALInputOutputStrategy (RdIValid_CUSTOM17_2)(146)
assign core_RdIValid_CUSTOM17_2_o = RdIValid_CUSTOM17_2_s;
//Logic - SpawnRdIValidStrategy_RdAnyValid_CUSTOM17_3(158)
assign RdAnyValid_CUSTOM17_3_internal_s = (RdIValid_CUSTOM17_3_s && RdInStageValid_3_s);
//Logic - SCALInputOutputStrategy (RdAnyValid_CUSTOM17_3)(147)
assign core_RdAnyValid_CUSTOM17_3_o = RdAnyValid_CUSTOM17_3_internal_s;
//Logic - SCALInputOutputStrategy (RdIValid_CUSTOM78_2)(148)
assign core_RdIValid_CUSTOM78_2_o = RdIValid_CUSTOM78_2_s;
//Logic - SpawnRdIValidStrategy_RdAnyValid_CUSTOM78_3(159)
assign RdAnyValid_CUSTOM78_3_internal_s = (RdIValid_CUSTOM78_3_s && RdInStageValid_3_s);
//Logic - SCALInputOutputStrategy (RdAnyValid_CUSTOM78_3)(149)
assign core_RdAnyValid_CUSTOM78_3_o = RdAnyValid_CUSTOM78_3_internal_s;
//Logic - SCALInputOutputStrategy (RdIValid_CUSTOM44_2)(150)
assign core_RdIValid_CUSTOM44_2_o = RdIValid_CUSTOM44_2_s;
//Logic - SpawnRdIValidStrategy_RdAnyValid_CUSTOM44_3(160)
assign RdAnyValid_CUSTOM44_3_internal_s = (RdIValid_CUSTOM44_3_s && RdInStageValid_3_s);
//Logic - SCALInputOutputStrategy (RdAnyValid_CUSTOM44_3)(151)
assign core_RdAnyValid_CUSTOM44_3_o = RdAnyValid_CUSTOM44_3_internal_s;
//Logic - SCALInputOutputStrategy (RdIValid_CUSTOM43_2)(152)
assign core_RdIValid_CUSTOM43_2_o = RdIValid_CUSTOM43_2_s;
//Logic - SpawnRdIValidStrategy_RdAnyValid_CUSTOM43_3(161)
assign RdAnyValid_CUSTOM43_3_internal_s = (RdIValid_CUSTOM43_3_s && RdInStageValid_3_s);
//Logic - SCALInputOutputStrategy (RdAnyValid_CUSTOM43_3)(153)
assign core_RdAnyValid_CUSTOM43_3_o = RdAnyValid_CUSTOM43_3_internal_s;
//Logic - SCALInputOutputStrategy (RdIValid_CUSTOM76_2)(154)
assign core_RdIValid_CUSTOM76_2_o = RdIValid_CUSTOM76_2_s;
//Logic - SpawnRdIValidStrategy_RdAnyValid_CUSTOM76_3(162)
assign RdAnyValid_CUSTOM76_3_internal_s = (RdIValid_CUSTOM76_3_s && RdInStageValid_3_s);
//Logic - SCALInputOutputStrategy (RdAnyValid_CUSTOM76_3)(155)
assign core_RdAnyValid_CUSTOM76_3_o = RdAnyValid_CUSTOM76_3_internal_s;


endmodule





