create_clock -period 50 -waveform {0 25} clk20
create_clock -period 50 -waveform {0 25} clk20_raw
create_clock -period 10 -waveform {0 5} clk_input
