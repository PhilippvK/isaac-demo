module lutram_1w_1r (
	clk,
	waddr,
	raddr,
	ram_write,
	new_ram_data,
	ram_data_out
);
	parameter WIDTH = 32;
	parameter DEPTH = 32;
	input wire clk;
	input wire [$clog2(DEPTH) - 1:0] waddr;
	input wire [$clog2(DEPTH) - 1:0] raddr;
	input wire ram_write;
	input wire [WIDTH - 1:0] new_ram_data;
	output wire [WIDTH - 1:0] ram_data_out;
	(* ram_style = "distributed" *) reg [WIDTH - 1:0] ram [DEPTH - 1:0];
	initial begin : sv2v_autoblock_1
		integer isaac_init;
		for (isaac_init = 0; isaac_init < DEPTH; isaac_init = isaac_init + 1)
			ram[isaac_init] = 1'sb0;
	end
	always @(posedge clk)
		if (ram_write)
			ram[waddr] <= new_ram_data;
	assign ram_data_out = ram[raddr];
endmodule
module lutram_1w_mr (
	clk,
	waddr,
	raddr,
	ram_write,
	new_ram_data,
	ram_data_out
);
	reg _sv2v_0;
	parameter WIDTH = 32;
	parameter DEPTH = 32;
	parameter NUM_READ_PORTS = 2;
	input wire clk;
	input wire [$clog2(DEPTH) - 1:0] waddr;
	input wire [(NUM_READ_PORTS * $clog2(DEPTH)) - 1:0] raddr;
	input wire ram_write;
	input wire [WIDTH - 1:0] new_ram_data;
	output reg [(NUM_READ_PORTS * WIDTH) - 1:0] ram_data_out;
	localparam [31:0] cva5_config_FPGA_VENDOR = 32'd0;
	function automatic [WIDTH - 1:0] sv2v_cast_6B8D6;
		input reg [WIDTH - 1:0] inp;
		sv2v_cast_6B8D6 = inp;
	endfunction
	generate
		if (1) begin : xilinx_gen
			reg [(DEPTH * WIDTH) - 1:0] ram;
			initial ram = {DEPTH {sv2v_cast_6B8D6(0)}};
			always @(posedge clk)
				if (ram_write)
					ram[waddr * WIDTH+:WIDTH] <= new_ram_data;
			always @(*) begin
				if (_sv2v_0)
					;
				begin : sv2v_autoblock_1
					reg signed [31:0] i;
					for (i = 0; i < NUM_READ_PORTS; i = i + 1)
						ram_data_out[((NUM_READ_PORTS - 1) - i) * WIDTH+:WIDTH] = ram[raddr[((NUM_READ_PORTS - 1) - i) * $clog2(DEPTH)+:$clog2(DEPTH)] * WIDTH+:WIDTH];
				end
			end
		end
	endgenerate
	initial _sv2v_0 = 0;
endmodule
module set_clr_reg_with_rst (
	clk,
	rst,
	set,
	clr,
	result
);
	parameter SET_OVER_CLR = 0;
	parameter WIDTH = 16;
	parameter [WIDTH - 1:0] RST_VALUE = 1'sb0;
	input wire clk;
	input wire rst;
	input wire [WIDTH - 1:0] set;
	input wire [WIDTH - 1:0] clr;
	output reg [WIDTH - 1:0] result;
	generate
		if (SET_OVER_CLR) begin : gen_set_over_clear
			always @(posedge clk)
				if (rst)
					result <= RST_VALUE;
				else
					result <= set | (result & ~clr);
		end
		else begin : genblk1
			always @(posedge clk) begin : gen_clear_over_set
				if (rst)
					result <= RST_VALUE;
				else
					result <= (set | result) & ~clr;
			end
		end
	endgenerate
endmodule
module one_hot_to_integer (
	one_hot,
	int_out
);
	reg _sv2v_0;
	parameter C_WIDTH = 40;
	input wire [C_WIDTH - 1:0] one_hot;
	output reg [(C_WIDTH == 1 ? 0 : $clog2(C_WIDTH) - 1):0] int_out;
	function automatic signed [$clog2(C_WIDTH) - 1:0] sv2v_cast_639C0_signed;
		input reg signed [$clog2(C_WIDTH) - 1:0] inp;
		sv2v_cast_639C0_signed = inp;
	endfunction
	generate
		if (C_WIDTH == 1) begin : gen_width_one
			wire [((C_WIDTH == 1 ? 0 : $clog2(C_WIDTH) - 1) >= 0 ? (C_WIDTH == 1 ? 0 : $clog2(C_WIDTH) - 1) + 1 : 1 - (C_WIDTH == 1 ? 0 : $clog2(C_WIDTH) - 1)):1] sv2v_tmp_00EC1;
			assign sv2v_tmp_00EC1 = 0;
			always @(*) int_out = sv2v_tmp_00EC1;
		end
		else begin : gen_width_two_plus
			always @(*) begin
				if (_sv2v_0)
					;
				int_out = 0;
				begin : sv2v_autoblock_1
					reg signed [31:0] i;
					for (i = 0; i < C_WIDTH; i = i + 1)
						int_out = int_out | (one_hot[i] ? sv2v_cast_639C0_signed(i) : 0);
				end
			end
		end
	endgenerate
	initial _sv2v_0 = 0;
endmodule
module cycler (
	clk,
	rst,
	en,
	one_hot
);
	parameter C_WIDTH = 2;
	input wire clk;
	input wire rst;
	input wire en;
	output reg [C_WIDTH - 1:0] one_hot;
	generate
		if (C_WIDTH == 1) begin : gen_width_one
			wire [C_WIDTH:1] sv2v_tmp_62CAA;
			assign sv2v_tmp_62CAA = 1;
			always @(*) one_hot = sv2v_tmp_62CAA;
		end
		else begin : gen_width_two_plus
			always @(posedge clk)
				if (rst)
					one_hot <= 1;
				else if (en)
					one_hot <= {one_hot[C_WIDTH - 2:0], one_hot[C_WIDTH - 1]};
		end
	endgenerate
endmodule
module lfsr (
	clk,
	rst,
	en,
	value
);
	parameter [31:0] WIDTH = 3;
	parameter NEEDS_RESET = 1;
	input wire clk;
	input wire rst;
	input wire en;
	output reg [WIDTH - 1:0] value;
	localparam [2719:0] LFSR_TAPS = 2720'h1000000000000000000000000000000000000000100000000000000000000000000000000000000010000000000000000000000000000000000000002000000000000000000000001000000020000000200000000000000000000000200000003000000020000000000000000000000020000000400000002000000000000000000000004000000050000000200000000000000000000000500000006000000040000000300000004000000050000000700000002000000000000000000000004000000080000000200000000000000000000000600000009000000020000000000000000000000080000000a000000040000000000000003000000050000000b000000040000000000000002000000030000000c000000040000000000000002000000040000000d0000000200000000000000000000000d0000000e00000004000000030000000c0000000e0000000f;
	localparam [159:0] TAPS = LFSR_TAPS[(16 - WIDTH) * 160+:160];
	wire [TAPS[159-:32] - 1:0] feedback_input;
	wire feedback;
	function automatic signed [31:0] sv2v_cast_32_signed;
		input reg signed [31:0] inp;
		sv2v_cast_32_signed = inp;
	endfunction
	generate
		if (WIDTH == 2) begin : gen_width_two
			assign feedback = ~value[WIDTH - 1];
		end
		else begin : gen_width_three_plus
			genvar _gv_i_2;
			for (_gv_i_2 = 0; _gv_i_2 < TAPS[159-:32]; _gv_i_2 = _gv_i_2 + 1) begin : gen_taps
				localparam i = _gv_i_2;
				assign feedback_input[i] = value[sv2v_cast_32_signed(TAPS[0 + (i * 32)+:32])];
			end
			assign feedback = ~^feedback_input ^ |value[WIDTH - 2:0];
		end
	endgenerate
	initial value = 0;
	always @(posedge clk)
		if (NEEDS_RESET & rst)
			value <= 1'sb0;
		else if (en)
			value <= {value[WIDTH - 2:0], feedback};
endmodule
module priority_encoder (
	priority_vector,
	encoded_result
);
	parameter WIDTH = 4;
	input wire [WIDTH - 1:0] priority_vector;
	output wire [(WIDTH == 1 ? 0 : $clog2(WIDTH) - 1):0] encoded_result;
	generate
		if (WIDTH > 12) begin : genblk1
			initial $display("Error [elaboration] rtl/priority_encoder.sv:39:9 - priority_encoder.genblk1\n msg: ", "Max priority encoder width exceeded!");
		end
	endgenerate
	localparam MIN_WIDTH = (WIDTH == 1 ? 2 : WIDTH);
	localparam LOG2_WIDTH = $clog2(MIN_WIDTH);
	function automatic signed [LOG2_WIDTH - 1:0] sv2v_cast_C8F70_signed;
		input reg signed [LOG2_WIDTH - 1:0] inp;
		sv2v_cast_C8F70_signed = inp;
	endfunction
	function [((2 ** MIN_WIDTH) * LOG2_WIDTH) - 1:0] table_gen;
		input reg _sv2v_unused;
		reg signed [31:0] i;
		for (i = 0; i < (2 ** MIN_WIDTH); i = i + 1)
			begin
				table_gen[i * LOG2_WIDTH+:LOG2_WIDTH] = sv2v_cast_C8F70_signed(MIN_WIDTH - 1);
				begin : sv2v_autoblock_1
					reg signed [31:0] j;
					for (j = MIN_WIDTH - 2; j >= 0; j = j - 1)
						if (i[j])
							table_gen[i * LOG2_WIDTH+:LOG2_WIDTH] = sv2v_cast_C8F70_signed(j);
				end
			end
	endfunction
	localparam [((2 ** MIN_WIDTH) * LOG2_WIDTH) - 1:0] ENCODER_ROM = table_gen(0);
	assign encoded_result = (WIDTH == 1 ? 0 : ENCODER_ROM[priority_vector * LOG2_WIDTH+:LOG2_WIDTH]);
endmodule
module toggle_memory (
	clk,
	rst,
	toggle,
	toggle_id,
	read_id,
	read_data
);
	parameter DEPTH = 8;
	parameter NUM_READ_PORTS = 2;
	input wire clk;
	input wire rst;
	input wire toggle;
	input wire [$clog2(DEPTH) - 1:0] toggle_id;
	input wire [(NUM_READ_PORTS * $clog2(DEPTH)) - 1:0] read_id;
	output wire [0:NUM_READ_PORTS - 1] read_data;
	wire new_ram_data;
	wire [0:NUM_READ_PORTS + 0] _read_data;
	wire [(0 >= (NUM_READ_PORTS + 0) ? ((1 - (NUM_READ_PORTS + 0)) * $clog2(DEPTH)) + (((NUM_READ_PORTS + 0) * $clog2(DEPTH)) - 1) : ((NUM_READ_PORTS + 1) * $clog2(DEPTH)) - 1):(0 >= (NUM_READ_PORTS + 0) ? (NUM_READ_PORTS + 0) * $clog2(DEPTH) : 0)] _read_id;
	assign _read_id[(0 >= (NUM_READ_PORTS + 0) ? 0 : NUM_READ_PORTS + 0) * $clog2(DEPTH)+:$clog2(DEPTH)] = toggle_id;
	assign _read_id[$clog2(DEPTH) * (0 >= (NUM_READ_PORTS + 0) ? (0 >= (NUM_READ_PORTS + 0) ? (1 >= NUM_READ_PORTS ? 1 : (1 + (1 >= NUM_READ_PORTS ? 2 - NUM_READ_PORTS : NUM_READ_PORTS)) - 1) - ((1 >= NUM_READ_PORTS ? 2 - NUM_READ_PORTS : NUM_READ_PORTS) - 1) : (1 >= NUM_READ_PORTS ? 1 : (1 + (1 >= NUM_READ_PORTS ? 2 - NUM_READ_PORTS : NUM_READ_PORTS)) - 1)) : (NUM_READ_PORTS + 0) - (0 >= (NUM_READ_PORTS + 0) ? (1 >= NUM_READ_PORTS ? 1 : (1 + (1 >= NUM_READ_PORTS ? 2 - NUM_READ_PORTS : NUM_READ_PORTS)) - 1) - ((1 >= NUM_READ_PORTS ? 2 - NUM_READ_PORTS : NUM_READ_PORTS) - 1) : (1 >= NUM_READ_PORTS ? 1 : (1 + (1 >= NUM_READ_PORTS ? 2 - NUM_READ_PORTS : NUM_READ_PORTS)) - 1)))+:$clog2(DEPTH) * (1 >= NUM_READ_PORTS ? 2 - NUM_READ_PORTS : NUM_READ_PORTS)] = read_id;
	assign new_ram_data = toggle ^ _read_data[0];
	lutram_1w_mr #(
		.WIDTH(1),
		.DEPTH(DEPTH),
		.NUM_READ_PORTS(NUM_READ_PORTS + 1)
	) write_port(
		.clk(clk),
		.waddr(toggle_id),
		.raddr(_read_id),
		.ram_write(1'b1),
		.new_ram_data(new_ram_data),
		.ram_data_out(_read_data)
	);
	assign read_data = _read_data[1:NUM_READ_PORTS];
endmodule
module toggle_memory_set (
	clk,
	rst,
	init_clear,
	toggle,
	toggle_addr,
	read_addr,
	in_use
);
	reg _sv2v_0;
	parameter DEPTH = 64;
	parameter NUM_WRITE_PORTS = 3;
	parameter NUM_READ_PORTS = 2;
	parameter WRITE_INDEX_FOR_RESET = 0;
	parameter READ_INDEX_FOR_RESET = 0;
	input wire clk;
	input wire rst;
	input wire init_clear;
	input wire [0:NUM_WRITE_PORTS - 1] toggle;
	input wire [(NUM_WRITE_PORTS * $clog2(DEPTH)) - 1:0] toggle_addr;
	input wire [(NUM_READ_PORTS * $clog2(DEPTH)) - 1:0] read_addr;
	output reg [0:NUM_READ_PORTS - 1] in_use;
	reg [(0 >= (NUM_WRITE_PORTS + 0) ? ((1 - (NUM_WRITE_PORTS + 0)) * $clog2(DEPTH)) + (((NUM_WRITE_PORTS + 0) * $clog2(DEPTH)) - 1) : ((NUM_WRITE_PORTS + 1) * $clog2(DEPTH)) - 1):(0 >= (NUM_WRITE_PORTS + 0) ? (NUM_WRITE_PORTS + 0) * $clog2(DEPTH) : 0)] _toggle_addr;
	reg [0:NUM_WRITE_PORTS + 0] _toggle;
	reg [(0 >= (NUM_READ_PORTS + 0) ? ((1 - (NUM_READ_PORTS + 0)) * $clog2(DEPTH)) + (((NUM_READ_PORTS + 0) * $clog2(DEPTH)) - 1) : ((NUM_READ_PORTS + 1) * $clog2(DEPTH)) - 1):(0 >= (NUM_READ_PORTS + 0) ? (NUM_READ_PORTS + 0) * $clog2(DEPTH) : 0)] _read_addr;
	wire [0:NUM_READ_PORTS + 0] read_data [0:NUM_WRITE_PORTS + 0];
	reg [0:NUM_READ_PORTS + 0] _in_use;
	wire [$clog2(DEPTH) - 1:0] clear_index;
	lfsr #(
		.WIDTH($clog2(DEPTH)),
		.NEEDS_RESET(0)
	) lfsr_counter(
		.clk(clk),
		.rst(rst),
		.en(init_clear),
		.value(clear_index)
	);
	always @(*) begin
		if (_sv2v_0)
			;
		_toggle_addr[$clog2(DEPTH) * (0 >= (NUM_WRITE_PORTS + 0) ? (0 >= (NUM_WRITE_PORTS + 0) ? (NUM_WRITE_PORTS - 1) - (NUM_WRITE_PORTS - 1) : NUM_WRITE_PORTS - 1) : (NUM_WRITE_PORTS + 0) - (0 >= (NUM_WRITE_PORTS + 0) ? (NUM_WRITE_PORTS - 1) - (NUM_WRITE_PORTS - 1) : NUM_WRITE_PORTS - 1))+:$clog2(DEPTH) * NUM_WRITE_PORTS] = toggle_addr;
		_toggle[0:NUM_WRITE_PORTS - 1] = toggle;
		_read_addr[$clog2(DEPTH) * (0 >= (NUM_READ_PORTS + 0) ? (0 >= (NUM_READ_PORTS + 0) ? (NUM_READ_PORTS - 1) - (NUM_READ_PORTS - 1) : NUM_READ_PORTS - 1) : (NUM_READ_PORTS + 0) - (0 >= (NUM_READ_PORTS + 0) ? (NUM_READ_PORTS - 1) - (NUM_READ_PORTS - 1) : NUM_READ_PORTS - 1))+:$clog2(DEPTH) * NUM_READ_PORTS] = read_addr;
		_toggle_addr[(0 >= (NUM_WRITE_PORTS + 0) ? NUM_WRITE_PORTS : (NUM_WRITE_PORTS + 0) - NUM_WRITE_PORTS) * $clog2(DEPTH)+:$clog2(DEPTH)] = clear_index;
		_toggle[NUM_WRITE_PORTS] = init_clear & _in_use[NUM_READ_PORTS];
		_read_addr[(0 >= (NUM_READ_PORTS + 0) ? NUM_READ_PORTS : (NUM_READ_PORTS + 0) - NUM_READ_PORTS) * $clog2(DEPTH)+:$clog2(DEPTH)] = clear_index;
	end
	genvar _gv_i_3;
	genvar _gv_j_1;
	generate
		for (_gv_j_1 = 0; _gv_j_1 < (NUM_WRITE_PORTS + 1); _gv_j_1 = _gv_j_1 + 1) begin : write_port_gen
			localparam j = _gv_j_1;
			toggle_memory #(
				.DEPTH(DEPTH),
				.NUM_READ_PORTS(NUM_READ_PORTS + 1)
			) mem(
				.clk(clk),
				.rst(rst),
				.toggle(_toggle[j]),
				.toggle_id(_toggle_addr[(0 >= (NUM_WRITE_PORTS + 0) ? j : (NUM_WRITE_PORTS + 0) - j) * $clog2(DEPTH)+:$clog2(DEPTH)]),
				.read_id(_read_addr),
				.read_data(read_data[j])
			);
		end
	endgenerate
	always @(*) begin
		if (_sv2v_0)
			;
		_in_use = {NUM_READ_PORTS + 1 {1'd0}};
		begin : sv2v_autoblock_1
			reg signed [31:0] i;
			for (i = 0; i < (NUM_READ_PORTS + 1); i = i + 1)
				begin : sv2v_autoblock_2
					reg signed [31:0] j;
					for (j = 0; j < (NUM_WRITE_PORTS + 1); j = j + 1)
						_in_use[i] = _in_use[i] ^ read_data[j][i];
				end
		end
		begin : sv2v_autoblock_3
			reg signed [31:0] i;
			for (i = 0; i < NUM_READ_PORTS; i = i + 1)
				in_use[i] = _in_use[i];
		end
	end
	initial _sv2v_0 = 0;
endmodule
module xilinx_byte_enable_ram (
	clk,
	addr_a,
	en_a,
	be_a,
	data_in_a,
	data_out_a,
	addr_b,
	en_b,
	be_b,
	data_in_b,
	data_out_b
);
	parameter LINES = 4096;
	parameter preload_file = "";
	parameter USE_PRELOAD_FILE = 0;
	input wire clk;
	input wire [$clog2(LINES) - 1:0] addr_a;
	input wire en_a;
	localparam riscv_types_XLEN = 32;
	input wire [3:0] be_a;
	input wire [31:0] data_in_a;
	output reg [31:0] data_out_a;
	input wire [$clog2(LINES) - 1:0] addr_b;
	input wire en_b;
	input wire [3:0] be_b;
	input wire [31:0] data_in_b;
	output reg [31:0] data_out_b;
	reg [31:0] ram [LINES - 1:0];
	initial if (USE_PRELOAD_FILE)
		$readmemh(preload_file, ram, 0, LINES - 1);
	generate
		if (1) begin : gen_xilinx_bram
			genvar _gv_i_4;
			for (_gv_i_4 = 0; _gv_i_4 < 4; _gv_i_4 = _gv_i_4 + 1) begin : genblk1
				localparam i = _gv_i_4;
				always @(posedge clk)
					if (en_a) begin
						if (be_a[i]) begin
							ram[addr_a][8 * i+:8] <= data_in_a[8 * i+:8];
							data_out_a[8 * i+:8] <= data_in_a[8 * i+:8];
						end
						else
							data_out_a[8 * i+:8] <= ram[addr_a][8 * i+:8];
					end
			end
			for (_gv_i_4 = 0; _gv_i_4 < 4; _gv_i_4 = _gv_i_4 + 1) begin : genblk2
				localparam i = _gv_i_4;
				always @(posedge clk)
					if (en_b) begin
						if (be_b[i]) begin
							ram[addr_b][8 * i+:8] <= data_in_b[8 * i+:8];
							data_out_b[8 * i+:8] <= data_in_b[8 * i+:8];
						end
						else
							data_out_b[8 * i+:8] <= ram[addr_b][8 * i+:8];
					end
			end
		end
	endgenerate
endmodule
module byte_en_BRAM (
	clk,
	addr_a,
	en_a,
	be_a,
	data_in_a,
	data_out_a,
	addr_b,
	en_b,
	be_b,
	data_in_b,
	data_out_b
);
	parameter LINES = 4096;
	parameter preload_file = "";
	parameter USE_PRELOAD_FILE = 0;
	input wire clk;
	input wire [$clog2(LINES) - 1:0] addr_a;
	input wire en_a;
	localparam riscv_types_XLEN = 32;
	input wire [3:0] be_a;
	input wire [31:0] data_in_a;
	output wire [31:0] data_out_a;
	input wire [$clog2(LINES) - 1:0] addr_b;
	input wire en_b;
	input wire [3:0] be_b;
	input wire [31:0] data_in_b;
	output wire [31:0] data_out_b;
	localparam [31:0] cva5_config_FPGA_VENDOR = 32'd0;
	generate
		if (1) begin : genblk1
			xilinx_byte_enable_ram #(
				.LINES(LINES),
				.preload_file(preload_file),
				.USE_PRELOAD_FILE(USE_PRELOAD_FILE)
			) ram_block(
				.clk(clk),
				.addr_a(addr_a),
				.en_a(en_a),
				.be_a(be_a),
				.data_in_a(data_in_a),
				.data_out_a(data_out_a),
				.addr_b(addr_b),
				.en_b(en_b),
				.be_b(be_b),
				.data_in_b(data_in_b),
				.data_out_b(data_out_b)
			);
		end
	endgenerate
endmodule
module branch_comparator (
	less_than,
	a,
	b,
	xor_result,
	result
);
	reg _sv2v_0;
	input wire less_than;
	input wire [32:0] a;
	input wire [32:0] b;
	input wire xor_result;
	output wire result;
	wire [31:0] eq_a;
	wire [31:0] eq_b;
	wire [31:0] ls_a;
	wire [31:0] ls_b;
	reg [15:0] sub_ls_a;
	reg [15:0] sub_ls_b;
	reg [15:0] sub_eq_a;
	wire [15:0] sub_toss;
	wire carry_out;
	wire eq_carry_in;
	wire ls_carry_in;
	wire carry_in;
	assign eq_carry_in = ((a[0] & b[0]) | (~a[0] & ~b[0])) & ((a[1] & b[1]) | (~a[1] & ~b[1]));
	assign ls_carry_in = ((a[0] | ~b[0]) & (a[1] | ~b[1])) | (a[1] & ~b[1]);
	assign carry_in = (less_than ? ls_carry_in : eq_carry_in);
	assign ls_a = {1'b0, a[32:2]};
	assign ls_b = {1'b1, ~b[32:2]};
	assign eq_a = {1'b0, a[32:2]} & {1'b0, b[32:2]};
	assign eq_b = {1'b0, ~a[32:2]} & {1'b0, ~b[32:2]};
	always @(*) begin
		if (_sv2v_0)
			;
		begin : sv2v_autoblock_1
			reg signed [31:0] i;
			for (i = 0; i < 16; i = i + 1)
				begin
					sub_ls_a[i] = ((ls_a[2 * i] & ls_b[2 * i]) & (ls_a[(2 * i) + 1] | ls_b[(2 * i) + 1])) | (ls_a[(2 * i) + 1] & ls_b[(2 * i) + 1]);
					sub_ls_b[i] = (((ls_a[2 * i] & ls_b[2 * i]) & (ls_a[(2 * i) + 1] | ls_b[(2 * i) + 1])) | (ls_a[(2 * i) + 1] & ls_b[(2 * i) + 1])) | ((ls_a[2 * i] | ls_b[2 * i]) & (ls_a[(2 * i) + 1] | ls_b[(2 * i) + 1]));
					sub_eq_a[i] = (eq_a[2 * i] | eq_b[2 * i]) & (eq_a[(2 * i) + 1] | eq_b[(2 * i) + 1]);
				end
		end
		sub_ls_a[15] = sub_ls_a[15] ^ xor_result;
		sub_eq_a[15] = sub_eq_a[15] ^ xor_result;
	end
	assign {result, sub_toss} = {(less_than ? sub_ls_a : sub_eq_a), carry_in} + {(less_than ? sub_ls_b : 16'b0000000000000000), carry_in};
	initial _sv2v_0 = 0;
endmodule
module barrel_shifter (
	shifter_input,
	shift_amount,
	arith,
	lshift,
	shifted_result
);
	input wire [31:0] shifter_input;
	input wire [4:0] shift_amount;
	input wire arith;
	input wire lshift;
	output wire [31:0] shifted_result;
	wire [62:0] shift_in;
	wire [4:0] adjusted_shift_amount;
	assign shift_in = (lshift ? {shifter_input, 31'b0000000000000000000000000000000} : {{31 {arith}}, shifter_input});
	assign adjusted_shift_amount = shift_amount ^ {5 {lshift}};
	function automatic [31:0] sv2v_cast_32;
		input reg [31:0] inp;
		sv2v_cast_32 = inp;
	endfunction
	assign shifted_result = sv2v_cast_32(shift_in >> adjusted_shift_amount);
endmodule
module tag_bank (
	clk,
	rst,
	addr_a,
	addr_b,
	en_a,
	en_b,
	wen_a,
	wen_b,
	data_in_a,
	data_in_b,
	data_out_a,
	data_out_b
);
	parameter WIDTH = 32;
	parameter LINES = 512;
	input wire clk;
	input wire rst;
	input wire [$clog2(LINES) - 1:0] addr_a;
	input wire [$clog2(LINES) - 1:0] addr_b;
	input wire en_a;
	input wire en_b;
	input wire wen_a;
	input wire wen_b;
	input wire [WIDTH - 1:0] data_in_a;
	input wire [WIDTH - 1:0] data_in_b;
	output reg [WIDTH - 1:0] data_out_a;
	output reg [WIDTH - 1:0] data_out_b;
	(* ram_style = "block" *) reg [WIDTH - 1:0] tag_entry [0:LINES - 1];
	initial begin : sv2v_autoblock_1
		integer isaac_init;
		for (isaac_init = 0; isaac_init < LINES; isaac_init = isaac_init + 1)
			tag_entry[isaac_init] = 1'sb0;
	end
	always @(posedge clk)
		if (en_a) begin
			if (wen_a)
				tag_entry[addr_a] <= data_in_a;
			else
				data_out_a <= tag_entry[addr_a];
		end
	always @(posedge clk)
		if (en_b) begin
			if (wen_b)
				tag_entry[addr_b] <= data_in_b;
			else
				data_out_b <= tag_entry[addr_b];
		end
endmodule
module ddata_bank (
	clk,
	addr_a,
	en_a,
	be_a,
	data_in_a,
	data_out_a,
	addr_b,
	en_b,
	data_in_b
);
	parameter LINES = 2048;
	input wire clk;
	input wire [$clog2(LINES) - 1:0] addr_a;
	input wire en_a;
	input wire [3:0] be_a;
	input wire [31:0] data_in_a;
	output wire [31:0] data_out_a;
	input wire [$clog2(LINES) - 1:0] addr_b;
	input wire en_b;
	input wire [31:0] data_in_b;
	byte_en_BRAM #(
		.LINES(LINES),
		.preload_file(""),
		.USE_PRELOAD_FILE(0)
	) ram_block(
		.clk(clk),
		.addr_a(addr_a),
		.en_a(en_a),
		.be_a(be_a),
		.data_in_a(data_in_a),
		.data_out_a(data_out_a),
		.addr_b(addr_b),
		.en_b(en_b),
		.data_in_b(data_in_b),
		.be_b({4 {en_b}}),
		.data_out_b()
	);
endmodule
module dtag_banks (
	clk,
	rst,
	stage1_addr,
	stage2_addr,
	inv_addr,
	update_way,
	update,
	stage1_adv,
	stage1_inv,
	extern_inv,
	extern_inv_complete,
	tag_hit,
	tag_hit_way
);
	localparam [1209:0] cva5_config_EXAMPLE_CONFIG = 1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002;
	parameter [1209:0] CONFIG = cva5_config_EXAMPLE_CONFIG;
	parameter [95:0] SCONFIG = 96'h000000000000000000000000;
	input wire clk;
	input wire rst;
	input wire [29:0] stage1_addr;
	input wire [29:0] stage2_addr;
	input wire [29:0] inv_addr;
	input wire [CONFIG[646-:32] - 1:0] update_way;
	input wire update;
	input wire stage1_adv;
	input wire stage1_inv;
	input wire extern_inv;
	output wire extern_inv_complete;
	output wire tag_hit;
	output wire [CONFIG[646-:32] - 1:0] tag_hit_way;
	function [SCONFIG[31-:32] - 1:0] getTag;
		input reg [29:0] addr;
		getTag = addr[SCONFIG[63-:32] + SCONFIG[95-:32]+:SCONFIG[31-:32]];
	endfunction
	function [SCONFIG[95-:32] - 1:0] getLineAddr;
		input reg [29:0] addr;
		getLineAddr = addr[(SCONFIG[95-:32] + SCONFIG[63-:32]) - 1:SCONFIG[63-:32]];
	endfunction
	wire [(1 + SCONFIG[31-:32]) - 1:0] tag_line [CONFIG[646-:32] - 1:0];
	wire [(1 + SCONFIG[31-:32]) - 1:0] inv_tag_line [CONFIG[646-:32] - 1:0];
	wire [(1 + SCONFIG[31-:32]) - 1:0] new_tagline;
	wire [CONFIG[646-:32] - 1:0] update_tag_way;
	reg inv_tags_accessed;
	wire [CONFIG[646-:32] - 1:0] inv_hit_way;
	wire [CONFIG[646-:32] - 1:0] inv_hit_way_r;
	wire [SCONFIG[95-:32] - 1:0] update_port_addr;
	wire [(1 + SCONFIG[31-:32]) - 1:0] stage2_hit_comparison_tagline;
	wire [(1 + SCONFIG[31-:32]) - 1:0] inv_hit_comparison_tagline;
	assign update_port_addr = (CONFIG[614] ? (update ? getLineAddr(stage2_addr) : getLineAddr(inv_addr)) : getLineAddr(stage2_addr));
	function automatic [SCONFIG[31-:32] - 1:0] sv2v_cast_ABD35;
		input reg [SCONFIG[31-:32] - 1:0] inp;
		sv2v_cast_ABD35 = inp;
	endfunction
	assign new_tagline = {update, sv2v_cast_ABD35(getTag(stage2_addr))};
	always @(posedge clk)
		if (rst)
			inv_tags_accessed <= 0;
		else
			inv_tags_accessed <= extern_inv & ~update;
	assign extern_inv_complete = (extern_inv & ~update) & inv_tags_accessed;
	assign stage2_hit_comparison_tagline = {1'd1, sv2v_cast_ABD35(getTag(stage2_addr))};
	assign inv_hit_comparison_tagline = {1'd1, sv2v_cast_ABD35(getTag(inv_addr))};
	genvar _gv_i_6;
	generate
		for (_gv_i_6 = 0; _gv_i_6 < CONFIG[646-:32]; _gv_i_6 = _gv_i_6 + 1) begin : dtag_bank_gen
			localparam i = _gv_i_6;
			assign update_tag_way[i] = update_way[i] | (inv_hit_way[i] & extern_inv_complete);
			localparam sv2v_uu_dtag_bank_WIDTH = 1 + SCONFIG[31-:32];
			localparam [(1 + SCONFIG[31-:32]) - 1:0] sv2v_uu_dtag_bank_ext_data_in_a_0 = 1'sb0;
			tag_bank #(
				.WIDTH(1 + SCONFIG[31-:32]),
				.LINES(CONFIG[710-:32])
			) dtag_bank(
				.clk(clk),
				.rst(rst),
				.en_a(stage1_adv),
				.wen_a(stage1_inv),
				.addr_a(getLineAddr(stage1_addr)),
				.data_in_a(sv2v_uu_dtag_bank_ext_data_in_a_0),
				.data_out_a(tag_line[i]),
				.en_b(update | extern_inv),
				.wen_b(update_tag_way[i]),
				.addr_b(update_port_addr),
				.data_in_b(new_tagline),
				.data_out_b(inv_tag_line[i])
			);
			assign inv_hit_way[i] = inv_hit_comparison_tagline == inv_tag_line[i];
			assign tag_hit_way[i] = stage2_hit_comparison_tagline == tag_line[i];
		end
	endgenerate
	assign tag_hit = |tag_hit_way;
endmodule
module amo_alu (
	amo_alu_inputs,
	result
);
	reg _sv2v_0;
	localparam riscv_types_XLEN = 32;
	input wire [68:0] amo_alu_inputs;
	output reg [31:0] result;
	wire rs1_smaller_than_rs2;
	wire signed [32:0] rs1_ext;
	wire signed [32:0] rs2_ext;
	assign rs1_ext = {~amo_alu_inputs[4] & amo_alu_inputs[68], amo_alu_inputs[68-:32]};
	assign rs2_ext = {~amo_alu_inputs[4] & amo_alu_inputs[36], amo_alu_inputs[36-:32]};
	assign rs1_smaller_than_rs2 = rs1_ext < rs2_ext;
	always @(*) begin
		if (_sv2v_0)
			;
		case (amo_alu_inputs[4-:5])
			5'b00001: result = amo_alu_inputs[36-:32];
			5'b00000: result = amo_alu_inputs[68-:32] + amo_alu_inputs[36-:32];
			5'b00100: result = amo_alu_inputs[68-:32] ^ amo_alu_inputs[36-:32];
			5'b01100: result = amo_alu_inputs[68-:32] & amo_alu_inputs[36-:32];
			5'b01000: result = amo_alu_inputs[68-:32] | amo_alu_inputs[36-:32];
			5'b10000: result = (rs1_smaller_than_rs2 ? amo_alu_inputs[68-:32] : amo_alu_inputs[36-:32]);
			5'b10100: result = (rs1_smaller_than_rs2 ? amo_alu_inputs[36-:32] : amo_alu_inputs[68-:32]);
			5'b11000: result = (rs1_smaller_than_rs2 ? amo_alu_inputs[68-:32] : amo_alu_inputs[36-:32]);
			5'b11100: result = (rs1_smaller_than_rs2 ? amo_alu_inputs[36-:32] : amo_alu_inputs[68-:32]);
		endcase
	end
	initial _sv2v_0 = 0;
endmodule
module addr_hash (
	clk,
	rst,
	addr,
	addr_hash
);
	input wire clk;
	input wire rst;
	input wire [31:0] addr;
	output wire [3:0] addr_hash;
	assign addr_hash[0] = (addr[2] ^ addr[6]) ^ addr[10];
	assign addr_hash[1] = (addr[3] ^ addr[7]) ^ addr[11];
	assign addr_hash[2] = addr[4] ^ addr[8];
	assign addr_hash[3] = addr[5] ^ addr[9];
endmodule
module itag_banks (
	clk,
	rst,
	stage1_addr,
	stage2_addr,
	update_way,
	update,
	stage1_adv,
	tag_hit,
	tag_hit_way
);
	localparam [1209:0] cva5_config_EXAMPLE_CONFIG = 1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002;
	parameter [1209:0] CONFIG = cva5_config_EXAMPLE_CONFIG;
	parameter [95:0] SCONFIG = 96'h000000000000000000000000;
	input wire clk;
	input wire rst;
	input wire [31:0] stage1_addr;
	input wire [31:0] stage2_addr;
	input wire [CONFIG[937-:32] - 1:0] update_way;
	input wire update;
	input wire stage1_adv;
	output wire tag_hit;
	output wire [CONFIG[937-:32] - 1:0] tag_hit_way;
	function [SCONFIG[31-:32] - 1:0] getTag;
		input reg [31:0] addr;
		getTag = addr[(2 + SCONFIG[63-:32]) + SCONFIG[95-:32]+:SCONFIG[31-:32]];
	endfunction
	function [SCONFIG[95-:32] - 1:0] getLineAddr;
		input reg [31:0] addr;
		getLineAddr = addr[(SCONFIG[95-:32] + SCONFIG[63-:32]) + 1:SCONFIG[63-:32] + 2];
	endfunction
	reg hit_allowed;
	wire [SCONFIG[31-:32]:0] tag_line [CONFIG[937-:32] - 1:0];
	wire [SCONFIG[31-:32]:0] stage2_tag;
	assign stage2_tag = {1'b1, getTag(stage2_addr)};
	always @(posedge clk)
		if (rst)
			hit_allowed <= 0;
		else
			hit_allowed <= stage1_adv;
	genvar _gv_i_8;
	generate
		for (_gv_i_8 = 0; _gv_i_8 < CONFIG[937-:32]; _gv_i_8 = _gv_i_8 + 1) begin : tag_bank_gen
			localparam i = _gv_i_8;
			localparam [0:0] sv2v_uu_itag_bank_ext_wen_a_0 = 1'sb0;
			localparam sv2v_uu_itag_bank_WIDTH = SCONFIG[31-:32] + 1;
			localparam [SCONFIG[31-:32] + 0:0] sv2v_uu_itag_bank_ext_data_in_a_0 = 1'sb0;
			tag_bank #(
				.WIDTH(SCONFIG[31-:32] + 1),
				.LINES(CONFIG[1001-:32])
			) itag_bank(
				.clk(clk),
				.rst(rst),
				.en_a(stage1_adv),
				.wen_a(sv2v_uu_itag_bank_ext_wen_a_0),
				.addr_a(getLineAddr(stage1_addr)),
				.data_in_a(sv2v_uu_itag_bank_ext_data_in_a_0),
				.data_out_a(tag_line[i]),
				.en_b(update),
				.wen_b(update_way[i]),
				.addr_b(getLineAddr(stage2_addr)),
				.data_in_b(stage2_tag),
				.data_out_b()
			);
			assign tag_hit_way[i] = {hit_allowed, stage2_tag} == {1'b1, tag_line[i]};
		end
	endgenerate
	assign tag_hit = |tag_hit_way;
endmodule
module clz (
	clz_input,
	clz
);
	reg _sv2v_0;
	input wire [31:0] clz_input;
	output reg [4:0] clz;
	reg [1:0] low_order_clz [7:0];
	reg [7:0] sub_clz;
	reg [1:0] upper_lower [3:0];
	reg [15:0] clz_low_table = 16'he500;
	always @(*) begin
		if (_sv2v_0)
			;
		begin : sv2v_autoblock_1
			reg signed [31:0] i;
			for (i = 0; i < 8; i = i + 1)
				begin
					sub_clz[7 - i] = ~|clz_input[i * 4+:4];
					low_order_clz[7 - i] = clz_low_table[(7 - clz_input[(i * 4) + 1+:3]) * 2+:2];
				end
		end
		clz[4] = &sub_clz[3:0];
		clz[3] = (clz[4] ? &sub_clz[5:4] : &sub_clz[1:0]);
		clz[2] = (((sub_clz[0] & ~sub_clz[1]) | (&sub_clz[2:0] & ~sub_clz[3])) | (&sub_clz[4:0] & ~sub_clz[5])) | &sub_clz[6:0];
		begin : sv2v_autoblock_2
			reg signed [31:0] i;
			for (i = 0; i < 8; i = i + 2)
				upper_lower[i / 2] = low_order_clz[{i[2:1], sub_clz[i]}];
		end
		clz[1:0] = upper_lower[clz[4:3]];
	end
	initial _sv2v_0 = 0;
endmodule
module branch_predictor_ram (
	clk,
	rst,
	write_addr,
	write_en,
	read_addr,
	read_en,
	write_data,
	read_data
);
	parameter C_DATA_WIDTH = 20;
	parameter C_DEPTH = 512;
	input wire clk;
	input wire rst;
	input wire [$clog2(C_DEPTH) - 1:0] write_addr;
	input wire write_en;
	input wire [$clog2(C_DEPTH) - 1:0] read_addr;
	input wire read_en;
	input wire [C_DATA_WIDTH - 1:0] write_data;
	output reg [C_DATA_WIDTH - 1:0] read_data;
	(* ram_style = "block" *) reg [C_DATA_WIDTH - 1:0] branch_ram [C_DEPTH - 1:0];
	initial begin : sv2v_autoblock_1
		integer isaac_init;
		for (isaac_init = 0; isaac_init < C_DEPTH; isaac_init = isaac_init + 1)
			branch_ram[isaac_init] = 1'sb0;
	end
	always @(posedge clk)
		if (write_en)
			branch_ram[write_addr] <= write_data;
	always @(posedge clk)
		if (read_en)
			read_data <= branch_ram[read_addr];
endmodule
module illegal_instruction_checker (
	instruction,
	illegal_instruction
);
	localparam [1209:0] cva5_config_EXAMPLE_CONFIG = 1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002;
	parameter [1209:0] CONFIG = cva5_config_EXAMPLE_CONFIG;
	input wire [31:0] instruction;
	output wire illegal_instruction;
	localparam [31:0] BEQ = 32'bzzzzzzzzzzzzzzzzz000zzzzz1100011;
	localparam [31:0] BNE = 32'bzzzzzzzzzzzzzzzzz001zzzzz1100011;
	localparam [31:0] BLT = 32'bzzzzzzzzzzzzzzzzz100zzzzz1100011;
	localparam [31:0] BGE = 32'bzzzzzzzzzzzzzzzzz101zzzzz1100011;
	localparam [31:0] BLTU = 32'bzzzzzzzzzzzzzzzzz110zzzzz1100011;
	localparam [31:0] BGEU = 32'bzzzzzzzzzzzzzzzzz111zzzzz1100011;
	localparam [31:0] JALR = 32'bzzzzzzzzzzzzzzzzz000zzzzz1100111;
	localparam [31:0] JAL = 32'bzzzzzzzzzzzzzzzzzzzzzzzzz1101111;
	localparam [31:0] LUI = 32'bzzzzzzzzzzzzzzzzzzzzzzzzz0110111;
	localparam [31:0] AUIPC = 32'bzzzzzzzzzzzzzzzzzzzzzzzzz0010111;
	localparam [31:0] ADDI = 32'bzzzzzzzzzzzzzzzzz000zzzzz0010011;
	localparam [31:0] SLLI = 32'b000000zzzzzzzzzzz001zzzzz0010011;
	localparam [31:0] SLTI = 32'bzzzzzzzzzzzzzzzzz010zzzzz0010011;
	localparam [31:0] SLTIU = 32'bzzzzzzzzzzzzzzzzz011zzzzz0010011;
	localparam [31:0] XORI = 32'bzzzzzzzzzzzzzzzzz100zzzzz0010011;
	localparam [31:0] SRLI = 32'b000000zzzzzzzzzzz101zzzzz0010011;
	localparam [31:0] SRAI = 32'b010000zzzzzzzzzzz101zzzzz0010011;
	localparam [31:0] ORI = 32'bzzzzzzzzzzzzzzzzz110zzzzz0010011;
	localparam [31:0] ANDI = 32'bzzzzzzzzzzzzzzzzz111zzzzz0010011;
	localparam [31:0] ADD = 32'b0000000zzzzzzzzzz000zzzzz0110011;
	localparam [31:0] SUB = 32'b0100000zzzzzzzzzz000zzzzz0110011;
	localparam [31:0] SLL = 32'b0000000zzzzzzzzzz001zzzzz0110011;
	localparam [31:0] SLT = 32'b0000000zzzzzzzzzz010zzzzz0110011;
	localparam [31:0] SLTU = 32'b0000000zzzzzzzzzz011zzzzz0110011;
	localparam [31:0] XOR = 32'b0000000zzzzzzzzzz100zzzzz0110011;
	localparam [31:0] SRL = 32'b0000000zzzzzzzzzz101zzzzz0110011;
	localparam [31:0] SRA = 32'b0100000zzzzzzzzzz101zzzzz0110011;
	localparam [31:0] OR = 32'b0000000zzzzzzzzzz110zzzzz0110011;
	localparam [31:0] AND = 32'b0000000zzzzzzzzzz111zzzzz0110011;
	localparam [31:0] LB = 32'bzzzzzzzzzzzzzzzzz000zzzzz0000011;
	localparam [31:0] LH = 32'bzzzzzzzzzzzzzzzzz001zzzzz0000011;
	localparam [31:0] LW = 32'bzzzzzzzzzzzzzzzzz010zzzzz0000011;
	localparam [31:0] LBU = 32'bzzzzzzzzzzzzzzzzz100zzzzz0000011;
	localparam [31:0] LHU = 32'bzzzzzzzzzzzzzzzzz101zzzzz0000011;
	localparam [31:0] SB = 32'bzzzzzzzzzzzzzzzzz000zzzzz0100011;
	localparam [31:0] SH = 32'bzzzzzzzzzzzzzzzzz001zzzzz0100011;
	localparam [31:0] SW = 32'bzzzzzzzzzzzzzzzzz010zzzzz0100011;
	localparam [31:0] FENCE = 32'bzzzzzzzzzzzzzzzzz000zzzzz0001111;
	localparam [31:0] FENCE_I = 32'bzzzzzzzzzzzzzzzzz001zzzzz0001111;
	localparam [31:0] ECALL = 32'b00000000000000000000000001110011;
	localparam [31:0] EBREAK = 32'b00000000000100000000000001110011;
	localparam [31:0] CSRRW = 32'bzzzzzzzzzzzzzzzzz001zzzzz1110011;
	localparam [31:0] CSRRS = 32'bzzzzzzzzzzzzzzzzz010zzzzz1110011;
	localparam [31:0] CSRRC = 32'bzzzzzzzzzzzzzzzzz011zzzzz1110011;
	localparam [31:0] CSRRWI = 32'bzzzzzzzzzzzzzzzzz101zzzzz1110011;
	localparam [31:0] CSRRSI = 32'bzzzzzzzzzzzzzzzzz110zzzzz1110011;
	localparam [31:0] CSRRCI = 32'bzzzzzzzzzzzzzzzzz111zzzzz1110011;
	localparam [31:0] MUL = 32'b0000001zzzzzzzzzz000zzzzz0110011;
	localparam [31:0] MULH = 32'b0000001zzzzzzzzzz001zzzzz0110011;
	localparam [31:0] MULHSU = 32'b0000001zzzzzzzzzz010zzzzz0110011;
	localparam [31:0] MULHU = 32'b0000001zzzzzzzzzz011zzzzz0110011;
	localparam [31:0] DIV = 32'b0000001zzzzzzzzzz100zzzzz0110011;
	localparam [31:0] DIVU = 32'b0000001zzzzzzzzzz101zzzzz0110011;
	localparam [31:0] REM = 32'b0000001zzzzzzzzzz110zzzzz0110011;
	localparam [31:0] REMU = 32'b0000001zzzzzzzzzz111zzzzz0110011;
	localparam [31:0] AMO_ADD = 32'b00000zzzzzzzzzzzz010zzzzz0101111;
	localparam [31:0] AMO_XOR = 32'b00100zzzzzzzzzzzz010zzzzz0101111;
	localparam [31:0] AMO_OR = 32'b01000zzzzzzzzzzzz010zzzzz0101111;
	localparam [31:0] AMO_AND = 32'b01100zzzzzzzzzzzz010zzzzz0101111;
	localparam [31:0] AMO_MIN = 32'b10000zzzzzzzzzzzz010zzzzz0101111;
	localparam [31:0] AMO_MAX = 32'b10100zzzzzzzzzzzz010zzzzz0101111;
	localparam [31:0] AMO_MINU = 32'b11000zzzzzzzzzzzz010zzzzz0101111;
	localparam [31:0] AMO_MAXU = 32'b11100zzzzzzzzzzzz010zzzzz0101111;
	localparam [31:0] AMO_SWAP = 32'b00001zzzzzzzzzzzz010zzzzz0101111;
	localparam [31:0] LR = 32'b00010zz00000zzzzz010zzzzz0101111;
	localparam [31:0] SC = 32'b00011zzzzzzzzzzzz010zzzzz0101111;
	localparam [31:0] SRET = 32'b00010000001000000000000001110011;
	localparam [31:0] MRET = 32'b00110000001000000000000001110011;
	localparam [31:0] SFENCE_VMA = 32'b0001001zzzzzzzzzz000000001110011;
	localparam [31:0] WFI = 32'b00010000010100000000000001110011;
	wire base_legal;
	wire csr_legal;
	wire csr_addr_base;
	wire csr_addr_machine;
	wire csr_addr_supervisor;
	wire csr_addr_debug;
	wire mul_legal;
	wire div_legal;
	wire ifence_legal;
	wire amo_legal;
	wire machine_legal;
	wire supervisor_legal;
	assign base_legal = |{(instruction | 32'b11111111111111111000111110000000) == 32'b11111111111111111000111111100011, (instruction | 32'b11111111111111111000111110000000) == 32'b11111111111111111001111111100011, (instruction | 32'b11111111111111111000111110000000) == 32'b11111111111111111100111111100011, (instruction | 32'b11111111111111111000111110000000) == 32'b11111111111111111101111111100011, (instruction | 32'b11111111111111111000111110000000) == 32'b11111111111111111110111111100011, (instruction | 32'b11111111111111111000111110000000) == 32'b11111111111111111111111111100011, (instruction | 32'b11111111111111111000111110000000) == 32'b11111111111111111000111111100111, (instruction | 32'b11111111111111111111111110000000) == 32'b11111111111111111111111111101111, (instruction | 32'b11111111111111111111111110000000) == 32'b11111111111111111111111110110111, (instruction | 32'b11111111111111111111111110000000) == 32'b11111111111111111111111110010111, (instruction | 32'b11111111111111111000111110000000) == 32'b11111111111111111000111110010011, (instruction | 32'b00000011111111111000111110000000) == 32'b00000011111111111001111110010011, (instruction | 32'b11111111111111111000111110000000) == 32'b11111111111111111010111110010011, (instruction | 32'b11111111111111111000111110000000) == 32'b11111111111111111011111110010011, (instruction | 32'b11111111111111111000111110000000) == 32'b11111111111111111100111110010011, (instruction | 32'b00000011111111111000111110000000) == 32'b00000011111111111101111110010011, (instruction | 32'b00000011111111111000111110000000) == 32'b01000011111111111101111110010011, (instruction | 32'b11111111111111111000111110000000) == 32'b11111111111111111110111110010011, (instruction | 32'b11111111111111111000111110000000) == 32'b11111111111111111111111110010011, (instruction | 32'b00000001111111111000111110000000) == 32'b00000001111111111000111110110011, (instruction | 32'b00000001111111111000111110000000) == 32'b01000001111111111000111110110011, (instruction | 32'b00000001111111111000111110000000) == 32'b00000001111111111001111110110011, (instruction | 32'b00000001111111111000111110000000) == 32'b00000001111111111010111110110011, (instruction | 32'b00000001111111111000111110000000) == 32'b00000001111111111011111110110011, (instruction | 32'b00000001111111111000111110000000) == 32'b00000001111111111100111110110011, (instruction | 32'b00000001111111111000111110000000) == 32'b00000001111111111101111110110011, (instruction | 32'b00000001111111111000111110000000) == 32'b01000001111111111101111110110011, (instruction | 32'b00000001111111111000111110000000) == 32'b00000001111111111110111110110011, (instruction | 32'b00000001111111111000111110000000) == 32'b00000001111111111111111110110011, (instruction | 32'b11111111111111111000111110000000) == 32'b11111111111111111000111110000011, (instruction | 32'b11111111111111111000111110000000) == 32'b11111111111111111001111110000011, (instruction | 32'b11111111111111111000111110000000) == 32'b11111111111111111010111110000011, (instruction | 32'b11111111111111111000111110000000) == 32'b11111111111111111100111110000011, (instruction | 32'b11111111111111111000111110000000) == 32'b11111111111111111101111110000011, (instruction | 32'b11111111111111111000111110000000) == 32'b11111111111111111000111110100011, (instruction | 32'b11111111111111111000111110000000) == 32'b11111111111111111001111110100011, (instruction | 32'b11111111111111111000111110000000) == 32'b11111111111111111010111110100011, (instruction | 32'b11111111111111111000111110000000) == 32'b11111111111111111000111110001111};
	assign csr_addr_base = |{instruction[31:20] == 12'h001, instruction[31:20] == 12'h002, instruction[31:20] == 12'h003, instruction[31:20] == 12'hc00, instruction[31:20] == 12'hc01, instruction[31:20] == 12'hc02, instruction[31:20] == 12'hc80, instruction[31:20] == 12'hc81, instruction[31:20] == 12'hc82};
	assign csr_addr_machine = |{instruction[31:20] == 12'hf11, instruction[31:20] == 12'hf12, instruction[31:20] == 12'hf13, instruction[31:20] == 12'hf14, instruction[31:20] == 12'h300, instruction[31:20] == 12'h301, instruction[31:20] == 12'h302, instruction[31:20] == 12'h303, instruction[31:20] == 12'h304, instruction[31:20] == 12'h305, instruction[31:20] == 12'h306, instruction[31:20] == 12'h340, instruction[31:20] == 12'h341, instruction[31:20] == 12'h342, instruction[31:20] == 12'h343, instruction[31:20] == 12'h344, instruction[31:20] == 12'hb00, instruction[31:20] == 12'hb02, instruction[31:20] == 12'hb80, instruction[31:20] == 12'hb82};
	assign csr_addr_supervisor = |{instruction[31:20] == 12'h100, instruction[31:20] == 12'h102, instruction[31:20] == 12'h103, instruction[31:20] == 12'h104, instruction[31:20] == 12'h105, instruction[31:20] == 12'h106, instruction[31:20] == 12'h140, instruction[31:20] == 12'h141, instruction[31:20] == 12'h142, instruction[31:20] == 12'h143, instruction[31:20] == 12'h144, instruction[31:20] == 12'h180};
	assign csr_addr_debug = |{instruction[31:20] == 12'h7b0, instruction[31:20] == 12'h7b1, instruction[31:20] == 12'h7b2};
	assign csr_legal = |{(instruction | 32'b11111111111111111000111110000000) == 32'b11111111111111111001111111110011, (instruction | 32'b11111111111111111000111110000000) == 32'b11111111111111111010111111110011, (instruction | 32'b11111111111111111000111110000000) == 32'b11111111111111111011111111110011, (instruction | 32'b11111111111111111000111110000000) == 32'b11111111111111111101111111110011, (instruction | 32'b11111111111111111000111110000000) == 32'b11111111111111111110111111110011, (instruction | 32'b11111111111111111000111110000000) == 32'b11111111111111111111111111110011} && ((csr_addr_base | (CONFIG[1209] & csr_addr_machine)) | (CONFIG[1208] & csr_addr_supervisor));
	assign mul_legal = |{(instruction | 32'b00000001111111111000111110000000) == 32'b00000011111111111000111110110011, (instruction | 32'b00000001111111111000111110000000) == 32'b00000011111111111001111110110011, (instruction | 32'b00000001111111111000111110000000) == 32'b00000011111111111010111110110011, (instruction | 32'b00000001111111111000111110000000) == 32'b00000011111111111011111110110011};
	assign div_legal = |{(instruction | 32'b00000001111111111000111110000000) == 32'b00000011111111111100111110110011, (instruction | 32'b00000001111111111000111110000000) == 32'b00000011111111111101111110110011, (instruction | 32'b00000001111111111000111110000000) == 32'b00000011111111111110111110110011, (instruction | 32'b00000001111111111000111110000000) == 32'b00000011111111111111111110110011};
	assign ifence_legal = (instruction | 32'b11111111111111111000111110000000) == 32'b11111111111111111001111110001111;
	assign amo_legal = |{(instruction | 32'b00000111111111111000111110000000) == 32'b00000111111111111010111110101111, (instruction | 32'b00000111111111111000111110000000) == 32'b00100111111111111010111110101111, (instruction | 32'b00000111111111111000111110000000) == 32'b01000111111111111010111110101111, (instruction | 32'b00000111111111111000111110000000) == 32'b01100111111111111010111110101111, (instruction | 32'b00000111111111111000111110000000) == 32'b10000111111111111010111110101111, (instruction | 32'b00000111111111111000111110000000) == 32'b10100111111111111010111110101111, (instruction | 32'b00000111111111111000111110000000) == 32'b11000111111111111010111110101111, (instruction | 32'b00000111111111111000111110000000) == 32'b11100111111111111010111110101111, (instruction | 32'b00000111111111111000111110000000) == 32'b00001111111111111010111110101111, (instruction | 32'b00000110000011111000111110000000) == 32'b00010110000011111010111110101111, (instruction | 32'b00000111111111111000111110000000) == 32'b00011111111111111010111110101111};
	assign machine_legal = |{instruction == MRET, instruction == ECALL, instruction == EBREAK};
	assign supervisor_legal = |{instruction == SRET, (instruction | 32'b00000001111111111000000000000000) == 32'b00010011111111111000000001110011, instruction == WFI};
	assign illegal_instruction = ~(((((((base_legal | (CONFIG[1202] & csr_legal)) | (CONFIG[1206] & mul_legal)) | (CONFIG[1205] & div_legal)) | (CONFIG[1201] & amo_legal)) | (CONFIG[1203] & ifence_legal)) | (CONFIG[1209] & machine_legal)) | (CONFIG[1208] & supervisor_legal));
endmodule
module register_bank (
	clk,
	rst,
	write_addr,
	new_data,
	commit,
	read_addr,
	data
);
	parameter NUM_READ_PORTS = 2;
	input wire clk;
	input wire rst;
	input wire [5:0] write_addr;
	input wire [31:0] new_data;
	input wire commit;
	input wire [(NUM_READ_PORTS * 6) - 1:0] read_addr;
	output wire [(NUM_READ_PORTS * 32) - 1:0] data;
	reg [31:0] register_file_bank [0:63];
	initial begin : sv2v_autoblock_1
		integer isaac_init;
		for (isaac_init = 0; isaac_init < 64; isaac_init = isaac_init + 1)
			register_file_bank[isaac_init] = 1'sb0;
	end
	always @(posedge clk)
		if (commit)
			register_file_bank[write_addr] <= new_data;
	genvar _gv_i_16;
	generate
		for (_gv_i_16 = 0; _gv_i_16 < NUM_READ_PORTS; _gv_i_16 = _gv_i_16 + 1) begin : genblk1
			localparam i = _gv_i_16;
			assign data[((NUM_READ_PORTS - 1) - i) * 32+:32] = register_file_bank[read_addr[((NUM_READ_PORTS - 1) - i) * 6+:6]];
		end
	endgenerate
endmodule
module l2_reservation_logic (
	clk,
	rst,
	addr,
	id,
	strobe,
	lr,
	sc,
	store,
	abort_request
);
	reg _sv2v_0;
	input wire clk;
	input wire rst;
	input wire [31:2] addr;
	localparam l2_config_and_types_L2_NUM_PORTS = 2;
	input wire [0:0] id;
	input wire strobe;
	input wire lr;
	input wire sc;
	input wire store;
	output wire abort_request;
	reg [31:2] reservation_address [1:0];
	reg [1:0] reservation;
	reg [1:0] address_match;
	reg [1:0] revoke_reservation;
	always @(*) begin
		if (_sv2v_0)
			;
		begin : sv2v_autoblock_1
			reg signed [31:0] i;
			for (i = 0; i < l2_config_and_types_L2_NUM_PORTS; i = i + 1)
				begin
					address_match[i] = reservation_address[i] == addr;
					revoke_reservation[i] = sc | (store & address_match[i]);
				end
		end
	end
	always @(posedge clk) begin : sv2v_autoblock_2
		reg signed [31:0] i;
		for (i = 0; i < l2_config_and_types_L2_NUM_PORTS; i = i + 1)
			if (rst)
				reservation[i] <= 0;
			else if (strobe) begin
				if (revoke_reservation[i])
					reservation[i] <= 0;
				else if (lr)
					reservation[i] <= 1;
			end
	end
	always @(posedge clk)
		if (strobe & lr)
			reservation_address[id] <= addr;
	assign abort_request = sc && (~reservation[id] || (reservation[id] && ~address_match[id]));
	initial _sv2v_0 = 0;
endmodule
module cva5_wrapper (
	clk,
	rst,
	instruction_bram_addr,
	instruction_bram_en,
	instruction_bram_we,
	instruction_bram_din,
	instruction_bram_dout,
	data_bram_addr,
	data_bram_en,
	data_bram_we,
	data_bram_din,
	data_bram_dout,
	m_axi_awvalid,
	m_axi_awready,
	m_axi_awid,
	m_axi_awaddr,
	m_axi_awlen,
	m_axi_awsize,
	m_axi_awburst,
	m_axi_awcache,
	m_axi_wvalid,
	m_axi_wready,
	m_axi_wdata,
	m_axi_wstrb,
	m_axi_wlast,
	m_axi_bvalid,
	m_axi_bready,
	m_axi_bresp,
	m_axi_bid,
	m_axi_arvalid,
	m_axi_arready,
	m_axi_arid,
	m_axi_araddr,
	m_axi_arlen,
	m_axi_arsize,
	m_axi_arburst,
	m_axi_arcache,
	m_axi_rvalid,
	m_axi_rready,
	m_axi_rid,
	m_axi_rdata,
	m_axi_rresp,
	m_axi_rlast,
	axi_awvalid,
	axi_awready,
	axi_awid,
	axi_awaddr,
	axi_awlen,
	axi_awsize,
	axi_awburst,
	axi_awcache,
	axi_awprot,
	axi_wvalid,
	axi_wready,
	axi_wdata,
	axi_wstrb,
	axi_wlast,
	axi_bvalid,
	axi_bready,
	axi_bresp,
	axi_bid,
	axi_arvalid,
	axi_arready,
	axi_arid,
	axi_araddr,
	axi_arlen,
	axi_arsize,
	axi_arburst,
	axi_arcache,
	axi_arprot,
	axi_rvalid,
	axi_rready,
	axi_rid,
	axi_rdata,
	axi_rresp,
	axi_rlast,
	timer_interrupt,
	interrupt,
	RdPipeInto_stage_executesv1_2_o,
	RdPipeInto_stage_executecva_2_o,
	glueToSCAL_IValid_cond_all_1_o,
	glueToSCAL_IValid_cond_all_2_o,
	glueToSCAL_IValid_cond_all_3_o,
	glueToSCAL_WrRD_spawn_addr_2_o,
	glueToSCAL_WrRD_spawn_addr_1_o
);
	input wire clk;
	input wire rst;
	output wire [31:0] instruction_bram_addr;
	output wire instruction_bram_en;
	output wire [3:0] instruction_bram_we;
	output wire [31:0] instruction_bram_din;
	input wire [31:0] instruction_bram_dout;
	output wire [31:0] data_bram_addr;
	output wire data_bram_en;
	output wire [3:0] data_bram_we;
	output wire [31:0] data_bram_din;
	input wire [31:0] data_bram_dout;
	output wire m_axi_awvalid;
	input wire m_axi_awready;
	output wire [5:0] m_axi_awid;
	output wire [31:0] m_axi_awaddr;
	output wire [7:0] m_axi_awlen;
	output wire [2:0] m_axi_awsize;
	output wire [1:0] m_axi_awburst;
	output wire [3:0] m_axi_awcache;
	output wire m_axi_wvalid;
	input wire m_axi_wready;
	output wire [31:0] m_axi_wdata;
	output wire [3:0] m_axi_wstrb;
	output wire m_axi_wlast;
	input wire m_axi_bvalid;
	output wire m_axi_bready;
	input wire [1:0] m_axi_bresp;
	input wire [5:0] m_axi_bid;
	output wire m_axi_arvalid;
	input wire m_axi_arready;
	output wire [5:0] m_axi_arid;
	output wire [31:0] m_axi_araddr;
	output wire [7:0] m_axi_arlen;
	output wire [2:0] m_axi_arsize;
	output wire [1:0] m_axi_arburst;
	output wire [3:0] m_axi_arcache;
	input wire m_axi_rvalid;
	output wire m_axi_rready;
	input wire [5:0] m_axi_rid;
	input wire [31:0] m_axi_rdata;
	input wire [1:0] m_axi_rresp;
	input wire m_axi_rlast;
	output wire axi_awvalid;
	input wire axi_awready;
	output wire [5:0] axi_awid;
	output wire [31:0] axi_awaddr;
	output wire [7:0] axi_awlen;
	output wire [2:0] axi_awsize;
	output wire [1:0] axi_awburst;
	output wire [3:0] axi_awcache;
	output wire [2:0] axi_awprot;
	output wire axi_wvalid;
	input wire axi_wready;
	output wire [31:0] axi_wdata;
	output wire [3:0] axi_wstrb;
	output wire axi_wlast;
	input wire axi_bvalid;
	output wire axi_bready;
	input wire [1:0] axi_bresp;
	input wire [5:0] axi_bid;
	output wire axi_arvalid;
	input wire axi_arready;
	output wire [5:0] axi_arid;
	output wire [31:0] axi_araddr;
	output wire [7:0] axi_arlen;
	output wire [2:0] axi_arsize;
	output wire [1:0] axi_arburst;
	output wire [3:0] axi_arcache;
	output wire [2:0] axi_arprot;
	input wire axi_rvalid;
	output wire axi_rready;
	input wire [5:0] axi_rid;
	input wire [31:0] axi_rdata;
	input wire [1:0] axi_rresp;
	input wire axi_rlast;
	input wire timer_interrupt;
	input wire interrupt;
	output wire RdPipeInto_stage_executesv1_2_o;
	output wire RdPipeInto_stage_executecva_2_o;
	output wire glueToSCAL_IValid_cond_all_1_o;
	output wire glueToSCAL_IValid_cond_all_2_o;
	output wire glueToSCAL_IValid_cond_all_3_o;
	output wire [12:0] glueToSCAL_WrRD_spawn_addr_2_o;
	output wire [12:0] glueToSCAL_WrRD_spawn_addr_1_o;
	generate
		if (1) begin : instruction_bram
			wire [29:0] addr;
			wire en;
			wire [3:0] be;
			wire [31:0] data_in;
			wire [31:0] data_out;
		end
	endgenerate
	assign instruction_bram_addr = {instruction_bram.addr[29:0], 2'b00};
	assign instruction_bram_en = instruction_bram.en;
	assign instruction_bram_we = instruction_bram.be;
	assign instruction_bram_din = instruction_bram.data_in;
	assign instruction_bram.data_out = instruction_bram_dout;
	generate
		if (1) begin : data_bram
			wire [29:0] addr;
			wire en;
			wire [3:0] be;
			wire [31:0] data_in;
			wire [31:0] data_out;
		end
	endgenerate
	assign data_bram_addr = {data_bram.addr[29:0], 2'b00};
	assign data_bram_en = data_bram.en;
	assign data_bram_we = data_bram.be;
	assign data_bram_din = data_bram.data_in;
	assign data_bram.data_out = data_bram_dout;
	generate
		if (1) begin : m_axi
			wire arready;
			wire arvalid;
			localparam cva5_config_C_M_AXI_ADDR_WIDTH = 32;
			reg [31:0] araddr;
			wire [7:0] arlen;
			reg [2:0] arsize;
			wire [1:0] arburst;
			wire [3:0] arcache;
			wire [5:0] arid;
			wire rready;
			wire rvalid;
			localparam cva5_config_C_M_AXI_DATA_WIDTH = 32;
			wire [31:0] rdata;
			wire [1:0] rresp;
			wire rlast;
			wire [5:0] rid;
			wire awready;
			wire awvalid;
			reg [31:0] awaddr;
			wire [7:0] awlen;
			reg [2:0] awsize;
			wire [1:0] awburst;
			wire [3:0] awcache;
			wire [5:0] awid;
			wire wready;
			wire wvalid;
			reg [31:0] wdata;
			reg [3:0] wstrb;
			wire wlast;
			wire bready;
			wire bvalid;
			wire [1:0] bresp;
			wire [5:0] bid;
		end
	endgenerate
	assign m_axi_awvalid = m_axi.awvalid;
	assign m_axi.awready = m_axi_awready;
	assign m_axi_awid = m_axi.awid;
	assign m_axi_awaddr = m_axi.awaddr;
	assign m_axi_awlen = m_axi.awlen;
	assign m_axi_awsize = m_axi.awsize;
	assign m_axi_awburst = m_axi.awburst;
	assign m_axi_awcache = m_axi.awcache;
	assign m_axi_wvalid = m_axi.wvalid;
	assign m_axi.wready = m_axi_wready;
	assign m_axi_wdata = m_axi.wdata;
	assign m_axi_wstrb = m_axi.wstrb;
	assign m_axi_wlast = m_axi.wlast;
	assign m_axi.bvalid = m_axi_bvalid;
	assign m_axi_bready = m_axi.bready;
	assign m_axi.bresp = m_axi_bresp;
	assign m_axi.bid = m_axi_bid;
	assign m_axi_arvalid = m_axi.arvalid;
	assign m_axi.arready = m_axi_arready;
	assign m_axi_arid = m_axi.arid;
	assign m_axi_araddr = m_axi.araddr;
	assign m_axi_arlen = m_axi.arlen;
	assign m_axi_arsize = m_axi.arsize;
	assign m_axi_arburst = m_axi.arburst;
	assign m_axi_arcache = m_axi.arcache;
	assign m_axi.rvalid = m_axi_rvalid;
	assign m_axi_rready = m_axi.rready;
	assign m_axi.rid = m_axi_rid;
	assign m_axi.rdata = m_axi_rdata;
	assign m_axi.rresp = m_axi_rresp;
	assign m_axi.rlast = m_axi_rlast;
	assign axi_awid = 0;
	generate
		if (1) begin : m_avalon
			reg [31:0] addr;
			reg read;
			reg write;
			reg [3:0] byteenable;
			wire [31:0] readdata;
			reg [31:0] writedata;
			wire waitrequest;
			wire readdatavalid;
			wire writeresponsevalid;
		end
		if (1) begin : dwishbone
			reg [29:0] adr;
			reg [31:0] dat_w;
			reg [3:0] sel;
			wire cyc;
			wire stb;
			reg we;
			wire [2:0] cti;
			wire [1:0] bte;
			wire [31:0] dat_r;
			wire ack;
			wire err;
		end
		if (1) begin : iwishbone
			reg [29:0] adr;
			reg [31:0] dat_w;
			reg [3:0] sel;
			wire cyc;
			wire stb;
			reg we;
			wire [2:0] cti;
			wire [1:0] bte;
			wire [31:0] dat_r;
			wire ack;
			wire err;
		end
	endgenerate
	localparam l2_config_and_types_L2_NUM_PORTS = 2;
	genvar _arr_C9364;
	generate
		for (_arr_C9364 = 1; _arr_C9364 >= 0; _arr_C9364 = _arr_C9364 - 1) begin : l2
			wire [29:0] addr;
			wire [3:0] be;
			wire rnw;
			wire is_amo;
			wire [4:0] amo_type_or_burst_size;
			localparam l2_config_and_types_L2_SUB_ID_W = 2;
			wire [1:0] sub_id;
			wire request_push;
			wire request_full;
			wire [31:2] inv_addr;
			wire inv_valid;
			wire inv_ack;
			reg con_result;
			reg con_valid;
			wire [31:0] wr_data;
			wire wr_data_push;
			wire data_full;
			wire [31:0] rd_data;
			wire [1:0] rd_sub_id;
			wire rd_data_valid;
			wire rd_data_ack;
		end
	endgenerate
	assign l2[1].request_push = 0;
	assign l2[1].wr_data_push = 0;
	assign l2[1].inv_ack = l2[1].inv_valid;
	assign l2[1].rd_data_ack = l2[1].rd_data_valid;
	generate
		if (1) begin : arb_mem
			localparam l2_config_and_types_L2_NUM_PORTS = 2;
			localparam l2_config_and_types_L2_SUB_ID_W = 2;
			localparam L2_ID_W = 3;
			wire [29:0] addr;
			wire [3:0] be;
			wire rnw;
			wire is_amo;
			wire [4:0] amo_type_or_burst_size;
			wire [2:0] id;
			wire request_pop;
			wire request_valid;
			wire abort_request;
			wire [31:0] wr_data;
			wire wr_data_valid;
			wire wr_data_read;
			wire [31:0] rd_data;
			wire [2:0] rd_id;
			wire rd_data_valid;
		end
	endgenerate
	wire [89:0] tr;
	wire [2:0] m_interrupt;
	assign m_interrupt[2] = 1'b0;
	assign m_interrupt[1] = timer_interrupt;
	assign m_interrupt[0] = interrupt;
	generate
		if (1) begin : scaiev
			localparam cva5_config_MAX_IDS_FETCH = 8;
			localparam LOG2_MAX_IDS_FETCH = 3;
			localparam cva5_config_MAX_IDS = 8;
			localparam LOG2_MAX_IDS = 3;
			wire [31:0] pre_fetch_PC;
			wire pre_fetch_isStalling;
			wire [31:0] fetch_PC;
			wire fetch_valid;
			wire [2:0] fetch_fetchID;
			wire fetch_isStalling;
			wire fetch_stall;
			wire fetch_isFlushing;
			wire fetch_isFlushing_internal;
			wire fetch_flush;
			wire [2:0] fetch_fetchFlushID;
			wire [3:0] fetch_fetchFlushCount;
			reg [31:0] fetch_wrPC;
			reg fetch_wrPCValid;
			wire [31:0] decode_PC;
			wire [31:0] decode_Instr;
			wire decode_valid;
			wire [2:0] decode_fetchID;
			wire decode_RS1_valid;
			wire [4:0] decode_RS1_id;
			wire decode_RS2_valid;
			wire [4:0] decode_RS2_id;
			wire decode_RD_AS_RS_valid;
			wire [4:0] decode_RD_AS_RS_id;
			wire decode_RD_valid;
			wire [4:0] decode_RD_id;
			wire decode_isSCAIEV;
			wire decode_isSCAIEV_stdencoding;
			wire decode_isSCAIEV_usesRS1;
			wire decode_isSCAIEV_usesRS2;
			wire decode_isSCAIEV_usesRD_AS_RS;
			wire decode_isSCAIEV_usesRD;
			wire decode_isSCAIEV_usesRD_decoupled;
			wire decode_isStalling;
			wire decode_stall;
			wire decode_isFlushing;
			wire decode_isFlushing_internal;
			wire decode_flush;
			wire decode_wrReg;
			wire [4:0] decode_wrReg_RD;
			wire [31:0] decode_wrReg_data;
			wire decode_rdReg;
			wire [4:0] decode_rdReg_RS1;
			wire [4:0] decode_rdReg_RS2;
			wire [4:0] decode_rdReg_RD_AS_RS;
			wire decode_repeat_next;
			wire decode_RS1_override;
			wire decode_RS2_override;
			wire decode_RD_AS_RS_override;
			wire decode_skip_wb;
			wire [5:0] decode_phys_RD_decoupled;
			wire [6:0] decode_prev_phys_RD_decoupled;
			wire [5:0] issue_phys_RD_decoupled;
			wire [6:0] issue_prev_phys_RD_decoupled;
			reg rf_wrReg;
			reg rf_wrReg_cancel;
			reg [5:0] rf_wrReg_phys_RD;
			reg [6:0] rf_wrReg_prev_phys_RD;
			reg [31:0] rf_wrReg_data;
			wire rf_ready;
			reg rf_isDecoupledWB;
			wire renamer_addtofree_valid;
			wire [5:0] renamer_addtofree_reg;
			wire renamer_addtofree_skip;
			wire [2:0] issue_ID;
			wire [2:0] issue_flushID;
			wire [31:0] issue_PC;
			wire [31:0] issue_Instr;
			wire issue_RS1_valid;
			wire [31:0] issue_RS1;
			wire issue_RS2_valid;
			wire [31:0] issue_RS2;
			wire issue_RD_AS_RS_valid;
			wire [31:0] issue_RD_AS_RS;
			wire issue_RD_valid;
			wire [4:0] issue_RD_id;
			wire issue_valid;
			wire issue_injected;
			wire issue_isSCAIEV;
			wire issue_isLS;
			wire issue_isStalling;
			wire issue_stall;
			wire issue_isFlushing;
			wire issue_isFlushing_internal;
			wire issue_flush;
			wire issue_injectLS_potentiallyValid;
			wire issue_injectLS_valid;
			wire issue_injectLS_rnw;
			wire issue_injectLS_relaxedOrdering;
			wire [31:0] issue_injectLS_addr;
			wire [31:0] issue_injectLS_storeVal;
			wire issue_injectLS_done;
			wire [31:0] execute_PC;
			wire [31:0] execute_Instr;
			wire [31:0] execute_RS1;
			wire [31:0] execute_RS2;
			wire [31:0] execute_RD_AS_RS;
			wire [2:0] execute_ID;
			wire [2:0] execute_ID_or_counter;
			wire execute_expects_rd;
			wire execute_valid;
			wire execute_flush;
			wire execute_stall;
			wire execute_isStalling;
			wire execute_isStalling_reason_isax;
			wire execute_isStalling_reason_core;
			wire execute_wrRD;
			wire [31:0] execute_wrRD_data;
			wire execute_deq;
			wire execute_commitNow;
			wire [2:0] execute_commitNow_ID;
			wire execute_commitNow_expects_rd;
			wire execute_commitNow_resp;
			reg execute_injectLS_potentiallyValid;
			reg execute_injectLS_valid;
			reg execute_injectLS_rnw;
			reg execute_injectLS_relaxedOrdering;
			reg [31:0] execute_injectLS_addr;
			reg [31:0] execute_injectLS_storeVal;
			wire execute_injectLS_done;
			wire injectLS_ready;
			wire [31:0] injectLS_readData;
			wire no_writebacks_pending;
			wire [2:0] retire_ID;
			wire [1:0] retire_count;
			wire retire_suppress;
		end
	endgenerate
	localparam _bbase_BB657_l2 = 0;
	function automatic signed [1:0] sv2v_cast_2_signed;
		input reg signed [1:0] inp;
		sv2v_cast_2_signed = inp;
	endfunction
	function automatic [2:0] sv2v_cast_3;
		input reg [2:0] inp;
		sv2v_cast_3 = inp;
	endfunction
	function automatic signed [2:0] sv2v_cast_3_signed;
		input reg signed [2:0] inp;
		sv2v_cast_3_signed = inp;
	endfunction
	function automatic [3:0] sv2v_cast_4;
		input reg [3:0] inp;
		sv2v_cast_4 = inp;
	endfunction
	function automatic signed [3:0] sv2v_cast_4_signed;
		input reg signed [3:0] inp;
		sv2v_cast_4_signed = inp;
	endfunction
	function automatic [1:0] sv2v_cast_2;
		input reg [1:0] inp;
		sv2v_cast_2 = inp;
	endfunction
	function automatic [63:0] sv2v_cast_64;
		input reg [63:0] inp;
		sv2v_cast_64 = inp;
	endfunction
	function automatic [4:0] sv2v_cast_5;
		input reg [4:0] inp;
		sv2v_cast_5 = inp;
	endfunction
	function automatic [5:0] sv2v_cast_6;
		input reg [5:0] inp;
		sv2v_cast_6 = inp;
	endfunction
	function automatic signed [31:0] sv2v_cast_32_signed;
		input reg signed [31:0] inp;
		sv2v_cast_32_signed = inp;
	endfunction
	function automatic signed [20:0] sv2v_cast_21_signed;
		input reg signed [20:0] inp;
		sv2v_cast_21_signed = inp;
	endfunction
	function automatic [0:0] sv2v_cast_1;
		input reg [0:0] inp;
		sv2v_cast_1 = inp;
	endfunction
	function automatic [31:0] sv2v_cast_32;
		input reg [31:0] inp;
		sv2v_cast_32 = inp;
	endfunction
	function automatic signed [63:0] sv2v_cast_64_signed;
		input reg signed [63:0] inp;
		sv2v_cast_64_signed = inp;
	endfunction
	function automatic [6:0] sv2v_cast_7;
		input reg [6:0] inp;
		sv2v_cast_7 = inp;
	endfunction
	generate
		if (1) begin : cva5
			localparam [1209:0] cva5_config_EXAMPLE_CONFIG = 1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002;
			localparam [1209:0] CONFIG = cva5_config_EXAMPLE_CONFIG;
			wire clk;
			wire rst;
			reg [89:0] tr;
			localparam _mbase_l2 = _bbase_BB657_l2;
			wire [2:0] s_interrupt;
			wire [2:0] m_interrupt;
			localparam [31:0] ALU_UNIT_ID = 32'd0;
			localparam [31:0] LS_UNIT_ID = 32'd1;
			localparam [31:0] CSR_UNIT_ID = LS_UNIT_ID + sv2v_cast_32_signed(CONFIG[1202]);
			localparam [31:0] MUL_UNIT_ID = CSR_UNIT_ID + sv2v_cast_32_signed(CONFIG[1206]);
			localparam [31:0] DIV_UNIT_ID = MUL_UNIT_ID + sv2v_cast_32_signed(CONFIG[1205]);
			localparam [31:0] SCAIEV_UNIT_ID = DIV_UNIT_ID + sv2v_cast_32_signed(CONFIG[1204]);
			localparam [31:0] BRANCH_UNIT_ID = SCAIEV_UNIT_ID + 1;
			localparam [31:0] IEC_UNIT_ID = BRANCH_UNIT_ID + 1;
			localparam [31:0] NUM_UNITS = IEC_UNIT_ID + 1;
			localparam [255:0] UNIT_IDS = {ALU_UNIT_ID, LS_UNIT_ID, CSR_UNIT_ID, MUL_UNIT_ID, DIV_UNIT_ID, SCAIEV_UNIT_ID, BRANCH_UNIT_ID, IEC_UNIT_ID};
			localparam [31:0] NUM_WB_UNITS_GROUP_1 = 1;
			localparam [31:0] NUM_WB_UNITS_GROUP_2 = (((1 + sv2v_cast_32_signed(CONFIG[1202])) + sv2v_cast_32_signed(CONFIG[1206])) + sv2v_cast_32_signed(CONFIG[1205])) + sv2v_cast_32_signed(CONFIG[1204]);
			localparam [31:0] NUM_WB_UNITS = NUM_WB_UNITS_GROUP_1 + NUM_WB_UNITS_GROUP_2;
			localparam cva5_config_L1_CONNECTIONS = 4;
			genvar _arr_12B49;
			for (_arr_12B49 = 3; _arr_12B49 >= 0; _arr_12B49 = _arr_12B49 - 1) begin : l1_request
				reg [31:0] addr;
				wire [31:0] data;
				wire rnw;
				wire [3:0] be;
				wire [4:0] size;
				wire is_amo;
				wire [4:0] amo;
				wire request;
				wire ack;
			end
			genvar _arr_727F0;
			for (_arr_727F0 = 3; _arr_727F0 >= 0; _arr_727F0 = _arr_727F0 - 1) begin : l1_response
				wire [31:2] inv_addr;
				wire inv_valid;
				wire inv_ack;
				wire [31:0] data;
				wire data_valid;
			end
			wire sc_complete;
			wire sc_success;
			if (1) begin : bp
				wire [31:0] if_pc;
				localparam cva5_config_MAX_IDS_FETCH = 8;
				localparam cva5_types_LOG2_MAX_IDS_FETCH = 3;
				wire [2:0] if_id;
				wire new_mem_request;
				wire [31:0] next_pc;
				wire [2:0] pc_id;
				wire pc_id_assigned;
				wire [31:0] branch_flush_pc;
				wire [31:0] predicted_pc;
				wire use_prediction;
				wire is_return;
				wire is_call;
				wire is_branch;
			end
			localparam cva5_config_MAX_IDS_FETCH = 8;
			localparam cva5_types_LOG2_MAX_IDS_FETCH = 3;
			localparam cva5_config_MAX_IDS = 8;
			localparam cva5_types_LOG2_MAX_IDS = 3;
			wire [74:0] br_results_branch;
			wire branch_flush_branch;
			wire potential_branch_exception;
			if (1) begin : br_exception
				reg valid;
				wire ack;
				localparam riscv_types_ECODE_W = 5;
				wire [4:0] code;
				localparam cva5_config_MAX_IDS = 8;
				localparam cva5_types_LOG2_MAX_IDS = 3;
				reg [2:0] id;
				wire [31:0] tval;
			end
			wire branch_exception_is_jump;
			if (1) begin : ras
				wire push;
				wire pop;
				wire branch_fetched;
				wire branch_retired;
				wire valid;
				wire [31:0] new_addr;
				wire [31:0] addr;
			end
			localparam riscv_types_ECODE_W = 5;
			wire [101:0] issue;
			localparam _param_6E3F8_NUM_WB_GROUPS = CONFIG[31-:32];
			if (1) begin : rf_issue
				localparam NUM_WB_GROUPS = _param_6E3F8_NUM_WB_GROUPS;
				localparam scaiev_config_ENABLE_NATIVE_RD_AS_RS = 0;
				localparam cva5_config_REGFILE_READ_PORTS = (scaiev_config_ENABLE_NATIVE_RD_AS_RS ? 3 : 2);
				wire [(cva5_config_REGFILE_READ_PORTS * 6) - 1:0] phys_rs_addr;
				wire [(cva5_config_REGFILE_READ_PORTS * $clog2(NUM_WB_GROUPS)) - 1:0] rs_wb_group;
				reg [31:0] data [0:cva5_config_REGFILE_READ_PORTS - 1];
				wire inuse [0:cva5_config_REGFILE_READ_PORTS - 1];
				wire [5:0] phys_rd_addr;
				wire single_cycle_or_flush;
			end
			localparam riscv_types_XLEN = 32;
			wire [141:0] alu_inputs;
			wire [98:0] ls_inputs;
			wire [162:0] branch_inputs;
			wire [65:0] mul_inputs;
			wire [66:0] div_inputs;
			wire [34:0] gc_inputs;
			wire [47:0] csr_inputs;
			wire [160:0] scaiev_inputs;
			genvar _arr_B7335;
			for (_arr_B7335 = NUM_UNITS - 1; _arr_B7335 >= 0; _arr_B7335 = _arr_B7335 - 1) begin : unit_issue
				wire possible_issue;
				wire new_request;
				localparam cva5_config_MAX_IDS = 8;
				localparam cva5_types_LOG2_MAX_IDS = 3;
				wire [2:0] id;
				wire ready;
			end
			wire [72:0] ls_exception;
			wire ls_exception_is_store;
			genvar _arr_3B905;
			for (_arr_3B905 = 0; _arr_3B905 <= (NUM_WB_UNITS - 1); _arr_3B905 = _arr_3B905 + 1) begin : unit_wb
				wire ack;
				localparam cva5_config_MAX_IDS = 8;
				localparam cva5_types_LOG2_MAX_IDS = 3;
				reg [2:0] id;
				reg done;
				localparam riscv_types_XLEN = 32;
				wire [31:0] rd;
			end
			if (1) begin : immu
				wire request;
				wire execute;
				wire rnw;
				wire [31:0] virtual_address;
				wire write_entry;
				reg [19:0] upper_physical_address;
				wire is_fault;
				wire [21:0] satp_ppn;
				wire mxr;
				wire sum;
				wire [1:0] privilege;
			end
			if (1) begin : dmmu
				wire request;
				wire execute;
				wire rnw;
				wire [31:0] virtual_address;
				wire write_entry;
				reg [19:0] upper_physical_address;
				wire is_fault;
				wire [21:0] satp_ppn;
				wire mxr;
				wire sum;
				wire [1:0] privilege;
			end
			if (1) begin : itlb
				wire ready;
				wire new_request;
				wire done;
				wire [31:0] virtual_address;
				wire rnw;
				wire execute;
				wire is_fault;
				reg [31:0] physical_address;
			end
			if (1) begin : dtlb
				wire ready;
				wire new_request;
				wire done;
				wire [31:0] virtual_address;
				wire rnw;
				wire execute;
				wire is_fault;
				reg [31:0] physical_address;
			end
			wire tlb_on;
			localparam riscv_types_ASIDLEN = 9;
			wire [8:0] asid;
			wire scaiev_decode_inject;
			wire pc_inject_keep_for_repeat;
			wire pc_inject_is_repeat;
			if (1) begin : ls_unit_wb
				wire ack;
				localparam cva5_config_MAX_IDS = 8;
				localparam cva5_types_LOG2_MAX_IDS = 3;
				wire [2:0] id;
				wire done;
				localparam riscv_types_XLEN = 32;
				wire [31:0] rd;
			end
			if (1) begin : ls_unit_issue
				wire possible_issue;
				wire new_request;
				localparam cva5_config_MAX_IDS = 8;
				localparam cva5_types_LOG2_MAX_IDS = 3;
				wire [2:0] id;
				wire ready;
			end
			if (1) begin : ls_issue_scaiev
				wire possible_issue;
				wire new_request;
				localparam cva5_config_MAX_IDS = 8;
				localparam cva5_types_LOG2_MAX_IDS = 3;
				wire [2:0] id;
				wire ready;
			end
			if (1) begin : ls_wb_scaiev
				wire ack;
				localparam cva5_config_MAX_IDS = 8;
				localparam cva5_types_LOG2_MAX_IDS = 3;
				wire [2:0] id;
				wire done;
				localparam riscv_types_XLEN = 32;
				wire [31:0] rd;
			end
			wire [98:0] ls_inputs_scaiev;
			wire [74:0] br_results;
			wire branch_flush;
			wire [98:0] ls_inputs_actual;
			wire [1:0] ls_wb_scaiev_meta;
			wire [1:0] ls_issue_scaiev_meta;
			wire scaiev_stall_issue;
			wire [74:0] br_results_scaiev;
			wire br_results_scaiev_override;
			wire branch_flush_scaiev;
			if (1) begin : br_exception_scaiev
				reg valid;
				wire ack;
				localparam riscv_types_ECODE_W = 5;
				wire [4:0] code;
				localparam cva5_config_MAX_IDS = 8;
				localparam cva5_types_LOG2_MAX_IDS = 3;
				reg [2:0] id;
				wire [31:0] tval;
			end
			wire [2:0] pc_id;
			wire pc_id_available;
			wire pc_id_assigned;
			wire [31:0] if_pc;
			wire pc_inject_id_available;
			wire pc_inject_id_assigned;
			wire [2:0] fetch_id;
			wire fetch_complete;
			wire [31:0] fetch_instruction;
			wire early_branch_flush;
			wire early_branch_flush_ras_adjust;
			wire [5:0] fetch_metadata;
			wire decode_advance;
			wire [76:0] decode;
			wire decode_uses_rd;
			wire decode_uses_rd_decoupled;
			wire issue_uses_rd_decoupled;
			wire [4:0] decode_rd_addr;
			wire [1:0] decode_exception_unit;
			wire [5:0] decode_phys_rd_addr;
			localparam scaiev_config_ENABLE_NATIVE_RD_AS_RS = 0;
			localparam cva5_config_REGFILE_READ_PORTS = (scaiev_config_ENABLE_NATIVE_RD_AS_RS ? 3 : 2);
			wire [(cva5_config_REGFILE_READ_PORTS * 6) - 1:0] decode_phys_rs_addr;
			wire [(cva5_config_REGFILE_READ_PORTS * $clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32])) - 1:0] decode_rs_wb_group;
			localparam cva5_config_RETIRE_PORTS = 2;
			localparam cva5_types_LOG2_RETIRE_PORTS = 1;
			wire [5:0] retire;
			wire [5:0] retire_ids;
			wire [5:0] retire_ids_next;
			wire [0:1] retire_port_valid;
			wire [(CONFIG[31-:32] * 36) - 1:0] wb_packet;
			wire [(CONFIG[31-:32] * 42) - 1:0] commit_packet;
			wire [31:0] oldest_pc;
			localparam _param_55864_NUM_WB_GROUPS = CONFIG[31-:32];
			if (1) begin : decode_rename_interface
				localparam NUM_WB_GROUPS = _param_55864_NUM_WB_GROUPS;
				wire [4:0] rd_addr;
				localparam scaiev_config_ENABLE_NATIVE_RD_AS_RS = 0;
				localparam cva5_config_REGFILE_READ_PORTS = (scaiev_config_ENABLE_NATIVE_RD_AS_RS ? 3 : 2);
				wire [(cva5_config_REGFILE_READ_PORTS * 5) - 1:0] rs_addr;
				wire [$clog2(NUM_WB_GROUPS) - 1:0] rd_wb_group;
				wire uses_rd;
				localparam cva5_config_MAX_IDS = 8;
				localparam cva5_types_LOG2_MAX_IDS = 3;
				wire [2:0] id;
				wire [(cva5_config_REGFILE_READ_PORTS * 6) - 1:0] phys_rs_addr;
				wire [5:0] phys_rd_addr;
				wire [(cva5_config_REGFILE_READ_PORTS * $clog2(NUM_WB_GROUPS)) - 1:0] rs_wb_group;
			end
			localparam cva5_config_NUM_EXCEPTION_SOURCES = 3;
			genvar _arr_006DB;
			for (_arr_006DB = 0; _arr_006DB <= 2; _arr_006DB = _arr_006DB + 1) begin : exception
				reg valid;
				wire ack;
				localparam riscv_types_ECODE_W = 5;
				reg [4:0] code;
				localparam cva5_config_MAX_IDS = 8;
				localparam cva5_types_LOG2_MAX_IDS = 3;
				reg [2:0] id;
				reg [31:0] tval;
			end
			wire [1:0] current_exception_unit;
			wire [115:0] gc;
			wire [2:0] load_store_status;
			wire [cva5_types_LOG2_MAX_IDS:0] post_issue_count;
			wire [1:0] current_privilege;
			wire mret;
			wire sret;
			wire [31:0] epc;
			wire [31:0] exception_target_pc;
			wire interrupt_taken;
			wire interrupt_pending;
			wire processing_csr;
			wire illegal_instruction;
			wire instruction_issued;
			wire instruction_issued_with_rd;
			wire [39:0] wb_snoop;
			wire tr_early_branch_correction;
			wire tr_operand_stall;
			wire tr_unit_stall;
			wire tr_no_id_stall;
			wire tr_no_instruction_stall;
			wire tr_other_stall;
			wire tr_branch_operand_stall;
			wire tr_alu_operand_stall;
			wire tr_ls_operand_stall;
			wire tr_div_operand_stall;
			wire tr_alu_op;
			wire tr_branch_or_jump_op;
			wire tr_load_op;
			wire tr_store_op;
			wire tr_mul_op;
			wire tr_div_op;
			wire tr_misc_op;
			wire tr_instruction_issued_dec;
			wire [31:0] tr_instruction_pc_dec;
			wire [31:0] tr_instruction_data_dec;
			wire tr_branch_correct;
			wire tr_branch_misspredict;
			wire tr_return_correct;
			wire tr_return_misspredict;
			wire tr_load_conflict_delay;
			wire tr_rs1_forwarding_needed;
			wire tr_rs2_forwarding_needed;
			wire tr_rs1_and_rs2_forwarding_needed;
			if (CONFIG[1204]) begin : gen_scaiev_ls
				assign ls_unit_wb.ack = unit_wb[UNIT_IDS[223-:32]].ack | ls_wb_scaiev.ack;
				wire [3:1] sv2v_tmp_37E1F;
				assign sv2v_tmp_37E1F = ls_unit_wb.id;
				always @(*) unit_wb[UNIT_IDS[223-:32]].id = sv2v_tmp_37E1F;
				wire [1:1] sv2v_tmp_F67D7;
				assign sv2v_tmp_F67D7 = ~ls_wb_scaiev_meta[1] & ls_unit_wb.done;
				always @(*) unit_wb[UNIT_IDS[223-:32]].done = sv2v_tmp_F67D7;
				assign unit_wb[UNIT_IDS[223-:32]].rd = ls_unit_wb.rd;
				assign ls_wb_scaiev.id = ls_unit_wb.id;
				assign ls_wb_scaiev.done = ls_wb_scaiev_meta[1] & ls_unit_wb.done;
				assign ls_wb_scaiev.rd = ls_unit_wb.rd;
				assign ls_issue_scaiev.ready = ls_unit_issue.ready;
				assign unit_issue[UNIT_IDS[223-:32]].ready = ls_unit_issue.ready;
				assign ls_unit_issue.possible_issue = ls_issue_scaiev.possible_issue || unit_issue[UNIT_IDS[223-:32]].possible_issue;
				assign ls_unit_issue.new_request = (ls_issue_scaiev.possible_issue ? ls_issue_scaiev.new_request : unit_issue[UNIT_IDS[223-:32]].new_request);
				assign ls_unit_issue.id = (ls_issue_scaiev.possible_issue ? ls_issue_scaiev.id : unit_issue[UNIT_IDS[223-:32]].id);
				assign ls_inputs_actual = (ls_issue_scaiev.possible_issue ? ls_inputs_scaiev : ls_inputs);
				assign ls_issue_scaiev_meta[1] = ls_issue_scaiev.possible_issue;
			end
			else begin : genblk1
				assign ls_unit_wb.ack = unit_wb[UNIT_IDS[223-:32]].ack;
				wire [3:1] sv2v_tmp_37E1F;
				assign sv2v_tmp_37E1F = ls_unit_wb.id;
				always @(*) unit_wb[UNIT_IDS[223-:32]].id = sv2v_tmp_37E1F;
				wire [1:1] sv2v_tmp_E7D13;
				assign sv2v_tmp_E7D13 = ls_unit_wb.done;
				always @(*) unit_wb[UNIT_IDS[223-:32]].done = sv2v_tmp_E7D13;
				assign unit_wb[UNIT_IDS[223-:32]].rd = ls_unit_wb.rd;
				assign unit_issue[UNIT_IDS[223-:32]].ready = ls_unit_issue.ready;
				assign ls_unit_issue.possible_issue = unit_issue[UNIT_IDS[223-:32]].possible_issue;
				assign ls_unit_issue.new_request = unit_issue[UNIT_IDS[223-:32]].new_request;
				assign ls_unit_issue.id = unit_issue[UNIT_IDS[223-:32]].id;
				assign ls_inputs_actual = ls_inputs;
				assign ls_issue_scaiev_meta[1] = 0;
				assign ls_issue_scaiev_meta[0] = 1'sbx;
			end
			if (CONFIG[1204]) begin : gen_scaiev_branch
				assign branch_flush = branch_flush_branch | branch_flush_scaiev;
				assign br_results = (br_results_scaiev_override ? br_results_scaiev : br_results_branch);
				reg br_exception_scaiev_select;
				wire new_exception;
				assign new_exception = |br_results_scaiev[5:4] & branch_flush_scaiev;
				always @(posedge clk)
					if (rst) begin
						br_exception_scaiev.valid <= 0;
						br_exception_scaiev_select <= 0;
					end
					else begin
						br_exception_scaiev.valid <= (br_exception_scaiev.valid & ~br_exception_scaiev.ack) | new_exception;
						br_exception_scaiev_select <= (br_exception_scaiev_select & ~br_exception_scaiev.ack) | (new_exception & ~br_exception.valid);
					end
				reg [31:0] exception_tval_pc;
				always @(posedge clk)
					if (branch_flush_scaiev) begin
						br_exception_scaiev.id <= br_results_scaiev[74-:3];
						exception_tval_pc <= br_results_scaiev[35-:32];
					end
				function automatic [4:0] sv2v_cast_7C56A;
					input reg [4:0] inp;
					sv2v_cast_7C56A = inp;
				endfunction
				assign br_exception_scaiev.code = sv2v_cast_7C56A(5'd0);
				assign br_exception_scaiev.tval = exception_tval_pc;
				wire [1:1] sv2v_tmp_F916C;
				assign sv2v_tmp_F916C = br_exception_scaiev.valid | br_exception.valid;
				always @(*) exception[2'd1].valid = sv2v_tmp_F916C;
				wire [5:1] sv2v_tmp_85898;
				assign sv2v_tmp_85898 = (br_exception_scaiev_select ? br_exception_scaiev.code : br_exception.code);
				always @(*) exception[2'd1].code = sv2v_tmp_85898;
				wire [3:1] sv2v_tmp_8E712;
				assign sv2v_tmp_8E712 = (br_exception_scaiev_select ? br_exception_scaiev.id : br_exception.id);
				always @(*) exception[2'd1].id = sv2v_tmp_8E712;
				wire [32:1] sv2v_tmp_784DA;
				assign sv2v_tmp_784DA = (br_exception_scaiev_select ? br_exception_scaiev.tval : br_exception.tval);
				always @(*) exception[2'd1].tval = sv2v_tmp_784DA;
				assign br_exception_scaiev.ack = br_exception_scaiev_select & exception[2'd1].ack;
				assign br_exception.ack = ~br_exception_scaiev_select & exception[2'd1].ack;
			end
			else begin : genblk2
				assign branch_flush = branch_flush_branch;
				assign br_results = br_results_branch;
				wire [1:1] sv2v_tmp_EF281;
				assign sv2v_tmp_EF281 = 0;
				always @(*) br_exception_scaiev.valid = sv2v_tmp_EF281;
				wire [3:1] sv2v_tmp_B4806;
				assign sv2v_tmp_B4806 = 1'sbx;
				always @(*) br_exception_scaiev.id = sv2v_tmp_B4806;
				assign br_exception_scaiev.code = 1'sbx;
				assign br_exception_scaiev.tval = 1'sbx;
				wire [1:1] sv2v_tmp_90520;
				assign sv2v_tmp_90520 = br_exception.valid;
				always @(*) exception[2'd1].valid = sv2v_tmp_90520;
				wire [5:1] sv2v_tmp_6D7E6;
				assign sv2v_tmp_6D7E6 = br_exception.code;
				always @(*) exception[2'd1].code = sv2v_tmp_6D7E6;
				wire [3:1] sv2v_tmp_0165A;
				assign sv2v_tmp_0165A = br_exception.id;
				always @(*) exception[2'd1].id = sv2v_tmp_0165A;
				wire [32:1] sv2v_tmp_40F86;
				assign sv2v_tmp_40F86 = br_exception.tval;
				always @(*) exception[2'd1].tval = sv2v_tmp_40F86;
				assign br_exception.ack = exception[2'd1].ack;
			end
			assign cva5_wrapper.scaiev.fetch_fetchID = pc_id;
			assign cva5_wrapper.scaiev.fetch_isFlushing = ((cva5_wrapper.scaiev.fetch_flush || cva5_wrapper.scaiev.decode_flush) || cva5_wrapper.scaiev.issue_flush) || gc[111];
			assign cva5_wrapper.scaiev.fetch_isFlushing_internal = (cva5_wrapper.scaiev.decode_flush || cva5_wrapper.scaiev.issue_flush) || gc[111];
			assign cva5_wrapper.scaiev.decode_fetchID = decode[73-:3];
			assign cva5_wrapper.scaiev.decode_PC = decode[70-:32];
			assign cva5_wrapper.scaiev.decode_valid = decode[6];
			assign cva5_wrapper.scaiev.decode_Instr = decode[38-:32];
			assign cva5_wrapper.scaiev.decode_isFlushing = (cva5_wrapper.scaiev.decode_flush || cva5_wrapper.scaiev.issue_flush) || gc[111];
			assign cva5_wrapper.scaiev.decode_isFlushing_internal = cva5_wrapper.scaiev.issue_flush || gc[111];
			assign cva5_wrapper.scaiev.issue_isFlushing = cva5_wrapper.scaiev.issue_flush || gc[111];
			assign cva5_wrapper.scaiev.issue_isFlushing_internal = gc[111];
			if ((CONFIG[1208] || CONFIG[1002]) || CONFIG[711]) begin : gen_l1_arbiter
				localparam _bbase_B204D_l2 = 0;
				localparam _bbase_B204D_l1_request = 0;
				localparam _bbase_B204D_l1_response = 0;
				localparam _param_B204D_CONFIG = CONFIG;
				if (1) begin : arb
					reg _sv2v_0;
					localparam [1209:0] cva5_config_EXAMPLE_CONFIG = 1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002;
					localparam [1209:0] CONFIG = _param_B204D_CONFIG;
					wire clk;
					wire rst;
					localparam _mbase_l2 = _bbase_B204D_l2;
					wire sc_complete;
					wire sc_success;
					localparam cva5_config_L1_CONNECTIONS = 4;
					localparam _mbase_l1_request = 0;
					localparam _mbase_l1_response = 0;
					localparam l2_config_and_types_L2_SUB_ID_W = 2;
					reg [171:0] l2_requests;
					wire [3:0] requests;
					reg [3:0] acks;
					wire [1:0] arb_sel;
					wire push_ready;
					wire request_exists;
					genvar _gv_i_23;
					for (_gv_i_23 = 0; _gv_i_23 < cva5_config_L1_CONNECTIONS; _gv_i_23 = _gv_i_23 + 1) begin : gen_requests
						localparam i = _gv_i_23;
						assign requests[i] = cva5_wrapper.cva5.l1_request[i + _mbase_l1_request].request;
						assign cva5_wrapper.cva5.l1_request[i + _mbase_l1_request].ack = acks[i];
					end
					assign cva5_wrapper.l2[_mbase_l2].rd_data_ack = cva5_wrapper.l2[_mbase_l2].rd_data_valid;
					assign sc_complete = CONFIG[1201] & cva5_wrapper.l2[_mbase_l2].con_valid;
					assign sc_success = CONFIG[1201] & cva5_wrapper.l2[_mbase_l2].con_result;
					assign push_ready = ~(cva5_wrapper.l2[_mbase_l2].request_full | cva5_wrapper.l2[_mbase_l2].data_full);
					assign request_exists = |requests;
					assign cva5_wrapper.l2[_mbase_l2].request_push = push_ready & request_exists;
					assign cva5_wrapper.l2[_mbase_l2].wr_data_push = CONFIG[711] & ((push_ready & cva5_wrapper.cva5.l1_request[2'd0 + _mbase_l1_request].request) & ~cva5_wrapper.cva5.l1_request[2'd0 + _mbase_l1_request].rnw);
					assign cva5_wrapper.l2[_mbase_l2].wr_data = cva5_wrapper.cva5.l1_request[2'd0 + _mbase_l1_request].data;
					assign cva5_wrapper.l2[_mbase_l2].inv_ack = (CONFIG[614] ? cva5_wrapper.cva5.l1_response[2'd0 + _mbase_l1_response].inv_ack : cva5_wrapper.l2[_mbase_l2].inv_valid);
					assign cva5_wrapper.cva5.l1_response[2'd0 + _mbase_l1_response].inv_addr = cva5_wrapper.l2[_mbase_l2].inv_addr;
					assign cva5_wrapper.cva5.l1_response[2'd0 + _mbase_l1_response].inv_valid = CONFIG[614] & cva5_wrapper.l2[_mbase_l2].inv_valid;
					genvar _gv_i_24;
					for (_gv_i_24 = 0; _gv_i_24 < cva5_config_L1_CONNECTIONS; _gv_i_24 = _gv_i_24 + 1) begin : gen_l2_requests
						localparam i = _gv_i_24;
						always @(*) begin
							if (_sv2v_0)
								;
							l2_requests[(i * 43) + 42-:30] = cva5_wrapper.cva5.l1_request[i + _mbase_l1_request].addr[31:2];
							l2_requests[(i * 43) + 8] = cva5_wrapper.cva5.l1_request[i + _mbase_l1_request].rnw;
							l2_requests[(i * 43) + 12-:4] = cva5_wrapper.cva5.l1_request[i + _mbase_l1_request].be;
							l2_requests[(i * 43) + 7] = cva5_wrapper.cva5.l1_request[i + _mbase_l1_request].is_amo;
							l2_requests[(i * 43) + 6-:5] = cva5_wrapper.cva5.l1_request[i + _mbase_l1_request].size;
							l2_requests[(i * 43) + 1-:l2_config_and_types_L2_SUB_ID_W] = sv2v_cast_2_signed(i);
						end
					end
					priority_encoder #(.WIDTH(cva5_config_L1_CONNECTIONS)) arb_encoder(
						.priority_vector(requests),
						.encoded_result(arb_sel)
					);
					always @(*) begin
						if (_sv2v_0)
							;
						acks = 1'sb0;
						acks[arb_sel] = cva5_wrapper.l2[_mbase_l2].request_push;
					end
					assign cva5_wrapper.l2[_mbase_l2].addr = l2_requests[(arb_sel * 43) + 42-:30];
					assign cva5_wrapper.l2[_mbase_l2].rnw = l2_requests[(arb_sel * 43) + 8];
					assign cva5_wrapper.l2[_mbase_l2].be = l2_requests[(arb_sel * 43) + 12-:4];
					assign cva5_wrapper.l2[_mbase_l2].is_amo = l2_requests[(arb_sel * 43) + 7];
					assign cva5_wrapper.l2[_mbase_l2].amo_type_or_burst_size = l2_requests[(arb_sel * 43) + 6-:5];
					assign cva5_wrapper.l2[_mbase_l2].sub_id = l2_requests[(arb_sel * 43) + 1-:l2_config_and_types_L2_SUB_ID_W];
					genvar _gv_i_25;
					for (_gv_i_25 = 0; _gv_i_25 < cva5_config_L1_CONNECTIONS; _gv_i_25 = _gv_i_25 + 1) begin : gen_l1_responses
						localparam i = _gv_i_25;
						assign cva5_wrapper.cva5.l1_response[i + _mbase_l1_response].data = cva5_wrapper.l2[_mbase_l2].rd_data;
						assign cva5_wrapper.cva5.l1_response[i + _mbase_l1_response].data_valid = cva5_wrapper.l2[_mbase_l2].rd_data_valid && (cva5_wrapper.l2[_mbase_l2].rd_sub_id == i);
					end
					initial _sv2v_0 = 0;
				end
				assign arb.clk = clk;
				assign arb.rst = rst;
				assign sc_complete = arb.sc_complete;
				assign sc_success = arb.sc_success;
			end
			localparam _param_4C8D4_CONFIG = CONFIG;
			if (1) begin : id_block
				reg _sv2v_0;
				localparam [1209:0] cva5_config_EXAMPLE_CONFIG = 1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002;
				localparam [1209:0] CONFIG = _param_4C8D4_CONFIG;
				wire clk;
				wire rst;
				localparam cva5_config_MAX_IDS = 8;
				localparam cva5_types_LOG2_MAX_IDS = 3;
				localparam riscv_types_ECODE_W = 5;
				wire [115:0] gc;
				localparam cva5_config_MAX_IDS_FETCH = 8;
				localparam cva5_types_LOG2_MAX_IDS_FETCH = 3;
				reg [2:0] pc_id;
				wire pc_id_available;
				wire [31:0] if_pc;
				wire pc_id_assigned;
				reg [2:0] fetch_id;
				wire early_branch_flush;
				wire fetch_complete;
				wire [31:0] fetch_instruction;
				wire [5:0] fetch_metadata;
				wire scaiev_decode_inject;
				wire pc_inject_id_available;
				wire pc_inject_id_assigned;
				wire pc_inject_keep_for_repeat;
				wire pc_inject_is_repeat;
				reg [76:0] decode;
				wire decode_advance;
				wire decode_uses_rd;
				wire [4:0] decode_rd_addr;
				wire [1:0] decode_exception_unit;
				wire [5:0] decode_phys_rd_addr;
				wire [101:0] issue;
				wire instruction_issued;
				wire instruction_issued_with_rd;
				wire [(CONFIG[31-:32] * 36) - 1:0] wb_packet;
				wire [(CONFIG[31-:32] * 42) - 1:0] commit_packet;
				localparam cva5_config_RETIRE_PORTS = 2;
				localparam cva5_types_LOG2_RETIRE_PORTS = 1;
				reg [5:0] retire;
				reg [5:0] retire_ids;
				reg [5:0] retire_ids_next;
				reg [0:1] retire_port_valid;
				reg [cva5_types_LOG2_MAX_IDS:0] post_issue_count;
				wire [31:0] oldest_pc;
				localparam cva5_config_NUM_EXCEPTION_SOURCES = 3;
				wire [1:0] current_exception_unit;
				localparam scaiev_config_ENABLE_DECODE_INJECT = 0;
				if (!scaiev_config_ENABLE_DECODE_INJECT) begin : gen_vanilla
					wire [76:0] decode_vanilla;
					always @(*) begin
						if (_sv2v_0)
							;
						decode = decode_vanilla;
						decode[73-:3] = decode_vanilla[76-:3];
					end
					assign pc_inject_id_available = 0;
					localparam _param_6000A_CONFIG = CONFIG;
					if (1) begin : id_block_vanilla
						reg _sv2v_0;
						localparam [1209:0] cva5_config_EXAMPLE_CONFIG = 1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002;
						localparam [1209:0] CONFIG = _param_6000A_CONFIG;
						wire clk;
						wire rst;
						localparam cva5_config_MAX_IDS = 8;
						localparam cva5_types_LOG2_MAX_IDS = 3;
						localparam riscv_types_ECODE_W = 5;
						wire [115:0] gc;
						reg [2:0] pc_id;
						wire pc_id_available;
						wire [31:0] if_pc;
						wire pc_id_assigned;
						reg [2:0] fetch_id;
						wire early_branch_flush;
						wire fetch_complete;
						wire [31:0] fetch_instruction;
						wire [5:0] fetch_metadata;
						localparam cva5_config_MAX_IDS_FETCH = 8;
						localparam cva5_types_LOG2_MAX_IDS_FETCH = 3;
						wire [76:0] decode;
						wire decode_advance;
						wire decode_uses_rd;
						wire [4:0] decode_rd_addr;
						wire [1:0] decode_exception_unit;
						wire [5:0] decode_phys_rd_addr;
						wire [101:0] issue;
						wire instruction_issued;
						wire instruction_issued_with_rd;
						wire [(CONFIG[31-:32] * 36) - 1:0] wb_packet;
						wire [(CONFIG[31-:32] * 42) - 1:0] commit_packet;
						localparam cva5_config_RETIRE_PORTS = 2;
						localparam cva5_types_LOG2_RETIRE_PORTS = 1;
						reg [5:0] retire;
						reg [5:0] retire_ids;
						reg [5:0] retire_ids_next;
						reg [0:1] retire_port_valid;
						reg [cva5_types_LOG2_MAX_IDS:0] post_issue_count;
						wire [31:0] oldest_pc;
						localparam cva5_config_NUM_EXCEPTION_SOURCES = 3;
						wire [1:0] current_exception_unit;
						reg [31:0] pc_table [0:7];
						reg [31:0] instruction_table [0:7];
						wire [0:0] valid_fetch_addr_table [0:7];
						reg [5:0] phys_addr_table [0:7];
						reg [0:0] uses_rd_table [0:7];
						reg [5:0] fetch_metadata_table [0:7];
						reg [1:0] exception_unit_table [0:7];
						reg [2:0] decode_id;
						reg [2:0] oldest_pre_issue_id;
						reg [2:0] oldest_pre_decode_id;
						localparam ID_COUNTER_W = 4;
						reg [cva5_types_LOG2_MAX_IDS:0] fetched_count_neg;
						reg [cva5_types_LOG2_MAX_IDS:0] pre_issue_count;
						reg [cva5_types_LOG2_MAX_IDS:0] pre_issue_count_next;
						wire [cva5_types_LOG2_MAX_IDS:0] post_issue_count_next;
						reg [cva5_types_LOG2_MAX_IDS:0] inflight_count;
						reg [5:0] retire_next;
						reg retire_port_valid_next [0:1];
						genvar _gv_i_21;
						always @(posedge clk)
							if (pc_id_assigned)
								pc_table[pc_id] <= if_pc;
						always @(posedge clk)
							if (fetch_complete)
								instruction_table[fetch_id] <= fetch_instruction;
						always @(posedge clk)
							if (fetch_complete)
								fetch_metadata_table[fetch_id] <= fetch_metadata;
						always @(posedge clk)
							if (decode_advance)
								phys_addr_table[decode_id] <= decode_phys_rd_addr;
						always @(posedge clk)
							if (decode_advance)
								uses_rd_table[decode_id] <= decode_uses_rd & |decode_rd_addr;
						always @(posedge clk)
							if (decode_advance)
								exception_unit_table[decode_id] <= decode_exception_unit;
						always @(posedge clk)
							if (rst)
								oldest_pre_issue_id <= 0;
							else if (instruction_issued)
								oldest_pre_issue_id <= oldest_pre_issue_id + 1;
						always @(posedge clk)
							if (rst)
								oldest_pre_decode_id <= 0;
							else if (gc[111] | cva5_wrapper.scaiev.issue_flush)
								oldest_pre_decode_id <= oldest_pre_issue_id;
							else if (decode_advance && !cva5_wrapper.scaiev.decode_flush)
								oldest_pre_decode_id <= oldest_pre_decode_id + 1;
						assign cva5_wrapper.scaiev.fetch_fetchFlushID = (gc[111] | cva5_wrapper.scaiev.issue_flush ? oldest_pre_issue_id : oldest_pre_decode_id);
						assign cva5_wrapper.scaiev.fetch_fetchFlushCount = ((gc[111] | cva5_wrapper.scaiev.issue_flush) | cva5_wrapper.scaiev.decode_flush ? {1'b0, pc_id} - {1'b0, cva5_wrapper.scaiev.fetch_fetchFlushID} : {4 {1'sb0}});
						assign cva5_wrapper.scaiev.issue_flushID = (gc[111] | cva5_wrapper.scaiev.issue_flush ? oldest_pre_issue_id : oldest_pre_decode_id);
						always @(posedge clk)
							if (gc[111] | cva5_wrapper.scaiev.issue_flush) begin
								pc_id <= oldest_pre_issue_id;
								fetch_id <= oldest_pre_issue_id;
								decode_id <= oldest_pre_issue_id;
							end
							else if (cva5_wrapper.scaiev.decode_flush) begin
								pc_id <= oldest_pre_decode_id;
								fetch_id <= oldest_pre_decode_id;
								decode_id <= oldest_pre_decode_id;
							end
							else begin
								pc_id <= (early_branch_flush ? fetch_id : pc_id) + sv2v_cast_3(pc_id_assigned);
								fetch_id <= fetch_id + sv2v_cast_3(fetch_complete);
								decode_id <= decode_id + sv2v_cast_3(decode_advance);
							end
						for (_gv_i_21 = 0; _gv_i_21 < cva5_config_RETIRE_PORTS; _gv_i_21 = _gv_i_21 + 1) begin : gen_retire_ids
							localparam i = _gv_i_21;
							always @(posedge clk)
								if (rst)
									retire_ids_next[(1 - i) * cva5_types_LOG2_MAX_IDS+:cva5_types_LOG2_MAX_IDS] <= sv2v_cast_3_signed(i);
								else
									retire_ids_next[(1 - i) * cva5_types_LOG2_MAX_IDS+:cva5_types_LOG2_MAX_IDS] <= retire_ids_next[(1 - i) * cva5_types_LOG2_MAX_IDS+:cva5_types_LOG2_MAX_IDS] + sv2v_cast_3(retire_next[1-:2]);
							always @(posedge clk)
								if (~gc[109])
									retire_ids[(1 - i) * cva5_types_LOG2_MAX_IDS+:cva5_types_LOG2_MAX_IDS] <= retire_ids_next[(1 - i) * cva5_types_LOG2_MAX_IDS+:cva5_types_LOG2_MAX_IDS];
						end
						always @(posedge clk)
							if (gc[111] | (cva5_wrapper.scaiev.decode_flush | cva5_wrapper.scaiev.issue_flush))
								fetched_count_neg <= 0;
							else
								fetched_count_neg <= (fetched_count_neg + sv2v_cast_4(decode_advance)) - sv2v_cast_4(fetch_complete);
						always @(*) begin
							if (_sv2v_0)
								;
							pre_issue_count_next = (pre_issue_count + sv2v_cast_4(pc_id_assigned)) - sv2v_cast_4(instruction_issued);
							if (cva5_wrapper.scaiev.decode_flush & ~(gc[111] | cva5_wrapper.scaiev.issue_flush))
								pre_issue_count_next = (issue[6] & ~instruction_issued ? 1 : 0);
						end
						always @(posedge clk)
							if (gc[111] | cva5_wrapper.scaiev.issue_flush)
								pre_issue_count <= 0;
							else
								pre_issue_count <= pre_issue_count_next;
						assign post_issue_count_next = (post_issue_count + sv2v_cast_4(instruction_issued)) - sv2v_cast_4(retire_next[1-:2]);
						always @(posedge clk)
							if (rst)
								post_issue_count <= 0;
							else
								post_issue_count <= post_issue_count_next;
						always @(posedge clk)
							if (gc[111] | cva5_wrapper.scaiev.issue_flush)
								inflight_count <= post_issue_count_next;
							else
								inflight_count <= pre_issue_count_next + post_issue_count_next;
						wire [0:1] id_waiting_for_writeback;
						toggle_memory_set #(
							.DEPTH(cva5_config_MAX_IDS),
							.NUM_WRITE_PORTS(2),
							.NUM_READ_PORTS(cva5_config_RETIRE_PORTS),
							.WRITE_INDEX_FOR_RESET(0),
							.READ_INDEX_FOR_RESET(0)
						) id_waiting_for_writeback_toggle_mem_set(
							.clk(clk),
							.rst(rst),
							.init_clear(gc[115]),
							.toggle({instruction_issued_with_rd & issue[15], wb_packet[((CONFIG[31-:32] - 2) * 36) + 32]}),
							.toggle_addr({issue[14-:3], wb_packet[((CONFIG[31-:32] - 2) * 36) + 35-:3]}),
							.read_addr(retire_ids_next),
							.in_use(id_waiting_for_writeback)
						);
						reg contiguous_retire;
						reg id_is_post_issue [0:1];
						reg id_ready_to_retire [0:1];
						wire [0:0] phys_id_sel;
						wire [1:0] retire_id_uses_rd;
						wire [1:0] retire_id_waiting_for_writeback;
						for (_gv_i_21 = 0; _gv_i_21 < cva5_config_RETIRE_PORTS; _gv_i_21 = _gv_i_21 + 1) begin : gen_retire_writeback
							localparam i = _gv_i_21;
							assign retire_id_uses_rd[i] = uses_rd_table[retire_ids_next[(1 - i) * cva5_types_LOG2_MAX_IDS+:cva5_types_LOG2_MAX_IDS]] || ((i == 1) && cva5_wrapper.scaiev.rf_wrReg);
							assign retire_id_waiting_for_writeback[i] = id_waiting_for_writeback[i] || ((i == 1) && cva5_wrapper.scaiev.rf_wrReg);
						end
						reg retire_with_rd_found;
						reg retire_with_rd_is_scaiev_decoupled;
						always @(*) begin
							if (_sv2v_0)
								;
							contiguous_retire = ~gc[109];
							retire_with_rd_is_scaiev_decoupled = 0;
							retire_with_rd_found = 0;
							begin : sv2v_autoblock_1
								reg signed [31:0] i;
								for (i = 0; i < cva5_config_RETIRE_PORTS; i = i + 1)
									begin
										id_is_post_issue[i] = post_issue_count > sv2v_cast_4_signed(i);
										id_ready_to_retire[i] = ((i == 1) && cva5_wrapper.scaiev.rf_wrReg) || ((id_is_post_issue[i] & contiguous_retire) & ~id_waiting_for_writeback[i]);
										retire_port_valid_next[i] = id_ready_to_retire[i] & ~(retire_id_uses_rd[i] & retire_with_rd_found);
										retire_with_rd_is_scaiev_decoupled = retire_with_rd_is_scaiev_decoupled | (((i == 1) && cva5_wrapper.scaiev.rf_wrReg) && !retire_with_rd_found);
										retire_with_rd_found = retire_with_rd_found | ((retire_port_valid_next[i] & retire_id_uses_rd[i]) || ((i == 1) && cva5_wrapper.scaiev.rf_wrReg));
										contiguous_retire = contiguous_retire & (retire_port_valid_next[i] & ~gc[106]);
									end
							end
						end
						priority_encoder #(.WIDTH(cva5_config_RETIRE_PORTS)) phys_id_sel_encoder(
							.priority_vector(retire_id_uses_rd),
							.encoded_result(phys_id_sel)
						);
						wire [3:1] sv2v_tmp_C15C7;
						assign sv2v_tmp_C15C7 = retire_ids_next[(1 - phys_id_sel) * cva5_types_LOG2_MAX_IDS+:cva5_types_LOG2_MAX_IDS];
						always @(*) retire_next[4-:3] = sv2v_tmp_C15C7;
						wire [1:1] sv2v_tmp_A5B53;
						assign sv2v_tmp_A5B53 = retire_with_rd_found && !retire_with_rd_is_scaiev_decoupled;
						always @(*) retire_next[5] = sv2v_tmp_A5B53;
						always @(*) begin
							if (_sv2v_0)
								;
							retire_next[1-:2] = 0;
							begin : sv2v_autoblock_2
								reg signed [31:0] i;
								for (i = 0; i < cva5_config_RETIRE_PORTS; i = i + 1)
									retire_next[1-:2] = retire_next[1-:2] + (retire_port_valid_next[i] && ((i != 1) || !cva5_wrapper.scaiev.rf_wrReg));
							end
						end
						always @(posedge clk) begin
							retire[5] <= retire_next[5];
							retire[4-:3] <= retire_next[4-:3];
							retire[1-:2] <= (gc[110] ? {2 {1'sb0}} : retire_next[1-:2]);
							begin : sv2v_autoblock_3
								reg signed [31:0] i;
								for (i = 0; i < cva5_config_RETIRE_PORTS; i = i + 1)
									retire_port_valid[i] <= (retire_port_valid_next[i] & ~gc[110]) && ((i != 1) || !cva5_wrapper.scaiev.rf_wrReg);
							end
						end
						assign cva5_wrapper.scaiev.retire_ID = retire_ids_next[cva5_types_LOG2_MAX_IDS+:cva5_types_LOG2_MAX_IDS];
						assign cva5_wrapper.scaiev.retire_count = retire_next[1-:2];
						assign cva5_wrapper.scaiev.retire_suppress = gc[110];
						assign pc_id_available = ~inflight_count[cva5_types_LOG2_MAX_IDS];
						assign decode[76-:3] = decode_id;
						assign decode[6] = fetched_count_neg[cva5_types_LOG2_MAX_IDS];
						assign decode[70-:32] = pc_table[decode_id];
						assign decode[38-:32] = instruction_table[decode_id];
						function automatic [4:0] sv2v_cast_E7B46;
							input reg [4:0] inp;
							sv2v_cast_E7B46 = inp;
						endfunction
						assign decode[5-:6] = (CONFIG[1209] ? fetch_metadata_table[decode_id] : {1'd1, sv2v_cast_E7B46(5'd1)});
						wire [5:0] commit_phys_addr [0:CONFIG[31-:32] - 1];
						assign commit_phys_addr[0] = issue[22-:6];
						for (_gv_i_21 = 1; _gv_i_21 < CONFIG[31-:32]; _gv_i_21 = _gv_i_21 + 1) begin : gen_commit_phys_addr
							localparam i = _gv_i_21;
							assign commit_phys_addr[i] = phys_addr_table[wb_packet[(((CONFIG[31-:32] - 1) - i) * 36) + 35-:3]];
						end
						for (_gv_i_21 = 0; _gv_i_21 < CONFIG[31-:32]; _gv_i_21 = _gv_i_21 + 1) begin : gen_commit_packet
							localparam i = _gv_i_21;
							assign commit_packet[(((CONFIG[31-:32] - 1) - i) * 42) + 41-:3] = wb_packet[(((CONFIG[31-:32] - 1) - i) * 36) + 35-:3];
							assign commit_packet[(((CONFIG[31-:32] - 1) - i) * 42) + 37-:6] = ((i == 1) && cva5_wrapper.scaiev.rf_wrReg ? cva5_wrapper.scaiev.rf_wrReg_phys_RD : commit_phys_addr[i]);
							assign commit_packet[(((CONFIG[31-:32] - 1) - i) * 42) + 38] = ((i == 1) && cva5_wrapper.scaiev.rf_wrReg) || (wb_packet[(((CONFIG[31-:32] - 1) - i) * 36) + 32] & |commit_phys_addr[i]);
							assign commit_packet[(((CONFIG[31-:32] - 1) - i) * 42) + 31-:32] = ((i == 1) && cva5_wrapper.scaiev.rf_wrReg ? cva5_wrapper.scaiev.rf_wrReg_data : wb_packet[(((CONFIG[31-:32] - 1) - i) * 36) + 31-:32]);
						end
						assign cva5_wrapper.scaiev.rf_ready = !retire[5];
						if (CONFIG[1209]) begin : gen_id_exception_support
							assign oldest_pc = pc_table[retire_ids_next[cva5_types_LOG2_MAX_IDS+:cva5_types_LOG2_MAX_IDS]];
							assign current_exception_unit = exception_unit_table[retire_ids_next[cva5_types_LOG2_MAX_IDS+:cva5_types_LOG2_MAX_IDS]];
						end
						initial _sv2v_0 = 0;
					end
					assign id_block_vanilla.clk = clk;
					assign id_block_vanilla.rst = rst;
					assign decode_vanilla = id_block_vanilla.decode;
					assign id_block_vanilla.gc = gc;
					wire [3:1] sv2v_tmp_AA6FD;
					assign sv2v_tmp_AA6FD = id_block_vanilla.pc_id;
					always @(*) pc_id = sv2v_tmp_AA6FD;
					assign pc_id_available = id_block_vanilla.pc_id_available;
					assign id_block_vanilla.if_pc = if_pc;
					assign id_block_vanilla.pc_id_assigned = pc_id_assigned;
					wire [3:1] sv2v_tmp_81B07;
					assign sv2v_tmp_81B07 = id_block_vanilla.fetch_id;
					always @(*) fetch_id = sv2v_tmp_81B07;
					assign id_block_vanilla.early_branch_flush = early_branch_flush;
					assign id_block_vanilla.fetch_complete = fetch_complete;
					assign id_block_vanilla.fetch_instruction = fetch_instruction;
					assign id_block_vanilla.fetch_metadata = fetch_metadata;
					assign id_block_vanilla.decode_advance = decode_advance;
					assign id_block_vanilla.decode_uses_rd = decode_uses_rd;
					assign id_block_vanilla.decode_rd_addr = decode_rd_addr;
					assign id_block_vanilla.decode_exception_unit = decode_exception_unit;
					assign id_block_vanilla.decode_phys_rd_addr = decode_phys_rd_addr;
					assign id_block_vanilla.issue = issue;
					assign id_block_vanilla.instruction_issued = instruction_issued;
					assign id_block_vanilla.instruction_issued_with_rd = instruction_issued_with_rd;
					assign id_block_vanilla.wb_packet = wb_packet;
					assign commit_packet = id_block_vanilla.commit_packet;
					wire [6:1] sv2v_tmp_350C3;
					assign sv2v_tmp_350C3 = id_block_vanilla.retire;
					always @(*) retire = sv2v_tmp_350C3;
					wire [6:1] sv2v_tmp_C6E0B;
					assign sv2v_tmp_C6E0B = id_block_vanilla.retire_ids;
					always @(*) retire_ids = sv2v_tmp_C6E0B;
					wire [6:1] sv2v_tmp_27041;
					assign sv2v_tmp_27041 = id_block_vanilla.retire_ids_next;
					always @(*) retire_ids_next = sv2v_tmp_27041;
					wire [2:1] sv2v_tmp_34EA5;
					assign sv2v_tmp_34EA5 = id_block_vanilla.retire_port_valid;
					always @(*) retire_port_valid = sv2v_tmp_34EA5;
					wire [4:1] sv2v_tmp_6CD57;
					assign sv2v_tmp_6CD57 = id_block_vanilla.post_issue_count;
					always @(*) post_issue_count = sv2v_tmp_6CD57;
					assign oldest_pc = id_block_vanilla.oldest_pc;
					assign current_exception_unit = id_block_vanilla.current_exception_unit;
				end
				else begin : gen_scaiev_injectable
					reg [31:0] pc_table [0:7];
					reg [31:0] instruction_table [0:7];
					reg [5:0] phys_addr_table [0:7];
					reg [0:0] uses_rd_table [0:7];
					reg [5:0] fetch_metadata_table [0:7];
					reg [2:0] pc_fetch_id_translation [0:7];
					reg pops_fetch_id [0:7];
					reg [1:0] exception_unit_table [0:7];
					reg [2:0] pre_decode_id;
					reg [2:0] post_decode_id;
					reg [2:0] oldest_pre_issue_id;
					reg [2:0] oldest_pre_issue_fetch_id;
					reg [2:0] oldest_pre_decode_id;
					reg [2:0] oldest_pre_decode_fetch_id;
					localparam ID_COUNTER_W = 4;
					localparam ID_COUNTER_FETCH_W = 4;
					reg [cva5_types_LOG2_MAX_IDS_FETCH:0] fetched_count_neg;
					reg [cva5_types_LOG2_MAX_IDS_FETCH:0] pre_issue_count;
					reg [cva5_types_LOG2_MAX_IDS_FETCH:0] pre_issue_count_next;
					wire [cva5_types_LOG2_MAX_IDS:0] post_issue_count_next;
					reg [cva5_types_LOG2_MAX_IDS:0] post_decode_count;
					reg [cva5_types_LOG2_MAX_IDS:0] post_decode_count_next;
					reg [cva5_types_LOG2_MAX_IDS:0] post_issue_count_noninject;
					wire [cva5_types_LOG2_MAX_IDS:0] post_issue_count_noninject_next;
					reg [cva5_types_LOG2_MAX_IDS_FETCH:0] inflight_count_noninject;
					wire [cva5_types_LOG2_MAX_IDS_FETCH:0] inflight_count_noninject_next;
					reg [5:0] retire_next;
					reg [cva5_types_LOG2_RETIRE_PORTS:0] retire_next_count_noninject;
					reg retire_port_valid_next [0:1];
					wire pop_pre_decode_instr;
					genvar _gv_i_22;
					always @(posedge clk)
						if (pc_id_assigned)
							pc_table[pc_id] <= if_pc;
					always @(posedge clk)
						if (fetch_complete)
							instruction_table[fetch_id] <= fetch_instruction;
					always @(posedge clk)
						if (fetch_complete)
							fetch_metadata_table[fetch_id] <= fetch_metadata;
					always @(posedge clk)
						if (decode_advance)
							pc_fetch_id_translation[post_decode_id] <= pre_decode_id;
					always @(posedge clk)
						if (decode_advance)
							pops_fetch_id[post_decode_id] <= pop_pre_decode_instr;
					always @(posedge clk)
						if (decode_advance)
							phys_addr_table[post_decode_id] <= decode_phys_rd_addr;
					always @(posedge clk)
						if (decode_advance)
							uses_rd_table[post_decode_id] <= decode_uses_rd & |decode_rd_addr;
					always @(posedge clk)
						if (decode_advance)
							exception_unit_table[post_decode_id] <= decode_exception_unit;
					assign pop_pre_decode_instr = !pc_inject_keep_for_repeat && (pc_inject_is_repeat || !pc_inject_id_assigned);
					function [2:0] incr_fetch_id_t_wrap;
						input reg [2:0] op;
						incr_fetch_id_t_wrap = (op == 3'sd7 ? {3 {1'sb0}} : op + 1);
					endfunction
					always @(posedge clk)
						if (rst) begin
							oldest_pre_issue_id <= 0;
							oldest_pre_issue_fetch_id <= 0;
						end
						else if (instruction_issued) begin
							oldest_pre_issue_id <= oldest_pre_issue_id + 1;
							if (~cva5_wrapper.scaiev.issue_injected)
								oldest_pre_issue_fetch_id <= incr_fetch_id_t_wrap(oldest_pre_issue_fetch_id);
						end
					always @(posedge clk)
						if (rst) begin
							oldest_pre_decode_id <= 0;
							oldest_pre_decode_fetch_id <= 0;
						end
						else if (cva5_wrapper.scaiev.issue_flush | gc[111]) begin
							oldest_pre_decode_id <= oldest_pre_issue_id;
							oldest_pre_decode_fetch_id <= oldest_pre_issue_fetch_id;
						end
						else if (decode_advance && !cva5_wrapper.scaiev.decode_flush) begin
							oldest_pre_decode_id <= oldest_pre_decode_id + 1;
							if (pop_pre_decode_instr)
								oldest_pre_decode_fetch_id <= incr_fetch_id_t_wrap(oldest_pre_decode_fetch_id);
						end
					assign cva5_wrapper.scaiev.fetch_fetchFlushID = (gc[111] | cva5_wrapper.scaiev.issue_flush ? oldest_pre_issue_fetch_id : oldest_pre_decode_fetch_id);
					assign cva5_wrapper.scaiev.fetch_fetchFlushCount = ((gc[111] | cva5_wrapper.scaiev.issue_flush) | cva5_wrapper.scaiev.decode_flush ? {1'b0, pc_id} - {1'b0, cva5_wrapper.scaiev.fetch_fetchFlushID} : {4 {1'sb0}});
					assign cva5_wrapper.scaiev.issue_flushID = (gc[111] | cva5_wrapper.scaiev.issue_flush ? oldest_pre_issue_id : oldest_pre_decode_id);
					reg [2:0] pc_id_incr_wrap;
					reg [2:0] fetch_id_incr_wrap;
					reg [2:0] pre_decode_id_incr_wrap;
					always @(*) begin
						if (_sv2v_0)
							;
						pc_id_incr_wrap = (early_branch_flush ? fetch_id : pc_id);
						if (pc_id_assigned)
							pc_id_incr_wrap = incr_fetch_id_t_wrap(pc_id_incr_wrap);
						fetch_id_incr_wrap = fetch_id;
						if (fetch_complete)
							fetch_id_incr_wrap = incr_fetch_id_t_wrap(fetch_id_incr_wrap);
						pre_decode_id_incr_wrap = pre_decode_id;
						if (decode_advance && pop_pre_decode_instr)
							pre_decode_id_incr_wrap = incr_fetch_id_t_wrap(pre_decode_id_incr_wrap);
					end
					always @(posedge clk)
						if (rst) begin
							pc_id <= 0;
							fetch_id <= 0;
							pre_decode_id <= 0;
							post_decode_id <= 0;
						end
						else if (gc[111] | cva5_wrapper.scaiev.issue_flush) begin
							pc_id <= oldest_pre_issue_fetch_id;
							fetch_id <= oldest_pre_issue_fetch_id;
							pre_decode_id <= oldest_pre_issue_fetch_id;
							post_decode_id <= oldest_pre_issue_id;
						end
						else if (cva5_wrapper.scaiev.decode_flush) begin
							pc_id <= oldest_pre_decode_fetch_id;
							fetch_id <= oldest_pre_decode_fetch_id;
							pre_decode_id <= oldest_pre_decode_fetch_id;
							post_decode_id <= oldest_pre_decode_id;
						end
						else begin
							pc_id <= pc_id_incr_wrap;
							fetch_id <= fetch_id_incr_wrap;
							pre_decode_id <= pre_decode_id_incr_wrap;
							post_decode_id <= post_decode_id + sv2v_cast_3(decode_advance);
						end
					for (_gv_i_22 = 0; _gv_i_22 < cva5_config_RETIRE_PORTS; _gv_i_22 = _gv_i_22 + 1) begin : gen_retire_ids
						localparam i = _gv_i_22;
						always @(posedge clk)
							if (rst)
								retire_ids_next[(1 - i) * cva5_types_LOG2_MAX_IDS+:cva5_types_LOG2_MAX_IDS] <= sv2v_cast_3_signed(i);
							else
								retire_ids_next[(1 - i) * cva5_types_LOG2_MAX_IDS+:cva5_types_LOG2_MAX_IDS] <= retire_ids_next[(1 - i) * cva5_types_LOG2_MAX_IDS+:cva5_types_LOG2_MAX_IDS] + sv2v_cast_3(retire_next[1-:2]);
						always @(posedge clk)
							if (~gc[109])
								retire_ids[(1 - i) * cva5_types_LOG2_MAX_IDS+:cva5_types_LOG2_MAX_IDS] <= retire_ids_next[(1 - i) * cva5_types_LOG2_MAX_IDS+:cva5_types_LOG2_MAX_IDS];
					end
					always @(posedge clk)
						if (gc[111] | (cva5_wrapper.scaiev.decode_flush | cva5_wrapper.scaiev.issue_flush))
							fetched_count_neg <= 0;
						else
							fetched_count_neg <= (fetched_count_neg + sv2v_cast_4(decode_advance && pop_pre_decode_instr)) - sv2v_cast_4(fetch_complete);
					always @(*) begin
						if (_sv2v_0)
							;
						pre_issue_count_next = ((pre_issue_count + sv2v_cast_4(pc_id_assigned)) + sv2v_cast_4(pc_inject_id_assigned)) - sv2v_cast_4(instruction_issued);
						if (cva5_wrapper.scaiev.decode_flush & ~(gc[111] | cva5_wrapper.scaiev.issue_flush))
							pre_issue_count_next = (issue[6] & ~instruction_issued ? 1 : 0);
					end
					always @(posedge clk)
						if (gc[111] | cva5_wrapper.scaiev.issue_flush)
							pre_issue_count <= 0;
						else
							pre_issue_count <= pre_issue_count_next;
					assign post_issue_count_next = (post_issue_count + sv2v_cast_4(instruction_issued)) - sv2v_cast_4(retire_next[1-:2]);
					always @(posedge clk)
						if (rst)
							post_issue_count <= 0;
						else
							post_issue_count <= post_issue_count_next;
					assign post_issue_count_noninject_next = (post_issue_count_noninject + sv2v_cast_4(instruction_issued && !cva5_wrapper.scaiev.issue_injected)) - sv2v_cast_4(retire_next_count_noninject);
					always @(posedge clk)
						if (rst)
							post_issue_count_noninject <= 0;
						else
							post_issue_count_noninject <= post_issue_count_noninject_next;
					assign inflight_count_noninject_next = (inflight_count_noninject + sv2v_cast_4(pc_id_assigned)) - sv2v_cast_4(retire_next_count_noninject);
					always @(posedge clk)
						if (gc[111] | cva5_wrapper.scaiev.issue_flush)
							inflight_count_noninject <= sv2v_cast_4(post_issue_count_noninject_next);
						else if (cva5_wrapper.scaiev.decode_flush)
							inflight_count_noninject <= post_issue_count_noninject_next + sv2v_cast_4((issue[6] && !cva5_wrapper.scaiev.issue_injected) && !instruction_issued);
						else
							inflight_count_noninject <= inflight_count_noninject_next;
					always @(*) begin
						if (_sv2v_0)
							;
						post_decode_count_next = (post_decode_count + sv2v_cast_4(decode_advance && !cva5_wrapper.scaiev.decode_flush)) - sv2v_cast_4(retire_next[1-:2]);
						if (gc[111] | cva5_wrapper.scaiev.issue_flush)
							post_decode_count_next = post_issue_count_next;
					end
					always @(posedge clk)
						if (rst)
							post_decode_count <= 0;
						else
							post_decode_count <= post_decode_count_next;
					wire [0:1] id_waiting_for_writeback;
					toggle_memory_set #(
						.DEPTH(cva5_config_MAX_IDS),
						.NUM_WRITE_PORTS(2),
						.NUM_READ_PORTS(cva5_config_RETIRE_PORTS),
						.WRITE_INDEX_FOR_RESET(0),
						.READ_INDEX_FOR_RESET(0)
					) id_waiting_for_writeback_toggle_mem_set(
						.clk(clk),
						.rst(rst),
						.init_clear(gc[115]),
						.toggle({instruction_issued_with_rd & issue[15], wb_packet[((CONFIG[31-:32] - 2) * 36) + 32]}),
						.toggle_addr({issue[14-:3], wb_packet[((CONFIG[31-:32] - 2) * 36) + 35-:3]}),
						.read_addr(retire_ids_next),
						.in_use(id_waiting_for_writeback)
					);
					reg contiguous_retire;
					reg id_is_post_issue [0:1];
					reg id_ready_to_retire [0:1];
					wire [0:0] phys_id_sel;
					wire [1:0] retire_id_uses_rd;
					wire [1:0] retire_id_waiting_for_writeback;
					for (_gv_i_22 = 0; _gv_i_22 < cva5_config_RETIRE_PORTS; _gv_i_22 = _gv_i_22 + 1) begin : gen_retire_writeback
						localparam i = _gv_i_22;
						assign retire_id_uses_rd[i] = uses_rd_table[retire_ids_next[(1 - i) * cva5_types_LOG2_MAX_IDS+:cva5_types_LOG2_MAX_IDS]] || ((i == 1) && cva5_wrapper.scaiev.rf_wrReg);
						assign retire_id_waiting_for_writeback[i] = id_waiting_for_writeback[i] || ((i == 1) && cva5_wrapper.scaiev.rf_wrReg);
					end
					reg retire_with_rd_found;
					reg retire_with_rd_is_scaiev_decoupled;
					always @(*) begin
						if (_sv2v_0)
							;
						contiguous_retire = ~gc[109];
						retire_with_rd_is_scaiev_decoupled = 0;
						retire_with_rd_found = 0;
						begin : sv2v_autoblock_4
							reg signed [31:0] i;
							for (i = 0; i < cva5_config_RETIRE_PORTS; i = i + 1)
								begin
									id_is_post_issue[i] = post_issue_count > sv2v_cast_4_signed(i);
									id_ready_to_retire[i] = ((i == 1) && cva5_wrapper.scaiev.rf_wrReg) || ((id_is_post_issue[i] & contiguous_retire) & ~id_waiting_for_writeback[i]);
									retire_port_valid_next[i] = id_ready_to_retire[i] & ~(retire_id_uses_rd[i] & retire_with_rd_found);
									retire_with_rd_is_scaiev_decoupled = retire_with_rd_is_scaiev_decoupled | (((i == 1) && cva5_wrapper.scaiev.rf_wrReg) && !retire_with_rd_found);
									retire_with_rd_found = retire_with_rd_found | ((retire_port_valid_next[i] & retire_id_uses_rd[i]) || ((i == 1) && cva5_wrapper.scaiev.rf_wrReg));
									contiguous_retire = contiguous_retire & (retire_port_valid_next[i] & ~gc[106]);
								end
						end
					end
					priority_encoder #(.WIDTH(cva5_config_RETIRE_PORTS)) phys_id_sel_encoder(
						.priority_vector(retire_id_uses_rd),
						.encoded_result(phys_id_sel)
					);
					wire [3:1] sv2v_tmp_2EF09;
					assign sv2v_tmp_2EF09 = retire_ids_next[(1 - phys_id_sel) * cva5_types_LOG2_MAX_IDS+:cva5_types_LOG2_MAX_IDS];
					always @(*) retire_next[4-:3] = sv2v_tmp_2EF09;
					wire [1:1] sv2v_tmp_A5B53;
					assign sv2v_tmp_A5B53 = retire_with_rd_found && !retire_with_rd_is_scaiev_decoupled;
					always @(*) retire_next[5] = sv2v_tmp_A5B53;
					always @(*) begin
						if (_sv2v_0)
							;
						retire_next[1-:2] = 0;
						retire_next_count_noninject = 0;
						begin : sv2v_autoblock_5
							reg signed [31:0] i;
							for (i = 0; i < cva5_config_RETIRE_PORTS; i = i + 1)
								begin
									retire_next[1-:2] = retire_next[1-:2] + (retire_port_valid_next[i] && ((i != 1) || !cva5_wrapper.scaiev.rf_wrReg));
									retire_next_count_noninject = retire_next_count_noninject + ((retire_port_valid_next[i] && pops_fetch_id[retire_ids_next[(1 - i) * cva5_types_LOG2_MAX_IDS+:cva5_types_LOG2_MAX_IDS]]) && ((i != 1) || !cva5_wrapper.scaiev.rf_wrReg));
								end
						end
					end
					always @(posedge clk) begin
						retire[5] <= retire_next[5];
						retire[4-:3] <= retire_next[4-:3];
						retire[1-:2] <= (gc[110] ? {2 {1'sb0}} : retire_next[1-:2]);
						begin : sv2v_autoblock_6
							reg signed [31:0] i;
							for (i = 0; i < cva5_config_RETIRE_PORTS; i = i + 1)
								retire_port_valid[i] <= (retire_port_valid_next[i] & ~gc[110]) && ((i != 1) || !cva5_wrapper.scaiev.rf_wrReg);
						end
					end
					assign cva5_wrapper.scaiev.retire_ID = retire_ids_next[cva5_types_LOG2_MAX_IDS+:cva5_types_LOG2_MAX_IDS];
					assign cva5_wrapper.scaiev.retire_count = retire_next[1-:2];
					assign cva5_wrapper.scaiev.retire_suppress = gc[110];
					assign pc_id_available = ~inflight_count_noninject[cva5_types_LOG2_MAX_IDS_FETCH];
					assign pc_inject_id_available = ~post_decode_count[cva5_types_LOG2_MAX_IDS];
					wire [3:1] sv2v_tmp_59094;
					assign sv2v_tmp_59094 = post_decode_id;
					always @(*) decode[76-:3] = sv2v_tmp_59094;
					wire [1:1] sv2v_tmp_6EC3B;
					assign sv2v_tmp_6EC3B = fetched_count_neg[cva5_types_LOG2_MAX_IDS_FETCH] && ~post_decode_count[cva5_types_LOG2_MAX_IDS];
					always @(*) decode[6] = sv2v_tmp_6EC3B;
					wire [32:1] sv2v_tmp_0E2D6;
					assign sv2v_tmp_0E2D6 = pc_table[pre_decode_id];
					always @(*) decode[70-:32] = sv2v_tmp_0E2D6;
					wire [3:1] sv2v_tmp_17B63;
					assign sv2v_tmp_17B63 = pre_decode_id;
					always @(*) decode[73-:3] = sv2v_tmp_17B63;
					wire [32:1] sv2v_tmp_444CE;
					assign sv2v_tmp_444CE = instruction_table[pre_decode_id];
					always @(*) decode[38-:32] = sv2v_tmp_444CE;
					function automatic [4:0] sv2v_cast_39584;
						input reg [4:0] inp;
						sv2v_cast_39584 = inp;
					endfunction
					wire [6:1] sv2v_tmp_3AD73;
					assign sv2v_tmp_3AD73 = (CONFIG[1209] ? fetch_metadata_table[pre_decode_id] : {1'd1, sv2v_cast_39584(5'd1)});
					always @(*) decode[5-:6] = sv2v_tmp_3AD73;
					wire [5:0] commit_phys_addr [0:CONFIG[31-:32] - 1];
					assign commit_phys_addr[0] = issue[22-:6];
					for (_gv_i_22 = 1; _gv_i_22 < CONFIG[31-:32]; _gv_i_22 = _gv_i_22 + 1) begin : gen_commit_phys_addr
						localparam i = _gv_i_22;
						assign commit_phys_addr[i] = phys_addr_table[wb_packet[(((CONFIG[31-:32] - 1) - i) * 36) + 35-:3]];
					end
					for (_gv_i_22 = 0; _gv_i_22 < CONFIG[31-:32]; _gv_i_22 = _gv_i_22 + 1) begin : gen_commit_packet
						localparam i = _gv_i_22;
						assign commit_packet[(((CONFIG[31-:32] - 1) - i) * 42) + 41-:3] = wb_packet[(((CONFIG[31-:32] - 1) - i) * 36) + 35-:3];
						assign commit_packet[(((CONFIG[31-:32] - 1) - i) * 42) + 37-:6] = ((i == 1) && cva5_wrapper.scaiev.rf_wrReg ? cva5_wrapper.scaiev.rf_wrReg_phys_RD : commit_phys_addr[i]);
						assign commit_packet[(((CONFIG[31-:32] - 1) - i) * 42) + 38] = ((i == 1) && cva5_wrapper.scaiev.rf_wrReg) || (wb_packet[(((CONFIG[31-:32] - 1) - i) * 36) + 32] & |commit_phys_addr[i]);
						assign commit_packet[(((CONFIG[31-:32] - 1) - i) * 42) + 31-:32] = ((i == 1) && cva5_wrapper.scaiev.rf_wrReg ? cva5_wrapper.scaiev.rf_wrReg_data : wb_packet[(((CONFIG[31-:32] - 1) - i) * 36) + 31-:32]);
					end
					assign cva5_wrapper.scaiev.rf_ready = !retire[5];
					if (CONFIG[1209]) begin : gen_id_exception_support
						assign oldest_pc = pc_table[pc_fetch_id_translation[retire_ids_next[cva5_types_LOG2_MAX_IDS+:cva5_types_LOG2_MAX_IDS]]];
						assign current_exception_unit = exception_unit_table[retire_ids_next[cva5_types_LOG2_MAX_IDS+:cva5_types_LOG2_MAX_IDS]];
					end
				end
				initial _sv2v_0 = 0;
			end
			assign id_block.clk = clk;
			assign id_block.rst = rst;
			assign id_block.gc = gc;
			assign pc_id = id_block.pc_id;
			assign pc_id_available = id_block.pc_id_available;
			assign id_block.if_pc = if_pc;
			assign id_block.pc_id_assigned = pc_id_assigned;
			assign id_block.scaiev_decode_inject = scaiev_decode_inject;
			assign pc_inject_id_available = id_block.pc_inject_id_available;
			assign id_block.pc_inject_id_assigned = pc_inject_id_assigned;
			assign id_block.pc_inject_keep_for_repeat = pc_inject_keep_for_repeat;
			assign id_block.pc_inject_is_repeat = pc_inject_is_repeat;
			assign fetch_id = id_block.fetch_id;
			assign id_block.early_branch_flush = early_branch_flush;
			assign id_block.fetch_complete = fetch_complete;
			assign id_block.fetch_instruction = fetch_instruction;
			assign id_block.fetch_metadata = fetch_metadata;
			assign decode = id_block.decode;
			assign id_block.decode_advance = decode_advance;
			assign id_block.decode_uses_rd = decode_uses_rd;
			assign id_block.decode_rd_addr = decode_rd_addr;
			assign id_block.decode_phys_rd_addr = decode_phys_rd_addr;
			assign id_block.decode_exception_unit = decode_exception_unit;
			assign id_block.issue = issue;
			assign id_block.instruction_issued = instruction_issued;
			assign id_block.instruction_issued_with_rd = instruction_issued_with_rd;
			assign id_block.wb_packet = wb_packet;
			assign commit_packet = id_block.commit_packet;
			assign retire = id_block.retire;
			assign retire_ids = id_block.retire_ids;
			assign retire_ids_next = id_block.retire_ids_next;
			assign retire_port_valid = id_block.retire_port_valid;
			assign post_issue_count = id_block.post_issue_count;
			assign oldest_pc = id_block.oldest_pc;
			assign current_exception_unit = id_block.current_exception_unit;
			localparam _bbase_9937B_l1_request = 2'd2;
			localparam _bbase_9937B_l1_response = 2'd2;
			localparam _param_9937B_CONFIG = CONFIG;
			if (1) begin : fetch_block
				localparam [1209:0] cva5_config_EXAMPLE_CONFIG = 1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002;
				localparam [1209:0] CONFIG = _param_9937B_CONFIG;
				wire clk;
				wire rst;
				wire branch_flush;
				localparam cva5_config_MAX_IDS = 8;
				localparam cva5_types_LOG2_MAX_IDS = 3;
				localparam riscv_types_ECODE_W = 5;
				wire [115:0] gc;
				wire tlb_on;
				wire exception;
				localparam cva5_config_MAX_IDS_FETCH = 8;
				localparam cva5_types_LOG2_MAX_IDS_FETCH = 3;
				wire [2:0] pc_id;
				wire pc_id_available;
				wire pc_id_assigned;
				wire fetch_complete;
				wire [5:0] fetch_metadata;
				wire early_branch_flush;
				wire early_branch_flush_ras_adjust;
				wire [31:0] if_pc;
				wire [31:0] fetch_instruction;
				wire icache_on;
				localparam _mbase_l1_request = _bbase_9937B_l1_request;
				localparam _mbase_l1_response = _bbase_9937B_l1_response;
				wire tr_early_branch_correction;
				localparam NUM_SUB_UNITS = (sv2v_cast_32_signed(CONFIG[420]) + sv2v_cast_32_signed(CONFIG[1002])) + sv2v_cast_32_signed(CONFIG[290]);
				localparam NUM_SUB_UNITS_W = (NUM_SUB_UNITS == 1 ? 1 : $clog2(NUM_SUB_UNITS));
				localparam LOCAL_MEM_ID = 0;
				localparam ICACHE_ID = sv2v_cast_32_signed(CONFIG[420]);
				localparam BUS_ID = ICACHE_ID + sv2v_cast_32_signed(CONFIG[1002]);
				localparam MAX_OUTSTANDING_REQUESTS = 2;
				localparam MAX_OUTSTANDING_REQUESTS_W = 1;
				localparam _param_C8449_BASE_ADDR = CONFIG[419-:32];
				localparam _param_C8449_UPPER_BOUND = CONFIG[387-:32];
				if (1) begin : ilocal_mem_addr_utils
					localparam [31:0] BASE_ADDR = _param_C8449_BASE_ADDR;
					localparam [31:0] UPPER_BOUND = _param_C8449_UPPER_BOUND;
					function [31:0] bit_range;
						input reg _sv2v_unused;
						reg [0:1] _sv2v_jump;
						begin
							_sv2v_jump = 2'b00;
							begin : sv2v_autoblock_7
								reg signed [31:0] i;
								begin : sv2v_autoblock_8
									reg signed [31:0] _sv2v_value_on_break;
									for (i = 0; i < 32; i = i + 1)
										if (_sv2v_jump < 2'b10) begin
											_sv2v_jump = 2'b00;
											if (BASE_ADDR[i] == UPPER_BOUND[i]) begin
												bit_range = 32 - i;
												_sv2v_jump = 2'b11;
											end
											_sv2v_value_on_break = i;
										end
									if (!(_sv2v_jump < 2'b10))
										i = _sv2v_value_on_break;
									if (_sv2v_jump != 2'b11)
										_sv2v_jump = 2'b00;
								end
							end
							if (_sv2v_jump == 2'b00) begin
								bit_range = 0;
								_sv2v_jump = 2'b11;
							end
						end
					endfunction
					localparam [31:0] BIT_RANGE = bit_range(0);
					function address_range_check;
						input reg [31:0] addr;
						reg range_match;
						reg signed [31:0] i;
						begin
							range_match = 1;
							for (i = 32 - BIT_RANGE; i <= 31; i = i + 1)
								if (addr[i] != BASE_ADDR[i])
									range_match = 0;
							address_range_check = range_match;
						end
					endfunction
				end
				localparam _param_2A9DE_BASE_ADDR = CONFIG[839-:32];
				localparam _param_2A9DE_UPPER_BOUND = CONFIG[807-:32];
				if (1) begin : icache_addr_utils
					localparam [31:0] BASE_ADDR = _param_2A9DE_BASE_ADDR;
					localparam [31:0] UPPER_BOUND = _param_2A9DE_UPPER_BOUND;
					function [31:0] bit_range;
						input reg _sv2v_unused;
						reg [0:1] _sv2v_jump;
						begin
							_sv2v_jump = 2'b00;
							begin : sv2v_autoblock_9
								reg signed [31:0] i;
								begin : sv2v_autoblock_10
									reg signed [31:0] _sv2v_value_on_break;
									for (i = 0; i < 32; i = i + 1)
										if (_sv2v_jump < 2'b10) begin
											_sv2v_jump = 2'b00;
											if (BASE_ADDR[i] == UPPER_BOUND[i]) begin
												bit_range = 32 - i;
												_sv2v_jump = 2'b11;
											end
											_sv2v_value_on_break = i;
										end
									if (!(_sv2v_jump < 2'b10))
										i = _sv2v_value_on_break;
									if (_sv2v_jump != 2'b11)
										_sv2v_jump = 2'b00;
								end
							end
							if (_sv2v_jump == 2'b00) begin
								bit_range = 0;
								_sv2v_jump = 2'b11;
							end
						end
					endfunction
					localparam [31:0] BIT_RANGE = bit_range(0);
					function address_range_check;
						input reg [31:0] addr;
						reg range_match;
						reg signed [31:0] i;
						begin
							range_match = 1;
							for (i = 32 - BIT_RANGE; i <= 31; i = i + 1)
								if (addr[i] != BASE_ADDR[i])
									range_match = 0;
							address_range_check = range_match;
						end
					endfunction
				end
				localparam _param_20490_BASE_ADDR = CONFIG[289-:32];
				localparam _param_20490_UPPER_BOUND = CONFIG[257-:32];
				if (1) begin : ibus_addr_utils
					localparam [31:0] BASE_ADDR = _param_20490_BASE_ADDR;
					localparam [31:0] UPPER_BOUND = _param_20490_UPPER_BOUND;
					function [31:0] bit_range;
						input reg _sv2v_unused;
						reg [0:1] _sv2v_jump;
						begin
							_sv2v_jump = 2'b00;
							begin : sv2v_autoblock_11
								reg signed [31:0] i;
								begin : sv2v_autoblock_12
									reg signed [31:0] _sv2v_value_on_break;
									for (i = 0; i < 32; i = i + 1)
										if (_sv2v_jump < 2'b10) begin
											_sv2v_jump = 2'b00;
											if (BASE_ADDR[i] == UPPER_BOUND[i]) begin
												bit_range = 32 - i;
												_sv2v_jump = 2'b11;
											end
											_sv2v_value_on_break = i;
										end
									if (!(_sv2v_jump < 2'b10))
										i = _sv2v_value_on_break;
									if (_sv2v_jump != 2'b11)
										_sv2v_jump = 2'b00;
								end
							end
							if (_sv2v_jump == 2'b00) begin
								bit_range = 0;
								_sv2v_jump = 2'b11;
							end
						end
					endfunction
					localparam [31:0] BIT_RANGE = bit_range(0);
					function address_range_check;
						input reg [31:0] addr;
						reg range_match;
						reg signed [31:0] i;
						begin
							range_match = 1;
							for (i = 32 - BIT_RANGE; i <= 31; i = i + 1)
								if (addr[i] != BASE_ADDR[i])
									range_match = 0;
							address_range_check = range_match;
						end
					endfunction
				end
				genvar _arr_40C6E;
				for (_arr_40C6E = NUM_SUB_UNITS - 1; _arr_40C6E >= 0; _arr_40C6E = _arr_40C6E - 1) begin : sub_unit
					wire new_request;
					wire [31:0] addr;
					wire re;
					wire we;
					wire [3:0] be;
					wire [31:0] data_in;
					reg [31:0] data_out;
					reg data_valid;
					wire ready;
				end
				wire [NUM_SUB_UNITS - 1:0] sub_unit_address_match;
				wire [NUM_SUB_UNITS - 1:0] unit_ready;
				wire [NUM_SUB_UNITS - 1:0] unit_data_valid;
				wire [31:0] unit_data_array [NUM_SUB_UNITS - 1:0];
				wire units_ready;
				wire address_valid;
				wire [(4 + NUM_SUB_UNITS_W) - 1:0] fetch_attr_next;
				wire [(4 + NUM_SUB_UNITS_W) - 1:0] fetch_attr;
				reg [MAX_OUTSTANDING_REQUESTS_W:0] inflight_count;
				wire [MAX_OUTSTANDING_REQUESTS_W:0] inflight_count_next;
				reg [MAX_OUTSTANDING_REQUESTS_W:0] flush_count;
				wire [MAX_OUTSTANDING_REQUESTS_W:0] flush_count_next;
				wire [31:0] pc_plus_4;
				wire [31:0] pc_mux [0:3];
				wire [1:0] pc_sel;
				wire [31:0] next_pc_prescaiev;
				wire [31:0] next_pc;
				reg [31:0] pc_prescaiev;
				wire [31:0] pc;
				wire flush_or_rst;
				localparam _param_02133_DATA_WIDTH = 4 + NUM_SUB_UNITS_W;
				if (1) begin : fetch_attr_fifo
					localparam DATA_WIDTH = _param_02133_DATA_WIDTH;
					wire push;
					wire pop;
					wire [DATA_WIDTH - 1:0] data_in;
					wire [DATA_WIDTH - 1:0] data_out;
					wire valid;
					wire full;
					wire potential_push;
				end
				wire update_pc_prescaiev;
				wire update_pc;
				wire new_mem_request;
				reg exception_pending;
				wire internal_fetch_complete;
				wire [31:0] translated_address;
				wire scaiev_full_fetch_flush;
				genvar _gv_i_12;
				assign scaiev_full_fetch_flush = cva5_wrapper.scaiev.decode_flush | cva5_wrapper.scaiev.issue_flush;
				assign update_pc_prescaiev = (((new_mem_request | gc[111]) | early_branch_flush) | scaiev_full_fetch_flush) | cva5_wrapper.scaiev.fetch_flush;
				assign update_pc = update_pc_prescaiev;
				always @(posedge clk)
					if (gc[115])
						pc_prescaiev <= CONFIG[1136-:32];
					else if (update_pc)
						pc_prescaiev <= {next_pc[31:2], 2'b00};
				assign pc = pc_prescaiev;
				assign pc_plus_4 = pc + 4;
				priority_encoder #(.WIDTH(4)) pc_sel_encoder(
					.priority_vector({1'b1, cva5_wrapper.cva5.bp.use_prediction & ~early_branch_flush, branch_flush, gc[32]}),
					.encoded_result(pc_sel)
				);
				assign pc_mux[0] = gc[31-:32];
				assign pc_mux[1] = cva5_wrapper.cva5.bp.branch_flush_pc;
				assign pc_mux[2] = (cva5_wrapper.cva5.bp.is_return & cva5_wrapper.cva5.ras.valid ? cva5_wrapper.cva5.ras.addr : cva5_wrapper.cva5.bp.predicted_pc);
				assign pc_mux[3] = pc_plus_4;
				assign next_pc_prescaiev = pc_mux[pc_sel];
				assign next_pc = (cva5_wrapper.scaiev.fetch_wrPCValid ? cva5_wrapper.scaiev.fetch_wrPC : next_pc_prescaiev);
				assign cva5_wrapper.scaiev.pre_fetch_PC = next_pc_prescaiev;
				assign cva5_wrapper.scaiev.pre_fetch_isStalling = ~update_pc;
				always @(posedge clk)
					if (flush_or_rst)
						exception_pending <= 0;
					else if (cva5_wrapper.cva5.itlb.is_fault | (new_mem_request & ~address_valid))
						exception_pending <= 1;
				assign cva5_wrapper.cva5.bp.new_mem_request = update_pc_prescaiev;
				assign cva5_wrapper.cva5.bp.next_pc = next_pc_prescaiev;
				assign cva5_wrapper.cva5.bp.if_pc = pc;
				assign cva5_wrapper.cva5.bp.pc_id = pc_id;
				assign cva5_wrapper.cva5.bp.pc_id_assigned = pc_id_assigned;
				assign cva5_wrapper.cva5.ras.pop = ((((cva5_wrapper.cva5.bp.use_prediction & cva5_wrapper.cva5.bp.is_return) & ~branch_flush) & ~gc[32]) & new_mem_request) & ~early_branch_flush;
				assign cva5_wrapper.cva5.ras.push = ((((cva5_wrapper.cva5.bp.use_prediction & cva5_wrapper.cva5.bp.is_call) & ~branch_flush) & ~gc[32]) & new_mem_request) & ~early_branch_flush;
				assign cva5_wrapper.cva5.ras.new_addr = pc_plus_4;
				assign cva5_wrapper.cva5.ras.branch_fetched = ((cva5_wrapper.cva5.bp.use_prediction & cva5_wrapper.cva5.bp.is_branch) & new_mem_request) & ~early_branch_flush;
				assign cva5_wrapper.cva5.itlb.virtual_address = pc;
				assign cva5_wrapper.cva5.itlb.execute = 1;
				assign cva5_wrapper.cva5.itlb.rnw = 0;
				assign cva5_wrapper.cva5.itlb.new_request = cva5_wrapper.cva5.itlb.ready & (CONFIG[1208] & tlb_on);
				assign translated_address = (CONFIG[1208] & tlb_on ? cva5_wrapper.cva5.itlb.physical_address : pc);
				assign flush_or_rst = ((rst | gc[111]) | early_branch_flush) | scaiev_full_fetch_flush;
				wire new_mem_request_prescaiev;
				assign new_mem_request_prescaiev = (((((~tlb_on | cva5_wrapper.cva5.itlb.done) & pc_id_available) & ~fetch_attr_fifo.full) & units_ready) & ~gc[114]) & ~exception_pending;
				assign new_mem_request = new_mem_request_prescaiev & ~(cva5_wrapper.scaiev.fetch_flush | cva5_wrapper.scaiev.fetch_stall);
				assign pc_id_assigned = new_mem_request | cva5_wrapper.cva5.itlb.is_fault;
				assign cva5_wrapper.scaiev.fetch_PC = pc;
				assign cva5_wrapper.scaiev.fetch_valid = new_mem_request_prescaiev | cva5_wrapper.cva5.itlb.is_fault;
				assign cva5_wrapper.scaiev.fetch_isStalling = ~new_mem_request_prescaiev;
				assign fetch_attr_fifo.push = pc_id_assigned;
				assign fetch_attr_fifo.potential_push = pc_id_assigned;
				assign fetch_attr_fifo.pop = internal_fetch_complete;
				one_hot_to_integer #(.C_WIDTH(NUM_SUB_UNITS)) hit_way_conv(
					.one_hot(sub_unit_address_match),
					.int_out(fetch_attr_next[NUM_SUB_UNITS_W - 1-:NUM_SUB_UNITS_W])
				);
				assign fetch_attr_next[2 + (NUM_SUB_UNITS_W + 1)] = cva5_wrapper.cva5.bp.use_prediction;
				assign fetch_attr_next[2 + (NUM_SUB_UNITS_W + 0)] = cva5_wrapper.cva5.bp.use_prediction & cva5_wrapper.cva5.bp.is_branch;
				assign fetch_attr_next[NUM_SUB_UNITS_W + 1] = address_valid;
				assign fetch_attr_next[NUM_SUB_UNITS_W + 0] = cva5_wrapper.cva5.itlb.is_fault;
				assign fetch_attr_fifo.data_in = fetch_attr_next;
				localparam _param_8ED13_DATA_WIDTH = 4 + NUM_SUB_UNITS_W;
				localparam _param_8ED13_FIFO_DEPTH = MAX_OUTSTANDING_REQUESTS;
				if (1) begin : attributes_fifo
					localparam DATA_WIDTH = _param_8ED13_DATA_WIDTH;
					localparam FIFO_DEPTH = _param_8ED13_FIFO_DEPTH;
					wire clk;
					wire rst;
					localparam LOG2_FIFO_DEPTH = 1;
					if (1) begin : gen_width_two
						reg [DATA_WIDTH - 1:0] shift_reg [0:1];
						reg [LOG2_FIFO_DEPTH:0] inflight_count;
						always @(posedge clk)
							if (rst)
								inflight_count <= 0;
							else
								inflight_count <= (inflight_count + sv2v_cast_2(cva5_wrapper.cva5.fetch_block.fetch_attr_fifo.pop)) - sv2v_cast_2(cva5_wrapper.cva5.fetch_block.fetch_attr_fifo.push);
						assign cva5_wrapper.cva5.fetch_block.fetch_attr_fifo.valid = inflight_count[LOG2_FIFO_DEPTH];
						assign cva5_wrapper.cva5.fetch_block.fetch_attr_fifo.full = cva5_wrapper.cva5.fetch_block.fetch_attr_fifo.valid & ~|inflight_count[0:0];
						always @(posedge clk)
							if (cva5_wrapper.cva5.fetch_block.fetch_attr_fifo.push) begin
								shift_reg[0] <= cva5_wrapper.cva5.fetch_block.fetch_attr_fifo.data_in;
								shift_reg[1] <= shift_reg[0];
							end
						assign cva5_wrapper.cva5.fetch_block.fetch_attr_fifo.data_out = shift_reg[~inflight_count[0]];
					end
				end
				assign attributes_fifo.clk = clk;
				assign attributes_fifo.rst = rst;
				assign fetch_attr = fetch_attr_fifo.data_out;
				assign inflight_count_next = (inflight_count + fetch_attr_fifo.push) - fetch_attr_fifo.pop;
				always @(posedge clk)
					if (rst)
						inflight_count <= 0;
					else
						inflight_count <= inflight_count_next;
				always @(posedge clk)
					if (rst)
						flush_count <= 0;
					else if ((gc[111] | scaiev_full_fetch_flush) | early_branch_flush)
						flush_count <= inflight_count_next;
					else if (|flush_count & fetch_attr_fifo.pop)
						flush_count <= flush_count - 1;
				for (_gv_i_12 = 0; _gv_i_12 < NUM_SUB_UNITS; _gv_i_12 = _gv_i_12 + 1) begin : gen_fetch_sources
					localparam i = _gv_i_12;
					assign sub_unit[i].new_request = fetch_attr_fifo.push & sub_unit_address_match[i];
					assign sub_unit[i].addr = translated_address;
					assign sub_unit[i].re = 1;
					assign sub_unit[i].we = 0;
					assign sub_unit[i].be = 1'sb0;
					assign sub_unit[i].data_in = 1'sb0;
					assign unit_ready[i] = sub_unit[i].ready;
					assign unit_data_valid[i] = sub_unit[i].data_valid;
					assign unit_data_array[i] = sub_unit[i].data_out;
				end
				if (CONFIG[420]) begin : gen_fetch_local_mem
					assign sub_unit_address_match[LOCAL_MEM_ID] = ilocal_mem_addr_utils.address_range_check(translated_address);
					localparam _bbase_AE507_unit = LOCAL_MEM_ID;
					if (1) begin : i_local_mem
						wire clk;
						wire rst;
						localparam _mbase_unit = _bbase_AE507_unit;
						assign cva5_wrapper.cva5.fetch_block.sub_unit[_mbase_unit].ready = 1;
						assign cva5_wrapper.instruction_bram.addr = cva5_wrapper.cva5.fetch_block.sub_unit[_mbase_unit].addr[31:2];
						assign cva5_wrapper.instruction_bram.en = cva5_wrapper.cva5.fetch_block.sub_unit[_mbase_unit].new_request;
						assign cva5_wrapper.instruction_bram.be = cva5_wrapper.cva5.fetch_block.sub_unit[_mbase_unit].be;
						assign cva5_wrapper.instruction_bram.data_in = cva5_wrapper.cva5.fetch_block.sub_unit[_mbase_unit].data_in;
						wire [32:1] sv2v_tmp_0B938;
						assign sv2v_tmp_0B938 = cva5_wrapper.instruction_bram.data_out;
						always @(*) cva5_wrapper.cva5.fetch_block.sub_unit[_mbase_unit].data_out = sv2v_tmp_0B938;
						always @(posedge clk)
							if (rst)
								cva5_wrapper.cva5.fetch_block.sub_unit[_mbase_unit].data_valid <= 0;
							else
								cva5_wrapper.cva5.fetch_block.sub_unit[_mbase_unit].data_valid <= cva5_wrapper.cva5.fetch_block.sub_unit[_mbase_unit].new_request & cva5_wrapper.cva5.fetch_block.sub_unit[_mbase_unit].re;
					end
					assign i_local_mem.clk = clk;
					assign i_local_mem.rst = rst;
				end
				if (CONFIG[290]) begin : gen_fetch_ibus
					assign sub_unit_address_match[BUS_ID] = ibus_addr_utils.address_range_check(translated_address);
					localparam _bbase_0BF02_ls = BUS_ID;
					if (1) begin : iwishbone_bus
						wire clk;
						wire rst;
						localparam _mbase_ls = _bbase_0BF02_ls;
						reg busy;
						assign cva5_wrapper.iwishbone.cti = 0;
						assign cva5_wrapper.iwishbone.bte = 0;
						always @(posedge clk)
							if (cva5_wrapper.cva5.fetch_block.sub_unit[_mbase_ls].new_request) begin
								cva5_wrapper.iwishbone.adr <= cva5_wrapper.cva5.fetch_block.sub_unit[_mbase_ls].addr[31:2];
								cva5_wrapper.iwishbone.sel <= (cva5_wrapper.cva5.fetch_block.sub_unit[_mbase_ls].we ? cva5_wrapper.cva5.fetch_block.sub_unit[_mbase_ls].be : {4 {1'sb1}});
								cva5_wrapper.iwishbone.we <= cva5_wrapper.cva5.fetch_block.sub_unit[_mbase_ls].we;
								cva5_wrapper.iwishbone.dat_w <= cva5_wrapper.cva5.fetch_block.sub_unit[_mbase_ls].data_in;
							end
						always @(posedge clk)
							if (rst)
								busy <= 0;
							else
								busy <= (busy & ~cva5_wrapper.iwishbone.ack) | cva5_wrapper.cva5.fetch_block.sub_unit[_mbase_ls].new_request;
						assign cva5_wrapper.cva5.fetch_block.sub_unit[_mbase_ls].ready = ~busy;
						assign cva5_wrapper.iwishbone.stb = busy;
						assign cva5_wrapper.iwishbone.cyc = busy;
						always @(posedge clk)
							if (rst)
								cva5_wrapper.cva5.fetch_block.sub_unit[_mbase_ls].data_valid <= 0;
							else
								cva5_wrapper.cva5.fetch_block.sub_unit[_mbase_ls].data_valid <= ~cva5_wrapper.iwishbone.we & cva5_wrapper.iwishbone.ack;
						always @(posedge clk)
							if (cva5_wrapper.iwishbone.ack)
								cva5_wrapper.cva5.fetch_block.sub_unit[_mbase_ls].data_out <= cva5_wrapper.iwishbone.dat_r;
					end
					assign iwishbone_bus.clk = clk;
					assign iwishbone_bus.rst = rst;
				end
				if (CONFIG[1002]) begin : gen_fetch_icache
					assign sub_unit_address_match[ICACHE_ID] = icache_addr_utils.address_range_check(translated_address);
					localparam _bbase_4F463_l1_request = 2'd2;
					localparam _bbase_4F463_l1_response = 2'd2;
					localparam _bbase_4F463_fetch_sub = ICACHE_ID;
					localparam _param_4F463_CONFIG = CONFIG;
					if (1) begin : i_cache
						reg _sv2v_0;
						localparam [1209:0] cva5_config_EXAMPLE_CONFIG = 1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002;
						localparam [1209:0] CONFIG = _param_4F463_CONFIG;
						wire clk;
						wire rst;
						localparam cva5_config_MAX_IDS = 8;
						localparam cva5_types_LOG2_MAX_IDS = 3;
						localparam riscv_types_ECODE_W = 5;
						wire [115:0] gc;
						wire icache_on;
						localparam _mbase_l1_request = _bbase_4F463_l1_request;
						localparam _mbase_l1_response = _bbase_4F463_l1_response;
						localparam _mbase_fetch_sub = _bbase_4F463_fetch_sub;
						function [95:0] cva5_config_get_derived_cache_params;
							input reg [1209:0] cpu;
							input reg [161:0] cache;
							input reg [63:0] addr;
							cva5_config_get_derived_cache_params = {sv2v_cast_32($clog2(cache[161-:32])), sv2v_cast_32($clog2(cache[129-:32])), sv2v_cast_32((($clog2((sv2v_cast_64(addr[31-:32]) - sv2v_cast_64(addr[63-:32])) + 1) - $clog2(cache[161-:32])) - $clog2(cache[129-:32])) - 2)};
						endfunction
						localparam [95:0] SCONFIG = cva5_config_get_derived_cache_params(CONFIG, CONFIG[1001-:162], CONFIG[839-:64]);
						wire tag_hit;
						wire [CONFIG[937-:32] - 1:0] tag_hit_way;
						reg tag_update;
						wire [CONFIG[937-:32] - 1:0] replacement_way;
						reg [CONFIG[937-:32] - 1:0] tag_update_way;
						reg [SCONFIG[63-:32] - 1:0] word_count;
						wire is_target_word;
						wire line_complete;
						wire [31:0] data_out [CONFIG[937-:32] - 1:0];
						reg [31:0] miss_data;
						reg miss_in_progress;
						reg miss_data_valid;
						reg second_cycle;
						reg [31:0] second_cycle_addr;
						reg idle;
						reg memory_complete;
						always @(posedge clk)
							if (rst)
								second_cycle <= 0;
							else
								second_cycle <= cva5_wrapper.cva5.fetch_block.sub_unit[_mbase_fetch_sub].new_request;
						always @(posedge clk)
							if (cva5_wrapper.cva5.fetch_block.sub_unit[_mbase_fetch_sub].new_request)
								second_cycle_addr <= cva5_wrapper.cva5.fetch_block.sub_unit[_mbase_fetch_sub].addr;
						always @(posedge clk)
							if (rst)
								tag_update <= 0;
							else
								tag_update <= cva5_wrapper.cva5.l1_request[_mbase_l1_request].ack;
						cycler #(.C_WIDTH(CONFIG[937-:32])) replacement_policy(
							.clk(clk),
							.rst(rst),
							.en(1'b1),
							.one_hot(replacement_way)
						);
						always @(posedge clk)
							if (second_cycle)
								tag_update_way <= replacement_way;
						wire initiate_l1_request;
						reg request_r;
						wire [32:1] sv2v_tmp_81A6C;
						assign sv2v_tmp_81A6C = second_cycle_addr;
						always @(*) cva5_wrapper.cva5.l1_request[_mbase_l1_request].addr = sv2v_tmp_81A6C;
						assign cva5_wrapper.cva5.l1_request[_mbase_l1_request].data = 0;
						assign cva5_wrapper.cva5.l1_request[_mbase_l1_request].rnw = 1;
						assign cva5_wrapper.cva5.l1_request[_mbase_l1_request].be = 0;
						assign cva5_wrapper.cva5.l1_request[_mbase_l1_request].size = sv2v_cast_5(CONFIG[969-:32] - 1);
						assign cva5_wrapper.cva5.l1_request[_mbase_l1_request].is_amo = 0;
						assign cva5_wrapper.cva5.l1_request[_mbase_l1_request].amo = 0;
						assign initiate_l1_request = second_cycle & (~tag_hit | ~icache_on);
						always @(posedge clk)
							if (rst)
								request_r <= 0;
							else
								request_r <= (initiate_l1_request | request_r) & ~cva5_wrapper.cva5.l1_request[_mbase_l1_request].ack;
						assign cva5_wrapper.cva5.l1_request[_mbase_l1_request].request = request_r;
						always @(posedge clk)
							if (rst)
								miss_in_progress <= 0;
							else
								miss_in_progress <= cva5_wrapper.cva5.l1_request[_mbase_l1_request].ack | (miss_in_progress & ~line_complete);
						itag_banks #(
							.CONFIG(CONFIG),
							.SCONFIG(SCONFIG)
						) icache_tag_banks(
							.clk(clk),
							.rst(rst),
							.stage1_addr(cva5_wrapper.cva5.fetch_block.sub_unit[_mbase_fetch_sub].addr),
							.stage2_addr(second_cycle_addr),
							.update_way(tag_update_way),
							.update(tag_update),
							.stage1_adv(cva5_wrapper.cva5.fetch_block.sub_unit[_mbase_fetch_sub].new_request & icache_on),
							.tag_hit(tag_hit),
							.tag_hit_way(tag_hit_way)
						);
						genvar _gv_i_9;
						for (_gv_i_9 = 0; _gv_i_9 < CONFIG[937-:32]; _gv_i_9 = _gv_i_9 + 1) begin : idata_bank_gen
							localparam i = _gv_i_9;
							localparam [3:0] sv2v_uu_idata_bank_ext_be_a_0 = 1'sb0;
							localparam [3:0] sv2v_uu_idata_bank_ext_be_b_1 = 1'sb1;
							localparam [31:0] sv2v_uu_idata_bank_ext_data_in_a_0 = 1'sb0;
							byte_en_BRAM #(.LINES(CONFIG[1001-:32] * CONFIG[969-:32])) idata_bank(
								.clk(clk),
								.addr_a(cva5_wrapper.cva5.fetch_block.sub_unit[_mbase_fetch_sub].addr[2+:SCONFIG[95-:32] + SCONFIG[63-:32]]),
								.addr_b({second_cycle_addr[2 + SCONFIG[63-:32]+:SCONFIG[95-:32]], word_count}),
								.en_a(cva5_wrapper.cva5.fetch_block.sub_unit[_mbase_fetch_sub].new_request),
								.en_b(tag_update_way[i] & cva5_wrapper.cva5.l1_response[_mbase_l1_response].data_valid),
								.be_a(sv2v_uu_idata_bank_ext_be_a_0),
								.be_b(sv2v_uu_idata_bank_ext_be_b_1),
								.data_in_a(sv2v_uu_idata_bank_ext_data_in_a_0),
								.data_in_b(cva5_wrapper.cva5.l1_response[_mbase_l1_response].data),
								.data_out_a(data_out[i]),
								.data_out_b()
							);
						end
						always @(posedge clk)
							if (rst)
								word_count <= 0;
							else if (cva5_wrapper.cva5.l1_response[_mbase_l1_response].data_valid)
								word_count <= word_count + 1;
						assign is_target_word = second_cycle_addr[2+:SCONFIG[63-:32]] == word_count;
						always @(posedge clk)
							if (cva5_wrapper.cva5.l1_response[_mbase_l1_response].data_valid & is_target_word)
								miss_data <= cva5_wrapper.cva5.l1_response[_mbase_l1_response].data;
							else
								miss_data <= 0;
						always @(posedge clk)
							if (rst)
								miss_data_valid <= 0;
							else
								miss_data_valid <= (miss_in_progress & cva5_wrapper.cva5.l1_response[_mbase_l1_response].data_valid) & is_target_word;
						function automatic [SCONFIG[63-:32] - 1:0] sv2v_cast_03DB4;
							input reg [SCONFIG[63-:32] - 1:0] inp;
							sv2v_cast_03DB4 = inp;
						endfunction
						assign line_complete = cva5_wrapper.cva5.l1_response[_mbase_l1_response].data_valid && (word_count == sv2v_cast_03DB4(CONFIG[969-:32] - 1));
						always @(posedge clk)
							if (rst)
								memory_complete <= 0;
							else
								memory_complete <= line_complete;
						always @(*) begin
							if (_sv2v_0)
								;
							cva5_wrapper.cva5.fetch_block.sub_unit[_mbase_fetch_sub].data_out = miss_data;
							begin : sv2v_autoblock_13
								reg signed [31:0] i;
								for (i = 0; i < CONFIG[937-:32]; i = i + 1)
									cva5_wrapper.cva5.fetch_block.sub_unit[_mbase_fetch_sub].data_out = cva5_wrapper.cva5.fetch_block.sub_unit[_mbase_fetch_sub].data_out | (data_out[i] & {32 {tag_hit_way[i]}});
							end
						end
						wire [1:1] sv2v_tmp_05ADA;
						assign sv2v_tmp_05ADA = miss_data_valid | tag_hit;
						always @(*) cva5_wrapper.cva5.fetch_block.sub_unit[_mbase_fetch_sub].data_valid = sv2v_tmp_05ADA;
						always @(posedge clk)
							if (rst)
								idle <= 1;
							else if (cva5_wrapper.cva5.fetch_block.sub_unit[_mbase_fetch_sub].new_request)
								idle <= 0;
							else if (memory_complete | tag_hit)
								idle <= 1;
						assign cva5_wrapper.cva5.fetch_block.sub_unit[_mbase_fetch_sub].ready = (tag_hit | memory_complete) | idle;
						initial _sv2v_0 = 0;
					end
					assign i_cache.clk = clk;
					assign i_cache.rst = rst;
					assign i_cache.gc = gc;
					assign i_cache.icache_on = icache_on;
				end
				assign units_ready = &unit_ready;
				assign address_valid = |sub_unit_address_match;
				wire valid_fetch_result;
				assign valid_fetch_result = (CONFIG[1209] ? (fetch_attr_fifo.valid & fetch_attr[NUM_SUB_UNITS_W + 1]) & ~fetch_attr[NUM_SUB_UNITS_W + 0] : 1);
				assign if_pc = pc;
				assign fetch_metadata[5] = valid_fetch_result;
				function automatic [4:0] sv2v_cast_8A97A;
					input reg [4:0] inp;
					sv2v_cast_8A97A = inp;
				endfunction
				assign fetch_metadata[4-:riscv_types_ECODE_W] = sv2v_cast_8A97A(5'd1);
				assign fetch_instruction = unit_data_array[fetch_attr[NUM_SUB_UNITS_W - 1-:NUM_SUB_UNITS_W]];
				assign internal_fetch_complete = fetch_attr_fifo.valid & (fetch_attr[NUM_SUB_UNITS_W + 1] ? |unit_data_valid : ~valid_fetch_result);
				assign fetch_complete = internal_fetch_complete & ~|flush_count;
				localparam cva5_config_ENABLE_TRACE_INTERFACE = 1;
				if (CONFIG[1203] | CONFIG[1208]) begin : gen_branch_corruption_check
					wire is_branch_or_jump;
					assign is_branch_or_jump = |{fetch_instruction[6:2] == 5'b11011, fetch_instruction[6:2] == 5'b11001, fetch_instruction[6:2] == 5'b11000};
					assign early_branch_flush = ((valid_fetch_result & |unit_data_valid) & fetch_attr[2 + (NUM_SUB_UNITS_W + 1)]) & ~is_branch_or_jump;
					assign early_branch_flush_ras_adjust = ((valid_fetch_result & |unit_data_valid) & fetch_attr[2 + (NUM_SUB_UNITS_W + 0)]) & ~is_branch_or_jump;
					if (cva5_config_ENABLE_TRACE_INTERFACE) begin : genblk1
						assign tr_early_branch_correction = early_branch_flush;
					end
				end
			end
			assign fetch_block.clk = clk;
			assign fetch_block.rst = rst;
			assign fetch_block.branch_flush = branch_flush;
			assign fetch_block.gc = gc;
			assign fetch_block.pc_id = pc_id;
			assign fetch_block.pc_id_available = pc_id_available & ~cva5_wrapper.scaiev.fetch_stall;
			assign pc_id_assigned = fetch_block.pc_id_assigned;
			assign fetch_complete = fetch_block.fetch_complete;
			assign fetch_metadata = fetch_block.fetch_metadata;
			assign early_branch_flush = fetch_block.early_branch_flush;
			assign early_branch_flush_ras_adjust = fetch_block.early_branch_flush_ras_adjust;
			assign if_pc = fetch_block.if_pc;
			assign fetch_instruction = fetch_block.fetch_instruction;
			assign fetch_block.icache_on = 1'sb1;
			assign fetch_block.tlb_on = tlb_on;
			assign fetch_block.exception = 1'b0;
			assign tr_early_branch_correction = fetch_block.tr_early_branch_correction;
			localparam _param_4888A_CONFIG = CONFIG;
			if (1) begin : bp_block
				reg _sv2v_0;
				localparam [1209:0] cva5_config_EXAMPLE_CONFIG = 1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002;
				localparam [1209:0] CONFIG = _param_4888A_CONFIG;
				wire clk;
				wire rst;
				localparam cva5_config_MAX_IDS_FETCH = 8;
				localparam cva5_types_LOG2_MAX_IDS_FETCH = 3;
				localparam cva5_config_MAX_IDS = 8;
				localparam cva5_types_LOG2_MAX_IDS = 3;
				wire [74:0] br_results;
				localparam signed [63:0] CACHE_RANGE = (sv2v_cast_64(CONFIG[807-:32]) - sv2v_cast_64(CONFIG[839-:32])) + 1;
				localparam signed [63:0] SCRATCH_RANGE = (sv2v_cast_64(CONFIG[387-:32]) - sv2v_cast_64(CONFIG[419-:32])) + 1;
				localparam signed [63:0] BUS_RANGE = (sv2v_cast_64(CONFIG[257-:32]) - sv2v_cast_64(CONFIG[289-:32])) + 1;
				function signed [31:0] get_memory_width;
					input reg _sv2v_unused;
					if (CONFIG[1208])
						get_memory_width = 32;
					else if (CONFIG[1002] && (((CONFIG[420] && (CACHE_RANGE > SCRATCH_RANGE)) || (CONFIG[290] && (CACHE_RANGE > BUS_RANGE))) || (!CONFIG[420] && !CONFIG[290])))
						get_memory_width = $clog2(CACHE_RANGE);
					else if (CONFIG[290] && ((CONFIG[420] && (BUS_RANGE > SCRATCH_RANGE)) || !CONFIG[420]))
						get_memory_width = $clog2(BUS_RANGE);
					else
						get_memory_width = $clog2(SCRATCH_RANGE);
				endfunction
				localparam BRANCH_ADDR_W = $clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[95-:32]);
				localparam BTAG_W = (get_memory_width(0) - BRANCH_ADDR_W) - 2;
				function [BTAG_W - 1:0] get_tag;
					input reg [31:0] pc;
					get_tag = pc[BRANCH_ADDR_W + 2+:BTAG_W];
				endfunction
				wire [(((1 + BTAG_W) + 4) >= 0 ? (CONFIG[127-:32] * ((1 + BTAG_W) + 5)) - 1 : (CONFIG[127-:32] * (1 - ((1 + BTAG_W) + 4))) + ((1 + BTAG_W) + 3)):(((1 + BTAG_W) + 4) >= 0 ? 0 : (1 + BTAG_W) + 4)] if_entry;
				reg [(1 + BTAG_W) + 4:0] ex_entry;
				reg [(3 + CONFIG[127-:32]) - 1:0] branch_metadata_table [0:7];
				wire [(3 + CONFIG[127-:32]) - 1:0] branch_metadata_if;
				wire [(3 + CONFIG[127-:32]) - 1:0] branch_metadata_ex;
				wire branch_predictor_direction_changed;
				wire [31:0] new_jump_addr;
				wire [(CONFIG[127-:32] * 32) - 1:0] predicted_pc;
				wire [CONFIG[127-:32] - 1:0] tag_matches;
				wire [CONFIG[127-:32] - 1:0] replacement_way;
				wire [CONFIG[127-:32] - 1:0] tag_update_way;
				wire [CONFIG[127-:32] - 1:0] target_update_way;
				wire [$clog2((1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[127-:32] > 1 ? 1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[127-:32] : 2)) - 1:0] hit_way;
				wire tag_match;
				wire use_predicted_pc;
				genvar _gv_i_11;
				if (CONFIG[128]) begin : genblk1
					for (_gv_i_11 = 0; _gv_i_11 < CONFIG[127-:32]; _gv_i_11 = _gv_i_11 + 1) begin : gen_branch_tag_banks
						localparam i = _gv_i_11;
						branch_predictor_ram #(
							.C_DATA_WIDTH((((1 + BTAG_W) + 4) >= 0 ? (1 + BTAG_W) + 5 : 1 - ((1 + BTAG_W) + 4))),
							.C_DEPTH(CONFIG[95-:32])
						) tag_bank(
							.clk(clk),
							.rst(rst),
							.write_addr(br_results[38+:BRANCH_ADDR_W]),
							.write_en(tag_update_way[i]),
							.write_data(ex_entry),
							.read_addr(cva5_wrapper.cva5.bp.next_pc[2+:BRANCH_ADDR_W]),
							.read_en(cva5_wrapper.cva5.bp.new_mem_request),
							.read_data(if_entry[(((1 + BTAG_W) + 4) >= 0 ? 0 : (1 + BTAG_W) + 4) + (i * (((1 + BTAG_W) + 4) >= 0 ? (1 + BTAG_W) + 5 : 1 - ((1 + BTAG_W) + 4)))+:(((1 + BTAG_W) + 4) >= 0 ? (1 + BTAG_W) + 5 : 1 - ((1 + BTAG_W) + 4))])
						);
					end
				end
				if (CONFIG[128]) begin : genblk2
					for (_gv_i_11 = 0; _gv_i_11 < CONFIG[127-:32]; _gv_i_11 = _gv_i_11 + 1) begin : gen_branch_table_banks
						localparam i = _gv_i_11;
						branch_predictor_ram #(
							.C_DATA_WIDTH(32),
							.C_DEPTH(CONFIG[95-:32])
						) addr_table(
							.clk(clk),
							.rst(rst),
							.write_addr(br_results[38+:BRANCH_ADDR_W]),
							.write_en(target_update_way[i]),
							.write_data(br_results[35-:32]),
							.read_addr(cva5_wrapper.cva5.bp.next_pc[2+:BRANCH_ADDR_W]),
							.read_en(cva5_wrapper.cva5.bp.new_mem_request),
							.read_data(predicted_pc[i * 32+:32])
						);
					end
				end
				if (CONFIG[128]) begin : genblk3
					for (_gv_i_11 = 0; _gv_i_11 < CONFIG[127-:32]; _gv_i_11 = _gv_i_11 + 1) begin : gen_branch_hit_detection
						localparam i = _gv_i_11;
						assign tag_matches[i] = {if_entry[(i * (((1 + BTAG_W) + 4) >= 0 ? (1 + BTAG_W) + 5 : 1 - ((1 + BTAG_W) + 4))) + (((1 + BTAG_W) + 4) >= 0 ? 1 + (BTAG_W + 4) : ((1 + BTAG_W) + 4) - (1 + (BTAG_W + 4)))], if_entry[(((1 + BTAG_W) + 4) >= 0 ? (i * (((1 + BTAG_W) + 4) >= 0 ? (1 + BTAG_W) + 5 : 1 - ((1 + BTAG_W) + 4))) + (((1 + BTAG_W) + 4) >= 0 ? BTAG_W + 4 : ((1 + BTAG_W) + 4) - (BTAG_W + 4)) : (((i * (((1 + BTAG_W) + 4) >= 0 ? (1 + BTAG_W) + 5 : 1 - ((1 + BTAG_W) + 4))) + (((1 + BTAG_W) + 4) >= 0 ? BTAG_W + 4 : ((1 + BTAG_W) + 4) - (BTAG_W + 4))) + ((BTAG_W + 4) >= 5 ? BTAG_W + 0 : 6 - (BTAG_W + 4))) - 1)-:((BTAG_W + 4) >= 5 ? BTAG_W + 0 : 6 - (BTAG_W + 4))]} == {1'b1, get_tag(cva5_wrapper.cva5.bp.if_pc)};
					end
				end
				if (CONFIG[127-:32] > 1) begin : genblk4
					one_hot_to_integer #(.C_WIDTH(CONFIG[127-:32])) hit_way_conv(
						.one_hot(tag_matches),
						.int_out(hit_way)
					);
				end
				else begin : genblk4
					assign hit_way = 0;
				end
				assign tag_match = |tag_matches;
				assign use_predicted_pc = CONFIG[128] & tag_match;
				assign cva5_wrapper.cva5.bp.predicted_pc = predicted_pc[hit_way * 32+:32];
				assign cva5_wrapper.cva5.bp.use_prediction = use_predicted_pc;
				assign cva5_wrapper.cva5.bp.is_branch = if_entry[(hit_way * (((1 + BTAG_W) + 4) >= 0 ? (1 + BTAG_W) + 5 : 1 - ((1 + BTAG_W) + 4))) + (((1 + BTAG_W) + 4) >= 0 ? 4 : (1 + BTAG_W) + 0)];
				assign cva5_wrapper.cva5.bp.is_return = if_entry[(hit_way * (((1 + BTAG_W) + 4) >= 0 ? (1 + BTAG_W) + 5 : 1 - ((1 + BTAG_W) + 4))) + (((1 + BTAG_W) + 4) >= 0 ? 3 : (1 + BTAG_W) + 1)];
				assign cva5_wrapper.cva5.bp.is_call = if_entry[(hit_way * (((1 + BTAG_W) + 4) >= 0 ? (1 + BTAG_W) + 5 : 1 - ((1 + BTAG_W) + 4))) + (((1 + BTAG_W) + 4) >= 0 ? 2 : (1 + BTAG_W) + 2)];
				cycler #(.C_WIDTH(CONFIG[127-:32])) replacement_policy(
					.clk(clk),
					.rst(rst),
					.en(1'b1),
					.one_hot(replacement_way)
				);
				assign branch_metadata_if[CONFIG[127-:32] + 2-:((CONFIG[127-:32] + 2) >= (1 + (CONFIG[127-:32] + 0)) ? ((CONFIG[127-:32] + 2) - (1 + (CONFIG[127-:32] + 0))) + 1 : ((1 + (CONFIG[127-:32] + 0)) - (CONFIG[127-:32] + 2)) + 1)] = if_entry[(((1 + BTAG_W) + 4) >= 0 ? (hit_way * (((1 + BTAG_W) + 4) >= 0 ? (1 + BTAG_W) + 5 : 1 - ((1 + BTAG_W) + 4))) + (((1 + BTAG_W) + 4) >= 0 ? 1 : (1 + BTAG_W) + 3) : ((hit_way * (((1 + BTAG_W) + 4) >= 0 ? (1 + BTAG_W) + 5 : 1 - ((1 + BTAG_W) + 4))) + (((1 + BTAG_W) + 4) >= 0 ? 1 : (1 + BTAG_W) + 3)) + 1)-:2];
				assign branch_metadata_if[CONFIG[127-:32] + 0] = use_predicted_pc;
				assign branch_metadata_if[CONFIG[127-:32] - 1-:CONFIG[127-:32]] = (tag_match ? tag_matches : replacement_way);
				always @(posedge clk)
					if (cva5_wrapper.cva5.bp.pc_id_assigned)
						branch_metadata_table[cva5_wrapper.cva5.bp.pc_id] <= branch_metadata_if;
				assign branch_metadata_ex = branch_metadata_table[br_results[71-:3]];
				wire [1:1] sv2v_tmp_5776B;
				assign sv2v_tmp_5776B = 1;
				always @(*) ex_entry[1 + (BTAG_W + 4)] = sv2v_tmp_5776B;
				wire [((BTAG_W + 4) >= 5 ? BTAG_W + 0 : 6 - (BTAG_W + 4)) * 1:1] sv2v_tmp_D772B;
				assign sv2v_tmp_D772B = get_tag(br_results[67-:32]);
				always @(*) ex_entry[BTAG_W + 4-:((BTAG_W + 4) >= 5 ? BTAG_W + 0 : 6 - (BTAG_W + 4))] = sv2v_tmp_D772B;
				wire [1:1] sv2v_tmp_07CC6;
				assign sv2v_tmp_07CC6 = br_results[2];
				always @(*) ex_entry[4] = sv2v_tmp_07CC6;
				wire [1:1] sv2v_tmp_D0AA2;
				assign sv2v_tmp_D0AA2 = br_results[1];
				always @(*) ex_entry[3] = sv2v_tmp_D0AA2;
				wire [1:1] sv2v_tmp_1AF02;
				assign sv2v_tmp_1AF02 = br_results[0];
				always @(*) ex_entry[2] = sv2v_tmp_1AF02;
				always @(*) begin
					if (_sv2v_0)
						;
					case (branch_metadata_ex[CONFIG[127-:32] + 2-:((CONFIG[127-:32] + 2) >= (1 + (CONFIG[127-:32] + 0)) ? ((CONFIG[127-:32] + 2) - (1 + (CONFIG[127-:32] + 0))) + 1 : ((1 + (CONFIG[127-:32] + 0)) - (CONFIG[127-:32] + 2)) + 1)])
						2'b00: ex_entry[1-:2] = (br_results[3] ? 2'b01 : 2'b00);
						2'b01: ex_entry[1-:2] = (br_results[3] ? 2'b10 : 2'b00);
						2'b10: ex_entry[1-:2] = (br_results[3] ? 2'b11 : 2'b01);
						2'b11: ex_entry[1-:2] = (br_results[3] ? 2'b11 : 2'b10);
					endcase
					if (~branch_metadata_ex[CONFIG[127-:32] + 0])
						ex_entry[1-:2] = (br_results[3] ? 2'b11 : 2'b00);
				end
				assign branch_predictor_direction_changed = ~branch_metadata_ex[CONFIG[127-:32] + 0] | (branch_metadata_ex[CONFIG[127-:32] + 2] ^ ex_entry[1]);
				assign tag_update_way = {CONFIG[127-:32] {br_results[68]}} & branch_metadata_ex[CONFIG[127-:32] - 1-:CONFIG[127-:32]];
				assign target_update_way = {CONFIG[127-:32] {branch_predictor_direction_changed}} & tag_update_way;
				assign cva5_wrapper.cva5.bp.branch_flush_pc = br_results[35-:32];
				assign cva5_wrapper.cva5.ras.branch_retired = (br_results[68] & br_results[2]) & branch_metadata_ex[CONFIG[127-:32] + 0];
				initial _sv2v_0 = 0;
			end
			assign bp_block.clk = clk;
			assign bp_block.rst = rst;
			assign bp_block.br_results = br_results;
			localparam _param_E6997_CONFIG = CONFIG;
			if (1) begin : ras_block
				localparam [1209:0] cva5_config_EXAMPLE_CONFIG = 1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002;
				localparam [1209:0] CONFIG = _param_E6997_CONFIG;
				wire clk;
				wire rst;
				localparam cva5_config_MAX_IDS = 8;
				localparam cva5_types_LOG2_MAX_IDS = 3;
				localparam riscv_types_ECODE_W = 5;
				wire [115:0] gc;
				wire early_branch_flush_ras_adjust;
				reg [31:0] lut_ram [0:CONFIG[63-:32] - 1];
				reg [CONFIG[63-:32] - 1:0] lut_ram_valid;
				localparam RAS_DEPTH_W = $clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[63-:32]);
				reg [RAS_DEPTH_W - 1:0] read_index;
				wire [RAS_DEPTH_W - 1:0] new_index;
				localparam _param_FE3FA_DATA_WIDTH = RAS_DEPTH_W;
				if (1) begin : ri_fifo
					localparam DATA_WIDTH = _param_FE3FA_DATA_WIDTH;
					wire push;
					wire pop;
					wire [DATA_WIDTH - 1:0] data_in;
					wire [DATA_WIDTH - 1:0] data_out;
					wire valid;
					wire full;
					wire potential_push;
				end
				initial begin : sv2v_autoblock_14
					integer isaac_init;
					for (isaac_init = 0; isaac_init < CONFIG[63-:32]; isaac_init = isaac_init + 1)
						lut_ram[isaac_init] = 1'sb0;
				end
				assign cva5_wrapper.cva5.ras.addr = lut_ram[read_index];
				assign cva5_wrapper.cva5.ras.valid = lut_ram_valid[read_index];
				localparam cva5_config_MAX_IDS_FETCH = 8;
				localparam _param_8D7F1_DATA_WIDTH = RAS_DEPTH_W;
				localparam _param_8D7F1_FIFO_DEPTH = cva5_config_MAX_IDS_FETCH;
				if (1) begin : read_index_fifo
					localparam DATA_WIDTH = _param_8D7F1_DATA_WIDTH;
					localparam FIFO_DEPTH = _param_8D7F1_FIFO_DEPTH;
					wire clk;
					wire rst;
					localparam LOG2_FIFO_DEPTH = 3;
					if (1) begin : gen_width_3_plus
						wire [DATA_WIDTH - 1:0] lut_ram [0:7];
						wire [2:0] write_index;
						wire [2:0] read_index;
						reg [LOG2_FIFO_DEPTH:0] inflight_count;
						always @(posedge clk)
							if (rst)
								inflight_count <= 0;
							else
								inflight_count <= (inflight_count + sv2v_cast_4(cva5_wrapper.cva5.ras_block.ri_fifo.pop)) - sv2v_cast_4(cva5_wrapper.cva5.ras_block.ri_fifo.push);
						assign cva5_wrapper.cva5.ras_block.ri_fifo.valid = inflight_count[LOG2_FIFO_DEPTH];
						assign cva5_wrapper.cva5.ras_block.ri_fifo.full = cva5_wrapper.cva5.ras_block.ri_fifo.valid & ~|inflight_count[2:0];
						lfsr #(
							.WIDTH(LOG2_FIFO_DEPTH),
							.NEEDS_RESET(1)
						) lfsr_read_index(
							.clk(clk),
							.rst(rst),
							.en(cva5_wrapper.cva5.ras_block.ri_fifo.pop),
							.value(read_index)
						);
						lfsr #(
							.WIDTH(LOG2_FIFO_DEPTH),
							.NEEDS_RESET(1)
						) lfsr_write_index(
							.clk(clk),
							.rst(rst),
							.en(cva5_wrapper.cva5.ras_block.ri_fifo.push),
							.value(write_index)
						);
						lutram_1w_1r #(
							.WIDTH(DATA_WIDTH),
							.DEPTH(FIFO_DEPTH)
						) write_port(
							.clk(clk),
							.waddr(write_index),
							.raddr(read_index),
							.ram_write(cva5_wrapper.cva5.ras_block.ri_fifo.potential_push),
							.new_ram_data(cva5_wrapper.cva5.ras_block.ri_fifo.data_in),
							.ram_data_out(cva5_wrapper.cva5.ras_block.ri_fifo.data_out)
						);
					end
				end
				assign read_index_fifo.clk = clk;
				assign read_index_fifo.rst = (rst | gc[111]) | early_branch_flush_ras_adjust;
				assign ri_fifo.data_in = read_index;
				assign ri_fifo.push = cva5_wrapper.cva5.ras.branch_fetched;
				assign ri_fifo.potential_push = cva5_wrapper.cva5.ras.branch_fetched;
				assign ri_fifo.pop = cva5_wrapper.cva5.ras.branch_retired & ri_fifo.valid;
				always @(posedge clk)
					if (cva5_wrapper.cva5.ras.push)
						lut_ram[new_index] <= cva5_wrapper.cva5.ras.new_addr;
				always @(posedge clk)
					if (rst)
						lut_ram_valid <= 1'sb0;
					else begin
						if (cva5_wrapper.cva5.ras.push)
							lut_ram_valid[new_index] <= 1'b1;
						if (cva5_wrapper.cva5.ras.pop)
							lut_ram_valid[read_index] <= 1'b0;
					end
				wire [RAS_DEPTH_W - 1:0] new_index_base;
				assign new_index_base = (gc[111] & ri_fifo.valid ? ri_fifo.data_out : read_index);
				function automatic [RAS_DEPTH_W - 1:0] sv2v_cast_FFB34;
					input reg [RAS_DEPTH_W - 1:0] inp;
					sv2v_cast_FFB34 = inp;
				endfunction
				assign new_index = (new_index_base + sv2v_cast_FFB34(cva5_wrapper.cva5.ras.push)) - sv2v_cast_FFB34(cva5_wrapper.cva5.ras.pop);
				always @(posedge clk) read_index <= new_index;
			end
			assign ras_block.clk = clk;
			assign ras_block.rst = rst;
			assign ras_block.gc = gc;
			assign ras_block.early_branch_flush_ras_adjust = early_branch_flush_ras_adjust;
			if (CONFIG[1208]) begin : gen_itlb_immu
				localparam _param_DAC67_WAYS = CONFIG[775-:32];
				localparam _param_DAC67_DEPTH = CONFIG[743-:32];
				if (1) begin : i_tlb
					reg _sv2v_0;
					localparam WAYS = _param_DAC67_WAYS;
					localparam DEPTH = _param_DAC67_DEPTH;
					wire clk;
					wire rst;
					localparam cva5_config_MAX_IDS = 8;
					localparam cva5_types_LOG2_MAX_IDS = 3;
					localparam riscv_types_ECODE_W = 5;
					wire [115:0] gc;
					wire abort_request;
					localparam riscv_types_ASIDLEN = 9;
					wire [8:0] asid;
					localparam TLB_TAG_W = 20 - $clog2(DEPTH);
					wire [$clog2(DEPTH) - 1:0] tlb_addr;
					wire [TLB_TAG_W - 1:0] virtual_tag;
					wire [(1 + TLB_TAG_W) + 19:0] ram [DEPTH - 1:0][WAYS - 1:0];
					wire [DEPTH - 1:0] valid [WAYS - 1:0];
					reg [WAYS - 1:0] tag_hit;
					wire hit;
					wire [WAYS - 1:0] replacement_way;
					wire [(((1 + TLB_TAG_W) + 19) >= 0 ? (1 + TLB_TAG_W) + 20 : 1 - ((1 + TLB_TAG_W) + 19)) - 1:0] ram_data [WAYS - 1:0];
					wire [(1 + TLB_TAG_W) + 19:0] ram_entry [WAYS - 1:0];
					wire [(1 + TLB_TAG_W) + 19:0] new_entry;
					wire [$clog2(DEPTH) - 1:0] flush_addr;
					wire [WAYS - 1:0] tlb_write;
					reg request_in_progress;
					reg mmu_request_complete;
					lfsr #(
						.WIDTH($clog2(DEPTH)),
						.NEEDS_RESET(0)
					) lfsr_counter(
						.clk(clk),
						.rst(rst),
						.en(gc[107]),
						.value(flush_addr)
					);
					assign tlb_addr = (gc[107] ? flush_addr : cva5_wrapper.cva5.itlb.virtual_address[12+:$clog2(DEPTH)]);
					assign tlb_write = {WAYS {gc[107]}} | replacement_way;
					assign new_entry[1 + (TLB_TAG_W + 19)] = ~gc[107];
					assign new_entry[TLB_TAG_W + 19-:((TLB_TAG_W + 19) >= 20 ? TLB_TAG_W + 0 : 21 - (TLB_TAG_W + 19))] = virtual_tag;
					assign new_entry[19-:20] = cva5_wrapper.cva5.immu.upper_physical_address;
					genvar _gv_i_10;
					for (_gv_i_10 = 0; _gv_i_10 < WAYS; _gv_i_10 = _gv_i_10 + 1) begin : lut_rams
						localparam i = _gv_i_10;
						lutram_1w_1r #(
							.WIDTH((((1 + TLB_TAG_W) + 19) >= 0 ? (1 + TLB_TAG_W) + 20 : 1 - ((1 + TLB_TAG_W) + 19))),
							.DEPTH(DEPTH)
						) write_port(
							.clk(clk),
							.waddr(tlb_addr),
							.raddr(tlb_addr),
							.ram_write(tlb_write[i]),
							.new_ram_data(new_entry),
							.ram_data_out(ram_data[i])
						);
						assign ram_entry[i] = ram_data[i];
					end
					cycler #(.C_WIDTH(WAYS)) replacement_policy(
						.clk(clk),
						.rst(rst),
						.en(1'b1),
						.one_hot(replacement_way)
					);
					assign virtual_tag = cva5_wrapper.cva5.itlb.virtual_address[31:32 - TLB_TAG_W];
					always @(*) begin
						if (_sv2v_0)
							;
						begin : sv2v_autoblock_15
							reg signed [31:0] i;
							for (i = 0; i < WAYS; i = i + 1)
								tag_hit[i] = {ram_entry[i][1 + (TLB_TAG_W + 19)], ram_entry[i][TLB_TAG_W + 19-:((TLB_TAG_W + 19) >= 20 ? TLB_TAG_W + 0 : 21 - (TLB_TAG_W + 19))]} == {1'b1, virtual_tag};
						end
					end
					assign cva5_wrapper.cva5.itlb.ready = ~request_in_progress;
					always @(posedge clk)
						if (rst)
							request_in_progress <= 0;
						else if ((cva5_wrapper.cva5.immu.write_entry | cva5_wrapper.cva5.immu.is_fault) | abort_request)
							request_in_progress <= 0;
						else if (cva5_wrapper.cva5.itlb.new_request & ~hit)
							request_in_progress <= 1;
					assign cva5_wrapper.cva5.immu.request = request_in_progress;
					always @(posedge clk)
						if (rst)
							mmu_request_complete <= 0;
						else
							mmu_request_complete <= cva5_wrapper.cva5.immu.write_entry;
					assign cva5_wrapper.cva5.immu.virtual_address = cva5_wrapper.cva5.itlb.virtual_address;
					assign cva5_wrapper.cva5.immu.execute = cva5_wrapper.cva5.itlb.execute;
					assign cva5_wrapper.cva5.immu.rnw = cva5_wrapper.cva5.itlb.rnw;
					assign hit = |tag_hit;
					assign cva5_wrapper.cva5.itlb.done = hit & (cva5_wrapper.cva5.itlb.new_request | mmu_request_complete);
					assign cva5_wrapper.cva5.itlb.is_fault = cva5_wrapper.cva5.immu.is_fault;
					always @(*) begin
						if (_sv2v_0)
							;
						cva5_wrapper.cva5.itlb.physical_address[11:0] = cva5_wrapper.cva5.itlb.virtual_address[11:0];
						cva5_wrapper.cva5.itlb.physical_address[31:12] = 0;
						begin : sv2v_autoblock_16
							reg signed [31:0] i;
							for (i = 0; i < WAYS; i = i + 1)
								if (tag_hit[i])
									cva5_wrapper.cva5.itlb.physical_address[31:12] = cva5_wrapper.cva5.itlb.physical_address[31:12] | ram_entry[i][19-:20];
						end
					end
					initial _sv2v_0 = 0;
				end
				assign i_tlb.clk = clk;
				assign i_tlb.rst = rst;
				assign i_tlb.gc = gc;
				assign i_tlb.abort_request = (((gc[111] | early_branch_flush) | cva5_wrapper.scaiev.fetch_flush) | cva5_wrapper.scaiev.decode_flush) | cva5_wrapper.scaiev.issue_flush;
				assign i_tlb.asid = asid;
				localparam _bbase_D4ACC_l1_request = 2'd3;
				localparam _bbase_D4ACC_l1_response = 2'd3;
				if (1) begin : i_mmu
					reg _sv2v_0;
					wire clk;
					wire rst;
					wire abort_request;
					localparam _mbase_l1_request = _bbase_D4ACC_l1_request;
					localparam _mbase_l1_response = _bbase_D4ACC_l1_response;
					reg [6:0] state;
					reg [6:0] next_state;
					wire [31:0] pte;
					wire access_valid;
					wire privilege_valid;
					localparam MAX_ABORTED_REQUESTS = 4;
					wire abort_queue_full;
					wire discard_data;
					assign cva5_wrapper.cva5.l1_request[_mbase_l1_request].rnw = 1;
					assign cva5_wrapper.cva5.l1_request[_mbase_l1_request].be = 1'sb1;
					assign cva5_wrapper.cva5.l1_request[_mbase_l1_request].size = 1'sb0;
					assign cva5_wrapper.cva5.l1_request[_mbase_l1_request].is_amo = 0;
					assign cva5_wrapper.cva5.l1_request[_mbase_l1_request].amo = 0;
					assign cva5_wrapper.cva5.l1_request[_mbase_l1_request].request = (state[32'd1] | state[32'd3]) & ~abort_request;
					always @(posedge clk)
						if (state[32'd0] | cva5_wrapper.cva5.l1_response[_mbase_l1_response].data_valid) begin
							if (state[32'd0])
								cva5_wrapper.cva5.l1_request[_mbase_l1_request].addr <= {cva5_wrapper.cva5.immu.satp_ppn[19:0], cva5_wrapper.cva5.immu.virtual_address[31:22], 2'b00};
							else
								cva5_wrapper.cva5.l1_request[_mbase_l1_request].addr <= {pte[29:20], pte[19-:10], cva5_wrapper.cva5.immu.virtual_address[21:12], 2'b00};
						end
					assign pte = cva5_wrapper.cva5.l1_response[_mbase_l1_response].data;
					localparam COUNT_W = 2;
					reg [COUNT_W:0] abort_tracking;
					wire delayed_abort;
					wire delayed_abort_complete;
					assign delayed_abort = abort_request & (state[32'd2] | state[32'd4]);
					assign delayed_abort_complete = discard_data & cva5_wrapper.cva5.l1_response[_mbase_l1_response].data_valid;
					always @(posedge clk)
						if (rst)
							abort_tracking <= 0;
						else
							abort_tracking <= (abort_tracking - sv2v_cast_2(delayed_abort)) + sv2v_cast_2(delayed_abort_complete);
					assign discard_data = abort_tracking[COUNT_W];
					assign abort_queue_full = abort_tracking[COUNT_W] & ~|abort_tracking[1:0];
					assign access_valid = (((cva5_wrapper.cva5.immu.execute & pte[3]) & pte[6]) | ((cva5_wrapper.cva5.immu.rnw & (pte[1] | (pte[3] & cva5_wrapper.cva5.immu.mxr))) & pte[6])) | ((((~cva5_wrapper.cva5.immu.rnw & ~cva5_wrapper.cva5.immu.execute) & pte[2]) & pte[6]) & pte[7]);
					assign privilege_valid = ((cva5_wrapper.cva5.immu.privilege == 2'b11) | ((cva5_wrapper.cva5.immu.privilege == 2'b01) & (~pte[4] | (pte[4] & cva5_wrapper.cva5.immu.sum)))) | ((cva5_wrapper.cva5.immu.privilege == 2'b00) & pte[4]);
					always @(*) begin
						if (_sv2v_0)
							;
						next_state = state;
						case (1'b1)
							state[32'd0]:
								if (cva5_wrapper.cva5.immu.request & ~abort_queue_full)
									next_state = 2;
							state[32'd1]:
								if (cva5_wrapper.cva5.l1_request[_mbase_l1_request].ack)
									next_state = 4;
							state[32'd2]:
								if (cva5_wrapper.cva5.l1_response[_mbase_l1_response].data_valid & ~discard_data) begin
									if (~pte[0] | (~pte[1] & pte[2]))
										next_state = 64;
									else if (pte[0] & (pte[1] | pte[3])) begin
										if (access_valid & privilege_valid)
											next_state = 32;
										else
											next_state = 64;
									end
									else
										next_state = 8;
								end
							state[32'd3]:
								if (cva5_wrapper.cva5.l1_request[_mbase_l1_request].ack)
									next_state = 16;
							state[32'd4]:
								if (cva5_wrapper.cva5.l1_response[_mbase_l1_response].data_valid & ~discard_data) begin
									if (access_valid & privilege_valid)
										next_state = 32;
									else
										next_state = 64;
								end
							state[32'd5], state[32'd6]: next_state = 1;
						endcase
						if (abort_request)
							next_state = 1;
					end
					always @(posedge clk)
						if (rst)
							state <= 1;
						else
							state <= next_state;
					always @(posedge clk)
						if (cva5_wrapper.cva5.l1_response[_mbase_l1_response].data_valid) begin
							cva5_wrapper.cva5.immu.upper_physical_address[19:10] <= pte[29:20];
							cva5_wrapper.cva5.immu.upper_physical_address[9:0] <= (state[32'd4] ? pte[19-:10] : cva5_wrapper.cva5.immu.virtual_address[21:12]);
						end
					assign cva5_wrapper.cva5.immu.write_entry = state[32'd5];
					assign cva5_wrapper.cva5.immu.is_fault = state[32'd6];
					initial _sv2v_0 = 0;
				end
				assign i_mmu.clk = clk;
				assign i_mmu.rst = rst;
				assign i_mmu.abort_request = ((gc[111] | cva5_wrapper.scaiev.fetch_flush) | cva5_wrapper.scaiev.decode_flush) | cva5_wrapper.scaiev.issue_flush;
			end
			else begin : genblk4
				assign itlb.ready = 1;
				assign itlb.done = itlb.new_request;
				wire [32:1] sv2v_tmp_95400;
				assign sv2v_tmp_95400 = itlb.virtual_address;
				always @(*) itlb.physical_address = sv2v_tmp_95400;
			end
			localparam _param_F6B5F_CONFIG = CONFIG;
			if (1) begin : renamer_block
				reg _sv2v_0;
				localparam [1209:0] cva5_config_EXAMPLE_CONFIG = 1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002;
				localparam [1209:0] CONFIG = _param_F6B5F_CONFIG;
				wire clk;
				wire rst;
				localparam cva5_config_MAX_IDS = 8;
				localparam cva5_types_LOG2_MAX_IDS = 3;
				localparam riscv_types_ECODE_W = 5;
				wire [115:0] gc;
				wire decode_advance;
				wire decode_uses_rd_decoupled;
				localparam cva5_config_MAX_IDS_FETCH = 8;
				localparam cva5_types_LOG2_MAX_IDS_FETCH = 3;
				wire [101:0] issue;
				wire instruction_issued_with_rd;
				wire issue_uses_rd_decoupled;
				localparam cva5_config_RETIRE_PORTS = 2;
				localparam cva5_types_LOG2_RETIRE_PORTS = 1;
				wire [5:0] retire;
				wire [(17 + $clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32])) - 1:0] inuse_list_input;
				wire [(17 + $clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32])) - 1:0] inuse_list_output;
				wire [5:0] clear_index;
				localparam _param_608C9_DATA_WIDTH = 6;
				if (1) begin : free_list
					localparam DATA_WIDTH = _param_608C9_DATA_WIDTH;
					wire push;
					wire pop;
					wire [5:0] data_in;
					wire [5:0] data_out;
					wire valid;
					wire full;
					wire potential_push;
				end
				localparam _param_D5848_DATA_WIDTH = 17 + $clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]);
				if (1) begin : inuse_list
					localparam DATA_WIDTH = _param_D5848_DATA_WIDTH;
					wire push;
					wire pop;
					wire [DATA_WIDTH - 1:0] data_in;
					wire [DATA_WIDTH - 1:0] data_out;
					wire valid;
					wire full;
					wire potential_push;
				end
				wire rename_valid;
				wire rollback;
				assign rename_valid = ((((~gc[111] & ~cva5_wrapper.scaiev.issue_flush) & ~cva5_wrapper.scaiev.decode_flush) & decode_advance) & (cva5_wrapper.cva5.decode_rename_interface.uses_rd | decode_uses_rd_decoupled)) & |cva5_wrapper.cva5.decode_rename_interface.rd_addr;
				assign rollback = (((gc[111] | cva5_wrapper.scaiev.issue_flush) & issue[6]) & (issue[16] | issue_uses_rd_decoupled)) & |issue[27-:5];
				lfsr #(
					.WIDTH(6),
					.NEEDS_RESET(0)
				) lfsr_read_index(
					.clk(clk),
					.rst(rst),
					.en(gc[115]),
					.value(clear_index)
				);
				localparam _param_9E4DA_DATA_WIDTH = 6;
				localparam _param_9E4DA_FIFO_DEPTH = 32;
				if (1) begin : free_list_fifo
					localparam DATA_WIDTH = _param_9E4DA_DATA_WIDTH;
					localparam FIFO_DEPTH = _param_9E4DA_FIFO_DEPTH;
					wire clk;
					wire rst;
					wire rollback;
					localparam LOG2_FIFO_DEPTH = 5;
					reg [5:0] lut_ram [0:31];
					reg [4:0] write_index;
					reg [4:0] read_index;
					reg [LOG2_FIFO_DEPTH:0] inflight_count;
					always @(posedge clk)
						if (rst)
							inflight_count <= 0;
						else
							inflight_count <= ((inflight_count + sv2v_cast_6(cva5_wrapper.cva5.renamer_block.free_list.pop)) - sv2v_cast_6(cva5_wrapper.cva5.renamer_block.free_list.push)) - sv2v_cast_6(rollback);
					assign cva5_wrapper.cva5.renamer_block.free_list.valid = inflight_count[LOG2_FIFO_DEPTH];
					assign cva5_wrapper.cva5.renamer_block.free_list.full = cva5_wrapper.cva5.renamer_block.free_list.valid & ~|inflight_count[4:0];
					always @(posedge clk)
						if (rst) begin
							read_index <= 1'sb0;
							write_index <= 1'sb0;
						end
						else begin
							read_index <= (read_index + sv2v_cast_5(cva5_wrapper.cva5.renamer_block.free_list.pop)) - sv2v_cast_5(rollback);
							write_index <= write_index + sv2v_cast_5(cva5_wrapper.cva5.renamer_block.free_list.push);
						end
					always @(posedge clk)
						if (cva5_wrapper.cva5.renamer_block.free_list.potential_push)
							lut_ram[write_index] <= cva5_wrapper.cva5.renamer_block.free_list.data_in;
					assign cva5_wrapper.cva5.renamer_block.free_list.data_out = lut_ram[read_index];
				end
				assign free_list_fifo.clk = clk;
				assign free_list_fifo.rst = rst;
				assign free_list_fifo.rollback = rollback;
				assign free_list.potential_push = ((gc[115] & ~clear_index[5]) | retire[5]) | cva5_wrapper.scaiev.rf_wrReg;
				assign free_list.push = free_list.potential_push && !cva5_wrapper.scaiev.renamer_addtofree_skip;
				reg [5:0] freed_phys_addr;
				always @(*) begin
					if (_sv2v_0)
						;
					if (gc[115])
						freed_phys_addr = {1'b1, clear_index[4:0]};
					else if (cva5_wrapper.scaiev.rf_wrReg && !retire[5])
						freed_phys_addr = (cva5_wrapper.scaiev.rf_wrReg_cancel ? cva5_wrapper.scaiev.rf_wrReg_phys_RD : cva5_wrapper.scaiev.rf_wrReg_prev_phys_RD[5:0]);
					else
						freed_phys_addr = (gc[110] ? inuse_list_output[$clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) + 11-:(($clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) + 11) >= (6 + ($clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) + 0)) ? (($clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) + 11) - (6 + ($clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) + 0))) + 1 : ((6 + ($clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) + 0)) - ($clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) + 11)) + 1)] : inuse_list_output[$clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) + 5-:(($clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) + 5) >= ($clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) + 0) ? (($clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) + 5) - ($clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) + 0)) + 1 : (($clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) + 0) - ($clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) + 5)) + 1)]);
				end
				assign free_list.data_in = freed_phys_addr;
				assign free_list.pop = rename_valid;
				assign cva5_wrapper.scaiev.renamer_addtofree_valid = free_list.potential_push;
				assign cva5_wrapper.scaiev.renamer_addtofree_reg = freed_phys_addr;
				localparam _param_736D5_DATA_WIDTH = 17 + $clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]);
				localparam _param_736D5_FIFO_DEPTH = 32;
				if (1) begin : inuse_list_fifo
					localparam DATA_WIDTH = _param_736D5_DATA_WIDTH;
					localparam FIFO_DEPTH = _param_736D5_FIFO_DEPTH;
					wire clk;
					wire rst;
					localparam LOG2_FIFO_DEPTH = 5;
					if (1) begin : gen_width_3_plus
						wire [DATA_WIDTH - 1:0] lut_ram [0:31];
						wire [4:0] write_index;
						wire [4:0] read_index;
						reg [LOG2_FIFO_DEPTH:0] inflight_count;
						always @(posedge clk)
							if (rst)
								inflight_count <= 0;
							else
								inflight_count <= (inflight_count + sv2v_cast_6(cva5_wrapper.cva5.renamer_block.inuse_list.pop)) - sv2v_cast_6(cva5_wrapper.cva5.renamer_block.inuse_list.push);
						assign cva5_wrapper.cva5.renamer_block.inuse_list.valid = inflight_count[LOG2_FIFO_DEPTH];
						assign cva5_wrapper.cva5.renamer_block.inuse_list.full = cva5_wrapper.cva5.renamer_block.inuse_list.valid & ~|inflight_count[4:0];
						lfsr #(
							.WIDTH(LOG2_FIFO_DEPTH),
							.NEEDS_RESET(1)
						) lfsr_read_index(
							.clk(clk),
							.rst(rst),
							.en(cva5_wrapper.cva5.renamer_block.inuse_list.pop),
							.value(read_index)
						);
						lfsr #(
							.WIDTH(LOG2_FIFO_DEPTH),
							.NEEDS_RESET(1)
						) lfsr_write_index(
							.clk(clk),
							.rst(rst),
							.en(cva5_wrapper.cva5.renamer_block.inuse_list.push),
							.value(write_index)
						);
						lutram_1w_1r #(
							.WIDTH(DATA_WIDTH),
							.DEPTH(FIFO_DEPTH)
						) write_port(
							.clk(clk),
							.waddr(write_index),
							.raddr(read_index),
							.ram_write(cva5_wrapper.cva5.renamer_block.inuse_list.potential_push),
							.new_ram_data(cva5_wrapper.cva5.renamer_block.inuse_list.data_in),
							.ram_data_out(cva5_wrapper.cva5.renamer_block.inuse_list.data_out)
						);
					end
				end
				assign inuse_list_fifo.clk = clk;
				assign inuse_list_fifo.rst = rst;
				assign inuse_list.potential_push = instruction_issued_with_rd & |issue[27-:5];
				assign inuse_list.push = inuse_list.potential_push;
				assign inuse_list_input[11 + ($clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) + 5)-:((11 + ($clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) + 5)) >= (12 + ($clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) + 0)) ? ((11 + ($clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) + 5)) - (12 + ($clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) + 0))) + 1 : ((12 + ($clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) + 0)) - (11 + ($clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) + 5))) + 1)] = issue[27-:5];
				assign inuse_list_input[$clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) + 11-:(($clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) + 11) >= (6 + ($clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) + 0)) ? (($clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) + 11) - (6 + ($clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) + 0))) + 1 : ((6 + ($clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) + 0)) - ($clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) + 11)) + 1)] = issue[22-:6];
				assign inuse_list.data_in = inuse_list_input;
				assign inuse_list_output = inuse_list.data_out;
				assign inuse_list.pop = retire[5];
				localparam scaiev_config_ENABLE_NATIVE_RD_AS_RS = 0;
				localparam cva5_config_REGFILE_READ_PORTS = (scaiev_config_ENABLE_NATIVE_RD_AS_RS ? 3 : 2);
				wire [(0 >= (cva5_config_REGFILE_READ_PORTS + 0) ? ((1 - (cva5_config_REGFILE_READ_PORTS + 0)) * 5) + (((cva5_config_REGFILE_READ_PORTS + 0) * 5) - 1) : ((cva5_config_REGFILE_READ_PORTS + 1) * 5) - 1):(0 >= (cva5_config_REGFILE_READ_PORTS + 0) ? (cva5_config_REGFILE_READ_PORTS + 0) * 5 : 0)] spec_table_read_addr;
				wire [(0 >= (cva5_config_REGFILE_READ_PORTS + 0) ? ((1 - (cva5_config_REGFILE_READ_PORTS + 0)) * (6 + $clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]))) + (((cva5_config_REGFILE_READ_PORTS + 0) * (6 + $clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]))) - 1) : ((cva5_config_REGFILE_READ_PORTS + 1) * (6 + $clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]))) - 1):(0 >= (cva5_config_REGFILE_READ_PORTS + 0) ? (cva5_config_REGFILE_READ_PORTS + 0) * (6 + $clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32])) : 0)] spec_table_read_data;
				wire [(6 + $clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32])) - 1:0] spec_table_next;
				wire [(6 + $clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32])) - 1:0] spec_table_next_mux [0:3];
				wire [(6 + $clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32])) - 1:0] spec_table_previous;
				reg [(6 + $clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32])) - 1:0] spec_table_previous_r;
				assign inuse_list_input[$clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) + 5-:(($clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) + 5) >= ($clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) + 0) ? (($clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) + 5) - ($clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) + 0)) + 1 : (($clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) + 0) - ($clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) + 5)) + 1)] = spec_table_previous_r[$clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) + 5-:(($clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) + 5) >= ($clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) + 0) ? (($clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) + 5) - ($clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) + 0)) + 1 : (($clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) + 0) - ($clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) + 5)) + 1)];
				assign inuse_list_input[$clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) - 1-:$clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32])] = spec_table_previous_r[$clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) - 1-:$clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32])];
				assign cva5_wrapper.scaiev.decode_prev_phys_RD_decoupled = {spec_table_previous[$clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) - 1-:$clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32])], spec_table_previous[$clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) + 5-:(($clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) + 5) >= ($clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) + 0) ? (($clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) + 5) - ($clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) + 0)) + 1 : (($clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) + 0) - ($clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) + 5)) + 1)]};
				assign cva5_wrapper.scaiev.issue_prev_phys_RD_decoupled = {spec_table_previous_r[$clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) - 1-:$clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32])], spec_table_previous_r[$clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) + 5-:(($clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) + 5) >= ($clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) + 0) ? (($clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) + 5) - ($clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) + 0)) + 1 : (($clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) + 0) - ($clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) + 5)) + 1)]};
				wire spec_table_update;
				wire [4:0] spec_table_write_index;
				wire [4:0] spec_table_write_index_mux [0:3];
				assign spec_table_update = ((rename_valid | rollback) | gc[115]) | (retire[5] & gc[110]);
				wire [1:0] spec_table_sel;
				one_hot_to_integer #(.C_WIDTH(4)) spec_table_sel_one_hot_to_int(
					.one_hot({gc[115], rollback, retire[5] & gc[110], 1'b0}),
					.int_out(spec_table_sel)
				);
				assign spec_table_write_index_mux[0] = cva5_wrapper.cva5.decode_rename_interface.rd_addr;
				assign spec_table_next_mux[0][$clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) + 5-:(($clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) + 5) >= ($clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) + 0) ? (($clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) + 5) - ($clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) + 0)) + 1 : (($clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) + 0) - ($clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) + 5)) + 1)] = free_list.data_out;
				assign spec_table_next_mux[0][$clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) - 1-:$clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32])] = cva5_wrapper.cva5.decode_rename_interface.rd_wb_group;
				assign spec_table_write_index_mux[1] = inuse_list_output[11 + ($clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) + 5)-:((11 + ($clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) + 5)) >= (12 + ($clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) + 0)) ? ((11 + ($clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) + 5)) - (12 + ($clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) + 0))) + 1 : ((12 + ($clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) + 0)) - (11 + ($clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) + 5))) + 1)];
				assign spec_table_next_mux[1][$clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) + 5-:(($clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) + 5) >= ($clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) + 0) ? (($clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) + 5) - ($clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) + 0)) + 1 : (($clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) + 0) - ($clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) + 5)) + 1)] = inuse_list_output[$clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) + 5-:(($clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) + 5) >= ($clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) + 0) ? (($clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) + 5) - ($clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) + 0)) + 1 : (($clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) + 0) - ($clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) + 5)) + 1)];
				assign spec_table_next_mux[1][$clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) - 1-:$clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32])] = inuse_list_output[$clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) - 1-:$clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32])];
				assign spec_table_write_index_mux[2] = issue[27-:5];
				assign spec_table_next_mux[2][$clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) + 5-:(($clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) + 5) >= ($clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) + 0) ? (($clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) + 5) - ($clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) + 0)) + 1 : (($clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) + 0) - ($clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) + 5)) + 1)] = spec_table_previous_r[$clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) + 5-:(($clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) + 5) >= ($clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) + 0) ? (($clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) + 5) - ($clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) + 0)) + 1 : (($clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) + 0) - ($clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) + 5)) + 1)];
				assign spec_table_next_mux[2][$clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) - 1-:$clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32])] = spec_table_previous_r[$clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) - 1-:$clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32])];
				assign spec_table_write_index_mux[3] = clear_index[4:0];
				assign spec_table_next_mux[3][$clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) + 5-:(($clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) + 5) >= ($clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) + 0) ? (($clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) + 5) - ($clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) + 0)) + 1 : (($clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) + 0) - ($clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) + 5)) + 1)] = {1'b0, clear_index[4:0]};
				assign spec_table_next_mux[3][$clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) - 1-:$clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32])] = 1'sb0;
				assign spec_table_write_index = spec_table_write_index_mux[spec_table_sel];
				assign spec_table_next = spec_table_next_mux[spec_table_sel];
				assign spec_table_read_addr[(0 >= (cva5_config_REGFILE_READ_PORTS + 0) ? 0 : cva5_config_REGFILE_READ_PORTS + 0) * 5+:5] = spec_table_write_index;
				assign spec_table_read_addr[5 * (0 >= (cva5_config_REGFILE_READ_PORTS + 0) ? (0 >= (cva5_config_REGFILE_READ_PORTS + 0) ? 1 : 2) : (cva5_config_REGFILE_READ_PORTS + 0) - (0 >= (cva5_config_REGFILE_READ_PORTS + 0) ? 1 : 2))+:10] = {cva5_wrapper.cva5.decode_rename_interface.rs_addr[(1 - 2'd0) * 5+:5], cva5_wrapper.cva5.decode_rename_interface.rs_addr[(1 - 2'd1) * 5+:5]};
				if (scaiev_config_ENABLE_NATIVE_RD_AS_RS) begin : genblk1
					assign spec_table_read_addr[(0 >= (cva5_config_REGFILE_READ_PORTS + 0) ? 3 : cva5_config_REGFILE_READ_PORTS - 3) * 5+:5] = cva5_wrapper.cva5.decode_rename_interface.rs_addr[(1 - 2'd2) * 5+:5];
				end
				lutram_1w_mr #(
					.WIDTH(6 + $clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32])),
					.DEPTH(32),
					.NUM_READ_PORTS(cva5_config_REGFILE_READ_PORTS + 1)
				) spec_table_ram(
					.clk(clk),
					.waddr(spec_table_write_index),
					.raddr(spec_table_read_addr),
					.ram_write(spec_table_update),
					.new_ram_data(spec_table_next),
					.ram_data_out(spec_table_read_data)
				);
				assign spec_table_previous = spec_table_read_data[(0 >= (cva5_config_REGFILE_READ_PORTS + 0) ? 0 : cva5_config_REGFILE_READ_PORTS + 0) * (6 + $clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]))+:6 + $clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32])];
				always @(posedge clk)
					if (spec_table_update)
						spec_table_previous_r <= spec_table_previous;
				wire [(cva5_config_REGFILE_READ_PORTS * (6 + $clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]))) - 1:0] spec_table_decode;
				genvar _gv_i_14;
				for (_gv_i_14 = 0; _gv_i_14 < cva5_config_REGFILE_READ_PORTS; _gv_i_14 = _gv_i_14 + 1) begin : gen_renamed_addrs
					localparam i = _gv_i_14;
					assign spec_table_decode[i * (6 + $clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]))+:6 + $clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32])] = spec_table_read_data[(0 >= (cva5_config_REGFILE_READ_PORTS + 0) ? i + 1 : (cva5_config_REGFILE_READ_PORTS + 0) - (i + 1)) * (6 + $clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]))+:6 + $clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32])];
					assign cva5_wrapper.cva5.decode_rename_interface.phys_rs_addr[(1 - i) * 6+:6] = spec_table_decode[(i * (6 + $clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]))) + ($clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) + 5)-:(($clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) + 5) >= ($clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) + 0) ? (($clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) + 5) - ($clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) + 0)) + 1 : (($clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) + 0) - ($clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) + 5)) + 1)];
					assign cva5_wrapper.cva5.decode_rename_interface.rs_wb_group[(1 - i) * $clog2(_param_55864_NUM_WB_GROUPS)+:$clog2(_param_55864_NUM_WB_GROUPS)] = spec_table_decode[(i * (6 + $clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]))) + ($clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32]) - 1)-:$clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32])];
				end
				assign cva5_wrapper.cva5.decode_rename_interface.phys_rd_addr = (|cva5_wrapper.cva5.decode_rename_interface.rd_addr ? free_list.data_out : {6 {1'sb0}});
				genvar _gv_i_15;
				for (_gv_i_15 = 0; _gv_i_15 < cva5_config_REGFILE_READ_PORTS; _gv_i_15 = _gv_i_15 + 1) begin : rename_rs_zero_assertion
					localparam i = _gv_i_15;
				end
				initial _sv2v_0 = 0;
			end
			assign renamer_block.clk = clk;
			assign renamer_block.rst = rst;
			assign renamer_block.gc = gc;
			assign renamer_block.decode_advance = decode_advance;
			assign renamer_block.decode_uses_rd_decoupled = decode_uses_rd_decoupled;
			assign renamer_block.issue_uses_rd_decoupled = issue_uses_rd_decoupled;
			assign renamer_block.issue = issue;
			assign renamer_block.instruction_issued_with_rd = instruction_issued_with_rd;
			assign renamer_block.retire = retire;
			localparam _bbase_0D1F1_unit_issue = 0;
			localparam _bbase_0D1F1_exception = 2'd2;
			localparam _param_0D1F1_CONFIG = CONFIG;
			localparam _param_0D1F1_NUM_UNITS = NUM_UNITS;
			localparam _param_0D1F1_UNIT_IDS = UNIT_IDS;
			if (1) begin : decode_and_issue_block
				reg _sv2v_0;
				localparam [1209:0] cva5_config_EXAMPLE_CONFIG = 1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002;
				localparam [1209:0] CONFIG = _param_0D1F1_CONFIG;
				localparam NUM_UNITS = _param_0D1F1_NUM_UNITS;
				localparam [255:0] cva5_config_EXAMPLE_UNIT_IDS = 256'h0000000000000001000000020000000300000004000000050000000600000007;
				localparam [255:0] UNIT_IDS = _param_0D1F1_UNIT_IDS;
				wire clk;
				wire rst;
				wire pc_id_available;
				wire pc_inject_id_available;
				wire pc_inject_id_assigned;
				wire pc_inject_keep_for_repeat;
				wire pc_inject_is_repeat;
				localparam cva5_config_MAX_IDS_FETCH = 8;
				localparam cva5_types_LOG2_MAX_IDS_FETCH = 3;
				localparam riscv_types_ECODE_W = 5;
				localparam cva5_config_MAX_IDS = 8;
				localparam cva5_types_LOG2_MAX_IDS = 3;
				wire [76:0] decode;
				wire decode_advance;
				reg [1:0] decode_exception_unit;
				wire decode_uses_rd;
				wire decode_uses_rd_decoupled;
				reg issue_uses_rd_decoupled;
				wire [4:0] decode_rd_addr;
				wire [5:0] decode_phys_rd_addr;
				localparam scaiev_config_ENABLE_NATIVE_RD_AS_RS = 0;
				localparam cva5_config_REGFILE_READ_PORTS = (scaiev_config_ENABLE_NATIVE_RD_AS_RS ? 3 : 2);
				wire [(cva5_config_REGFILE_READ_PORTS * 6) - 1:0] decode_phys_rs_addr;
				wire [(cva5_config_REGFILE_READ_PORTS * $clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32])) - 1:0] decode_rs_wb_group;
				wire instruction_issued;
				wire instruction_issued_with_rd;
				reg [101:0] issue;
				localparam riscv_types_XLEN = 32;
				wire [141:0] alu_inputs;
				reg [98:0] ls_inputs;
				wire [162:0] branch_inputs;
				wire [34:0] gc_inputs;
				wire [47:0] csr_inputs;
				wire [65:0] mul_inputs;
				wire [66:0] div_inputs;
				wire [160:0] scaiev_inputs;
				wire scaiev_stall_issue;
				localparam _mbase_unit_issue = 0;
				wire scaiev_decode_inject;
				wire [115:0] gc;
				wire [1:0] current_privilege;
				localparam _mbase_exception = _bbase_0D1F1_exception;
				wire tr_operand_stall;
				wire tr_unit_stall;
				wire tr_no_id_stall;
				wire tr_no_instruction_stall;
				wire tr_other_stall;
				wire tr_branch_operand_stall;
				wire tr_alu_operand_stall;
				wire tr_ls_operand_stall;
				wire tr_div_operand_stall;
				reg tr_alu_op;
				reg tr_branch_or_jump_op;
				reg tr_load_op;
				reg tr_store_op;
				reg tr_mul_op;
				reg tr_div_op;
				reg tr_misc_op;
				wire tr_instruction_issued_dec;
				wire [31:0] tr_instruction_pc_dec;
				wire [31:0] tr_instruction_data_dec;
				wire [31:0] selected_instruction;
				wire [2:0] fn3;
				wire [6:0] opcode;
				wire [4:0] opcode_trim;
				wire [0:cva5_config_REGFILE_READ_PORTS - 1] uses_rs;
				wire uses_rd;
				wire [(cva5_config_REGFILE_READ_PORTS * 5) - 1:0] rs_addr;
				wire [4:0] rd_addr;
				wire is_csr;
				wire is_fence;
				wire is_ifence;
				wire csr_imm_op;
				wire environment_op;
				wire is_scaiev_isax;
				wire is_scaiev_isax_stdencoding;
				wire scaiev_uses_rs1;
				wire scaiev_uses_rs2;
				wire scaiev_uses_rd_as_rs;
				wire scaiev_uses_rd;
				wire scaiev_uses_rd_decoupled;
				reg stall_rd_decoupled;
				wire decode_valid;
				reg decode_cur_is_repeat;
				wire issue_valid_or_waiting_for_operands;
				wire issue_valid_prescaiev;
				wire issue_valid;
				wire operands_ready;
				wire mult_div_op;
				wire [NUM_UNITS - 1:0] unit_needed;
				reg [NUM_UNITS - 1:0] unit_needed_issue_stage;
				wire [NUM_UNITS - 1:0] unit_ready;
				wire [NUM_UNITS - 1:0] issue_ready;
				wire [NUM_UNITS - 1:0] issue_to;
				reg [(cva5_config_REGFILE_READ_PORTS * 5) - 1:0] issue_rs_addr;
				reg [(cva5_config_REGFILE_READ_PORTS * 6) - 1:0] issue_phys_rs_addr;
				reg [(cva5_config_REGFILE_READ_PORTS * $clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32])) - 1:0] issue_rs_wb_group;
				reg [0:cva5_config_REGFILE_READ_PORTS - 1] issue_uses_rs;
				reg issue_is_injected;
				reg pre_issue_exception_pending;
				wire illegal_instruction_pattern_prescaiev;
				wire illegal_instruction_pattern;
				wire issue_stage_ready;
				wire [cva5_config_REGFILE_READ_PORTS - 1:0] rs_conflict;
				genvar _gv_i_13;
				assign scaiev_decode_inject = cva5_wrapper.scaiev.decode_wrReg || cva5_wrapper.scaiev.decode_rdReg;
				assign selected_instruction = {decode[38:32], decode[31:27], decode[26:22], decode[21:19], decode[18:14], (!scaiev_decode_inject ? decode[13:7] : 7'b0010111)};
				assign pc_inject_id_assigned = (((scaiev_decode_inject || decode_cur_is_repeat) & pc_inject_id_available) & issue_stage_ready) & ~cva5_wrapper.scaiev.decode_stall;
				assign decode_valid = (scaiev_decode_inject || decode_cur_is_repeat ? pc_inject_id_available : decode[6]);
				assign issue_stage_ready = ~issue[6] | ((issue_valid & |issue_ready) & ~gc[112]);
				assign decode_advance = (((decode_valid & issue_stage_ready) & ~cva5_wrapper.scaiev.decode_stall) & ~(scaiev_uses_rd_decoupled & stall_rd_decoupled)) & ~gc[113];
				assign opcode = selected_instruction[6:0];
				assign opcode_trim = opcode[6:2];
				assign fn3 = selected_instruction[14:12];
				assign rs_addr[(cva5_config_REGFILE_READ_PORTS - (1 + 2'd0)) * 5+:5] = (!scaiev_decode_inject && !cva5_wrapper.scaiev.decode_RS1_override ? selected_instruction[19:15] : cva5_wrapper.scaiev.decode_rdReg_RS1);
				assign rs_addr[(cva5_config_REGFILE_READ_PORTS - (1 + 2'd1)) * 5+:5] = (!scaiev_decode_inject && !cva5_wrapper.scaiev.decode_RS2_override ? selected_instruction[24:20] : cva5_wrapper.scaiev.decode_rdReg_RS2);
				if (scaiev_config_ENABLE_NATIVE_RD_AS_RS) begin : genblk1
					assign rs_addr[(cva5_config_REGFILE_READ_PORTS - (1 + 2'd2)) * 5+:5] = (!scaiev_decode_inject && !cva5_wrapper.scaiev.decode_RD_AS_RS_override ? selected_instruction[11:7] : cva5_wrapper.scaiev.decode_rdReg_RD_AS_RS);
				end
				assign rd_addr = (!scaiev_decode_inject ? selected_instruction[11:7] : (cva5_wrapper.scaiev.decode_wrReg ? cva5_wrapper.scaiev.decode_wrReg_RD : 5'b00000));
				assign is_csr = (CONFIG[1202] & (opcode_trim == 5'b11100)) & (fn3 != 0);
				assign is_fence = (opcode_trim == 5'b00011) & ~fn3[0];
				assign is_ifence = (CONFIG[1203] & (opcode_trim == 5'b00011)) & fn3[0];
				assign csr_imm_op = (opcode_trim == 5'b11100) & fn3[2];
				assign environment_op = (opcode_trim == 5'b11100) & (fn3 == 0);
				assign is_scaiev_isax = cva5_wrapper.scaiev.decode_isSCAIEV & ~scaiev_decode_inject;
				assign is_scaiev_isax_stdencoding = cva5_wrapper.scaiev.decode_isSCAIEV_stdencoding & ~scaiev_decode_inject;
				assign scaiev_uses_rs1 = (is_scaiev_isax && cva5_wrapper.scaiev.decode_isSCAIEV_usesRS1) || cva5_wrapper.scaiev.decode_RS1_override;
				assign scaiev_uses_rs2 = (is_scaiev_isax && cva5_wrapper.scaiev.decode_isSCAIEV_usesRS2) || cva5_wrapper.scaiev.decode_RS2_override;
				if (scaiev_config_ENABLE_NATIVE_RD_AS_RS) begin : genblk2
					assign scaiev_uses_rd_as_rs = (is_scaiev_isax && cva5_wrapper.scaiev.decode_isSCAIEV_usesRD_AS_RS) || cva5_wrapper.scaiev.decode_RD_AS_RS_override;
				end
				else begin : genblk2
					assign scaiev_uses_rd_as_rs = 0;
				end
				assign scaiev_uses_rd = is_scaiev_isax && cva5_wrapper.scaiev.decode_isSCAIEV_usesRD;
				assign pc_inject_keep_for_repeat = cva5_wrapper.scaiev.decode_repeat_next;
				assign pc_inject_is_repeat = decode_cur_is_repeat && !scaiev_decode_inject;
				always @(posedge clk)
					if ((rst || ((decode_advance && !scaiev_decode_inject) && !cva5_wrapper.scaiev.decode_repeat_next)) || ((gc[111] | cva5_wrapper.scaiev.issue_flush) | cva5_wrapper.scaiev.decode_flush))
						decode_cur_is_repeat <= 0;
					else if ((decode_advance && cva5_wrapper.scaiev.decode_repeat_next) && !scaiev_decode_inject)
						decode_cur_is_repeat <= 1;
				localparam scaiev_config_ENABLE_DECOUPLED_WRITEBACK = 0;
				if (scaiev_config_ENABLE_DECOUPLED_WRITEBACK) begin : genblk3
					assign scaiev_uses_rd_decoupled = is_scaiev_isax && cva5_wrapper.scaiev.decode_isSCAIEV_usesRD_decoupled;
					reg [5:0] pending_decoupled;
					always @(posedge clk) begin : sv2v_autoblock_17
						reg [5:0] next_pending_decoupled;
						next_pending_decoupled = pending_decoupled;
						if ((scaiev_uses_rd_decoupled && !scaiev_decode_inject) && decode_advance) begin
							next_pending_decoupled = next_pending_decoupled + 6'd1;
							if (next_pending_decoupled == 6'd0) begin
								$display("Error: next_pending_decoupled overflow");
								$finish;
							end
						end
						if ((cva5_wrapper.scaiev.rf_wrReg && cva5_wrapper.scaiev.rf_ready) && cva5_wrapper.scaiev.rf_isDecoupledWB) begin
							if (next_pending_decoupled == 6'd0) begin
								$display("Error: next_pending_decoupled underflow");
								$finish;
							end
							next_pending_decoupled = next_pending_decoupled - 6'd1;
						end
						if (rst)
							pending_decoupled <= 0;
						else
							pending_decoupled <= next_pending_decoupled;
						stall_rd_decoupled <= next_pending_decoupled >= 24;
					end
					assign cva5_wrapper.scaiev.no_writebacks_pending = pending_decoupled == {6 {1'sb0}};
				end
				else begin : genblk3
					assign scaiev_uses_rd_decoupled = 0;
					wire [1:1] sv2v_tmp_AAB1B;
					assign sv2v_tmp_AAB1B = 0;
					always @(*) stall_rd_decoupled = sv2v_tmp_AAB1B;
					assign cva5_wrapper.scaiev.no_writebacks_pending = 1;
				end
				assign uses_rs[2'd0] = (((|{opcode_trim == 5'b11001, opcode_trim == 5'b11000, opcode_trim == 5'b00000, opcode_trim == 5'b01000, opcode_trim == 5'b00100, opcode_trim == 5'b01100, opcode_trim == 5'b01011} && !is_scaiev_isax_stdencoding) | is_csr) | scaiev_uses_rs1) | cva5_wrapper.scaiev.decode_rdReg;
				assign uses_rs[2'd1] = ((|{opcode_trim == 5'b11000, opcode_trim == 5'b01100, opcode_trim == 5'b01011} && !is_scaiev_isax_stdencoding) | scaiev_uses_rs2) | cva5_wrapper.scaiev.decode_rdReg;
				if (scaiev_config_ENABLE_NATIVE_RD_AS_RS) begin : genblk4
					assign uses_rs[2'd2] = scaiev_uses_rd_as_rs | cva5_wrapper.scaiev.decode_rdReg;
				end
				assign uses_rd = ((((|{opcode_trim == 5'b01101, opcode_trim == 5'b00101, opcode_trim == 5'b11011, opcode_trim == 5'b11001, opcode_trim == 5'b00000, opcode_trim == 5'b00100, opcode_trim == 5'b01100} && !is_scaiev_isax_stdencoding) | is_csr) | scaiev_uses_rd) && !cva5_wrapper.scaiev.decode_skip_wb) || scaiev_decode_inject;
				assign cva5_wrapper.scaiev.decode_RS1_valid = uses_rs[2'd0];
				assign cva5_wrapper.scaiev.decode_RS1_id = rs_addr[(cva5_config_REGFILE_READ_PORTS - (1 + 2'd0)) * 5+:5];
				assign cva5_wrapper.scaiev.decode_RS2_valid = uses_rs[2'd1] || (opcode_trim == 5'b01000);
				assign cva5_wrapper.scaiev.decode_RS2_id = rs_addr[(cva5_config_REGFILE_READ_PORTS - (1 + 2'd1)) * 5+:5];
				if (scaiev_config_ENABLE_NATIVE_RD_AS_RS) begin : genblk5
					assign cva5_wrapper.scaiev.decode_RD_AS_RS_valid = uses_rs[2'd2];
					assign cva5_wrapper.scaiev.decode_RD_AS_RS_id = rs_addr[(cva5_config_REGFILE_READ_PORTS - (1 + 2'd2)) * 5+:5];
				end
				else begin : genblk5
					assign cva5_wrapper.scaiev.decode_RD_AS_RS_valid = 0;
					assign cva5_wrapper.scaiev.decode_RD_AS_RS_id = 0;
				end
				assign cva5_wrapper.scaiev.decode_RD_valid = uses_rd;
				assign cva5_wrapper.scaiev.decode_RD_id = rd_addr;
				assign unit_needed[UNIT_IDS[63-:32]] = |{opcode_trim == 5'b11000, opcode_trim == 5'b11011, opcode_trim == 5'b11001} && !is_scaiev_isax_stdencoding;
				assign unit_needed[UNIT_IDS[255-:32]] = (|{opcode_trim == 5'b01100, opcode_trim == 5'b00100, opcode_trim == 5'b00101, opcode_trim == 5'b01101, opcode_trim == 5'b11011, opcode_trim == 5'b11001} && !is_scaiev_isax_stdencoding) & ~mult_div_op;
				assign unit_needed[UNIT_IDS[223-:32]] = |{opcode_trim == 5'b00000, opcode_trim == 5'b01000, opcode_trim == 5'b01011} | is_fence;
				if (CONFIG[1202]) begin : genblk6
					assign unit_needed[UNIT_IDS[191-:32]] = is_csr;
				end
				assign unit_needed[UNIT_IDS[31-:32]] = (((opcode_trim == 5'b11100) & ~is_csr) & CONFIG[1209]) | is_ifence;
				assign mult_div_op = ((opcode_trim == 5'b01100) && decode[32]) && !is_scaiev_isax_stdencoding;
				if (CONFIG[1206]) begin : genblk7
					assign unit_needed[UNIT_IDS[159-:32]] = mult_div_op && ~fn3[2];
				end
				if (CONFIG[1205]) begin : genblk8
					assign unit_needed[UNIT_IDS[127-:32]] = mult_div_op && fn3[2];
				end
				if (CONFIG[1204]) begin : genblk9
					assign unit_needed[UNIT_IDS[95-:32]] = is_scaiev_isax;
				end
				assign cva5_wrapper.cva5.decode_rename_interface.rd_addr = rd_addr;
				assign cva5_wrapper.cva5.decode_rename_interface.rs_addr = rs_addr;
				assign cva5_wrapper.cva5.decode_rename_interface.uses_rd = uses_rd;
				assign cva5_wrapper.cva5.decode_rename_interface.rd_wb_group = ~unit_needed[UNIT_IDS[255-:32]];
				assign cva5_wrapper.cva5.decode_rename_interface.id = decode[76-:3];
				assign decode_uses_rd = uses_rd;
				assign decode_uses_rd_decoupled = (scaiev_uses_rd_decoupled && !cva5_wrapper.scaiev.decode_skip_wb) && !scaiev_decode_inject;
				assign decode_rd_addr = rd_addr;
				assign decode_phys_rd_addr = cva5_wrapper.cva5.decode_rename_interface.phys_rd_addr;
				assign decode_phys_rs_addr = cva5_wrapper.cva5.decode_rename_interface.phys_rs_addr;
				assign decode_rs_wb_group = cva5_wrapper.cva5.decode_rename_interface.rs_wb_group;
				always @(posedge clk)
					if (issue_stage_ready) begin
						issue[101-:32] <= decode[70-:32];
						issue[69-:32] <= selected_instruction;
						issue[5-:6] <= decode[5-:6];
						issue[37-:3] <= fn3;
						issue[34-:7] <= opcode;
						issue_rs_addr <= rs_addr;
						issue_phys_rs_addr <= cva5_wrapper.cva5.decode_rename_interface.phys_rs_addr;
						issue_rs_wb_group <= cva5_wrapper.cva5.decode_rename_interface.rs_wb_group;
						issue[27-:5] <= rd_addr;
						issue[22-:6] <= cva5_wrapper.cva5.decode_rename_interface.phys_rd_addr;
						issue[15] <= ~unit_needed[UNIT_IDS[255-:32]];
						issue[14-:3] <= decode[76-:3];
						issue[11-:3] <= decode[73-:3];
						issue[8-:2] <= decode_exception_unit;
						issue_uses_rs <= uses_rs;
						issue[16] <= uses_rd;
						issue_is_injected <= scaiev_decode_inject || decode_cur_is_repeat;
						issue_uses_rd_decoupled <= decode_uses_rd_decoupled;
					end
				always @(posedge clk)
					if (issue_stage_ready)
						unit_needed_issue_stage <= unit_needed;
				always @(posedge clk)
					if ((rst | gc[111]) | cva5_wrapper.scaiev.issue_flush)
						issue[6] <= 0;
					else if (issue_stage_ready)
						issue[6] <= (((decode_valid & ~(scaiev_uses_rd_decoupled & stall_rd_decoupled)) & ~cva5_wrapper.scaiev.decode_stall) & ~(cva5_wrapper.scaiev.decode_flush | cva5_wrapper.scaiev.issue_flush)) & ~gc[113];
				for (_gv_i_13 = 0; _gv_i_13 < NUM_UNITS; _gv_i_13 = _gv_i_13 + 1) begin : genblk10
					localparam i = _gv_i_13;
					assign unit_ready[i] = cva5_wrapper.cva5.unit_issue[i + _mbase_unit_issue].ready;
				end
				for (_gv_i_13 = 0; _gv_i_13 < cva5_config_REGFILE_READ_PORTS; _gv_i_13 = _gv_i_13 + 1) begin : genblk11
					localparam i = _gv_i_13;
					assign rs_conflict[i] = cva5_wrapper.cva5.rf_issue.inuse[i] & issue_uses_rs[i];
				end
				assign operands_ready = ~|rs_conflict;
				assign issue_ready = unit_needed_issue_stage & unit_ready;
				assign issue_valid_or_waiting_for_operands = issue[6] & ~pre_issue_exception_pending;
				assign issue_valid_prescaiev = (issue_valid_or_waiting_for_operands & operands_ready) & ~gc[112];
				assign issue_valid = (issue_valid_prescaiev & ~scaiev_stall_issue) & ~cva5_wrapper.scaiev.issue_stall;
				assign issue_to = {NUM_UNITS {(issue_valid & ~gc[111]) & ~cva5_wrapper.scaiev.issue_flush}} & issue_ready;
				assign instruction_issued = ((issue_valid & ~gc[111]) & ~cva5_wrapper.scaiev.issue_flush) & |issue_ready;
				assign instruction_issued_with_rd = instruction_issued & issue[16];
				assign cva5_wrapper.cva5.rf_issue.phys_rs_addr = issue_phys_rs_addr;
				assign cva5_wrapper.cva5.rf_issue.phys_rd_addr = issue[22-:6];
				assign cva5_wrapper.cva5.rf_issue.rs_wb_group = issue_rs_wb_group;
				assign cva5_wrapper.cva5.rf_issue.single_cycle_or_flush = ((instruction_issued_with_rd & |issue[27-:5]) & ~issue[15]) | (((issue[6] & (issue[16] | issue_uses_rd_decoupled)) & |issue[27-:5]) & (gc[111] | cva5_wrapper.scaiev.issue_flush));
				wire [31:0] alu_rs2_data;
				reg alu_imm_type;
				reg [31:0] constant_alu;
				reg [1:0] alu_op;
				reg [1:0] alu_op_r;
				reg [1:0] alu_logic_op;
				reg [1:0] alu_logic_op_r;
				reg alu_subtract;
				wire sub_instruction;
				always @(*) begin
					if (_sv2v_0)
						;
					if (|{opcode_trim == 5'b01101, opcode_trim == 5'b00101, opcode_trim == 5'b11011, opcode_trim == 5'b11001})
						alu_op = 2'b00;
					else if (|{fn3 == 3'b011, fn3 == 3'b010})
						alu_op = 2'b10;
					else if (|{fn3 == 3'b001, fn3 == 3'b101})
						alu_op = 2'b11;
					else
						alu_op = 2'b01;
				end
				always @(*) begin
					if (_sv2v_0)
						;
					case (fn3)
						3'b100: alu_logic_op = 2'b00;
						3'b110: alu_logic_op = 2'b01;
						3'b111: alu_logic_op = 2'b10;
						default: alu_logic_op = 2'b11;
					endcase
				end
				assign sub_instruction = ((fn3 == 3'b000) && decode[37]) && opcode[5];
				always @(posedge clk)
					if (issue_stage_ready) begin
						constant_alu <= (opcode_trim == 5'b01101 ? {32 {1'sb0}} : (!cva5_wrapper.scaiev.decode_wrReg ? decode[70-:32] : cva5_wrapper.scaiev.decode_wrReg_data)) + (|{opcode_trim == 5'b01101, opcode_trim == 5'b00101} ? {(!cva5_wrapper.scaiev.decode_wrReg ? decode[38:19] : 20'b00000000000000000000), 12'b000000000000} : 4);
						alu_imm_type <= opcode_trim == 5'b00100;
						alu_op_r <= alu_op;
						alu_subtract <= |{fn3 == 3'b011, fn3 == 3'b010} || sub_instruction;
						alu_logic_op_r <= alu_logic_op;
					end
				assign alu_inputs[0] = ~issue[37];
				assign alu_inputs[7-:5] = (alu_imm_type ? issue_rs_addr[(cva5_config_REGFILE_READ_PORTS - (1 + 2'd1)) * 5+:5] : cva5_wrapper.cva5.rf_issue.data[2'd1][4:0]);
				assign alu_inputs[1] = cva5_wrapper.cva5.rf_issue.data[2'd0][31] & issue[68];
				assign alu_inputs[75-:32] = cva5_wrapper.cva5.rf_issue.data[2'd0];
				assign alu_inputs[43-:32] = constant_alu;
				assign alu_inputs[2] = alu_subtract;
				assign alu_inputs[9-:2] = alu_logic_op_r;
				assign alu_inputs[141-:33] = {cva5_wrapper.cva5.rf_issue.data[2'd0][31] & ~issue[35], cva5_wrapper.cva5.rf_issue.data[2'd0]};
				assign alu_rs2_data = (alu_imm_type ? sv2v_cast_32_signed($signed(issue[69:58])) : cva5_wrapper.cva5.rf_issue.data[2'd1]);
				assign alu_inputs[108-:33] = {alu_rs2_data[31] & ~issue[35], alu_rs2_data};
				assign alu_inputs[11-:2] = alu_op_r;
				wire is_load;
				wire is_store;
				wire amo_op;
				wire store_conditional;
				wire load_reserve;
				wire [4:0] amo_type;
				assign amo_op = (CONFIG[1201] ? opcode_trim == 5'b01011 : 1'b0);
				assign amo_type = decode[38:34];
				assign store_conditional = amo_type == 5'b00011;
				assign load_reserve = amo_type == 5'b00010;
				if (CONFIG[1201]) begin : gen_decode_ls_amo
					wire [1:1] sv2v_tmp_7C66E;
					assign sv2v_tmp_7C66E = load_reserve;
					always @(*) ls_inputs[7] = sv2v_tmp_7C66E;
					wire [1:1] sv2v_tmp_759B3;
					assign sv2v_tmp_759B3 = store_conditional;
					always @(*) ls_inputs[6] = sv2v_tmp_759B3;
					wire [1:1] sv2v_tmp_05C14;
					assign sv2v_tmp_05C14 = amo_op & ~(load_reserve | store_conditional);
					always @(*) ls_inputs[5] = sv2v_tmp_05C14;
					wire [5:1] sv2v_tmp_C9363;
					assign sv2v_tmp_C9363 = amo_type;
					always @(*) ls_inputs[4-:5] = sv2v_tmp_C9363;
				end
				else begin : genblk12
					wire [8:1] sv2v_tmp_F6773;
					assign sv2v_tmp_F6773 = 1'sb0;
					always @(*) ls_inputs[7-:8] = sv2v_tmp_F6773;
				end
				assign is_load = |{opcode_trim == 5'b00000, opcode_trim == 5'b01011} && !(amo_op & store_conditional);
				assign is_store = (opcode_trim == 5'b01000) || (amo_op && store_conditional);
				reg [11:0] ls_offset;
				reg is_load_r;
				reg is_store_r;
				reg is_fence_r;
				always @(posedge clk)
					if (issue_stage_ready) begin
						ls_offset <= (opcode[5] ? {decode[38:32], decode[18:14]} : decode[38:27]);
						is_load_r <= is_load;
						is_store_r <= is_store;
						is_fence_r <= is_fence;
					end
				reg [2:0] rd_to_id_table [0:31];
				always @(posedge clk)
					if (instruction_issued_with_rd)
						rd_to_id_table[issue[27-:5]] <= issue[14-:3];
				reg rd_scaiev_decoupled_table [0:31];
				if (scaiev_config_ENABLE_DECOUPLED_WRITEBACK) begin : genblk13
					always @(posedge clk)
						if (rst) begin : sv2v_autoblock_18
							integer i;
							for (i = 0; i <= 31; i = i + 1)
								rd_scaiev_decoupled_table[i] <= 0;
						end
						else if (instruction_issued)
							rd_scaiev_decoupled_table[issue[27-:5]] <= issue_uses_rd_decoupled;
				end
				else begin : genblk13
					for (_gv_i_13 = 0; _gv_i_13 < 32; _gv_i_13 = _gv_i_13 + 1) begin : genblk1
						localparam i = _gv_i_13;
						wire [1:1] sv2v_tmp_A0C9E;
						assign sv2v_tmp_A0C9E = 0;
						always @(*) rd_scaiev_decoupled_table[i] = sv2v_tmp_A0C9E;
					end
				end
				wire [12:1] sv2v_tmp_0E798;
				assign sv2v_tmp_0E798 = ls_offset;
				always @(*) ls_inputs[34-:12] = sv2v_tmp_0E798;
				wire [1:1] sv2v_tmp_0C3B4;
				assign sv2v_tmp_0C3B4 = is_load_r;
				always @(*) ls_inputs[19] = sv2v_tmp_0C3B4;
				wire [1:1] sv2v_tmp_262AF;
				assign sv2v_tmp_262AF = is_store_r;
				always @(*) ls_inputs[18] = sv2v_tmp_262AF;
				wire [1:1] sv2v_tmp_5775C;
				assign sv2v_tmp_5775C = 0;
				always @(*) ls_inputs[17] = sv2v_tmp_5775C;
				wire [1:1] sv2v_tmp_3E655;
				assign sv2v_tmp_3E655 = is_fence_r;
				always @(*) ls_inputs[16] = sv2v_tmp_3E655;
				wire [3:1] sv2v_tmp_DA193;
				assign sv2v_tmp_DA193 = (amo_op ? 3'b010 : issue[37-:3]);
				always @(*) ls_inputs[22-:3] = sv2v_tmp_DA193;
				wire [32:1] sv2v_tmp_8E982;
				assign sv2v_tmp_8E982 = cva5_wrapper.cva5.rf_issue.data[2'd0];
				always @(*) ls_inputs[98-:32] = sv2v_tmp_8E982;
				wire [32:1] sv2v_tmp_39E72;
				assign sv2v_tmp_39E72 = cva5_wrapper.cva5.rf_issue.data[2'd1];
				always @(*) ls_inputs[66-:32] = sv2v_tmp_39E72;
				wire [1:1] sv2v_tmp_DCE5B;
				assign sv2v_tmp_DCE5B = cva5_wrapper.cva5.rf_issue.inuse[2'd1];
				always @(*) ls_inputs[15] = sv2v_tmp_DCE5B;
				wire store_forward_is_from_instruction = !rd_scaiev_decoupled_table[issue_rs_addr[(cva5_config_REGFILE_READ_PORTS - (1 + 2'd1)) * 5+:5]];
				wire [1:1] sv2v_tmp_A3A9F;
				assign sv2v_tmp_A3A9F = store_forward_is_from_instruction;
				always @(*) ls_inputs[14] = sv2v_tmp_A3A9F;
				always @(*) begin
					if (_sv2v_0)
						;
					ls_inputs[13-:3] = 1'sbx;
					ls_inputs[10-:3] = 1'sbx;
					ls_inputs[13-:6] = 1'sbx;
					if (store_forward_is_from_instruction)
						ls_inputs[13-:3] = rd_to_id_table[issue_rs_addr[(cva5_config_REGFILE_READ_PORTS - (1 + 2'd1)) * 5+:5]];
					else
						ls_inputs[13-:6] = issue_phys_rs_addr[(cva5_config_REGFILE_READ_PORTS - (1 + 2'd1)) * 6+:6];
				end
				wire rs1_link;
				wire rd_link;
				wire rs1_eq_rd;
				reg is_return;
				reg is_call;
				assign rs1_link = |{rs_addr[(cva5_config_REGFILE_READ_PORTS - (1 + 2'd0)) * 5+:5] == 1, rs_addr[(cva5_config_REGFILE_READ_PORTS - (1 + 2'd0)) * 5+:5] == 5};
				assign rd_link = |{rd_addr == 1, rd_addr == 5};
				assign rs1_eq_rd = rs_addr[(cva5_config_REGFILE_READ_PORTS - (1 + 2'd0)) * 5+:5] == rd_addr;
				reg br_use_signed;
				always @(posedge clk)
					if (issue_stage_ready) begin
						is_return <= (opcode_trim == 5'b11001) && ((rs1_link & ~rd_link) | ((rs1_link & rd_link) & ~rs1_eq_rd));
						is_call <= |{opcode_trim == 5'b11011, opcode_trim == 5'b11001} && rd_link;
						br_use_signed <= !(|{fn3 == 3'b110, fn3 == 3'b111});
					end
				wire [19:0] jal_imm;
				wire [11:0] jalr_imm;
				wire [11:0] br_imm;
				reg [20:0] pc_offset;
				reg [20:0] pc_offset_r;
				assign jal_imm = {decode[38], decode[26:19], decode[27], decode[37:28]};
				assign jalr_imm = decode[38:27];
				assign br_imm = {decode[38], decode[14], decode[37:32], decode[18:15]};
				always @(*) begin
					if (_sv2v_0)
						;
					case (opcode[3:2])
						2'b11: pc_offset = sv2v_cast_21_signed($signed({jal_imm, 1'b0}));
						2'b01: pc_offset = sv2v_cast_21_signed($signed(jalr_imm));
						default: pc_offset = sv2v_cast_21_signed($signed({br_imm, 1'b0}));
					endcase
				end
				reg jalr;
				always @(posedge clk)
					if (issue_stage_ready) begin
						pc_offset_r <= pc_offset;
						jalr <= ~opcode[3] & opcode[2];
					end
				assign branch_inputs[162-:3] = issue[11-:3];
				assign branch_inputs[21] = is_return;
				assign branch_inputs[22] = is_call;
				assign branch_inputs[61-:3] = issue[37-:3];
				assign branch_inputs[20-:21] = pc_offset_r;
				assign branch_inputs[25] = issue[31];
				assign branch_inputs[24] = jalr;
				assign branch_inputs[23] = issue[30];
				assign branch_inputs[58-:32] = issue[101-:32];
				assign branch_inputs[26] = issue[6];
				assign branch_inputs[159-:33] = {cva5_wrapper.cva5.rf_issue.data[2'd0][31] & br_use_signed, cva5_wrapper.cva5.rf_issue.data[2'd0]};
				assign branch_inputs[126-:33] = {cva5_wrapper.cva5.rf_issue.data[2'd1][31] & br_use_signed, cva5_wrapper.cva5.rf_issue.data[2'd1]};
				assign branch_inputs[93-:32] = constant_alu;
				reg is_ecall_r;
				reg is_ebreak_r;
				reg is_mret_r;
				reg is_sret_r;
				reg is_ifence_r;
				reg [7:0] sys_op_match;
				always @(*) begin
					if (_sv2v_0)
						;
					sys_op_match = 1'sb0;
					if (decode[38:27] == 12'b000000000000)
						sys_op_match[3'd0] = CONFIG[1209];
					else if (decode[38:27] == 12'b000000000001)
						sys_op_match[3'd1] = CONFIG[1209];
					else if (decode[38:27] == 12'b000100000010)
						sys_op_match[3'd3] = CONFIG[1208];
					else if (decode[38:27] == 12'b001100000010)
						sys_op_match[3'd4] = CONFIG[1209];
					else if ((decode[38:27] | 12'b000000011111) == 12'b000100111111)
						sys_op_match[3'd5] = CONFIG[1208];
					else
						sys_op_match = 1'sb0;
				end
				always @(posedge clk)
					if (issue_stage_ready) begin
						is_ecall_r <= sys_op_match[3'd0];
						is_ebreak_r <= sys_op_match[3'd1];
						is_mret_r <= sys_op_match[3'd4];
						is_sret_r <= sys_op_match[3'd3];
						is_ifence_r <= is_ifence;
					end
				assign gc_inputs[34-:32] = constant_alu;
				assign gc_inputs[2] = is_ifence_r;
				assign gc_inputs[1] = is_mret_r;
				assign gc_inputs[0] = is_sret_r;
				if (CONFIG[1202]) begin : gen_decode_csr_inputs
					assign csr_inputs[47-:12] = issue[69:58];
					assign csr_inputs[35-:2] = issue[36:35];
					assign csr_inputs[31-:riscv_types_XLEN] = (issue[37] ? {27'b000000000000000000000000000, issue_rs_addr[(cva5_config_REGFILE_READ_PORTS - (1 + 2'd0)) * 5+:5]} : cva5_wrapper.cva5.rf_issue.data[2'd0]);
					assign csr_inputs[33] = ~((issue[36:35] == 2'b01) && (issue[27-:5] == 0));
					assign csr_inputs[32] = ~((issue[36:35] == 2'b11) && (issue_rs_addr[(cva5_config_REGFILE_READ_PORTS - (1 + 2'd0)) * 5+:5] == 0));
				end
				if (CONFIG[1206]) begin : gen_decode_mul_inputs
					assign mul_inputs[65-:32] = cva5_wrapper.cva5.rf_issue.data[2'd0];
					assign mul_inputs[33-:32] = cva5_wrapper.cva5.rf_issue.data[2'd1];
					assign mul_inputs[1-:2] = issue[36:35];
				end
				if (CONFIG[1205]) begin : gen_decode_div_inputs
					reg [11:0] prev_div_rs_addr;
					reg prev_div_signed;
					wire [1:0] div_rd_match;
					wire prev_div_result_valid;
					wire div_rs_overwrite;
					wire div_op_reuse;
					wire signed_divop;
					always @(posedge clk)
						if (rst) begin
							prev_div_rs_addr[6+:6] <= 1'sb0;
							prev_div_rs_addr[0+:6] <= 1'sb0;
							prev_div_signed <= 1'sb0;
						end
						else if (issue_to[UNIT_IDS[127-:32]]) begin
							prev_div_rs_addr <= issue_phys_rs_addr[6 * ((cva5_config_REGFILE_READ_PORTS - 1) - ((2'd0 + ((2'd1 - 2'd0) + 1)) - 1))+:6 * ((2'd1 - 2'd0) + 1)];
							prev_div_signed <= signed_divop;
						end
					assign signed_divop = ~issue[35];
					assign div_op_reuse = ((prev_div_result_valid && (prev_div_rs_addr[(1 - sv2v_cast_1(2'd0)) * 6+:6] == issue_phys_rs_addr[(cva5_config_REGFILE_READ_PORTS - (1 + 2'd0)) * 6+:6])) && (prev_div_rs_addr[(1 - sv2v_cast_1(2'd1)) * 6+:6] == issue_phys_rs_addr[(cva5_config_REGFILE_READ_PORTS - (1 + 2'd1)) * 6+:6])) && (prev_div_signed == signed_divop);
					assign div_rd_match[sv2v_cast_1(2'd0)] = issue[22-:6] == prev_div_rs_addr[(1 - sv2v_cast_1(2'd0)) * 6+:6];
					assign div_rd_match[sv2v_cast_1(2'd1)] = issue[22-:6] == prev_div_rs_addr[(1 - sv2v_cast_1(2'd1)) * 6+:6];
					assign div_rs_overwrite = |div_rd_match;
					set_clr_reg_with_rst #(
						.SET_OVER_CLR(1),
						.WIDTH(1),
						.RST_VALUE(0)
					) prev_div_result_valid_m(
						.clk(clk),
						.rst(rst),
						.set(instruction_issued & unit_needed_issue_stage[UNIT_IDS[127-:32]]),
						.clr(((instruction_issued & issue[16]) & div_rs_overwrite) | gc[110]),
						.result(prev_div_result_valid)
					);
					assign div_inputs[66-:32] = cva5_wrapper.cva5.rf_issue.data[2'd0];
					assign div_inputs[34-:32] = cva5_wrapper.cva5.rf_issue.data[2'd1];
					assign div_inputs[2-:2] = issue[36:35];
					assign div_inputs[0] = div_op_reuse;
				end
				if (CONFIG[1204]) begin : gen_decode_scaiev_inputs
					assign scaiev_inputs[160-:32] = cva5_wrapper.cva5.rf_issue.data[2'd0];
					assign scaiev_inputs[128-:32] = cva5_wrapper.cva5.rf_issue.data[2'd1];
					if (scaiev_config_ENABLE_NATIVE_RD_AS_RS) begin : genblk1
						assign scaiev_inputs[96-:32] = cva5_wrapper.cva5.rf_issue.data[2'd2];
					end
					else begin : genblk1
						assign scaiev_inputs[96-:32] = 0;
					end
					assign scaiev_inputs[64-:32] = issue[69-:32];
					assign scaiev_inputs[32-:32] = issue[101-:32];
					assign scaiev_inputs[0] = issue[16];
					assign cva5_wrapper.scaiev.issue_ID = issue[14-:3];
					assign cva5_wrapper.scaiev.issue_PC = issue[101-:32];
					assign cva5_wrapper.scaiev.issue_RS1_valid = !rs_conflict[2'd0];
					assign cva5_wrapper.scaiev.issue_RS1 = cva5_wrapper.cva5.rf_issue.data[2'd0];
					assign cva5_wrapper.scaiev.issue_RS2_valid = !rs_conflict[2'd1];
					assign cva5_wrapper.scaiev.issue_RS2 = cva5_wrapper.cva5.rf_issue.data[2'd1];
					if (scaiev_config_ENABLE_NATIVE_RD_AS_RS) begin : genblk2
						assign cva5_wrapper.scaiev.issue_RD_AS_RS_valid = !rs_conflict[2'd2];
						assign cva5_wrapper.scaiev.issue_RD_AS_RS = cva5_wrapper.cva5.rf_issue.data[2'd2];
					end
					else begin : genblk2
						assign cva5_wrapper.scaiev.issue_RD_AS_RS_valid = 0;
						assign cva5_wrapper.scaiev.issue_RD_AS_RS = 1'sb0;
					end
					assign cva5_wrapper.scaiev.issue_RD_valid = issue[16];
					assign cva5_wrapper.scaiev.issue_RD_id = issue[27-:5];
					assign cva5_wrapper.scaiev.issue_Instr = issue[69-:32];
					assign cva5_wrapper.scaiev.issue_valid = issue_valid_or_waiting_for_operands;
					assign cva5_wrapper.scaiev.decode_isStalling = !(decode_valid & issue_stage_ready);
					assign cva5_wrapper.scaiev.issue_isStalling = ((!issue_valid_prescaiev || !(|issue_ready)) || gc[111]) || cva5_wrapper.scaiev.issue_flush;
					assign cva5_wrapper.scaiev.issue_isSCAIEV = unit_needed_issue_stage[UNIT_IDS[95-:32]];
					assign cva5_wrapper.scaiev.issue_isLS = unit_needed_issue_stage[UNIT_IDS[223-:32]];
					assign cva5_wrapper.scaiev.issue_injected = issue_is_injected;
					assign cva5_wrapper.scaiev.decode_phys_RD_decoupled = cva5_wrapper.cva5.decode_rename_interface.phys_rd_addr;
					assign cva5_wrapper.scaiev.issue_phys_RD_decoupled = issue[22-:6];
				end
				for (_gv_i_13 = 0; _gv_i_13 < NUM_UNITS; _gv_i_13 = _gv_i_13 + 1) begin : gen_unit_issue_signals
					localparam i = _gv_i_13;
					assign cva5_wrapper.cva5.unit_issue[i + _mbase_unit_issue].possible_issue = (issue[6] & unit_needed_issue_stage[i]) & cva5_wrapper.cva5.unit_issue[i + _mbase_unit_issue].ready;
					assign cva5_wrapper.cva5.unit_issue[i + _mbase_unit_issue].new_request = issue_to[i];
					assign cva5_wrapper.cva5.unit_issue[i + _mbase_unit_issue].id = issue[14-:3];
				end
				reg illegal_instruction_pattern_r;
				if (CONFIG[1209]) begin : gen_decode_exceptions
					illegal_instruction_checker #(.CONFIG(CONFIG)) illegal_op_check(
						.instruction(decode[38-:32]),
						.illegal_instruction(illegal_instruction_pattern_prescaiev)
					);
					assign illegal_instruction_pattern = (illegal_instruction_pattern_prescaiev & ~cva5_wrapper.scaiev.decode_isSCAIEV) & ~scaiev_decode_inject;
					always @(posedge clk)
						if (rst)
							illegal_instruction_pattern_r <= 0;
						else if (issue_stage_ready)
							illegal_instruction_pattern_r <= illegal_instruction_pattern;
					always @(*) begin
						if (_sv2v_0)
							;
						(* full_case, parallel_case *)
						case (1'b1)
							unit_needed[UNIT_IDS[223-:32]]: decode_exception_unit = 2'd0;
							unit_needed[UNIT_IDS[63-:32]]: decode_exception_unit = 2'd1;
							default: decode_exception_unit = 2'd2;
						endcase
						if (illegal_instruction_pattern)
							decode_exception_unit = 2'd2;
					end
					reg [4:0] ecall_code;
					always @(*) begin
						if (_sv2v_0)
							;
						case (current_privilege)
							2'b00: begin : sv2v_autoblock_19
								reg [4:0] sv2v_tmp_cast;
								sv2v_tmp_cast = 5'd8;
								ecall_code = sv2v_tmp_cast;
							end
							2'b01: begin : sv2v_autoblock_20
								reg [4:0] sv2v_tmp_cast_1;
								sv2v_tmp_cast_1 = 5'd9;
								ecall_code = sv2v_tmp_cast_1;
							end
							2'b11: begin : sv2v_autoblock_21
								reg [4:0] sv2v_tmp_cast_2;
								sv2v_tmp_cast_2 = 5'd11;
								ecall_code = sv2v_tmp_cast_2;
							end
							default: begin : sv2v_autoblock_22
								reg [4:0] sv2v_tmp_cast_3;
								sv2v_tmp_cast_3 = 5'd8;
								ecall_code = sv2v_tmp_cast_3;
							end
						endcase
					end
					wire new_exception;
					wire [4:0] ecode;
					always @(posedge clk)
						if (rst)
							pre_issue_exception_pending <= 0;
						else if (issue_stage_ready)
							pre_issue_exception_pending <= (illegal_instruction_pattern | (((opcode_trim == 5'b11100) & ~is_csr) & (sys_op_match[3'd0] | sys_op_match[3'd1]))) | ~decode[5];
					assign new_exception = (issue[6] & pre_issue_exception_pending) & ~((gc[112] | gc[111]) | cva5_wrapper.scaiev.issue_flush);
					always @(posedge clk)
						if (rst)
							cva5_wrapper.cva5.exception[_mbase_exception].valid <= 0;
						else
							cva5_wrapper.cva5.exception[_mbase_exception].valid <= (cva5_wrapper.cva5.exception[_mbase_exception].valid | new_exception) & ~cva5_wrapper.cva5.exception[_mbase_exception].ack;
					function automatic [4:0] sv2v_cast_B3515;
						input reg [4:0] inp;
						sv2v_cast_B3515 = inp;
					endfunction
					assign ecode = (illegal_instruction_pattern_r ? sv2v_cast_B3515(5'd2) : (is_ecall_r ? ecall_code : (~issue[5] ? issue[4-:riscv_types_ECODE_W] : sv2v_cast_B3515(5'd3))));
					always @(posedge clk)
						if (new_exception) begin
							cva5_wrapper.cva5.exception[_mbase_exception].code <= ecode;
							cva5_wrapper.cva5.exception[_mbase_exception].tval <= issue[69-:32];
							cva5_wrapper.cva5.exception[_mbase_exception].id <= issue[14-:3];
						end
				end
				localparam cva5_config_ENABLE_TRACE_INTERFACE = 1;
				if (cva5_config_ENABLE_TRACE_INTERFACE) begin : gen_decode_trace
					assign tr_operand_stall = (((((issue[6] & ~gc[111]) & ~cva5_wrapper.scaiev.issue_flush) & ~gc[112]) & ~pre_issue_exception_pending) & ~operands_ready) & |issue_ready;
					assign tr_unit_stall = ((issue_valid & ~gc[111]) & ~cva5_wrapper.scaiev.issue_flush) & ~|issue_ready;
					assign tr_no_id_stall = ((~issue[6] & ~pc_id_available) & ~gc[111]) & ~cva5_wrapper.scaiev.issue_flush;
					assign tr_no_instruction_stall = ((pc_id_available & ~issue[6]) | gc[111]) | cva5_wrapper.scaiev.issue_flush;
					assign tr_other_stall = (issue[6] & ~instruction_issued) & ~(((tr_operand_stall | tr_unit_stall) | tr_no_id_stall) | tr_no_instruction_stall);
					assign tr_branch_operand_stall = tr_operand_stall & unit_needed_issue_stage[UNIT_IDS[63-:32]];
					assign tr_alu_operand_stall = (tr_operand_stall & unit_needed_issue_stage[UNIT_IDS[255-:32]]) & ~unit_needed_issue_stage[UNIT_IDS[63-:32]];
					assign tr_ls_operand_stall = tr_operand_stall & unit_needed_issue_stage[UNIT_IDS[223-:32]];
					assign tr_div_operand_stall = tr_operand_stall & unit_needed_issue_stage[UNIT_IDS[127-:32]];
					always @(posedge clk) begin
						tr_alu_op <= issue_to[UNIT_IDS[255-:32]];
						tr_branch_or_jump_op <= issue_to[UNIT_IDS[63-:32]];
						tr_load_op <= issue_to[UNIT_IDS[223-:32]] & is_load_r;
						tr_store_op <= issue_to[UNIT_IDS[223-:32]] & is_store_r;
						tr_mul_op <= issue_to[UNIT_IDS[159-:32]];
						tr_div_op <= issue_to[UNIT_IDS[127-:32]];
						tr_misc_op <= issue_to[UNIT_IDS[191-:32]] | issue_to[UNIT_IDS[31-:32]];
					end
					assign tr_instruction_issued_dec = instruction_issued;
					assign tr_instruction_pc_dec = issue[101-:32];
					assign tr_instruction_data_dec = issue[69-:32];
				end
				initial _sv2v_0 = 0;
			end
			assign decode_and_issue_block.clk = clk;
			assign decode_and_issue_block.rst = rst;
			assign decode_and_issue_block.pc_id_available = pc_id_available;
			assign decode_and_issue_block.pc_inject_id_available = pc_inject_id_available;
			assign pc_inject_id_assigned = decode_and_issue_block.pc_inject_id_assigned;
			assign decode_and_issue_block.decode = decode;
			assign decode_advance = decode_and_issue_block.decode_advance;
			assign decode_uses_rd = decode_and_issue_block.decode_uses_rd;
			assign decode_uses_rd_decoupled = decode_and_issue_block.decode_uses_rd_decoupled;
			assign decode_rd_addr = decode_and_issue_block.decode_rd_addr;
			assign decode_exception_unit = decode_and_issue_block.decode_exception_unit;
			assign decode_phys_rd_addr = decode_and_issue_block.decode_phys_rd_addr;
			assign decode_phys_rs_addr = decode_and_issue_block.decode_phys_rs_addr;
			assign decode_rs_wb_group = decode_and_issue_block.decode_rs_wb_group;
			assign instruction_issued = decode_and_issue_block.instruction_issued;
			assign instruction_issued_with_rd = decode_and_issue_block.instruction_issued_with_rd;
			assign issue_uses_rd_decoupled = decode_and_issue_block.issue_uses_rd_decoupled;
			assign issue = decode_and_issue_block.issue;
			assign alu_inputs = decode_and_issue_block.alu_inputs;
			assign ls_inputs = decode_and_issue_block.ls_inputs;
			assign branch_inputs = decode_and_issue_block.branch_inputs;
			assign gc_inputs = decode_and_issue_block.gc_inputs;
			assign csr_inputs = decode_and_issue_block.csr_inputs;
			assign mul_inputs = decode_and_issue_block.mul_inputs;
			assign div_inputs = decode_and_issue_block.div_inputs;
			assign scaiev_inputs = decode_and_issue_block.scaiev_inputs;
			assign decode_and_issue_block.scaiev_stall_issue = scaiev_stall_issue;
			assign decode_and_issue_block.gc = gc;
			assign scaiev_decode_inject = decode_and_issue_block.scaiev_decode_inject;
			assign pc_inject_keep_for_repeat = decode_and_issue_block.pc_inject_keep_for_repeat;
			assign pc_inject_is_repeat = decode_and_issue_block.pc_inject_is_repeat;
			assign decode_and_issue_block.current_privilege = current_privilege;
			assign tr_operand_stall = decode_and_issue_block.tr_operand_stall;
			assign tr_unit_stall = decode_and_issue_block.tr_unit_stall;
			assign tr_no_id_stall = decode_and_issue_block.tr_no_id_stall;
			assign tr_no_instruction_stall = decode_and_issue_block.tr_no_instruction_stall;
			assign tr_other_stall = decode_and_issue_block.tr_other_stall;
			assign tr_branch_operand_stall = decode_and_issue_block.tr_branch_operand_stall;
			assign tr_alu_operand_stall = decode_and_issue_block.tr_alu_operand_stall;
			assign tr_ls_operand_stall = decode_and_issue_block.tr_ls_operand_stall;
			assign tr_div_operand_stall = decode_and_issue_block.tr_div_operand_stall;
			assign tr_alu_op = decode_and_issue_block.tr_alu_op;
			assign tr_branch_or_jump_op = decode_and_issue_block.tr_branch_or_jump_op;
			assign tr_load_op = decode_and_issue_block.tr_load_op;
			assign tr_store_op = decode_and_issue_block.tr_store_op;
			assign tr_mul_op = decode_and_issue_block.tr_mul_op;
			assign tr_div_op = decode_and_issue_block.tr_div_op;
			assign tr_misc_op = decode_and_issue_block.tr_misc_op;
			assign tr_instruction_issued_dec = decode_and_issue_block.tr_instruction_issued_dec;
			assign tr_instruction_pc_dec = decode_and_issue_block.tr_instruction_pc_dec;
			assign tr_instruction_data_dec = decode_and_issue_block.tr_instruction_data_dec;
			localparam _param_60E6B_CONFIG = CONFIG;
			if (1) begin : register_file_block
				localparam [1209:0] cva5_config_EXAMPLE_CONFIG = 1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002;
				localparam [1209:0] CONFIG = _param_60E6B_CONFIG;
				wire clk;
				wire rst;
				localparam cva5_config_MAX_IDS = 8;
				localparam cva5_types_LOG2_MAX_IDS = 3;
				localparam riscv_types_ECODE_W = 5;
				wire [115:0] gc;
				localparam scaiev_config_ENABLE_NATIVE_RD_AS_RS = 0;
				localparam cva5_config_REGFILE_READ_PORTS = (scaiev_config_ENABLE_NATIVE_RD_AS_RS ? 3 : 2);
				wire [(cva5_config_REGFILE_READ_PORTS * 6) - 1:0] decode_phys_rs_addr;
				wire [(cva5_config_REGFILE_READ_PORTS * $clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32])) - 1:0] decode_rs_wb_group;
				wire [5:0] decode_phys_rd_addr;
				wire decode_advance;
				wire decode_uses_rd;
				wire decode_uses_rd_decoupled;
				wire [(CONFIG[31-:32] * 42) - 1:0] commit;
				wire [(cva5_config_REGFILE_READ_PORTS * 32) - 1:0] rs_data_set [0:CONFIG[31-:32] - 1];
				wire [0:cva5_config_REGFILE_READ_PORTS - 1] decode_inuse;
				reg [0:cva5_config_REGFILE_READ_PORTS - 1] decode_inuse_r;
				genvar _gv_i_17;
				wire [((cva5_config_REGFILE_READ_PORTS * 2) * 6) - 1:0] read_addr_for_toggle_mem_set;
				assign read_addr_for_toggle_mem_set[((cva5_config_REGFILE_READ_PORTS * 2) - 1) * 6+:6] = decode_phys_rs_addr[(cva5_config_REGFILE_READ_PORTS - (1 + 2'd0)) * 6+:6];
				assign read_addr_for_toggle_mem_set[((cva5_config_REGFILE_READ_PORTS * 2) - 2) * 6+:6] = decode_phys_rs_addr[(cva5_config_REGFILE_READ_PORTS - (1 + 2'd1)) * 6+:6];
				assign read_addr_for_toggle_mem_set[((cva5_config_REGFILE_READ_PORTS * 2) - 3) * 6+:6] = cva5_wrapper.cva5.rf_issue.phys_rs_addr[(1 - 2'd0) * 6+:6];
				assign read_addr_for_toggle_mem_set[((cva5_config_REGFILE_READ_PORTS * 2) - 4) * 6+:6] = cva5_wrapper.cva5.rf_issue.phys_rs_addr[(1 - 2'd1) * 6+:6];
				if (scaiev_config_ENABLE_NATIVE_RD_AS_RS) begin : genblk1
					assign read_addr_for_toggle_mem_set[((cva5_config_REGFILE_READ_PORTS * 2) - 5) * 6+:6] = decode_phys_rs_addr[(cva5_config_REGFILE_READ_PORTS - (1 + 2'd2)) * 6+:6];
					assign read_addr_for_toggle_mem_set[((cva5_config_REGFILE_READ_PORTS * 2) - 6) * 6+:6] = cva5_wrapper.cva5.rf_issue.phys_rs_addr[(1 - 2'd2) * 6+:6];
				end
				wire [0:(cva5_config_REGFILE_READ_PORTS * 2) - 1] id_inuse_from_toggle_mem_set;
				assign decode_inuse[2'd0] = id_inuse_from_toggle_mem_set[0];
				assign decode_inuse[2'd1] = id_inuse_from_toggle_mem_set[1];
				assign cva5_wrapper.cva5.rf_issue.inuse[2'd0] = id_inuse_from_toggle_mem_set[2];
				assign cva5_wrapper.cva5.rf_issue.inuse[2'd1] = id_inuse_from_toggle_mem_set[3];
				if (scaiev_config_ENABLE_NATIVE_RD_AS_RS) begin : genblk2
					assign decode_inuse[2'd2] = id_inuse_from_toggle_mem_set[4];
					assign cva5_wrapper.cva5.rf_issue.inuse[2'd2] = id_inuse_from_toggle_mem_set[5];
				end
				toggle_memory_set #(
					.DEPTH(64),
					.NUM_WRITE_PORTS(3),
					.NUM_READ_PORTS(cva5_config_REGFILE_READ_PORTS * 2),
					.WRITE_INDEX_FOR_RESET(0),
					.READ_INDEX_FOR_RESET(0)
				) id_inuse_toggle_mem_set(
					.clk(clk),
					.rst(rst),
					.init_clear(gc[115]),
					.toggle({((decode_advance & (decode_uses_rd | decode_uses_rd_decoupled)) & |decode_phys_rd_addr) & ~((gc[111] | cva5_wrapper.scaiev.issue_flush) | cva5_wrapper.scaiev.decode_flush), cva5_wrapper.cva5.rf_issue.single_cycle_or_flush, commit[((CONFIG[31-:32] - 2) * 42) + 38]}),
					.toggle_addr({decode_phys_rd_addr, cva5_wrapper.cva5.rf_issue.phys_rd_addr, commit[((CONFIG[31-:32] - 2) * 42) + 37-:6]}),
					.read_addr(read_addr_for_toggle_mem_set),
					.in_use(id_inuse_from_toggle_mem_set)
				);
				always @(posedge clk)
					if (decode_advance)
						decode_inuse_r <= decode_inuse;
				for (_gv_i_17 = 0; _gv_i_17 < CONFIG[31-:32]; _gv_i_17 = _gv_i_17 + 1) begin : register_file_gen
					localparam i = _gv_i_17;
					register_bank #(.NUM_READ_PORTS(cva5_config_REGFILE_READ_PORTS)) reg_group(
						.clk(clk),
						.rst(rst),
						.write_addr(commit[(((CONFIG[31-:32] - 1) - i) * 42) + 37-:6]),
						.new_data(commit[(((CONFIG[31-:32] - 1) - i) * 42) + 31-:32]),
						.commit(commit[(((CONFIG[31-:32] - 1) - i) * 42) + 38] & ~gc[110]),
						.read_addr(decode_phys_rs_addr),
						.data(rs_data_set[i])
					);
				end
				wire [(cva5_config_REGFILE_READ_PORTS * $clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32])) - 1:0] rs_wb_group;
				wire [0:cva5_config_REGFILE_READ_PORTS - 1] bypass;
				assign rs_wb_group = (decode_advance ? decode_rs_wb_group : cva5_wrapper.cva5.rf_issue.rs_wb_group);
				assign bypass = (decode_advance ? decode_inuse : decode_inuse_r);
				always @(posedge clk) begin : sv2v_autoblock_23
					reg signed [31:0] i;
					for (i = 0; i < cva5_config_REGFILE_READ_PORTS; i = i + 1)
						if (decode_advance | cva5_wrapper.cva5.rf_issue.inuse[i])
							cva5_wrapper.cva5.rf_issue.data[i] <= (bypass[i] ? commit[(((CONFIG[31-:32] - 1) - rs_wb_group[((cva5_config_REGFILE_READ_PORTS - 1) - i) * $clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32])+:$clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32])]) * 42) + 31-:32] : rs_data_set[rs_wb_group[((cva5_config_REGFILE_READ_PORTS - 1) - i) * $clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32])+:$clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32])]][((cva5_config_REGFILE_READ_PORTS - 1) - i) * 32+:32]);
				end
				genvar _gv_i_18;
				for (_gv_i_18 = 0; _gv_i_18 < CONFIG[31-:32]; _gv_i_18 = _gv_i_18 + 1) begin : write_to_rd_zero_assertion
					localparam i = _gv_i_18;
				end
			end
			assign register_file_block.clk = clk;
			assign register_file_block.rst = rst;
			assign register_file_block.gc = gc;
			assign register_file_block.decode_phys_rs_addr = decode_phys_rs_addr;
			assign register_file_block.decode_phys_rd_addr = decode_phys_rd_addr;
			assign register_file_block.decode_rs_wb_group = decode_rs_wb_group;
			assign register_file_block.decode_advance = decode_advance;
			assign register_file_block.decode_uses_rd = decode_uses_rd;
			assign register_file_block.decode_uses_rd_decoupled = decode_uses_rd_decoupled;
			assign register_file_block.commit = commit_packet;
			localparam _bbase_3FA87_issue = UNIT_IDS[63-:32];
			localparam _param_3FA87_CONFIG = CONFIG;
			if (1) begin : branch_unit_block
				localparam [1209:0] cva5_config_EXAMPLE_CONFIG = 1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002;
				localparam [1209:0] CONFIG = _param_3FA87_CONFIG;
				wire clk;
				wire rst;
				localparam _mbase_issue = _bbase_3FA87_issue;
				localparam cva5_config_MAX_IDS_FETCH = 8;
				localparam cva5_types_LOG2_MAX_IDS_FETCH = 3;
				localparam riscv_types_XLEN = 32;
				wire [162:0] branch_inputs;
				localparam cva5_config_MAX_IDS = 8;
				localparam cva5_types_LOG2_MAX_IDS = 3;
				wire [74:0] br_results;
				wire branch_flush;
				wire tr_branch_correct;
				wire tr_branch_misspredict;
				wire tr_return_correct;
				wire tr_return_misspredict;
				wire branch_issued_r;
				wire result;
				wire branch_taken;
				reg branch_taken_ex;
				reg [2:0] pc_id_ex;
				reg [2:0] id_ex;
				wire [31:0] jump_pc;
				wire [31:0] new_pc;
				reg [31:0] new_pc_ex;
				reg [31:0] pc_ex;
				wire instruction_is_completing;
				wire branch_complete;
				reg jal_jalr_ex;
				assign cva5_wrapper.cva5.unit_issue[_mbase_issue].ready = 1;
				set_clr_reg_with_rst #(
					.SET_OVER_CLR(1),
					.WIDTH(1),
					.RST_VALUE(0)
				) branch_issued_m(
					.clk(clk),
					.rst(rst),
					.set(cva5_wrapper.cva5.unit_issue[_mbase_issue].new_request),
					.clr(branch_inputs[26] | cva5_wrapper.cva5.br_exception.valid),
					.result(branch_issued_r)
				);
				assign instruction_is_completing = branch_issued_r & branch_inputs[26];
				branch_comparator bc(
					.less_than(branch_inputs[61]),
					.a(branch_inputs[159-:33]),
					.b(branch_inputs[126-:33]),
					.xor_result(branch_inputs[59]),
					.result(result)
				);
				assign branch_taken = result | branch_inputs[23];
				assign jump_pc = (branch_inputs[24] ? branch_inputs[158:127] : branch_inputs[58-:32]) + sv2v_cast_32_signed($signed(branch_inputs[20-:21]));
				assign new_pc = (branch_taken ? jump_pc : branch_inputs[93-:32]);
				always @(posedge clk)
					if (cva5_wrapper.cva5.unit_issue[_mbase_issue].new_request) begin
						branch_taken_ex <= branch_taken;
						new_pc_ex <= {new_pc[31:1], new_pc[0] & ~branch_inputs[24]};
						id_ex <= cva5_wrapper.cva5.unit_issue[_mbase_issue].id;
						pc_id_ex <= branch_inputs[162-:3];
						jal_jalr_ex <= branch_inputs[23];
					end
				localparam riscv_types_ECODE_W = 5;
				if (CONFIG[1209]) begin : gen_branch_exception
					wire new_exception;
					assign new_exception = (new_pc[1] & branch_taken) & cva5_wrapper.cva5.unit_issue[_mbase_issue].new_request;
					always @(posedge clk)
						if (rst)
							cva5_wrapper.cva5.br_exception.valid <= 0;
						else
							cva5_wrapper.cva5.br_exception.valid <= (cva5_wrapper.cva5.br_exception.valid & ~cva5_wrapper.cva5.br_exception.ack) | new_exception;
					always @(posedge clk)
						if (cva5_wrapper.cva5.unit_issue[_mbase_issue].new_request)
							cva5_wrapper.cva5.br_exception.id <= cva5_wrapper.cva5.unit_issue[_mbase_issue].id;
					function automatic [4:0] sv2v_cast_97E1D;
						input reg [4:0] inp;
						sv2v_cast_97E1D = inp;
					endfunction
					assign cva5_wrapper.cva5.br_exception.code = sv2v_cast_97E1D(5'd0);
					assign cva5_wrapper.cva5.br_exception.tval = new_pc_ex;
				end
				reg is_return;
				reg is_call;
				always @(posedge clk)
					if (cva5_wrapper.cva5.unit_issue[_mbase_issue].possible_issue) begin
						is_return <= branch_inputs[21];
						is_call <= branch_inputs[22];
						pc_ex <= branch_inputs[58-:32];
					end
				assign br_results[71-:3] = pc_id_ex;
				assign br_results[74-:3] = id_ex;
				assign br_results[68] = instruction_is_completing;
				assign br_results[67-:32] = pc_ex;
				assign br_results[35-:32] = new_pc_ex;
				assign br_results[3] = branch_taken_ex;
				assign br_results[2] = ~jal_jalr_ex;
				assign br_results[1] = is_return;
				assign br_results[0] = is_call;
				assign branch_flush = instruction_is_completing && (branch_inputs[58:28] != new_pc_ex[31:1]);
				localparam cva5_config_ENABLE_TRACE_INTERFACE = 1;
				if (cva5_config_ENABLE_TRACE_INTERFACE) begin : genblk2
					assign tr_branch_correct = (instruction_is_completing & ~is_return) & ~branch_flush;
					assign tr_branch_misspredict = (instruction_is_completing & ~is_return) & branch_flush;
					assign tr_return_correct = (instruction_is_completing & is_return) & ~branch_flush;
					assign tr_return_misspredict = (instruction_is_completing & is_return) & branch_flush;
				end
			end
			assign branch_unit_block.clk = clk;
			assign branch_unit_block.rst = rst;
			assign branch_unit_block.branch_inputs = branch_inputs;
			assign br_results_branch = branch_unit_block.br_results;
			assign branch_flush_branch = branch_unit_block.branch_flush;
			assign tr_branch_correct = branch_unit_block.tr_branch_correct;
			assign tr_branch_misspredict = branch_unit_block.tr_branch_misspredict;
			assign tr_return_correct = branch_unit_block.tr_return_correct;
			assign tr_return_misspredict = branch_unit_block.tr_return_misspredict;
			localparam _bbase_4CF11_issue = UNIT_IDS[255-:32];
			localparam _bbase_4CF11_wb = UNIT_IDS[255-:32];
			if (1) begin : alu_unit_block
				reg _sv2v_0;
				wire clk;
				wire rst;
				localparam _mbase_issue = _bbase_4CF11_issue;
				localparam riscv_types_XLEN = 32;
				wire [141:0] alu_inputs;
				localparam _mbase_wb = _bbase_4CF11_wb;
				wire [riscv_types_XLEN:0] add_sub_result;
				wire add_sub_carry_in;
				reg [riscv_types_XLEN:0] adder_in1;
				reg [riscv_types_XLEN:0] adder_in2;
				wire [31:0] shift_result;
				reg [31:0] result;
				always @(*) begin
					if (_sv2v_0)
						;
					case (alu_inputs[9-:2])
						2'b00: adder_in1 = alu_inputs[141-:33] ^ alu_inputs[108-:33];
						2'b01: adder_in1 = alu_inputs[141-:33] | alu_inputs[108-:33];
						2'b10: adder_in1 = alu_inputs[141-:33] & alu_inputs[108-:33];
						default: adder_in1 = alu_inputs[141-:33];
					endcase
					case (alu_inputs[9-:2])
						2'b00, 2'b01, 2'b10: adder_in2 = 0;
						default: adder_in2 = alu_inputs[108-:33] ^ {33 {alu_inputs[2]}};
					endcase
				end
				assign {add_sub_result, add_sub_carry_in} = {adder_in1, 1'b1} + {adder_in2, alu_inputs[2]};
				barrel_shifter shifter(
					.shifter_input(alu_inputs[75-:32]),
					.shift_amount(alu_inputs[7-:5]),
					.arith(alu_inputs[1]),
					.lshift(alu_inputs[0]),
					.shifted_result(shift_result)
				);
				always @(*) begin
					if (_sv2v_0)
						;
					case (alu_inputs[11-:2])
						2'b00: result = alu_inputs[43-:32];
						2'b01: result = add_sub_result[31:0];
						2'b10: result = {31'b0000000000000000000000000000000, add_sub_result[riscv_types_XLEN]};
						default: result = shift_result;
					endcase
				end
				assign cva5_wrapper.cva5.unit_issue[_mbase_issue].ready = 1;
				assign cva5_wrapper.cva5.unit_wb[_mbase_wb].rd = result;
				wire [1:1] sv2v_tmp_B4F36;
				assign sv2v_tmp_B4F36 = cva5_wrapper.cva5.unit_issue[_mbase_issue].possible_issue;
				always @(*) cva5_wrapper.cva5.unit_wb[_mbase_wb].done = sv2v_tmp_B4F36;
				wire [3:1] sv2v_tmp_2F08F;
				assign sv2v_tmp_2F08F = cva5_wrapper.cva5.unit_issue[_mbase_issue].id;
				always @(*) cva5_wrapper.cva5.unit_wb[_mbase_wb].id = sv2v_tmp_2F08F;
				initial _sv2v_0 = 0;
			end
			assign alu_unit_block.clk = clk;
			assign alu_unit_block.rst = rst;
			assign alu_unit_block.alu_inputs = alu_inputs;
			localparam _bbase_5070F_l1_request = 2'd0;
			localparam _bbase_5070F_l1_response = 2'd0;
			localparam _bbase_5070F_exception = 2'd0;
			localparam _param_5070F_CONFIG = CONFIG;
			if (1) begin : load_store_unit_block
				reg _sv2v_0;
				localparam [1209:0] cva5_config_EXAMPLE_CONFIG = 1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002;
				localparam [1209:0] CONFIG = _param_5070F_CONFIG;
				wire clk;
				wire rst;
				localparam cva5_config_MAX_IDS = 8;
				localparam cva5_types_LOG2_MAX_IDS = 3;
				localparam riscv_types_ECODE_W = 5;
				wire [115:0] gc;
				localparam riscv_types_XLEN = 32;
				wire [98:0] ls_inputs;
				wire [1:0] issue_scaiev_meta;
				wire dcache_on;
				wire clear_reservation;
				wire tlb_on;
				localparam _mbase_l1_request = _bbase_5070F_l1_request;
				localparam _mbase_l1_response = _bbase_5070F_l1_response;
				wire sc_complete;
				wire sc_success;
				wire [39:0] wb_snoop;
				localparam cva5_config_RETIRE_PORTS = 2;
				wire [5:0] retire_ids;
				wire [0:1] retire_port_valid;
				localparam _mbase_exception = _bbase_5070F_exception;
				wire [2:0] load_store_status;
				wire [1:0] wb_scaiev_meta;
				wire tr_load_conflict_delay;
				localparam NUM_SUB_UNITS = (sv2v_cast_32_signed(CONFIG[355]) + sv2v_cast_32_signed(CONFIG[225])) + sv2v_cast_32_signed(CONFIG[711]);
				localparam NUM_SUB_UNITS_W = (NUM_SUB_UNITS == 1 ? 1 : $clog2(NUM_SUB_UNITS));
				localparam LOCAL_MEM_ID = 0;
				localparam BUS_ID = sv2v_cast_32_signed(CONFIG[355]);
				localparam DCACHE_ID = sv2v_cast_32_signed(CONFIG[355]) + sv2v_cast_32_signed(CONFIG[225]);
				localparam ATTRIBUTES_DEPTH = 2;
				localparam _param_F474D_BASE_ADDR = CONFIG[354-:32];
				localparam _param_F474D_UPPER_BOUND = CONFIG[322-:32];
				if (1) begin : dlocal_mem_addr_utils
					localparam [31:0] BASE_ADDR = _param_F474D_BASE_ADDR;
					localparam [31:0] UPPER_BOUND = _param_F474D_UPPER_BOUND;
					function [31:0] bit_range;
						input reg _sv2v_unused;
						reg [0:1] _sv2v_jump;
						begin
							_sv2v_jump = 2'b00;
							begin : sv2v_autoblock_24
								reg signed [31:0] i;
								begin : sv2v_autoblock_25
									reg signed [31:0] _sv2v_value_on_break;
									for (i = 0; i < 32; i = i + 1)
										if (_sv2v_jump < 2'b10) begin
											_sv2v_jump = 2'b00;
											if (BASE_ADDR[i] == UPPER_BOUND[i]) begin
												bit_range = 32 - i;
												_sv2v_jump = 2'b11;
											end
											_sv2v_value_on_break = i;
										end
									if (!(_sv2v_jump < 2'b10))
										i = _sv2v_value_on_break;
									if (_sv2v_jump != 2'b11)
										_sv2v_jump = 2'b00;
								end
							end
							if (_sv2v_jump == 2'b00) begin
								bit_range = 0;
								_sv2v_jump = 2'b11;
							end
						end
					endfunction
					localparam [31:0] BIT_RANGE = bit_range(0);
					function address_range_check;
						input reg [31:0] addr;
						reg range_match;
						reg signed [31:0] i;
						begin
							range_match = 1;
							for (i = 32 - BIT_RANGE; i <= 31; i = i + 1)
								if (addr[i] != BASE_ADDR[i])
									range_match = 0;
							address_range_check = range_match;
						end
					endfunction
				end
				localparam _param_A7E71_BASE_ADDR = CONFIG[224-:32];
				localparam _param_A7E71_UPPER_BOUND = CONFIG[192-:32];
				if (1) begin : dpbus_addr_utils
					localparam [31:0] BASE_ADDR = _param_A7E71_BASE_ADDR;
					localparam [31:0] UPPER_BOUND = _param_A7E71_UPPER_BOUND;
					function [31:0] bit_range;
						input reg _sv2v_unused;
						reg [0:1] _sv2v_jump;
						begin
							_sv2v_jump = 2'b00;
							begin : sv2v_autoblock_26
								reg signed [31:0] i;
								begin : sv2v_autoblock_27
									reg signed [31:0] _sv2v_value_on_break;
									for (i = 0; i < 32; i = i + 1)
										if (_sv2v_jump < 2'b10) begin
											_sv2v_jump = 2'b00;
											if (BASE_ADDR[i] == UPPER_BOUND[i]) begin
												bit_range = 32 - i;
												_sv2v_jump = 2'b11;
											end
											_sv2v_value_on_break = i;
										end
									if (!(_sv2v_jump < 2'b10))
										i = _sv2v_value_on_break;
									if (_sv2v_jump != 2'b11)
										_sv2v_jump = 2'b00;
								end
							end
							if (_sv2v_jump == 2'b00) begin
								bit_range = 0;
								_sv2v_jump = 2'b11;
							end
						end
					endfunction
					localparam [31:0] BIT_RANGE = bit_range(0);
					function address_range_check;
						input reg [31:0] addr;
						reg range_match;
						reg signed [31:0] i;
						begin
							range_match = 1;
							for (i = 32 - BIT_RANGE; i <= 31; i = i + 1)
								if (addr[i] != BASE_ADDR[i])
									range_match = 0;
							address_range_check = range_match;
						end
					endfunction
				end
				localparam _param_CFFEA_BASE_ADDR = CONFIG[548-:32];
				localparam _param_CFFEA_UPPER_BOUND = CONFIG[516-:32];
				if (1) begin : dcache_addr_utils
					localparam [31:0] BASE_ADDR = _param_CFFEA_BASE_ADDR;
					localparam [31:0] UPPER_BOUND = _param_CFFEA_UPPER_BOUND;
					function [31:0] bit_range;
						input reg _sv2v_unused;
						reg [0:1] _sv2v_jump;
						begin
							_sv2v_jump = 2'b00;
							begin : sv2v_autoblock_28
								reg signed [31:0] i;
								begin : sv2v_autoblock_29
									reg signed [31:0] _sv2v_value_on_break;
									for (i = 0; i < 32; i = i + 1)
										if (_sv2v_jump < 2'b10) begin
											_sv2v_jump = 2'b00;
											if (BASE_ADDR[i] == UPPER_BOUND[i]) begin
												bit_range = 32 - i;
												_sv2v_jump = 2'b11;
											end
											_sv2v_value_on_break = i;
										end
									if (!(_sv2v_jump < 2'b10))
										i = _sv2v_value_on_break;
									if (_sv2v_jump != 2'b11)
										_sv2v_jump = 2'b00;
								end
							end
							if (_sv2v_jump == 2'b00) begin
								bit_range = 0;
								_sv2v_jump = 2'b11;
							end
						end
					endfunction
					localparam [31:0] BIT_RANGE = bit_range(0);
					function address_range_check;
						input reg [31:0] addr;
						reg range_match;
						reg signed [31:0] i;
						begin
							range_match = 1;
							for (i = 32 - BIT_RANGE; i <= 31; i = i + 1)
								if (addr[i] != BASE_ADDR[i])
									range_match = 0;
							address_range_check = range_match;
						end
					endfunction
				end
				genvar _arr_53147;
				for (_arr_53147 = NUM_SUB_UNITS - 1; _arr_53147 >= 0; _arr_53147 = _arr_53147 - 1) begin : sub_unit
					wire new_request;
					wire [31:0] addr;
					wire re;
					wire we;
					wire [3:0] be;
					wire [31:0] data_in;
					reg [31:0] data_out;
					reg data_valid;
					reg ready;
				end
				localparam _param_657E3_BASE_ADDR = CONFIG[612-:32];
				localparam _param_657E3_UPPER_BOUND = CONFIG[580-:32];
				if (1) begin : uncacheable_utils
					localparam [31:0] BASE_ADDR = _param_657E3_BASE_ADDR;
					localparam [31:0] UPPER_BOUND = _param_657E3_UPPER_BOUND;
					function [31:0] bit_range;
						input reg _sv2v_unused;
						reg [0:1] _sv2v_jump;
						begin
							_sv2v_jump = 2'b00;
							begin : sv2v_autoblock_30
								reg signed [31:0] i;
								begin : sv2v_autoblock_31
									reg signed [31:0] _sv2v_value_on_break;
									for (i = 0; i < 32; i = i + 1)
										if (_sv2v_jump < 2'b10) begin
											_sv2v_jump = 2'b00;
											if (BASE_ADDR[i] == UPPER_BOUND[i]) begin
												bit_range = 32 - i;
												_sv2v_jump = 2'b11;
											end
											_sv2v_value_on_break = i;
										end
									if (!(_sv2v_jump < 2'b10))
										i = _sv2v_value_on_break;
									if (_sv2v_jump != 2'b11)
										_sv2v_jump = 2'b00;
								end
							end
							if (_sv2v_jump == 2'b00) begin
								bit_range = 0;
								_sv2v_jump = 2'b11;
							end
						end
					endfunction
					localparam [31:0] BIT_RANGE = bit_range(0);
					function address_range_check;
						input reg [31:0] addr;
						reg range_match;
						reg signed [31:0] i;
						begin
							range_match = 1;
							for (i = 32 - BIT_RANGE; i <= 31; i = i + 1)
								if (addr[i] != BASE_ADDR[i])
									range_match = 0;
							address_range_check = range_match;
						end
					endfunction
				end
				wire [NUM_SUB_UNITS - 1:0] sub_unit_address_match;
				wire [77:0] shared_inputs;
				wire [31:0] unit_data_array [NUM_SUB_UNITS - 1:0];
				wire [NUM_SUB_UNITS - 1:0] unit_ready;
				wire [NUM_SUB_UNITS - 1:0] unit_data_valid;
				reg [NUM_SUB_UNITS - 1:0] last_unit;
				wire [NUM_SUB_UNITS - 1:0] current_unit;
				wire units_ready;
				wire unit_switch;
				reg unit_switch_in_progress;
				wire unit_switch_hold;
				wire sub_unit_issue;
				wire load_complete;
				wire [31:0] virtual_address;
				wire [31:0] unit_muxed_load_data;
				wire [31:0] aligned_load_data;
				reg [31:0] final_load_data;
				reg unaligned_addr;
				reg load_exception_complete;
				reg fence_hold;
				wire [(11 + NUM_SUB_UNITS_W) - 1:0] mem_attr;
				wire [(11 + NUM_SUB_UNITS_W) - 1:0] wb_attr;
				reg [3:0] be;
				localparam _param_145E5_DATA_WIDTH = 1 * (11 + NUM_SUB_UNITS_W);
				if (1) begin : load_attributes
					localparam DATA_WIDTH = _param_145E5_DATA_WIDTH;
					wire push;
					wire pop;
					wire [DATA_WIDTH - 1:0] data_in;
					wire [DATA_WIDTH - 1:0] data_out;
					wire valid;
					wire full;
					wire potential_push;
				end
				if (1) begin : lsq
					localparam cva5_config_MAX_IDS = 8;
					localparam cva5_types_LOG2_MAX_IDS = 3;
					wire [86:0] data_in;
					wire potential_push;
					wire push;
					wire full;
					wire [77:0] data_out;
					wire valid;
					wire pop;
					wire sq_empty;
					wire empty;
					wire no_released_stores_pending;
				end
				wire tr_possible_load_conflict_delay;
				if (CONFIG[1209]) begin : gen_ls_exceptions
					wire new_exception;
					always @(*) begin
						if (_sv2v_0)
							;
						case (ls_inputs[22-:3])
							3'b001, 3'b101: unaligned_addr = virtual_address[0];
							3'b010: unaligned_addr = |virtual_address[1:0];
							default: unaligned_addr = 0;
						endcase
					end
					assign new_exception = (unaligned_addr & cva5_wrapper.cva5.ls_unit_issue.new_request) & ~ls_inputs[16];
					always @(posedge clk)
						if (rst)
							cva5_wrapper.cva5.exception[_mbase_exception].valid <= 0;
						else
							cva5_wrapper.cva5.exception[_mbase_exception].valid <= (cva5_wrapper.cva5.exception[_mbase_exception].valid & ~cva5_wrapper.cva5.exception[_mbase_exception].ack) | new_exception;
					always @(posedge clk)
						if (new_exception & ~cva5_wrapper.cva5.exception[_mbase_exception].valid) begin
							begin : sv2v_autoblock_32
								reg [4:0] sv2v_tmp_cast;
								reg [4:0] sv2v_tmp_cast_1;
								sv2v_tmp_cast = 5'd6;
								sv2v_tmp_cast_1 = 5'd4;
								cva5_wrapper.cva5.exception[_mbase_exception].code <= (ls_inputs[18] ? sv2v_tmp_cast : sv2v_tmp_cast_1);
							end
							cva5_wrapper.cva5.exception[_mbase_exception].tval <= virtual_address;
							cva5_wrapper.cva5.exception[_mbase_exception].id <= cva5_wrapper.cva5.ls_unit_issue.id;
						end
					always @(posedge clk)
						if (rst)
							load_exception_complete <= 0;
						else begin : sv2v_autoblock_33
							reg [4:0] sv2v_tmp_cast;
							sv2v_tmp_cast = 5'd4;
							load_exception_complete <= (cva5_wrapper.cva5.exception[_mbase_exception].valid & cva5_wrapper.cva5.exception[_mbase_exception].ack) & (cva5_wrapper.cva5.exception[_mbase_exception].code == sv2v_tmp_cast);
						end
				end
				assign load_store_status = {lsq.sq_empty, lsq.no_released_stores_pending, (lsq.empty & ~load_attributes.valid) & units_ready};
				assign virtual_address = ls_inputs[98-:32] + sv2v_cast_32_signed($signed(ls_inputs[34-:12]));
				assign cva5_wrapper.cva5.dtlb.virtual_address = virtual_address;
				assign cva5_wrapper.cva5.dtlb.new_request = tlb_on & cva5_wrapper.cva5.ls_unit_issue.new_request;
				assign cva5_wrapper.cva5.dtlb.execute = 0;
				assign cva5_wrapper.cva5.dtlb.rnw = ls_inputs[19] & ~ls_inputs[18];
				always @(*) begin
					if (_sv2v_0)
						;
					be = 0;
					case (ls_inputs[21:20])
						3'b000[1:0]: be[virtual_address[1:0]] = 1;
						3'b001[1:0]: begin
							be[virtual_address[1:0]] = 1;
							be[{virtual_address[1], 1'b1}] = 1;
						end
						default: be = 1'sb1;
					endcase
				end
				assign lsq.data_in = {sv2v_cast_32((tlb_on ? cva5_wrapper.cva5.dtlb.physical_address : virtual_address)), ls_inputs[19], ls_inputs[18], ls_inputs[17], be, sv2v_cast_3(ls_inputs[22-:3]), sv2v_cast_32(ls_inputs[66-:32]), cva5_wrapper.cva5.ls_unit_issue.id, issue_scaiev_meta, ls_inputs[15], sv2v_cast_7(ls_inputs[14-:7])};
				assign lsq.potential_push = cva5_wrapper.cva5.ls_unit_issue.possible_issue;
				assign lsq.push = ((cva5_wrapper.cva5.ls_unit_issue.new_request & ~unaligned_addr) & (~tlb_on | cva5_wrapper.cva5.dtlb.done)) & ~ls_inputs[16];
				localparam _param_24ADB_CONFIG = CONFIG;
				if (1) begin : lsq_block
					localparam [1209:0] cva5_config_EXAMPLE_CONFIG = 1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002;
					localparam [1209:0] CONFIG = _param_24ADB_CONFIG;
					wire clk;
					wire rst;
					localparam cva5_config_MAX_IDS = 8;
					localparam cva5_types_LOG2_MAX_IDS = 3;
					localparam riscv_types_ECODE_W = 5;
					wire [115:0] gc;
					wire [39:0] wb_snoop;
					localparam cva5_config_RETIRE_PORTS = 2;
					wire [5:0] retire_ids;
					wire [0:1] retire_port_valid;
					wire tr_possible_load_conflict_delay;
					wire [3:0] addr_hash;
					wire [CONFIG[1034-:32] - 1:0] potential_store_conflicts;
					wire [71:0] sq_entry;
					wire store_conflict;
					wire load_selected;
					wire [(40 + CONFIG[1034-:32]) - 1:0] lq_data_in;
					wire [(40 + CONFIG[1034-:32]) - 1:0] lq_data_out;
					localparam _param_275FD_DATA_WIDTH = 1 * (40 + CONFIG[1034-:32]);
					if (1) begin : lq
						localparam DATA_WIDTH = _param_275FD_DATA_WIDTH;
						wire push;
						wire pop;
						wire [DATA_WIDTH - 1:0] data_in;
						wire [DATA_WIDTH - 1:0] data_out;
						wire valid;
						wire full;
						wire potential_push;
					end
					if (1) begin : sq
						localparam cva5_config_MAX_IDS = 8;
						localparam cva5_types_LOG2_MAX_IDS = 3;
						wire [86:0] data_in;
						wire push;
						reg full;
						wire [71:0] data_out;
						wire valid;
						wire pop;
						wire empty;
						wire no_released_stores_pending;
					end
					assign cva5_wrapper.cva5.load_store_unit_block.lsq.full = cva5_wrapper.cva5.load_store_unit_block.lsq.data_in[53] & sq.full;
					addr_hash lsq_addr_hash(
						.clk(clk),
						.rst(rst | gc[108]),
						.addr(cva5_wrapper.cva5.load_store_unit_block.lsq.data_in[86-:32]),
						.addr_hash(addr_hash)
					);
					localparam _param_9162D_DATA_WIDTH = 1 * (40 + CONFIG[1034-:32]);
					localparam _param_9162D_FIFO_DEPTH = cva5_config_MAX_IDS;
					if (1) begin : load_queue_fifo
						localparam DATA_WIDTH = _param_9162D_DATA_WIDTH;
						localparam FIFO_DEPTH = _param_9162D_FIFO_DEPTH;
						wire clk;
						wire rst;
						localparam LOG2_FIFO_DEPTH = 3;
						if (1) begin : gen_width_3_plus
							wire [DATA_WIDTH - 1:0] lut_ram [0:7];
							wire [2:0] write_index;
							wire [2:0] read_index;
							reg [LOG2_FIFO_DEPTH:0] inflight_count;
							always @(posedge clk)
								if (rst)
									inflight_count <= 0;
								else
									inflight_count <= (inflight_count + sv2v_cast_4(cva5_wrapper.cva5.load_store_unit_block.lsq_block.lq.pop)) - sv2v_cast_4(cva5_wrapper.cva5.load_store_unit_block.lsq_block.lq.push);
							assign cva5_wrapper.cva5.load_store_unit_block.lsq_block.lq.valid = inflight_count[LOG2_FIFO_DEPTH];
							assign cva5_wrapper.cva5.load_store_unit_block.lsq_block.lq.full = cva5_wrapper.cva5.load_store_unit_block.lsq_block.lq.valid & ~|inflight_count[2:0];
							lfsr #(
								.WIDTH(LOG2_FIFO_DEPTH),
								.NEEDS_RESET(1)
							) lfsr_read_index(
								.clk(clk),
								.rst(rst),
								.en(cva5_wrapper.cva5.load_store_unit_block.lsq_block.lq.pop),
								.value(read_index)
							);
							lfsr #(
								.WIDTH(LOG2_FIFO_DEPTH),
								.NEEDS_RESET(1)
							) lfsr_write_index(
								.clk(clk),
								.rst(rst),
								.en(cva5_wrapper.cva5.load_store_unit_block.lsq_block.lq.push),
								.value(write_index)
							);
							lutram_1w_1r #(
								.WIDTH(DATA_WIDTH),
								.DEPTH(FIFO_DEPTH)
							) write_port(
								.clk(clk),
								.waddr(write_index),
								.raddr(read_index),
								.ram_write(cva5_wrapper.cva5.load_store_unit_block.lsq_block.lq.potential_push),
								.new_ram_data(cva5_wrapper.cva5.load_store_unit_block.lsq_block.lq.data_in),
								.ram_data_out(cva5_wrapper.cva5.load_store_unit_block.lsq_block.lq.data_out)
							);
						end
					end
					assign load_queue_fifo.clk = clk;
					assign load_queue_fifo.rst = rst;
					assign lq.push = cva5_wrapper.cva5.load_store_unit_block.lsq.push & cva5_wrapper.cva5.load_store_unit_block.lsq.data_in[54];
					assign lq.potential_push = cva5_wrapper.cva5.load_store_unit_block.lsq.potential_push;
					assign lq.pop = cva5_wrapper.cva5.load_store_unit_block.lsq.pop & load_selected;
					wire sv_load_order_irrelevant = cva5_wrapper.cva5.load_store_unit_block.lsq.data_in[52];
					function automatic [2:0] sv2v_cast_34AB7;
						input reg [2:0] inp;
						sv2v_cast_34AB7 = inp;
					endfunction
					assign lq_data_in = {cva5_wrapper.cva5.load_store_unit_block.lsq.data_in[86-:32], cva5_wrapper.cva5.load_store_unit_block.lsq.data_in[47-:3], sv2v_cast_34AB7(cva5_wrapper.cva5.load_store_unit_block.lsq.data_in[12-:3]), cva5_wrapper.cva5.load_store_unit_block.lsq.data_in[9-:2], potential_store_conflicts};
					assign lq.data_in = lq_data_in;
					assign lq_data_out = lq.data_out;
					assign sq.push = cva5_wrapper.cva5.load_store_unit_block.lsq.push & cva5_wrapper.cva5.load_store_unit_block.lsq.data_in[53];
					assign sq.pop = cva5_wrapper.cva5.load_store_unit_block.lsq.pop & ~load_selected;
					assign sq.data_in = cva5_wrapper.cva5.load_store_unit_block.lsq.data_in;
					localparam _param_2108C_CONFIG = CONFIG;
					if (1) begin : sq_block
						reg _sv2v_0;
						localparam [1209:0] cva5_config_EXAMPLE_CONFIG = 1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002;
						localparam [1209:0] CONFIG = _param_2108C_CONFIG;
						wire clk;
						wire rst;
						localparam cva5_config_MAX_IDS = 8;
						localparam cva5_types_LOG2_MAX_IDS = 3;
						localparam riscv_types_ECODE_W = 5;
						wire [115:0] gc;
						wire lq_push;
						wire lq_pop;
						wire lq_push_no_conflict;
						wire [3:0] addr_hash;
						reg [CONFIG[1034-:32] - 1:0] potential_store_conflicts;
						wire [CONFIG[1034-:32] - 1:0] prev_store_conflicts;
						wire store_conflict;
						wire [39:0] wb_snoop;
						localparam cva5_config_RETIRE_PORTS = 2;
						wire [5:0] retire_ids;
						wire [0:1] retire_port_valid;
						localparam LOG2_SQ_DEPTH = $clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[1034-:32]);
						reg [39:0] wb_snoop_r;
						reg [CONFIG[1034-:32] - 1:0] valid;
						wire [CONFIG[1034-:32] - 1:0] valid_next;
						reg [(CONFIG[1034-:32] * 4) - 1:0] hashes;
						reg [CONFIG[1034-:32] - 1:0] released;
						reg [(CONFIG[1034-:32] * 7) - 1:0] id_needed;
						reg [CONFIG[1034-:32] - 1:0] forward_complete;
						reg [(CONFIG[1034-:32] * 4) - 1:0] load_check_count;
						reg [31:0] store_data_from_wb [0:CONFIG[1034-:32] - 1];
						wire [71:0] sq_entry_in;
						reg [71:0] sq_entry [0:CONFIG[1034-:32] - 1];
						reg [(CONFIG[1034-:32] * cva5_types_LOG2_MAX_IDS) - 1:0] ids;
						reg [LOG2_SQ_DEPTH - 1:0] sq_ids [0:7];
						reg [(CONFIG[1034-:32] * 4) - 1:0] load_check_count_next;
						reg [LOG2_SQ_DEPTH - 1:0] sq_index;
						wire [LOG2_SQ_DEPTH - 1:0] sq_index_next;
						reg [LOG2_SQ_DEPTH - 1:0] sq_oldest;
						wire [CONFIG[1034-:32] - 1:0] new_request_one_hot;
						wire [CONFIG[1034-:32] - 1:0] new_request_released_one_hot;
						wire [CONFIG[1034-:32] - 1:0] issued_one_hot;
						wire [CONFIG[1034-:32] - 1:0] wb_id_match;
						function automatic [LOG2_SQ_DEPTH - 1:0] sv2v_cast_0D7E1;
							input reg [LOG2_SQ_DEPTH - 1:0] inp;
							sv2v_cast_0D7E1 = inp;
						endfunction
						assign sq_index_next = sq_index + sv2v_cast_0D7E1(cva5_wrapper.cva5.load_store_unit_block.lsq_block.sq.push);
						always @(posedge clk)
							if (rst)
								sq_index <= 0;
							else
								sq_index <= sq_index_next;
						always @(posedge clk)
							if (rst)
								sq_oldest <= 0;
							else begin : sv2v_autoblock_34
								reg [LOG2_SQ_DEPTH - 1:0] sv2v_tmp_cast;
								sv2v_tmp_cast = cva5_wrapper.cva5.load_store_unit_block.lsq_block.sq.pop;
								sq_oldest <= sq_oldest + sv2v_tmp_cast;
							end
						function automatic [CONFIG[1034-:32] - 1:0] sv2v_cast_C3AAE;
							input reg [CONFIG[1034-:32] - 1:0] inp;
							sv2v_cast_C3AAE = inp;
						endfunction
						assign new_request_one_hot = sv2v_cast_C3AAE(cva5_wrapper.cva5.load_store_unit_block.lsq_block.sq.push) << sq_index;
						assign new_request_released_one_hot = new_request_one_hot & {CONFIG[1034-:32] {cva5_wrapper.cva5.load_store_unit_block.lsq_block.sq.data_in[9]}};
						assign issued_one_hot = sv2v_cast_C3AAE(cva5_wrapper.cva5.load_store_unit_block.lsq_block.sq.pop) << sq_oldest;
						assign valid_next = (valid | new_request_one_hot) & ~issued_one_hot;
						always @(posedge clk)
							if (rst)
								valid <= 1'sb0;
							else
								valid <= valid_next;
						assign cva5_wrapper.cva5.load_store_unit_block.lsq_block.sq.empty = ~|valid;
						always @(posedge clk)
							if (rst)
								cva5_wrapper.cva5.load_store_unit_block.lsq_block.sq.full <= 0;
							else
								cva5_wrapper.cva5.load_store_unit_block.lsq_block.sq.full <= valid_next[sq_index_next] | (|load_check_count_next[0 + (sq_index_next * 4)+:4]);
						assign sq_entry_in = {cva5_wrapper.cva5.load_store_unit_block.lsq_block.sq.data_in[86-:32], cva5_wrapper.cva5.load_store_unit_block.lsq_block.sq.data_in[51-:4], cva5_wrapper.cva5.load_store_unit_block.lsq_block.sq.data_in[47-:3], cva5_wrapper.cva5.load_store_unit_block.lsq_block.sq.data_in[7], cva5_wrapper.cva5.load_store_unit_block.lsq_block.sq.data_in[44-:32]};
						always @(posedge clk)
							if (cva5_wrapper.cva5.load_store_unit_block.lsq_block.sq.push)
								sq_entry[sq_index] <= sq_entry_in;
						always @(posedge clk)
							if (cva5_wrapper.cva5.load_store_unit_block.lsq_block.sq.push)
								hashes[sq_index * 4+:4] <= addr_hash;
						reg [CONFIG[1034-:32] - 1:0] new_load_waiting;
						reg [CONFIG[1034-:32] - 1:0] waiting_load_completed;
						always @(*) begin
							if (_sv2v_0)
								;
							begin : sv2v_autoblock_35
								reg signed [31:0] i;
								for (i = 0; i < CONFIG[1034-:32]; i = i + 1)
									begin
										potential_store_conflicts[i] = ((valid[i] & ~issued_one_hot[i]) & (addr_hash == hashes[i * 4+:4])) & ~lq_push_no_conflict;
										new_load_waiting[i] = potential_store_conflicts[i] & lq_push;
										waiting_load_completed[i] = prev_store_conflicts[i] & lq_pop;
										load_check_count_next[0 + (i * 4)+:4] = (load_check_count[0 + (i * 4)+:4] + sv2v_cast_3(new_load_waiting[i])) - sv2v_cast_3(waiting_load_completed[i]);
									end
							end
						end
						always @(posedge clk)
							if (rst)
								load_check_count <= 1'sb0;
							else
								load_check_count <= load_check_count_next;
						assign store_conflict = |(prev_store_conflicts & valid);
						always @(posedge clk)
							if (cva5_wrapper.cva5.load_store_unit_block.lsq_block.sq.push)
								ids[sq_index * cva5_types_LOG2_MAX_IDS+:cva5_types_LOG2_MAX_IDS] <= cva5_wrapper.cva5.load_store_unit_block.lsq_block.sq.data_in[12-:3];
						always @(posedge clk)
							if (cva5_wrapper.cva5.load_store_unit_block.lsq_block.sq.push)
								sq_ids[cva5_wrapper.cva5.load_store_unit_block.lsq_block.sq.data_in[12-:3]] <= sq_index;
						always @(posedge clk)
							if (cva5_wrapper.cva5.load_store_unit_block.lsq_block.sq.push)
								id_needed[sq_index * 7+:7] <= cva5_wrapper.cva5.load_store_unit_block.lsq_block.sq.data_in[6-:7];
						reg [CONFIG[1034-:32] - 1:0] newly_released;
						reg [LOG2_SQ_DEPTH - 1:0] store_released_index [0:1];
						reg store_released [0:1];
						always @(*) begin
							if (_sv2v_0)
								;
							newly_released = 1'sb0;
							begin : sv2v_autoblock_36
								reg signed [31:0] i;
								for (i = 0; i < cva5_config_RETIRE_PORTS; i = i + 1)
									begin
										store_released_index[i] = sq_ids[retire_ids[(1 - i) * cva5_types_LOG2_MAX_IDS+:cva5_types_LOG2_MAX_IDS]];
										store_released[i] = {1'b1, ids[store_released_index[i] * cva5_types_LOG2_MAX_IDS+:cva5_types_LOG2_MAX_IDS]} == {retire_port_valid[i], retire_ids[(1 - i) * cva5_types_LOG2_MAX_IDS+:cva5_types_LOG2_MAX_IDS]};
										begin : sv2v_autoblock_37
											reg [CONFIG[1034-:32] - 1:0] sv2v_tmp_cast_1;
											sv2v_tmp_cast_1 = store_released[i];
											newly_released = newly_released | (sv2v_tmp_cast_1 << store_released_index[i]);
										end
									end
							end
						end
						always @(posedge clk) released <= ((released | newly_released) & ~new_request_one_hot) | new_request_released_one_hot;
						assign cva5_wrapper.cva5.load_store_unit_block.lsq_block.sq.no_released_stores_pending = ~|(valid & released);
						reg [CONFIG[1034-:32] - 1:0] store_snoop_pending;
						always @(posedge clk) begin
							if (wb_snoop_r[32] && !wb_snoop_r[39]) begin : sv2v_autoblock_38
								reg signed [31:0] i;
								for (i = 0; i < CONFIG[1034-:32]; i = i + 1)
									if (wb_snoop_r[38-:6] == id_needed[(i * 7) + 5-:6])
										store_snoop_pending[i] <= 0;
							end
							if (cva5_wrapper.cva5.load_store_unit_block.lsq_block.sq.push)
								store_snoop_pending[sq_index] <= cva5_wrapper.cva5.load_store_unit_block.lsq_block.sq.data_in[7] && !cva5_wrapper.cva5.load_store_unit_block.lsq_block.sq.data_in[6];
						end
						always @(posedge clk) wb_snoop_r <= wb_snoop;
						reg [CONFIG[1034-:32] - 1:0] applying_wb_snoop;
						always @(*) begin
							if (_sv2v_0)
								;
							begin : sv2v_autoblock_39
								reg signed [31:0] i;
								for (i = 0; i < CONFIG[1034-:32]; i = i + 1)
									begin
										applying_wb_snoop[i] = 1'b0;
										if ((((!(released[i] && id_needed[(i * 7) + 6]) && !forward_complete[i]) && wb_snoop_r[32]) && (wb_snoop_r[39] == id_needed[(i * 7) + 6])) && (wb_snoop_r[39] ? wb_snoop_r[38-:3] == id_needed[(i * 7) + 5-:3] : wb_snoop_r[38-:6] == id_needed[(i * 7) + 5-:6]))
											applying_wb_snoop[i] = 1'b1;
									end
							end
						end
						always @(posedge clk) begin : sv2v_autoblock_40
							reg signed [31:0] i;
							for (i = 0; i < CONFIG[1034-:32]; i = i + 1)
								if (gc[115])
									forward_complete[i] <= 1'b1;
								else if (cva5_wrapper.cva5.load_store_unit_block.lsq_block.sq.push && (i == sq_index))
									forward_complete[i] <= 1'b0;
								else if (applying_wb_snoop[i])
									forward_complete[i] <= 1'b1;
						end
						always @(posedge clk) begin : sv2v_autoblock_41
							reg signed [31:0] i;
							for (i = 0; i < CONFIG[1034-:32]; i = i + 1)
								if (gc[115])
									store_data_from_wb[i] <= 1'sb0;
								else if (applying_wb_snoop[i])
									store_data_from_wb[i] <= wb_snoop_r[31-:32];
						end
						reg [31:0] data_for_alignment;
						reg [31:0] sq_data;
						wire [71:0] output_entry;
						assign output_entry = sq_entry[sq_oldest];
						always @(*) begin
							if (_sv2v_0)
								;
							data_for_alignment = (output_entry[32] ? store_data_from_wb[sq_oldest] : output_entry[31-:32]);
							sq_data[7:0] = data_for_alignment[7:0];
							sq_data[15:8] = (output_entry[41:40] == 2'b01 ? data_for_alignment[7:0] : data_for_alignment[15:8]);
							sq_data[23:16] = (output_entry[41:40] == 2'b10 ? data_for_alignment[7:0] : data_for_alignment[23:16]);
							case (output_entry[41:40])
								2'b10: sq_data[31:24] = data_for_alignment[15:8];
								2'b11: sq_data[31:24] = data_for_alignment[7:0];
								default: sq_data[31:24] = data_for_alignment[31:24];
							endcase
						end
						assign cva5_wrapper.cva5.load_store_unit_block.lsq_block.sq.valid = (valid[sq_oldest] & released[sq_oldest]) & ~store_snoop_pending[sq_oldest];
						assign cva5_wrapper.cva5.load_store_unit_block.lsq_block.sq.data_out = {sv2v_cast_32(output_entry[71-:32]), sv2v_cast_4(output_entry[39-:4]), sv2v_cast_3(output_entry[35-:3]), output_entry[32], sq_data};
						initial _sv2v_0 = 0;
					end
					assign sq_block.clk = clk;
					assign sq_block.rst = rst | gc[108];
					assign sq_block.gc = gc;
					assign sq_block.lq_push = lq.push;
					assign sq_block.lq_pop = lq.pop;
					assign sq_block.lq_push_no_conflict = sv_load_order_irrelevant;
					assign sq_block.addr_hash = addr_hash;
					assign potential_store_conflicts = sq_block.potential_store_conflicts;
					assign sq_block.prev_store_conflicts = lq_data_out[CONFIG[1034-:32] - 1-:CONFIG[1034-:32]];
					assign store_conflict = sq_block.store_conflict;
					assign sq_block.wb_snoop = wb_snoop;
					assign sq_block.retire_ids = retire_ids;
					assign sq_block.retire_port_valid = retire_port_valid;
					assign load_selected = lq.valid & ~store_conflict;
					assign cva5_wrapper.cva5.load_store_unit_block.lsq.valid = load_selected | sq.valid;
					function automatic [2:0] sv2v_cast_120EB;
						input reg [2:0] inp;
						sv2v_cast_120EB = inp;
					endfunction
					assign cva5_wrapper.cva5.load_store_unit_block.lsq.data_out = {sv2v_cast_32((load_selected ? lq_data_out[35 + (cva5_types_LOG2_MAX_IDS + (CONFIG[1034-:32] + 1))-:((38 + (CONFIG[1034-:32] + 1)) >= (8 + (CONFIG[1034-:32] + 0)) ? ((35 + (cva5_types_LOG2_MAX_IDS + (CONFIG[1034-:32] + 1))) - (3 + (cva5_types_LOG2_MAX_IDS + (2 + (CONFIG[1034-:32] + 0))))) + 1 : ((3 + (cva5_types_LOG2_MAX_IDS + (2 + (CONFIG[1034-:32] + 0)))) - (35 + (cva5_types_LOG2_MAX_IDS + (CONFIG[1034-:32] + 1)))) + 1)] : sq.data_out[71-:32])), load_selected, ~load_selected, sv2v_cast_4((load_selected ? {4 {1'sb0}} : sq.data_out[39-:4])), sv2v_cast_3((load_selected ? lq_data_out[3 + (cva5_types_LOG2_MAX_IDS + (CONFIG[1034-:32] + 1))-:((6 + (CONFIG[1034-:32] + 1)) >= (5 + (CONFIG[1034-:32] + 0)) ? ((3 + (cva5_types_LOG2_MAX_IDS + (CONFIG[1034-:32] + 1))) - (cva5_types_LOG2_MAX_IDS + (2 + (CONFIG[1034-:32] + 0)))) + 1 : ((cva5_types_LOG2_MAX_IDS + (2 + (CONFIG[1034-:32] + 0))) - (3 + (cva5_types_LOG2_MAX_IDS + (CONFIG[1034-:32] + 1)))) + 1)] : sq.data_out[35-:3])), sv2v_cast_32(sq.data_out[31-:32]), sv2v_cast_120EB(lq_data_out[cva5_types_LOG2_MAX_IDS + (CONFIG[1034-:32] + 1)-:((cva5_types_LOG2_MAX_IDS + (CONFIG[1034-:32] + 1)) >= (2 + (CONFIG[1034-:32] + 0)) ? ((cva5_types_LOG2_MAX_IDS + (CONFIG[1034-:32] + 1)) - (2 + (CONFIG[1034-:32] + 0))) + 1 : ((2 + (CONFIG[1034-:32] + 0)) - (cva5_types_LOG2_MAX_IDS + (CONFIG[1034-:32] + 1))) + 1)]), sv2v_cast_2(lq_data_out[CONFIG[1034-:32] + 1-:((CONFIG[1034-:32] + 1) >= (CONFIG[1034-:32] + 0) ? ((CONFIG[1034-:32] + 1) - (CONFIG[1034-:32] + 0)) + 1 : ((CONFIG[1034-:32] + 0) - (CONFIG[1034-:32] + 1)) + 1)])};
					assign cva5_wrapper.cva5.load_store_unit_block.lsq.sq_empty = sq.empty;
					assign cva5_wrapper.cva5.load_store_unit_block.lsq.no_released_stores_pending = sq.no_released_stores_pending;
					assign cva5_wrapper.cva5.load_store_unit_block.lsq.empty = ~lq.valid & sq.empty;
					localparam cva5_config_ENABLE_TRACE_INTERFACE = 1;
					if (cva5_config_ENABLE_TRACE_INTERFACE) begin : gen_lsq_trace
						assign tr_possible_load_conflict_delay = lq.valid & (store_conflict | (sq.full & sq.valid));
					end
				end
				assign lsq_block.clk = clk;
				assign lsq_block.rst = rst;
				assign lsq_block.gc = gc;
				assign lsq_block.wb_snoop = wb_snoop;
				assign lsq_block.retire_ids = retire_ids;
				assign lsq_block.retire_port_valid = retire_port_valid;
				assign tr_possible_load_conflict_delay = lsq_block.tr_possible_load_conflict_delay;
				assign shared_inputs = lsq.data_out;
				assign lsq.pop = sub_unit_issue;
				assign current_unit = sub_unit_address_match;
				always @(posedge clk)
					if (load_attributes.push)
						last_unit <= sub_unit_address_match;
				assign unit_switch = (current_unit != last_unit) & load_attributes.valid;
				always @(posedge clk) unit_switch_in_progress <= (unit_switch_in_progress | unit_switch) & ~load_attributes.valid;
				assign unit_switch_hold = unit_switch | unit_switch_in_progress;
				assign units_ready = &unit_ready & ~unit_switch_hold;
				assign load_complete = |unit_data_valid;
				assign cva5_wrapper.cva5.ls_unit_issue.ready = (((~tlb_on | cva5_wrapper.cva5.dtlb.ready) & ~lsq.full) & ~fence_hold) & ~cva5_wrapper.cva5.exception[_mbase_exception].valid;
				assign sub_unit_issue = lsq.valid & units_ready;
				always @(posedge clk)
					if (rst)
						fence_hold <= 0;
					else
						fence_hold <= (fence_hold & ~load_store_status[0]) | (cva5_wrapper.cva5.ls_unit_issue.new_request & ls_inputs[16]);
				reg [1:0] final_mux_sel;
				wire [NUM_SUB_UNITS_W - 1:0] subunit_id;
				one_hot_to_integer #(.C_WIDTH(NUM_SUB_UNITS)) sub_unit_select(
					.one_hot(sub_unit_address_match),
					.int_out(subunit_id)
				);
				always @(*) begin
					if (_sv2v_0)
						;
					case (shared_inputs[39-:3])
						3'b000, 3'b100: final_mux_sel = 0;
						3'b001, 3'b101: final_mux_sel = 1;
						default: final_mux_sel = 2;
					endcase
				end
				function automatic [2:0] sv2v_cast_C24A7;
					input reg [2:0] inp;
					sv2v_cast_C24A7 = inp;
				endfunction
				assign mem_attr = {shared_inputs[37], ~|shared_inputs[39:38], sv2v_cast_2(shared_inputs[47:46]), final_mux_sel, sv2v_cast_C24A7(shared_inputs[4-:3]), sv2v_cast_2(shared_inputs[1-:2]), subunit_id};
				assign load_attributes.data_in = mem_attr;
				assign load_attributes.push = sub_unit_issue & shared_inputs[45];
				assign load_attributes.potential_push = load_attributes.push;
				localparam _param_23816_DATA_WIDTH = 1 * (11 + NUM_SUB_UNITS_W);
				localparam _param_23816_FIFO_DEPTH = ATTRIBUTES_DEPTH;
				if (1) begin : attributes_fifo
					localparam DATA_WIDTH = _param_23816_DATA_WIDTH;
					localparam FIFO_DEPTH = _param_23816_FIFO_DEPTH;
					wire clk;
					wire rst;
					localparam LOG2_FIFO_DEPTH = 1;
					if (1) begin : gen_width_two
						reg [DATA_WIDTH - 1:0] shift_reg [0:1];
						reg [LOG2_FIFO_DEPTH:0] inflight_count;
						always @(posedge clk)
							if (rst)
								inflight_count <= 0;
							else
								inflight_count <= (inflight_count + sv2v_cast_2(cva5_wrapper.cva5.load_store_unit_block.load_attributes.pop)) - sv2v_cast_2(cva5_wrapper.cva5.load_store_unit_block.load_attributes.push);
						assign cva5_wrapper.cva5.load_store_unit_block.load_attributes.valid = inflight_count[LOG2_FIFO_DEPTH];
						assign cva5_wrapper.cva5.load_store_unit_block.load_attributes.full = cva5_wrapper.cva5.load_store_unit_block.load_attributes.valid & ~|inflight_count[0:0];
						always @(posedge clk)
							if (cva5_wrapper.cva5.load_store_unit_block.load_attributes.push) begin
								shift_reg[0] <= cva5_wrapper.cva5.load_store_unit_block.load_attributes.data_in;
								shift_reg[1] <= shift_reg[0];
							end
						assign cva5_wrapper.cva5.load_store_unit_block.load_attributes.data_out = shift_reg[~inflight_count[0]];
					end
				end
				assign attributes_fifo.clk = clk;
				assign attributes_fifo.rst = rst;
				assign load_attributes.pop = load_complete;
				assign wb_attr = load_attributes.data_out;
				genvar _gv_i_7;
				for (_gv_i_7 = 0; _gv_i_7 < NUM_SUB_UNITS; _gv_i_7 = _gv_i_7 + 1) begin : gen_load_store_sources
					localparam i = _gv_i_7;
					assign sub_unit[i].new_request = sub_unit_issue & sub_unit_address_match[i];
					assign sub_unit[i].addr = shared_inputs[77-:32];
					assign sub_unit[i].re = shared_inputs[45];
					assign sub_unit[i].we = shared_inputs[44];
					assign sub_unit[i].be = shared_inputs[43-:4];
					assign sub_unit[i].data_in = shared_inputs[36-:32];
					assign unit_ready[i] = sub_unit[i].ready;
					assign unit_data_valid[i] = sub_unit[i].data_valid;
					assign unit_data_array[i] = sub_unit[i].data_out;
				end
				if (CONFIG[355]) begin : gen_ls_local_mem
					assign sub_unit_address_match[LOCAL_MEM_ID] = dlocal_mem_addr_utils.address_range_check(shared_inputs[77-:32]);
					localparam _bbase_180BD_unit = LOCAL_MEM_ID;
					if (1) begin : d_local_mem
						wire clk;
						wire rst;
						localparam _mbase_unit = _bbase_180BD_unit;
						wire [1:1] sv2v_tmp_34AD5;
						assign sv2v_tmp_34AD5 = 1;
						always @(*) cva5_wrapper.cva5.load_store_unit_block.sub_unit[_mbase_unit].ready = sv2v_tmp_34AD5;
						assign cva5_wrapper.data_bram.addr = cva5_wrapper.cva5.load_store_unit_block.sub_unit[_mbase_unit].addr[31:2];
						assign cva5_wrapper.data_bram.en = cva5_wrapper.cva5.load_store_unit_block.sub_unit[_mbase_unit].new_request;
						assign cva5_wrapper.data_bram.be = cva5_wrapper.cva5.load_store_unit_block.sub_unit[_mbase_unit].be;
						assign cva5_wrapper.data_bram.data_in = cva5_wrapper.cva5.load_store_unit_block.sub_unit[_mbase_unit].data_in;
						wire [32:1] sv2v_tmp_C81AE;
						assign sv2v_tmp_C81AE = cva5_wrapper.data_bram.data_out;
						always @(*) cva5_wrapper.cva5.load_store_unit_block.sub_unit[_mbase_unit].data_out = sv2v_tmp_C81AE;
						always @(posedge clk)
							if (rst)
								cva5_wrapper.cva5.load_store_unit_block.sub_unit[_mbase_unit].data_valid <= 0;
							else
								cva5_wrapper.cva5.load_store_unit_block.sub_unit[_mbase_unit].data_valid <= cva5_wrapper.cva5.load_store_unit_block.sub_unit[_mbase_unit].new_request & cva5_wrapper.cva5.load_store_unit_block.sub_unit[_mbase_unit].re;
					end
					assign d_local_mem.clk = clk;
					assign d_local_mem.rst = rst;
				end
				if (CONFIG[225]) begin : gen_ls_pbus
					assign sub_unit_address_match[BUS_ID] = dpbus_addr_utils.address_range_check(shared_inputs[77-:32]);
					if (CONFIG[160-:32] == 32'd0) begin : genblk1
						localparam _bbase_35C70_ls = BUS_ID;
						if (1) begin : axi_bus
							wire clk;
							wire rst;
							wire [2:0] size;
							localparam _mbase_ls = _bbase_35C70_ls;
							wire ready;
							assign cva5_wrapper.m_axi.arlen = 0;
							assign cva5_wrapper.m_axi.arburst = 0;
							assign cva5_wrapper.m_axi.rready = 1;
							always @(posedge clk)
								if (cva5_wrapper.cva5.load_store_unit_block.sub_unit[_mbase_ls].new_request) begin
									cva5_wrapper.m_axi.araddr <= cva5_wrapper.cva5.load_store_unit_block.sub_unit[_mbase_ls].addr;
									cva5_wrapper.m_axi.arsize <= size;
									cva5_wrapper.m_axi.awsize <= size;
									cva5_wrapper.m_axi.awaddr <= cva5_wrapper.cva5.load_store_unit_block.sub_unit[_mbase_ls].addr;
									cva5_wrapper.m_axi.wdata <= cva5_wrapper.cva5.load_store_unit_block.sub_unit[_mbase_ls].data_in;
									cva5_wrapper.m_axi.wstrb <= cva5_wrapper.cva5.load_store_unit_block.sub_unit[_mbase_ls].be;
								end
							assign cva5_wrapper.m_axi.awlen = 0;
							assign cva5_wrapper.m_axi.awburst = 0;
							assign cva5_wrapper.m_axi.bready = 1;
							set_clr_reg_with_rst #(
								.SET_OVER_CLR(0),
								.WIDTH(1),
								.RST_VALUE(1)
							) ready_m(
								.clk(clk),
								.rst(rst),
								.set(cva5_wrapper.m_axi.rvalid | cva5_wrapper.m_axi.bvalid),
								.clr(cva5_wrapper.cva5.load_store_unit_block.sub_unit[_mbase_ls].new_request),
								.result(ready)
							);
							wire [1:1] sv2v_tmp_58CF8;
							assign sv2v_tmp_58CF8 = ready;
							always @(*) cva5_wrapper.cva5.load_store_unit_block.sub_unit[_mbase_ls].ready = sv2v_tmp_58CF8;
							always @(posedge clk)
								if (rst)
									cva5_wrapper.cva5.load_store_unit_block.sub_unit[_mbase_ls].data_valid <= 0;
								else
									cva5_wrapper.cva5.load_store_unit_block.sub_unit[_mbase_ls].data_valid <= cva5_wrapper.m_axi.rvalid;
							set_clr_reg_with_rst #(
								.SET_OVER_CLR(1),
								.WIDTH(1),
								.RST_VALUE(0)
							) arvalid_m(
								.clk(clk),
								.rst(rst),
								.set(cva5_wrapper.cva5.load_store_unit_block.sub_unit[_mbase_ls].new_request & cva5_wrapper.cva5.load_store_unit_block.sub_unit[_mbase_ls].re),
								.clr(cva5_wrapper.m_axi.arready),
								.result(cva5_wrapper.m_axi.arvalid)
							);
							always @(posedge clk)
								if (cva5_wrapper.m_axi.rvalid)
									cva5_wrapper.cva5.load_store_unit_block.sub_unit[_mbase_ls].data_out <= cva5_wrapper.m_axi.rdata;
							set_clr_reg_with_rst #(
								.SET_OVER_CLR(1),
								.WIDTH(1),
								.RST_VALUE(0)
							) awvalid_m(
								.clk(clk),
								.rst(rst),
								.set(cva5_wrapper.cva5.load_store_unit_block.sub_unit[_mbase_ls].new_request & cva5_wrapper.cva5.load_store_unit_block.sub_unit[_mbase_ls].we),
								.clr(cva5_wrapper.m_axi.awready),
								.result(cva5_wrapper.m_axi.awvalid)
							);
							set_clr_reg_with_rst #(
								.SET_OVER_CLR(1),
								.WIDTH(1),
								.RST_VALUE(0)
							) wvalid_m(
								.clk(clk),
								.rst(rst),
								.set(cva5_wrapper.cva5.load_store_unit_block.sub_unit[_mbase_ls].new_request & cva5_wrapper.cva5.load_store_unit_block.sub_unit[_mbase_ls].we),
								.clr(cva5_wrapper.m_axi.wready),
								.result(cva5_wrapper.m_axi.wvalid)
							);
							assign cva5_wrapper.m_axi.wlast = cva5_wrapper.m_axi.wvalid;
						end
						assign axi_bus.clk = clk;
						assign axi_bus.rst = rst;
						assign axi_bus.size = {1'b0, shared_inputs[38:37]};
					end
					else if (CONFIG[160-:32] == 32'd2) begin : genblk1
						localparam _bbase_F5F96_ls = BUS_ID;
						if (1) begin : wishbone_bus
							wire clk;
							wire rst;
							localparam _mbase_ls = _bbase_F5F96_ls;
							reg busy;
							assign cva5_wrapper.dwishbone.cti = 0;
							assign cva5_wrapper.dwishbone.bte = 0;
							always @(posedge clk)
								if (cva5_wrapper.cva5.load_store_unit_block.sub_unit[_mbase_ls].new_request) begin
									cva5_wrapper.dwishbone.adr <= cva5_wrapper.cva5.load_store_unit_block.sub_unit[_mbase_ls].addr[31:2];
									cva5_wrapper.dwishbone.sel <= (cva5_wrapper.cva5.load_store_unit_block.sub_unit[_mbase_ls].we ? cva5_wrapper.cva5.load_store_unit_block.sub_unit[_mbase_ls].be : {4 {1'sb1}});
									cva5_wrapper.dwishbone.we <= cva5_wrapper.cva5.load_store_unit_block.sub_unit[_mbase_ls].we;
									cva5_wrapper.dwishbone.dat_w <= cva5_wrapper.cva5.load_store_unit_block.sub_unit[_mbase_ls].data_in;
								end
							always @(posedge clk)
								if (rst)
									busy <= 0;
								else
									busy <= (busy & ~cva5_wrapper.dwishbone.ack) | cva5_wrapper.cva5.load_store_unit_block.sub_unit[_mbase_ls].new_request;
							wire [1:1] sv2v_tmp_B6930;
							assign sv2v_tmp_B6930 = ~busy;
							always @(*) cva5_wrapper.cva5.load_store_unit_block.sub_unit[_mbase_ls].ready = sv2v_tmp_B6930;
							assign cva5_wrapper.dwishbone.stb = busy;
							assign cva5_wrapper.dwishbone.cyc = busy;
							always @(posedge clk)
								if (rst)
									cva5_wrapper.cva5.load_store_unit_block.sub_unit[_mbase_ls].data_valid <= 0;
								else
									cva5_wrapper.cva5.load_store_unit_block.sub_unit[_mbase_ls].data_valid <= ~cva5_wrapper.dwishbone.we & cva5_wrapper.dwishbone.ack;
							always @(posedge clk)
								if (cva5_wrapper.dwishbone.ack)
									cva5_wrapper.cva5.load_store_unit_block.sub_unit[_mbase_ls].data_out <= cva5_wrapper.dwishbone.dat_r;
						end
						assign wishbone_bus.clk = clk;
						assign wishbone_bus.rst = rst;
					end
					else if (CONFIG[160-:32] == 32'd1) begin : genblk1
						localparam _bbase_16A2A_ls = BUS_ID;
						if (1) begin : avalon_bus
							wire clk;
							wire rst;
							localparam _mbase_ls = _bbase_16A2A_ls;
							always @(posedge clk)
								if (cva5_wrapper.cva5.load_store_unit_block.sub_unit[_mbase_ls].new_request) begin
									cva5_wrapper.m_avalon.addr <= cva5_wrapper.cva5.load_store_unit_block.sub_unit[_mbase_ls].addr;
									cva5_wrapper.m_avalon.byteenable <= cva5_wrapper.cva5.load_store_unit_block.sub_unit[_mbase_ls].be;
									cva5_wrapper.m_avalon.writedata <= cva5_wrapper.cva5.load_store_unit_block.sub_unit[_mbase_ls].data_in;
								end
							always @(posedge clk)
								if (rst)
									cva5_wrapper.cva5.load_store_unit_block.sub_unit[_mbase_ls].ready <= 1;
								else if (cva5_wrapper.cva5.load_store_unit_block.sub_unit[_mbase_ls].new_request)
									cva5_wrapper.cva5.load_store_unit_block.sub_unit[_mbase_ls].ready <= 0;
								else if (~cva5_wrapper.cva5.load_store_unit_block.sub_unit[_mbase_ls].ready & ~cva5_wrapper.m_avalon.waitrequest)
									cva5_wrapper.cva5.load_store_unit_block.sub_unit[_mbase_ls].ready <= 1;
							always @(posedge clk)
								if (rst)
									cva5_wrapper.cva5.load_store_unit_block.sub_unit[_mbase_ls].data_valid <= 0;
								else if (cva5_wrapper.m_avalon.read & ~cva5_wrapper.m_avalon.waitrequest)
									cva5_wrapper.cva5.load_store_unit_block.sub_unit[_mbase_ls].data_valid <= 1;
								else
									cva5_wrapper.cva5.load_store_unit_block.sub_unit[_mbase_ls].data_valid <= 0;
							always @(posedge clk)
								if (cva5_wrapper.m_avalon.read & ~cva5_wrapper.m_avalon.waitrequest)
									cva5_wrapper.cva5.load_store_unit_block.sub_unit[_mbase_ls].data_out <= cva5_wrapper.m_avalon.readdata;
								else
									cva5_wrapper.cva5.load_store_unit_block.sub_unit[_mbase_ls].data_out <= 0;
							always @(posedge clk)
								if (rst)
									cva5_wrapper.m_avalon.read <= 0;
								else if (cva5_wrapper.cva5.load_store_unit_block.sub_unit[_mbase_ls].new_request & cva5_wrapper.cva5.load_store_unit_block.sub_unit[_mbase_ls].re)
									cva5_wrapper.m_avalon.read <= 1;
								else if (~cva5_wrapper.m_avalon.waitrequest)
									cva5_wrapper.m_avalon.read <= 0;
							always @(posedge clk)
								if (rst)
									cva5_wrapper.m_avalon.write <= 0;
								else if (cva5_wrapper.cva5.load_store_unit_block.sub_unit[_mbase_ls].new_request & cva5_wrapper.cva5.load_store_unit_block.sub_unit[_mbase_ls].we)
									cva5_wrapper.m_avalon.write <= 1;
								else if (~cva5_wrapper.m_avalon.waitrequest)
									cva5_wrapper.m_avalon.write <= 0;
						end
						assign avalon_bus.clk = clk;
						assign avalon_bus.rst = rst;
					end
				end
				if (CONFIG[711]) begin : gen_ls_dcache
					wire uncacheable;
					assign sub_unit_address_match[DCACHE_ID] = dcache_addr_utils.address_range_check(shared_inputs[77-:32]);
					assign uncacheable = uncacheable_utils.address_range_check(shared_inputs[77-:32]);
					localparam _bbase_A2070_l1_request = 2'd0;
					localparam _bbase_A2070_l1_response = 2'd0;
					localparam _bbase_A2070_ls = DCACHE_ID;
					localparam _param_A2070_CONFIG = CONFIG;
					if (1) begin : data_cache
						reg _sv2v_0;
						localparam [1209:0] cva5_config_EXAMPLE_CONFIG = 1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002;
						localparam [1209:0] CONFIG = _param_A2070_CONFIG;
						wire clk;
						wire rst;
						wire dcache_on;
						localparam _mbase_l1_request = _bbase_A2070_l1_request;
						localparam _mbase_l1_response = _bbase_A2070_l1_response;
						wire sc_complete;
						wire sc_success;
						wire clear_reservation;
						wire [7:0] amo;
						wire uncacheable;
						localparam _mbase_ls = _bbase_A2070_ls;
						localparam DCACHE_SIZE_IN_WORDS = (CONFIG[710-:32] * CONFIG[678-:32]) * CONFIG[646-:32];
						function [95:0] cva5_config_get_derived_cache_params;
							input reg [1209:0] cpu;
							input reg [161:0] cache;
							input reg [63:0] addr;
							cva5_config_get_derived_cache_params = {sv2v_cast_32($clog2(cache[161-:32])), sv2v_cast_32($clog2(cache[129-:32])), sv2v_cast_32((($clog2((sv2v_cast_64(addr[31-:32]) - sv2v_cast_64(addr[63-:32])) + 1) - $clog2(cache[161-:32])) - $clog2(cache[129-:32])) - 2)};
						endfunction
						localparam [95:0] SCONFIG = cva5_config_get_derived_cache_params(CONFIG, CONFIG[710-:162], CONFIG[548-:64]);
						localparam LOG2_DCACHE_WAYS = (CONFIG[646-:32] == 1 ? 1 : $clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[646-:32]));
						wire [$clog2(DCACHE_SIZE_IN_WORDS) - 1:0] data_bank_addr_a;
						wire [$clog2(DCACHE_SIZE_IN_WORDS) - 1:0] data_bank_addr_b;
						wire tag_hit;
						wire [CONFIG[646-:32] - 1:0] tag_hit_way;
						wire [LOG2_DCACHE_WAYS - 1:0] tag_hit_way_int;
						reg tag_update;
						reg [CONFIG[646-:32] - 1:0] tag_update_way;
						wire [CONFIG[646-:32] - 1:0] replacement_way;
						wire [LOG2_DCACHE_WAYS - 1:0] replacement_way_int;
						reg [LOG2_DCACHE_WAYS - 1:0] tag_update_way_int;
						reg [SCONFIG[63-:32] - 1:0] word_count;
						wire [SCONFIG[63-:32] - 1:0] sc_write_index;
						wire [SCONFIG[63-:32] - 1:0] update_word_index;
						wire line_complete;
						reg reservation;
						reg [76:0] stage2;
						wire [31:0] dbank_data_out;
						wire [31:0] hit_data;
						reg [31:0] miss_data;
						reg [31:0] new_line_data;
						wire [31:0] amo_result;
						reg [31:0] amo_rs2;
						wire [3:0] write_hit_be;
						reg second_cycle;
						wire new_arb_request;
						reg arb_request_r;
						wire is_target_word;
						wire hit_allowed;
						reg read_hit_allowed;
						reg read_hit_data_valid;
						wire read_hit;
						wire address_range_valid;
						reg idle;
						reg read_miss_complete;
						wire store_complete;
						localparam riscv_types_XLEN = 32;
						wire [68:0] amo_alu_inputs;
						always @(posedge clk)
							if (cva5_wrapper.cva5.load_store_unit_block.sub_unit[_mbase_ls].new_request) begin
								stage2[76-:30] <= cva5_wrapper.cva5.load_store_unit_block.sub_unit[_mbase_ls].addr[31:2];
								stage2[46-:4] <= cva5_wrapper.cva5.load_store_unit_block.sub_unit[_mbase_ls].be;
								stage2[42] <= cva5_wrapper.cva5.load_store_unit_block.sub_unit[_mbase_ls].re;
								stage2[41] <= cva5_wrapper.cva5.load_store_unit_block.sub_unit[_mbase_ls].we;
								stage2[40-:32] <= cva5_wrapper.cva5.load_store_unit_block.sub_unit[_mbase_ls].data_in;
								stage2[8-:8] <= amo;
								stage2[0] <= uncacheable;
							end
						always @(posedge clk) begin
							read_hit_allowed <= (((cva5_wrapper.cva5.load_store_unit_block.sub_unit[_mbase_ls].new_request & cva5_wrapper.cva5.load_store_unit_block.sub_unit[_mbase_ls].re) & dcache_on) & ~(amo[7] | amo[5])) & ~uncacheable;
							read_hit_data_valid <= read_hit_allowed;
							second_cycle <= cva5_wrapper.cva5.load_store_unit_block.sub_unit[_mbase_ls].new_request;
							tag_update <= (((second_cycle & dcache_on) & stage2[42]) & ~tag_hit) & ~stage2[0];
						end
						assign read_hit = tag_hit & read_hit_allowed;
						always @(posedge clk)
							if (rst)
								reservation <= 0;
							else if (second_cycle)
								reservation <= stage2[8];
							else if (sc_complete | clear_reservation)
								reservation <= 0;
						wire [32:1] sv2v_tmp_D361A;
						assign sv2v_tmp_D361A = {stage2[76-:30], 2'b00};
						always @(*) cva5_wrapper.cva5.l1_request[_mbase_l1_request].addr = sv2v_tmp_D361A;
						assign cva5_wrapper.cva5.l1_request[_mbase_l1_request].data = stage2[40-:32];
						assign cva5_wrapper.cva5.l1_request[_mbase_l1_request].rnw = ~stage2[41];
						assign cva5_wrapper.cva5.l1_request[_mbase_l1_request].be = stage2[46-:4];
						assign cva5_wrapper.cva5.l1_request[_mbase_l1_request].size = (stage2[42] & ~stage2[0] ? sv2v_cast_5(CONFIG[678-:32] - 1) : 0);
						assign cva5_wrapper.cva5.l1_request[_mbase_l1_request].is_amo = (stage2[6] | stage2[8]) | stage2[7];
						assign cva5_wrapper.cva5.l1_request[_mbase_l1_request].amo = stage2[5-:5];
						always @(posedge clk)
							if (rst | line_complete)
								word_count <= 0;
							else if (cva5_wrapper.cva5.l1_response[_mbase_l1_response].data_valid)
								word_count <= word_count + 1;
						assign is_target_word = (stage2[SCONFIG[63-:32] + 46:47] == word_count) | stage2[0];
						assign new_arb_request = second_cycle & ~read_hit;
						always @(posedge clk)
							if (rst)
								arb_request_r <= 0;
							else if (second_cycle & ~cva5_wrapper.cva5.l1_request[_mbase_l1_request].ack)
								arb_request_r <= new_arb_request;
							else if (cva5_wrapper.cva5.l1_request[_mbase_l1_request].ack)
								arb_request_r <= 0;
						assign cva5_wrapper.cva5.l1_request[_mbase_l1_request].request = new_arb_request | arb_request_r;
						cycler #(.C_WIDTH(CONFIG[646-:32])) replacement_policy(
							.clk(clk),
							.rst(rst),
							.en(1'b1),
							.one_hot(replacement_way)
						);
						one_hot_to_integer #(.C_WIDTH(CONFIG[646-:32])) hit_way_conv(
							.one_hot(tag_hit_way),
							.int_out(tag_hit_way_int)
						);
						one_hot_to_integer #(.C_WIDTH(CONFIG[646-:32])) update_way_conv(
							.one_hot(replacement_way),
							.int_out(replacement_way_int)
						);
						wire stage2_amo_with_load;
						assign stage2_amo_with_load = stage2[6] | stage2[8];
						always @(posedge clk)
							if (second_cycle) begin
								tag_update_way <= (stage2_amo_with_load & tag_hit ? tag_hit_way : replacement_way);
								tag_update_way_int <= (stage2_amo_with_load & tag_hit ? tag_hit_way_int : replacement_way_int);
							end
						dtag_banks #(
							.CONFIG(CONFIG),
							.SCONFIG(SCONFIG)
						) dcache_tag_banks(
							.clk(clk),
							.rst(rst),
							.stage1_addr(cva5_wrapper.cva5.load_store_unit_block.sub_unit[_mbase_ls].addr[31:2]),
							.stage2_addr(stage2[76-:30]),
							.inv_addr(cva5_wrapper.cva5.l1_response[_mbase_l1_response].inv_addr),
							.update_way(tag_update_way),
							.update(tag_update),
							.stage1_adv(cva5_wrapper.cva5.load_store_unit_block.sub_unit[_mbase_ls].new_request),
							.stage1_inv(1'b0),
							.extern_inv(cva5_wrapper.cva5.l1_response[_mbase_l1_response].inv_valid),
							.extern_inv_complete(cva5_wrapper.cva5.l1_response[_mbase_l1_response].inv_ack),
							.tag_hit(tag_hit),
							.tag_hit_way(tag_hit_way)
						);
						always @(posedge clk) amo_rs2 <= stage2[40-:32];
						assign amo_alu_inputs[68-:32] = cva5_wrapper.cva5.l1_response[_mbase_l1_response].data;
						assign amo_alu_inputs[36-:32] = amo_rs2;
						assign amo_alu_inputs[4-:5] = stage2[5-:5];
						if (CONFIG[1201]) begin : genblk1
							amo_alu amo_unit(
								.amo_alu_inputs(amo_alu_inputs),
								.result(amo_result)
							);
						end
						always @(*) begin
							if (_sv2v_0)
								;
							if (stage2[6] & is_target_word)
								new_line_data = amo_result;
							else if (stage2[7])
								new_line_data = stage2[40-:32];
							else
								new_line_data = cva5_wrapper.cva5.l1_response[_mbase_l1_response].data;
						end
						assign sc_write_index = stage2[SCONFIG[63-:32] + 46:47];
						assign write_hit_be = stage2[46-:4] & {4 {tag_hit}};
						assign update_word_index = (stage2[7] ? sc_write_index : word_count);
						if (CONFIG[646-:32] == 1) begin : bank_sel_gen
							assign data_bank_addr_a = stage2[(SCONFIG[95-:32] + SCONFIG[63-:32]) + 46:47];
							assign data_bank_addr_b = {stage2[(SCONFIG[95-:32] + SCONFIG[63-:32]) + 46:47 + SCONFIG[63-:32]], update_word_index};
						end
						else begin : genblk2
							assign data_bank_addr_a = {tag_hit_way_int, stage2[(SCONFIG[95-:32] + SCONFIG[63-:32]) + 46:47]};
							assign data_bank_addr_b = {tag_update_way_int, stage2[(SCONFIG[95-:32] + SCONFIG[63-:32]) + 46:47 + SCONFIG[63-:32]], update_word_index};
						end
						ddata_bank #(.LINES(DCACHE_SIZE_IN_WORDS)) data_bank(
							.clk(clk),
							.addr_a(data_bank_addr_a),
							.addr_b(data_bank_addr_b),
							.en_a(second_cycle),
							.en_b((cva5_wrapper.cva5.l1_response[_mbase_l1_response].data_valid & ~stage2[0]) | (sc_complete & sc_success)),
							.be_a(write_hit_be),
							.data_in_a(stage2[40-:32]),
							.data_in_b(new_line_data),
							.data_out_a(dbank_data_out)
						);
						always @(posedge clk)
							if (cva5_wrapper.cva5.l1_response[_mbase_l1_response].data_valid & is_target_word)
								miss_data <= cva5_wrapper.cva5.l1_response[_mbase_l1_response].data;
							else if (sc_complete)
								miss_data <= {31'b0000000000000000000000000000000, sc_success};
						wire [32:1] sv2v_tmp_53764;
						assign sv2v_tmp_53764 = (read_hit_data_valid ? dbank_data_out : miss_data);
						always @(*) cva5_wrapper.cva5.load_store_unit_block.sub_unit[_mbase_ls].data_out = sv2v_tmp_53764;
						function automatic [$clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[678-:32]) - 1:0] sv2v_cast_74AAD;
							input reg [$clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[678-:32]) - 1:0] inp;
							sv2v_cast_74AAD = inp;
						endfunction
						assign line_complete = cva5_wrapper.cva5.l1_response[_mbase_l1_response].data_valid & ((word_count == sv2v_cast_74AAD(CONFIG[678-:32] - 1)) | stage2[0]);
						assign store_complete = (cva5_wrapper.cva5.l1_request[_mbase_l1_request].ack & stage2[41]) & ~stage2[7];
						always @(posedge clk)
							if (rst)
								read_miss_complete <= 0;
							else
								read_miss_complete <= line_complete | sc_complete;
						always @(posedge clk)
							if (rst)
								cva5_wrapper.cva5.load_store_unit_block.sub_unit[_mbase_ls].data_valid <= 0;
							else
								cva5_wrapper.cva5.load_store_unit_block.sub_unit[_mbase_ls].data_valid <= ((cva5_wrapper.cva5.l1_response[_mbase_l1_response].data_valid & is_target_word) | read_hit) | sc_complete;
						wire [1:1] sv2v_tmp_90871;
						assign sv2v_tmp_90871 = ((read_hit | store_complete) | read_miss_complete) | idle;
						always @(*) cva5_wrapper.cva5.load_store_unit_block.sub_unit[_mbase_ls].ready = sv2v_tmp_90871;
						always @(posedge clk)
							if (rst)
								idle <= 1;
							else if (cva5_wrapper.cva5.load_store_unit_block.sub_unit[_mbase_ls].new_request)
								idle <= 0;
							else if (cva5_wrapper.cva5.load_store_unit_block.sub_unit[_mbase_ls].ready)
								idle <= 1;
						initial _sv2v_0 = 0;
					end
					assign data_cache.clk = clk;
					assign data_cache.rst = rst;
					assign data_cache.dcache_on = dcache_on;
					assign data_cache.sc_complete = sc_complete;
					assign data_cache.sc_success = sc_success;
					assign data_cache.clear_reservation = clear_reservation;
					assign data_cache.amo = ls_inputs[7-:8];
					assign data_cache.uncacheable = uncacheable;
				end
				wire [0:3] sign_bit_data;
				wire [1:0] sign_bit_sel;
				wire sign_bit;
				assign unit_muxed_load_data = unit_data_array[wb_attr[NUM_SUB_UNITS_W - 1-:NUM_SUB_UNITS_W]];
				assign aligned_load_data[31:16] = unit_muxed_load_data[31:16];
				assign aligned_load_data[15:8] = (wb_attr[7 + (NUM_SUB_UNITS_W + 1)] ? unit_muxed_load_data[31:24] : unit_muxed_load_data[15:8]);
				assign aligned_load_data[7:0] = unit_muxed_load_data[wb_attr[4 + (cva5_types_LOG2_MAX_IDS + (NUM_SUB_UNITS_W + 1))-:((7 + (NUM_SUB_UNITS_W + 1)) >= (7 + (NUM_SUB_UNITS_W + 0)) ? ((4 + (cva5_types_LOG2_MAX_IDS + (NUM_SUB_UNITS_W + 1))) - (2 + (cva5_types_LOG2_MAX_IDS + (2 + (NUM_SUB_UNITS_W + 0))))) + 1 : ((2 + (cva5_types_LOG2_MAX_IDS + (2 + (NUM_SUB_UNITS_W + 0)))) - (4 + (cva5_types_LOG2_MAX_IDS + (NUM_SUB_UNITS_W + 1)))) + 1)] * 8+:8];
				assign sign_bit_data = {unit_muxed_load_data[7], unit_muxed_load_data[15], unit_muxed_load_data[23], unit_muxed_load_data[31]};
				assign sign_bit_sel = wb_attr[4 + (cva5_types_LOG2_MAX_IDS + (NUM_SUB_UNITS_W + 1))-:((7 + (NUM_SUB_UNITS_W + 1)) >= (7 + (NUM_SUB_UNITS_W + 0)) ? ((4 + (cva5_types_LOG2_MAX_IDS + (NUM_SUB_UNITS_W + 1))) - (2 + (cva5_types_LOG2_MAX_IDS + (2 + (NUM_SUB_UNITS_W + 0))))) + 1 : ((2 + (cva5_types_LOG2_MAX_IDS + (2 + (NUM_SUB_UNITS_W + 0)))) - (4 + (cva5_types_LOG2_MAX_IDS + (NUM_SUB_UNITS_W + 1)))) + 1)] | {1'b0, wb_attr[6 + (cva5_types_LOG2_MAX_IDS + (NUM_SUB_UNITS_W + 1))]};
				assign sign_bit = wb_attr[5 + (cva5_types_LOG2_MAX_IDS + (NUM_SUB_UNITS_W + 1))] & sign_bit_data[sign_bit_sel];
				always @(*) begin
					if (_sv2v_0)
						;
					case (wb_attr[2 + (cva5_types_LOG2_MAX_IDS + (NUM_SUB_UNITS_W + 1))-:((5 + (NUM_SUB_UNITS_W + 1)) >= (5 + (NUM_SUB_UNITS_W + 0)) ? ((2 + (cva5_types_LOG2_MAX_IDS + (NUM_SUB_UNITS_W + 1))) - (cva5_types_LOG2_MAX_IDS + (2 + (NUM_SUB_UNITS_W + 0)))) + 1 : ((cva5_types_LOG2_MAX_IDS + (2 + (NUM_SUB_UNITS_W + 0))) - (2 + (cva5_types_LOG2_MAX_IDS + (NUM_SUB_UNITS_W + 1)))) + 1)])
						0: final_load_data = {{24 {sign_bit}}, aligned_load_data[7:0]};
						1: final_load_data = {{16 {sign_bit}}, aligned_load_data[15:0]};
						default: final_load_data = aligned_load_data;
					endcase
				end
				assign cva5_wrapper.cva5.ls_unit_wb.rd = final_load_data;
				assign cva5_wrapper.cva5.ls_unit_wb.done = load_complete | load_exception_complete;
				assign cva5_wrapper.cva5.ls_unit_wb.id = (load_exception_complete ? cva5_wrapper.cva5.exception[_mbase_exception].id : wb_attr[cva5_types_LOG2_MAX_IDS + (NUM_SUB_UNITS_W + 1)-:((cva5_types_LOG2_MAX_IDS + (NUM_SUB_UNITS_W + 1)) >= (2 + (NUM_SUB_UNITS_W + 0)) ? ((cva5_types_LOG2_MAX_IDS + (NUM_SUB_UNITS_W + 1)) - (2 + (NUM_SUB_UNITS_W + 0))) + 1 : ((2 + (NUM_SUB_UNITS_W + 0)) - (cva5_types_LOG2_MAX_IDS + (NUM_SUB_UNITS_W + 1))) + 1)]);
				assign wb_scaiev_meta = (load_exception_complete ? 0 : wb_attr[NUM_SUB_UNITS_W + 1-:((NUM_SUB_UNITS_W + 1) >= (NUM_SUB_UNITS_W + 0) ? ((NUM_SUB_UNITS_W + 1) - (NUM_SUB_UNITS_W + 0)) + 1 : ((NUM_SUB_UNITS_W + 0) - (NUM_SUB_UNITS_W + 1)) + 1)]);
				localparam cva5_config_ENABLE_TRACE_INTERFACE = 1;
				if (cva5_config_ENABLE_TRACE_INTERFACE) begin : gen_ls_trace
					assign tr_load_conflict_delay = tr_possible_load_conflict_delay & units_ready;
				end
				initial _sv2v_0 = 0;
			end
			assign load_store_unit_block.clk = clk;
			assign load_store_unit_block.rst = rst;
			assign load_store_unit_block.gc = gc;
			assign load_store_unit_block.ls_inputs = ls_inputs_actual;
			assign load_store_unit_block.issue_scaiev_meta = ls_issue_scaiev_meta;
			assign load_store_unit_block.dcache_on = 1'b1;
			assign load_store_unit_block.clear_reservation = 1'b0;
			assign load_store_unit_block.tlb_on = tlb_on;
			assign load_store_unit_block.sc_complete = sc_complete;
			assign load_store_unit_block.sc_success = sc_success;
			assign load_store_unit_block.wb_snoop = wb_snoop;
			assign load_store_unit_block.retire_ids = retire_ids;
			assign load_store_unit_block.retire_port_valid = retire_port_valid;
			assign load_store_status = load_store_unit_block.load_store_status;
			assign ls_wb_scaiev_meta = load_store_unit_block.wb_scaiev_meta;
			assign tr_load_conflict_delay = load_store_unit_block.tr_load_conflict_delay;
			if (CONFIG[1208]) begin : gen_dtlb_dmmu
				localparam _param_9E88A_WAYS = CONFIG[484-:32];
				localparam _param_9E88A_DEPTH = CONFIG[452-:32];
				if (1) begin : d_tlb
					reg _sv2v_0;
					localparam WAYS = _param_9E88A_WAYS;
					localparam DEPTH = _param_9E88A_DEPTH;
					wire clk;
					wire rst;
					localparam cva5_config_MAX_IDS = 8;
					localparam cva5_types_LOG2_MAX_IDS = 3;
					localparam riscv_types_ECODE_W = 5;
					wire [115:0] gc;
					wire abort_request;
					localparam riscv_types_ASIDLEN = 9;
					wire [8:0] asid;
					localparam TLB_TAG_W = 20 - $clog2(DEPTH);
					wire [$clog2(DEPTH) - 1:0] tlb_addr;
					wire [TLB_TAG_W - 1:0] virtual_tag;
					wire [(1 + TLB_TAG_W) + 19:0] ram [DEPTH - 1:0][WAYS - 1:0];
					wire [DEPTH - 1:0] valid [WAYS - 1:0];
					reg [WAYS - 1:0] tag_hit;
					wire hit;
					wire [WAYS - 1:0] replacement_way;
					wire [(((1 + TLB_TAG_W) + 19) >= 0 ? (1 + TLB_TAG_W) + 20 : 1 - ((1 + TLB_TAG_W) + 19)) - 1:0] ram_data [WAYS - 1:0];
					wire [(1 + TLB_TAG_W) + 19:0] ram_entry [WAYS - 1:0];
					wire [(1 + TLB_TAG_W) + 19:0] new_entry;
					wire [$clog2(DEPTH) - 1:0] flush_addr;
					wire [WAYS - 1:0] tlb_write;
					reg request_in_progress;
					reg mmu_request_complete;
					lfsr #(
						.WIDTH($clog2(DEPTH)),
						.NEEDS_RESET(0)
					) lfsr_counter(
						.clk(clk),
						.rst(rst),
						.en(gc[107]),
						.value(flush_addr)
					);
					assign tlb_addr = (gc[107] ? flush_addr : cva5_wrapper.cva5.dtlb.virtual_address[12+:$clog2(DEPTH)]);
					assign tlb_write = {WAYS {gc[107]}} | replacement_way;
					assign new_entry[1 + (TLB_TAG_W + 19)] = ~gc[107];
					assign new_entry[TLB_TAG_W + 19-:((TLB_TAG_W + 19) >= 20 ? TLB_TAG_W + 0 : 21 - (TLB_TAG_W + 19))] = virtual_tag;
					assign new_entry[19-:20] = cva5_wrapper.cva5.dmmu.upper_physical_address;
					genvar _gv_i_10;
					for (_gv_i_10 = 0; _gv_i_10 < WAYS; _gv_i_10 = _gv_i_10 + 1) begin : lut_rams
						localparam i = _gv_i_10;
						lutram_1w_1r #(
							.WIDTH((((1 + TLB_TAG_W) + 19) >= 0 ? (1 + TLB_TAG_W) + 20 : 1 - ((1 + TLB_TAG_W) + 19))),
							.DEPTH(DEPTH)
						) write_port(
							.clk(clk),
							.waddr(tlb_addr),
							.raddr(tlb_addr),
							.ram_write(tlb_write[i]),
							.new_ram_data(new_entry),
							.ram_data_out(ram_data[i])
						);
						assign ram_entry[i] = ram_data[i];
					end
					cycler #(.C_WIDTH(WAYS)) replacement_policy(
						.clk(clk),
						.rst(rst),
						.en(1'b1),
						.one_hot(replacement_way)
					);
					assign virtual_tag = cva5_wrapper.cva5.dtlb.virtual_address[31:32 - TLB_TAG_W];
					always @(*) begin
						if (_sv2v_0)
							;
						begin : sv2v_autoblock_42
							reg signed [31:0] i;
							for (i = 0; i < WAYS; i = i + 1)
								tag_hit[i] = {ram_entry[i][1 + (TLB_TAG_W + 19)], ram_entry[i][TLB_TAG_W + 19-:((TLB_TAG_W + 19) >= 20 ? TLB_TAG_W + 0 : 21 - (TLB_TAG_W + 19))]} == {1'b1, virtual_tag};
						end
					end
					assign cva5_wrapper.cva5.dtlb.ready = ~request_in_progress;
					always @(posedge clk)
						if (rst)
							request_in_progress <= 0;
						else if ((cva5_wrapper.cva5.dmmu.write_entry | cva5_wrapper.cva5.dmmu.is_fault) | abort_request)
							request_in_progress <= 0;
						else if (cva5_wrapper.cva5.dtlb.new_request & ~hit)
							request_in_progress <= 1;
					assign cva5_wrapper.cva5.dmmu.request = request_in_progress;
					always @(posedge clk)
						if (rst)
							mmu_request_complete <= 0;
						else
							mmu_request_complete <= cva5_wrapper.cva5.dmmu.write_entry;
					assign cva5_wrapper.cva5.dmmu.virtual_address = cva5_wrapper.cva5.dtlb.virtual_address;
					assign cva5_wrapper.cva5.dmmu.execute = cva5_wrapper.cva5.dtlb.execute;
					assign cva5_wrapper.cva5.dmmu.rnw = cva5_wrapper.cva5.dtlb.rnw;
					assign hit = |tag_hit;
					assign cva5_wrapper.cva5.dtlb.done = hit & (cva5_wrapper.cva5.dtlb.new_request | mmu_request_complete);
					assign cva5_wrapper.cva5.dtlb.is_fault = cva5_wrapper.cva5.dmmu.is_fault;
					always @(*) begin
						if (_sv2v_0)
							;
						cva5_wrapper.cva5.dtlb.physical_address[11:0] = cva5_wrapper.cva5.dtlb.virtual_address[11:0];
						cva5_wrapper.cva5.dtlb.physical_address[31:12] = 0;
						begin : sv2v_autoblock_43
							reg signed [31:0] i;
							for (i = 0; i < WAYS; i = i + 1)
								if (tag_hit[i])
									cva5_wrapper.cva5.dtlb.physical_address[31:12] = cva5_wrapper.cva5.dtlb.physical_address[31:12] | ram_entry[i][19-:20];
						end
					end
					initial _sv2v_0 = 0;
				end
				assign d_tlb.clk = clk;
				assign d_tlb.rst = rst;
				assign d_tlb.gc = gc;
				assign d_tlb.abort_request = 1'b0;
				assign d_tlb.asid = asid;
				localparam _bbase_23F01_l1_request = 2'd1;
				localparam _bbase_23F01_l1_response = 2'd1;
				if (1) begin : d_mmu
					reg _sv2v_0;
					wire clk;
					wire rst;
					wire abort_request;
					localparam _mbase_l1_request = _bbase_23F01_l1_request;
					localparam _mbase_l1_response = _bbase_23F01_l1_response;
					reg [6:0] state;
					reg [6:0] next_state;
					wire [31:0] pte;
					wire access_valid;
					wire privilege_valid;
					localparam MAX_ABORTED_REQUESTS = 4;
					wire abort_queue_full;
					wire discard_data;
					assign cva5_wrapper.cva5.l1_request[_mbase_l1_request].rnw = 1;
					assign cva5_wrapper.cva5.l1_request[_mbase_l1_request].be = 1'sb1;
					assign cva5_wrapper.cva5.l1_request[_mbase_l1_request].size = 1'sb0;
					assign cva5_wrapper.cva5.l1_request[_mbase_l1_request].is_amo = 0;
					assign cva5_wrapper.cva5.l1_request[_mbase_l1_request].amo = 0;
					assign cva5_wrapper.cva5.l1_request[_mbase_l1_request].request = (state[32'd1] | state[32'd3]) & ~abort_request;
					always @(posedge clk)
						if (state[32'd0] | cva5_wrapper.cva5.l1_response[_mbase_l1_response].data_valid) begin
							if (state[32'd0])
								cva5_wrapper.cva5.l1_request[_mbase_l1_request].addr <= {cva5_wrapper.cva5.dmmu.satp_ppn[19:0], cva5_wrapper.cva5.dmmu.virtual_address[31:22], 2'b00};
							else
								cva5_wrapper.cva5.l1_request[_mbase_l1_request].addr <= {pte[29:20], pte[19-:10], cva5_wrapper.cva5.dmmu.virtual_address[21:12], 2'b00};
						end
					assign pte = cva5_wrapper.cva5.l1_response[_mbase_l1_response].data;
					localparam COUNT_W = 2;
					reg [COUNT_W:0] abort_tracking;
					wire delayed_abort;
					wire delayed_abort_complete;
					assign delayed_abort = abort_request & (state[32'd2] | state[32'd4]);
					assign delayed_abort_complete = discard_data & cva5_wrapper.cva5.l1_response[_mbase_l1_response].data_valid;
					always @(posedge clk)
						if (rst)
							abort_tracking <= 0;
						else
							abort_tracking <= (abort_tracking - sv2v_cast_2(delayed_abort)) + sv2v_cast_2(delayed_abort_complete);
					assign discard_data = abort_tracking[COUNT_W];
					assign abort_queue_full = abort_tracking[COUNT_W] & ~|abort_tracking[1:0];
					assign access_valid = (((cva5_wrapper.cva5.dmmu.execute & pte[3]) & pte[6]) | ((cva5_wrapper.cva5.dmmu.rnw & (pte[1] | (pte[3] & cva5_wrapper.cva5.dmmu.mxr))) & pte[6])) | ((((~cva5_wrapper.cva5.dmmu.rnw & ~cva5_wrapper.cva5.dmmu.execute) & pte[2]) & pte[6]) & pte[7]);
					assign privilege_valid = ((cva5_wrapper.cva5.dmmu.privilege == 2'b11) | ((cva5_wrapper.cva5.dmmu.privilege == 2'b01) & (~pte[4] | (pte[4] & cva5_wrapper.cva5.dmmu.sum)))) | ((cva5_wrapper.cva5.dmmu.privilege == 2'b00) & pte[4]);
					always @(*) begin
						if (_sv2v_0)
							;
						next_state = state;
						case (1'b1)
							state[32'd0]:
								if (cva5_wrapper.cva5.dmmu.request & ~abort_queue_full)
									next_state = 2;
							state[32'd1]:
								if (cva5_wrapper.cva5.l1_request[_mbase_l1_request].ack)
									next_state = 4;
							state[32'd2]:
								if (cva5_wrapper.cva5.l1_response[_mbase_l1_response].data_valid & ~discard_data) begin
									if (~pte[0] | (~pte[1] & pte[2]))
										next_state = 64;
									else if (pte[0] & (pte[1] | pte[3])) begin
										if (access_valid & privilege_valid)
											next_state = 32;
										else
											next_state = 64;
									end
									else
										next_state = 8;
								end
							state[32'd3]:
								if (cva5_wrapper.cva5.l1_request[_mbase_l1_request].ack)
									next_state = 16;
							state[32'd4]:
								if (cva5_wrapper.cva5.l1_response[_mbase_l1_response].data_valid & ~discard_data) begin
									if (access_valid & privilege_valid)
										next_state = 32;
									else
										next_state = 64;
								end
							state[32'd5], state[32'd6]: next_state = 1;
						endcase
						if (abort_request)
							next_state = 1;
					end
					always @(posedge clk)
						if (rst)
							state <= 1;
						else
							state <= next_state;
					always @(posedge clk)
						if (cva5_wrapper.cva5.l1_response[_mbase_l1_response].data_valid) begin
							cva5_wrapper.cva5.dmmu.upper_physical_address[19:10] <= pte[29:20];
							cva5_wrapper.cva5.dmmu.upper_physical_address[9:0] <= (state[32'd4] ? pte[19-:10] : cva5_wrapper.cva5.dmmu.virtual_address[21:12]);
						end
					assign cva5_wrapper.cva5.dmmu.write_entry = state[32'd5];
					assign cva5_wrapper.cva5.dmmu.is_fault = state[32'd6];
					initial _sv2v_0 = 0;
				end
				assign d_mmu.clk = clk;
				assign d_mmu.rst = rst;
				assign d_mmu.abort_request = 1'b0;
			end
			else begin : genblk5
				assign dtlb.ready = 1;
				assign dtlb.done = dtlb.new_request;
				wire [32:1] sv2v_tmp_666C0;
				assign sv2v_tmp_666C0 = dtlb.virtual_address;
				always @(*) dtlb.physical_address = sv2v_tmp_666C0;
			end
			if (CONFIG[1202]) begin : gen_csrs
				localparam _bbase_6DC46_issue = UNIT_IDS[191-:32];
				localparam _bbase_6DC46_wb = UNIT_IDS[191-:32];
				localparam _param_6DC46_CONFIG = CONFIG;
				if (1) begin : csr_unit_block
					reg _sv2v_0;
					localparam [1209:0] cva5_config_EXAMPLE_CONFIG = 1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002;
					localparam [1209:0] CONFIG = _param_6DC46_CONFIG;
					wire clk;
					wire rst;
					localparam _mbase_issue = _bbase_6DC46_issue;
					localparam riscv_types_XLEN = 32;
					wire [47:0] csr_inputs;
					localparam _mbase_wb = _bbase_6DC46_wb;
					wire [1:0] current_privilege;
					wire interrupt_taken;
					wire interrupt_pending;
					wire processing_csr;
					wire tlb_on;
					localparam riscv_types_ASIDLEN = 9;
					wire [8:0] asid;
					localparam cva5_config_MAX_IDS = 8;
					localparam cva5_types_LOG2_MAX_IDS = 3;
					localparam riscv_types_ECODE_W = 5;
					wire [72:0] exception;
					wire [31:0] exception_target_pc;
					wire mret;
					wire sret;
					wire [31:0] epc;
					localparam cva5_config_RETIRE_PORTS = 2;
					localparam cva5_types_LOG2_RETIRE_PORTS = 1;
					wire [5:0] retire;
					wire [5:0] retire_ids;
					wire [2:0] s_interrupt;
					wire [2:0] m_interrupt;
					reg busy;
					wire commit;
					reg commit_in_progress;
					reg [47:0] csr_inputs_r;
					reg [1:0] privilege_level;
					reg [1:0] next_privilege_level;
					wire supervisor_write;
					wire machine_write;
					reg [31:0] selected_csr;
					reg [31:0] selected_csr_r;
					reg [31:0] updated_csr;
					reg swrite;
					reg mwrite;
					function mwrite_en;
						input reg [11:0] addr;
						mwrite_en = mwrite & (csr_inputs_r[43-:8] == addr[7-:8]);
					endfunction
					function swrite_en;
						input reg [11:0] addr;
						swrite_en = swrite & (csr_inputs_r[43-:8] == addr[7-:8]);
					endfunction
					assign processing_csr = busy | cva5_wrapper.cva5.unit_issue[_mbase_issue].new_request;
					assign cva5_wrapper.cva5.unit_issue[_mbase_issue].ready = ~busy;
					always @(posedge clk)
						if (rst)
							busy <= 0;
						else
							busy <= (busy & ~cva5_wrapper.cva5.unit_wb[_mbase_wb].ack) | cva5_wrapper.cva5.unit_issue[_mbase_issue].new_request;
					always @(posedge clk)
						if (cva5_wrapper.cva5.unit_issue[_mbase_issue].new_request)
							csr_inputs_r <= csr_inputs;
					always @(posedge clk)
						if (rst)
							commit_in_progress <= 0;
						else
							commit_in_progress <= (commit_in_progress & ~cva5_wrapper.cva5.unit_issue[_mbase_issue].new_request) | commit;
					assign commit = ((retire_ids[cva5_types_LOG2_MAX_IDS+:cva5_types_LOG2_MAX_IDS] == cva5_wrapper.cva5.unit_wb[_mbase_wb].id) & busy) & ~commit_in_progress;
					always @(posedge clk)
						if (rst)
							cva5_wrapper.cva5.unit_wb[_mbase_wb].done <= 0;
						else
							cva5_wrapper.cva5.unit_wb[_mbase_wb].done <= (cva5_wrapper.cva5.unit_wb[_mbase_wb].done & ~cva5_wrapper.cva5.unit_wb[_mbase_wb].ack) | commit;
					always @(posedge clk)
						if (cva5_wrapper.cva5.unit_issue[_mbase_issue].new_request)
							cva5_wrapper.cva5.unit_wb[_mbase_wb].id <= cva5_wrapper.cva5.unit_issue[_mbase_issue].id;
					assign cva5_wrapper.cva5.unit_wb[_mbase_wb].rd = selected_csr_r;
					localparam [1:0] csr_types_CSR_READ_ONLY = 2'b11;
					always @(posedge clk) begin
						mwrite <= (CONFIG[1209] && commit) && ((csr_inputs_r[47-:2] != csr_types_CSR_READ_ONLY) && (csr_inputs_r[45-:2] == 2'b11));
						swrite <= (CONFIG[1208] && commit) && ((csr_inputs_r[47-:2] != csr_types_CSR_READ_ONLY) && (csr_inputs_r[45-:2] == 2'b01));
					end
					always @(posedge clk)
						if (commit)
							case (csr_inputs_r[35-:2])
								2'b01: updated_csr = csr_inputs_r[31-:riscv_types_XLEN];
								2'b10: updated_csr = selected_csr | csr_inputs_r[31-:riscv_types_XLEN];
								2'b11: updated_csr = selected_csr & ~csr_inputs_r[31-:riscv_types_XLEN];
								default: updated_csr = csr_inputs_r[31-:riscv_types_XLEN];
							endcase
					reg [31:0] misa = {11'h200, CONFIG[1207], 1'd0, CONFIG[1208], 5'h00, CONFIG[1206] && CONFIG[1205], 11'h080, CONFIG[1201]};
					reg [31:0] mvendorid = 0;
					reg [31:0] marchid = 0;
					reg [31:0] mimpid = CONFIG[1200-:32];
					reg [31:0] mhartid = CONFIG[1168-:32];
					reg [31:0] mstatush = 0;
					reg [31:0] mstatus;
					reg [31:0] mtvec;
					reg [31:0] medeleg;
					reg [31:0] mideleg;
					reg [31:0] mip;
					wire [31:0] mip_mask;
					wire [31:0] mip_w_mask;
					reg [31:0] mip_new;
					reg [31:0] mie;
					wire [31:0] mie_mask;
					wire [31:0] sip_mask;
					wire [31:0] sie_mask;
					reg [31:0] mepc;
					wire [31:0] mtimecmp;
					reg [31:0] mcause;
					reg [31:0] mtval;
					reg [31:0] mscratch;
					reg [31:0] mstatus_mask = {12'h000, CONFIG[1208], CONFIG[1207] & CONFIG[1208], CONFIG[1207] | CONFIG[1208], 8'h0c, CONFIG[1208], 2'h2, CONFIG[1208], 3'h2, CONFIG[1208], 1'd0};
					reg [31:0] sstatus_mask = 32'h000c0122;
					if (CONFIG[1209]) begin : gen_csr_m_mode
						wire [1:0] trap_return_privilege_level;
						reg [1:0] exception_privilege_level;
						reg [1:0] interrupt_privilege_level;
						reg [31:0] mstatus_exception;
						reg [31:0] mstatus_return;
						reg [31:0] mstatus_new;
						reg [4:0] interrupt_cause_r;
						always @(*) begin
							if (_sv2v_0)
								;
							exception_privilege_level = 2'b11;
							interrupt_privilege_level = 2'b11;
							if (CONFIG[1208] && |{privilege_level == 2'b01, privilege_level == 2'b00}) begin
								if (exception[72] & medeleg[exception[71-:5]])
									exception_privilege_level = 2'b01;
								if (interrupt_taken & mideleg[interrupt_cause_r])
									interrupt_privilege_level = 2'b01;
							end
						end
						assign trap_return_privilege_level = (mret ? sv2v_cast_2(mstatus[12-:2]) : sv2v_cast_2({1'b0, mstatus[8]}));
						always @(*) begin
							if (_sv2v_0)
								;
							if (mret | sret)
								next_privilege_level = trap_return_privilege_level;
							else if (interrupt_taken)
								next_privilege_level = interrupt_privilege_level;
							else if (exception[72])
								next_privilege_level = exception_privilege_level;
							else
								next_privilege_level = privilege_level;
						end
						always @(posedge clk)
							if (rst)
								privilege_level <= 2'b11;
							else
								privilege_level <= next_privilege_level;
						assign current_privilege = privilege_level;
						always @(*) begin
							if (_sv2v_0)
								;
							mstatus_exception = mstatus;
							case (next_privilege_level)
								2'b01: begin
									mstatus_exception[5] = (privilege_level == 2'b01 ? mstatus[1] : 0);
									mstatus_exception[1] = 0;
									mstatus_exception[8] = privilege_level[0];
								end
								default: begin
									mstatus_exception[7] = (privilege_level == 2'b11 ? mstatus[3] : (privilege_level == 2'b01 ? mstatus[1] : 0));
									mstatus_exception[3] = 0;
									mstatus_exception[12-:2] = privilege_level;
								end
							endcase
						end
						always @(*) begin
							if (_sv2v_0)
								;
							mstatus_return = mstatus;
							if (sret) begin
								mstatus_return[1] = mstatus[5];
								mstatus_return[5] = 1;
								mstatus_return[8] = 2'b00[0];
								mstatus_return[17] = 0;
							end
							else if (mret) begin
								mstatus_return[3] = mstatus[7];
								mstatus_return[7] = 1;
								mstatus_return[12-:2] = (CONFIG[1207] ? 2'b00 : 2'b11);
								if (mstatus[12-:2] != 2'b11)
									mstatus_return[17] = 0;
							end
						end
						wire [31:0] mstatus_write_mask;
						assign mstatus_write_mask = (swrite ? sstatus_mask : mstatus_mask);
						always @(cva5_wrapper.cva5.gen_csrs.csr_unit_block.gen_csr_m_mode.mstatus_return or cva5_wrapper.cva5.gen_csrs.csr_unit_block.sret or cva5_wrapper.cva5.gen_csrs.csr_unit_block.mret or cva5_wrapper.cva5.gen_csrs.csr_unit_block.gen_csr_m_mode.mstatus_exception or cva5_wrapper.cva5.gen_csrs.csr_unit_block.exception[72] or cva5_wrapper.cva5.gen_csrs.csr_unit_block.interrupt_taken or cva5_wrapper.cva5.gen_csrs.csr_unit_block.gen_csr_m_mode.mstatus_write_mask or cva5_wrapper.cva5.gen_csrs.csr_unit_block.updated_csr or cva5_wrapper.cva5.gen_csrs.csr_unit_block.gen_csr_m_mode.mstatus_write_mask or cva5_wrapper.cva5.gen_csrs.csr_unit_block.mstatus or cva5_wrapper.cva5.gen_csrs.csr_unit_block.csr_inputs_r[43-:8] or cva5_wrapper.cva5.gen_csrs.csr_unit_block.swrite or cva5_wrapper.cva5.gen_csrs.csr_unit_block.csr_inputs_r[43-:8] or cva5_wrapper.cva5.gen_csrs.csr_unit_block.mwrite or cva5_wrapper.cva5.gen_csrs.csr_unit_block.mstatus or _sv2v_0) begin
							if (_sv2v_0)
								;
							mstatus_new = mstatus;
							if (mwrite_en(12'h300) | swrite_en(12'h100))
								mstatus_new = (mstatus & ~mstatus_write_mask) | (updated_csr & mstatus_write_mask);
							else if (interrupt_taken | exception[72])
								mstatus_new = mstatus_exception;
							else if (mret | sret)
								mstatus_new = mstatus_return;
						end
						always @(posedge clk)
							if (rst)
								mstatus <= 32'h00001800;
							else
								mstatus <= mstatus_new;
						initial mtvec[31:2] = CONFIG[1104:1075];
						always @(posedge clk) begin
							mtvec[1:0] <= 1'sb0;
							if (CONFIG[1038] & mwrite_en(12'h305))
								mtvec[31:2] <= updated_csr[31:2];
						end
						assign exception_target_pc = mtvec;
						reg [31:0] medeleg_mask;
						always @(*) begin
							if (_sv2v_0)
								;
							medeleg_mask = 0;
							if (CONFIG[1208]) begin
								begin : sv2v_autoblock_44
									reg [4:0] sv2v_tmp_cast;
									sv2v_tmp_cast = 5'd0;
									medeleg_mask[sv2v_tmp_cast] = 1;
								end
								begin : sv2v_autoblock_45
									reg [4:0] sv2v_tmp_cast_1;
									sv2v_tmp_cast_1 = 5'd1;
									medeleg_mask[sv2v_tmp_cast_1] = 1;
								end
								begin : sv2v_autoblock_46
									reg [4:0] sv2v_tmp_cast_2;
									sv2v_tmp_cast_2 = 5'd2;
									medeleg_mask[sv2v_tmp_cast_2] = 1;
								end
								begin : sv2v_autoblock_47
									reg [4:0] sv2v_tmp_cast_3;
									sv2v_tmp_cast_3 = 5'd3;
									medeleg_mask[sv2v_tmp_cast_3] = 1;
								end
								begin : sv2v_autoblock_48
									reg [4:0] sv2v_tmp_cast_4;
									sv2v_tmp_cast_4 = 5'd4;
									medeleg_mask[sv2v_tmp_cast_4] = 1;
								end
								begin : sv2v_autoblock_49
									reg [4:0] sv2v_tmp_cast_5;
									sv2v_tmp_cast_5 = 5'd5;
									medeleg_mask[sv2v_tmp_cast_5] = 1;
								end
								begin : sv2v_autoblock_50
									reg [4:0] sv2v_tmp_cast_6;
									sv2v_tmp_cast_6 = 5'd6;
									medeleg_mask[sv2v_tmp_cast_6] = 1;
								end
								begin : sv2v_autoblock_51
									reg [4:0] sv2v_tmp_cast_7;
									sv2v_tmp_cast_7 = 5'd7;
									medeleg_mask[sv2v_tmp_cast_7] = 1;
								end
								begin : sv2v_autoblock_52
									reg [4:0] sv2v_tmp_cast_8;
									sv2v_tmp_cast_8 = 5'd8;
									medeleg_mask[sv2v_tmp_cast_8] = 1;
								end
								begin : sv2v_autoblock_53
									reg [4:0] sv2v_tmp_cast_9;
									sv2v_tmp_cast_9 = 5'd12;
									medeleg_mask[sv2v_tmp_cast_9] = 1;
								end
								begin : sv2v_autoblock_54
									reg [4:0] sv2v_tmp_cast_10;
									sv2v_tmp_cast_10 = 5'd13;
									medeleg_mask[sv2v_tmp_cast_10] = 1;
								end
								begin : sv2v_autoblock_55
									reg [4:0] sv2v_tmp_cast_11;
									sv2v_tmp_cast_11 = 5'd15;
									medeleg_mask[sv2v_tmp_cast_11] = 1;
								end
							end
						end
						always @(posedge clk)
							if (rst)
								medeleg <= 1'sb0;
							else if (mwrite_en(12'h302) & CONFIG[1208])
								medeleg <= updated_csr & medeleg_mask;
						reg [31:0] mideleg_mask;
						always @(*) begin
							if (_sv2v_0)
								;
							mideleg_mask = 0;
							if (CONFIG[1208]) begin
								begin : sv2v_autoblock_56
									reg [4:0] sv2v_tmp_cast;
									sv2v_tmp_cast = 5'd1;
									mideleg_mask[sv2v_tmp_cast] = CONFIG[1208];
								end
								begin : sv2v_autoblock_57
									reg [4:0] sv2v_tmp_cast_1;
									sv2v_tmp_cast_1 = 5'd5;
									mideleg_mask[sv2v_tmp_cast_1] = CONFIG[1208];
								end
								begin : sv2v_autoblock_58
									reg [4:0] sv2v_tmp_cast_2;
									sv2v_tmp_cast_2 = 5'd9;
									mideleg_mask[sv2v_tmp_cast_2] = CONFIG[1208];
								end
							end
						end
						always @(posedge clk)
							if (rst)
								mideleg <= 1'sb0;
							else if (mwrite_en(12'h303) & CONFIG[1208])
								mideleg <= updated_csr & mideleg_mask;
						assign mip_mask = {22'h000002, CONFIG[1208], 3'h2, CONFIG[1208], 3'h2, CONFIG[1208], 1'd0};
						assign mip_w_mask = {22'h000000, CONFIG[1208], 3'h0, CONFIG[1208], 3'h0, CONFIG[1208], 1'd0};
						always @(*) begin
							if (_sv2v_0)
								;
							mip_new = 1'sb0;
							mip_new[1] = s_interrupt[2];
							mip_new[5] = s_interrupt[1];
							mip_new[9] = s_interrupt[0];
							mip_new[3] = m_interrupt[2];
							mip_new[7] = m_interrupt[1];
							mip_new[11] = m_interrupt[0];
							mip_new = mip_new & mip_mask;
						end
						always @(posedge clk)
							if (rst)
								mip <= 0;
							else if (mwrite_en(12'h344) | (|mip_new))
								mip <= (updated_csr & mip_w_mask) | mip_new;
						assign interrupt_pending = |(mip & mie) & mstatus[3];
						assign mie_mask = {22'h000002, CONFIG[1208], 3'h2, CONFIG[1208], 3'h2, CONFIG[1208], 1'd0};
						assign sie_mask = 32'h00000222;
						always @(posedge clk)
							if (rst)
								mie <= 1'sb0;
							else if (mwrite_en(12'h304) | swrite_en(12'h104))
								mie <= updated_csr & (swrite ? sie_mask : mie_mask);
						always @(posedge clk) begin
							mepc[1:0] <= 1'sb0;
							if ((mwrite_en(12'h341) | exception[72]) | interrupt_taken)
								mepc[31:2] <= (exception[72] | interrupt_taken ? exception[34:5] : updated_csr[31:2]);
						end
						assign epc = mepc;
						reg [0:31] M_EXCEPTION_MASKING_ROM;
						reg [0:31] M_INTERRUPT_MASKING_ROM;
						always @(*) begin
							if (_sv2v_0)
								;
							M_EXCEPTION_MASKING_ROM = {32 {1'd0}};
							begin : sv2v_autoblock_59
								reg [4:0] sv2v_tmp_cast;
								sv2v_tmp_cast = 5'd0;
								M_EXCEPTION_MASKING_ROM[sv2v_tmp_cast] = 1;
							end
							begin : sv2v_autoblock_60
								reg [4:0] sv2v_tmp_cast_1;
								sv2v_tmp_cast_1 = 5'd1;
								M_EXCEPTION_MASKING_ROM[sv2v_tmp_cast_1] = CONFIG[1208];
							end
							begin : sv2v_autoblock_61
								reg [4:0] sv2v_tmp_cast_2;
								sv2v_tmp_cast_2 = 5'd2;
								M_EXCEPTION_MASKING_ROM[sv2v_tmp_cast_2] = 1;
							end
							begin : sv2v_autoblock_62
								reg [4:0] sv2v_tmp_cast_3;
								sv2v_tmp_cast_3 = 5'd3;
								M_EXCEPTION_MASKING_ROM[sv2v_tmp_cast_3] = 1;
							end
							begin : sv2v_autoblock_63
								reg [4:0] sv2v_tmp_cast_4;
								sv2v_tmp_cast_4 = 5'd4;
								M_EXCEPTION_MASKING_ROM[sv2v_tmp_cast_4] = 1;
							end
							begin : sv2v_autoblock_64
								reg [4:0] sv2v_tmp_cast_5;
								sv2v_tmp_cast_5 = 5'd5;
								M_EXCEPTION_MASKING_ROM[sv2v_tmp_cast_5] = CONFIG[1208];
							end
							begin : sv2v_autoblock_65
								reg [4:0] sv2v_tmp_cast_6;
								sv2v_tmp_cast_6 = 5'd6;
								M_EXCEPTION_MASKING_ROM[sv2v_tmp_cast_6] = 1;
							end
							begin : sv2v_autoblock_66
								reg [4:0] sv2v_tmp_cast_7;
								sv2v_tmp_cast_7 = 5'd7;
								M_EXCEPTION_MASKING_ROM[sv2v_tmp_cast_7] = CONFIG[1208];
							end
							begin : sv2v_autoblock_67
								reg [4:0] sv2v_tmp_cast_8;
								sv2v_tmp_cast_8 = 5'd8;
								M_EXCEPTION_MASKING_ROM[sv2v_tmp_cast_8] = CONFIG[1208];
							end
							begin : sv2v_autoblock_68
								reg [4:0] sv2v_tmp_cast_9;
								sv2v_tmp_cast_9 = 5'd9;
								M_EXCEPTION_MASKING_ROM[sv2v_tmp_cast_9] = CONFIG[1208];
							end
							begin : sv2v_autoblock_69
								reg [4:0] sv2v_tmp_cast_10;
								sv2v_tmp_cast_10 = 5'd11;
								M_EXCEPTION_MASKING_ROM[sv2v_tmp_cast_10] = 1;
							end
							begin : sv2v_autoblock_70
								reg [4:0] sv2v_tmp_cast_11;
								sv2v_tmp_cast_11 = 5'd12;
								M_EXCEPTION_MASKING_ROM[sv2v_tmp_cast_11] = CONFIG[1208];
							end
							begin : sv2v_autoblock_71
								reg [4:0] sv2v_tmp_cast_12;
								sv2v_tmp_cast_12 = 5'd13;
								M_EXCEPTION_MASKING_ROM[sv2v_tmp_cast_12] = CONFIG[1208];
							end
							begin : sv2v_autoblock_72
								reg [4:0] sv2v_tmp_cast_13;
								sv2v_tmp_cast_13 = 5'd15;
								M_EXCEPTION_MASKING_ROM[sv2v_tmp_cast_13] = CONFIG[1208];
							end
							M_INTERRUPT_MASKING_ROM = {32 {1'd0}};
							begin : sv2v_autoblock_73
								reg [4:0] sv2v_tmp_cast_14;
								sv2v_tmp_cast_14 = 5'd1;
								M_INTERRUPT_MASKING_ROM[sv2v_tmp_cast_14] = CONFIG[1208];
							end
							begin : sv2v_autoblock_74
								reg [4:0] sv2v_tmp_cast_15;
								sv2v_tmp_cast_15 = 5'd3;
								M_INTERRUPT_MASKING_ROM[sv2v_tmp_cast_15] = 1;
							end
							begin : sv2v_autoblock_75
								reg [4:0] sv2v_tmp_cast_16;
								sv2v_tmp_cast_16 = 5'd5;
								M_INTERRUPT_MASKING_ROM[sv2v_tmp_cast_16] = CONFIG[1208];
							end
							begin : sv2v_autoblock_76
								reg [4:0] sv2v_tmp_cast_17;
								sv2v_tmp_cast_17 = 5'd7;
								M_INTERRUPT_MASKING_ROM[sv2v_tmp_cast_17] = 1;
							end
							begin : sv2v_autoblock_77
								reg [4:0] sv2v_tmp_cast_18;
								sv2v_tmp_cast_18 = 5'd9;
								M_INTERRUPT_MASKING_ROM[sv2v_tmp_cast_18] = CONFIG[1208];
							end
							begin : sv2v_autoblock_78
								reg [4:0] sv2v_tmp_cast_19;
								sv2v_tmp_cast_19 = 5'd11;
								M_INTERRUPT_MASKING_ROM[sv2v_tmp_cast_19] = 1;
							end
						end
						reg mcause_write_valid;
						always @(*) begin
							if (_sv2v_0)
								;
							if (updated_csr[31])
								mcause_write_valid = M_INTERRUPT_MASKING_ROM[updated_csr[4:0]];
							else
								mcause_write_valid = M_EXCEPTION_MASKING_ROM[updated_csr[4:0]];
						end
						wire [31:0] mip_cause;
						wire [5:0] mip_priority_vector;
						wire [2:0] mip_cause_sel;
						function automatic [4:0] sv2v_cast_F41FD;
							input reg [4:0] inp;
							sv2v_cast_F41FD = inp;
						endfunction
						reg [39:0] interruput_code_table = {64'h0000000000000000, sv2v_cast_F41FD(5'd11), sv2v_cast_F41FD(5'd7), sv2v_cast_F41FD(5'd3), sv2v_cast_F41FD(5'd9), sv2v_cast_F41FD(5'd5), sv2v_cast_F41FD(5'd1)};
						assign mip_cause = mip & mie;
						assign mip_priority_vector = {mip_cause[11], mip_cause[7], mip_cause[3], mip_cause[9], mip_cause[5], mip_cause[1]};
						priority_encoder #(.WIDTH(6)) interrupt_cause_encoder(
							.priority_vector(mip_priority_vector),
							.encoded_result(mip_cause_sel)
						);
						always @(posedge clk)
							if (interrupt_pending)
								interrupt_cause_r <= interruput_code_table[mip_cause_sel * 5+:5];
						always @(posedge clk) begin
							mcause[30-:26] <= 1'sb0;
							if (rst) begin
								mcause[31] <= 0;
								mcause[4-:riscv_types_ECODE_W] <= 0;
							end
							else if (CONFIG[1036] & (((mcause_write_valid & mwrite_en(12'h342)) | exception[72]) | interrupt_taken)) begin
								mcause[31] <= interrupt_taken | (mwrite_en(12'h342) & updated_csr[31]);
								mcause[4-:riscv_types_ECODE_W] <= (interrupt_taken ? interrupt_cause_r : (exception[72] ? exception[71-:5] : updated_csr[4:0]));
							end
						end
						always @(posedge clk)
							if (CONFIG[1035] & (mwrite_en(12'h343) | exception[72]))
								mtval <= (exception[72] ? exception[66-:32] : updated_csr);
						always @(posedge clk)
							if (CONFIG[1037] & mwrite_en(12'h340))
								mscratch <= updated_csr;
					end
					wire [31:0] sepc;
					wire [31:0] stime;
					wire [31:0] stimecmp;
					wire [31:0] scause;
					wire [31:0] stval;
					wire [31:0] sstatus;
					reg [31:0] stvec;
					reg [31:0] satp;
					reg [31:0] sscratch;
					assign tlb_on = CONFIG[1208] & satp[31];
					assign asid = satp[30-:9];
					if (CONFIG[1208]) begin : gen_csr_s_mode
						assign cva5_wrapper.cva5.immu.mxr = mstatus[19];
						assign cva5_wrapper.cva5.dmmu.mxr = mstatus[19];
						assign cva5_wrapper.cva5.immu.sum = mstatus[18];
						assign cva5_wrapper.cva5.dmmu.sum = mstatus[18];
						assign cva5_wrapper.cva5.immu.privilege = privilege_level;
						assign cva5_wrapper.cva5.dmmu.privilege = (mstatus[17] ? mstatus[12-:2] : privilege_level);
						assign cva5_wrapper.cva5.immu.satp_ppn = satp[21-:22];
						assign cva5_wrapper.cva5.dmmu.satp_ppn = satp[21-:22];
						assign sip_mask = 32'h00000222;
						wire [31:0] stvec_mask;
						assign stvec_mask = 1'sb1;
						always @(posedge clk)
							if (rst)
								stvec <= {CONFIG[1136:1107], 2'b00};
							else if (swrite_en(12'h105))
								stvec <= updated_csr & stvec_mask;
						wire [31:0] satp_mask;
						assign satp_mask = 1'sb1;
						always @(posedge clk)
							if (rst)
								satp <= 0;
							else if (swrite_en(12'h180))
								satp <= updated_csr & satp_mask;
						always @(posedge clk)
							if (swrite_en(12'h140))
								sscratch <= updated_csr;
					end
					reg [CONFIG[1072-:32] - 1:0] mcycle;
					wire [CONFIG[1072-:32] - 1:0] mtime;
					reg [CONFIG[1072-:32] - 1:0] minst_ret;
					reg [CONFIG[1072-:32] - 1:0] mcycle_input_next;
					reg [CONFIG[1072-:32] - 1:0] minst_ret_input_next;
					wire [cva5_types_LOG2_RETIRE_PORTS:0] minst_ret_inc;
					wire mcycle_inc;
					always @(cva5_wrapper.cva5.gen_csrs.csr_unit_block.updated_csr[CONFIG[1072-:32] - 33:0] or cva5_wrapper.cva5.gen_csrs.csr_unit_block.csr_inputs_r[43-:8] or cva5_wrapper.cva5.gen_csrs.csr_unit_block.mwrite or cva5_wrapper.cva5.gen_csrs.csr_unit_block.updated_csr or cva5_wrapper.cva5.gen_csrs.csr_unit_block.csr_inputs_r[43-:8] or cva5_wrapper.cva5.gen_csrs.csr_unit_block.mwrite or cva5_wrapper.cva5.gen_csrs.csr_unit_block.mcycle or _sv2v_0) begin
						if (_sv2v_0)
							;
						mcycle_input_next = mcycle;
						if (CONFIG[1040] & mwrite_en(12'hb00))
							mcycle_input_next[31:0] = updated_csr;
						if (CONFIG[1040] & mwrite_en(12'hb80))
							mcycle_input_next[CONFIG[1072-:32] - 1:32] = updated_csr[CONFIG[1072-:32] - 33:0];
					end
					assign mcycle_inc = ~(CONFIG[1040] & (mwrite_en(12'hb00) | mwrite_en(12'hb80)));
					always @(posedge clk)
						if (rst)
							mcycle <= 0;
						else begin : sv2v_autoblock_79
							reg [CONFIG[1072-:32] - 1:0] sv2v_tmp_cast;
							sv2v_tmp_cast = mcycle_inc;
							mcycle <= mcycle_input_next + sv2v_tmp_cast;
						end
					always @(cva5_wrapper.cva5.gen_csrs.csr_unit_block.updated_csr[CONFIG[1072-:32] - 33:0] or cva5_wrapper.cva5.gen_csrs.csr_unit_block.csr_inputs_r[43-:8] or cva5_wrapper.cva5.gen_csrs.csr_unit_block.mwrite or cva5_wrapper.cva5.gen_csrs.csr_unit_block.updated_csr or cva5_wrapper.cva5.gen_csrs.csr_unit_block.csr_inputs_r[43-:8] or cva5_wrapper.cva5.gen_csrs.csr_unit_block.mwrite or cva5_wrapper.cva5.gen_csrs.csr_unit_block.minst_ret or _sv2v_0) begin
						if (_sv2v_0)
							;
						minst_ret_input_next = minst_ret;
						if (CONFIG[1039] & mwrite_en(12'hb02))
							minst_ret_input_next[31:0] = updated_csr;
						if (CONFIG[1039] & mwrite_en(12'hb82))
							minst_ret_input_next[CONFIG[1072-:32] - 1:32] = updated_csr[CONFIG[1072-:32] - 33:0];
					end
					assign minst_ret_inc = {2 {~(CONFIG[1039] & (mwrite_en(12'hb02) | mwrite_en(12'hb82)))}} & retire[1-:2];
					always @(posedge clk)
						if (rst)
							minst_ret <= 0;
						else begin : sv2v_autoblock_80
							reg [CONFIG[1072-:32] - 1:0] sv2v_tmp_cast_1;
							sv2v_tmp_cast_1 = minst_ret_inc;
							minst_ret <= minst_ret_input_next + sv2v_tmp_cast_1;
						end
					always @(*) begin
						if (_sv2v_0)
							;
						if (csr_inputs_r[47-:12] == 12'h301)
							selected_csr = (CONFIG[1209] ? misa : 0);
						else if (csr_inputs_r[47-:12] == 12'hf11)
							selected_csr = (CONFIG[1209] ? mvendorid : 0);
						else if (csr_inputs_r[47-:12] == 12'hf12)
							selected_csr = (CONFIG[1209] ? marchid : 0);
						else if (csr_inputs_r[47-:12] == 12'hf13)
							selected_csr = (CONFIG[1209] ? mimpid : 0);
						else if (csr_inputs_r[47-:12] == 12'hf14)
							selected_csr = (CONFIG[1209] ? mhartid : 0);
						else if (csr_inputs_r[47-:12] == 12'h300)
							selected_csr = (CONFIG[1209] ? mstatus : 0);
						else if (csr_inputs_r[47-:12] == 12'h302)
							selected_csr = (CONFIG[1209] ? medeleg : 0);
						else if (csr_inputs_r[47-:12] == 12'h303)
							selected_csr = (CONFIG[1209] ? mideleg : 0);
						else if (csr_inputs_r[47-:12] == 12'h304)
							selected_csr = (CONFIG[1209] ? mie : 0);
						else if (csr_inputs_r[47-:12] == 12'h305)
							selected_csr = (CONFIG[1209] ? mtvec : 0);
						else if (csr_inputs_r[47-:12] == 12'h306)
							selected_csr = 0;
						else if (csr_inputs_r[47-:12] == 12'h340)
							selected_csr = (CONFIG[1209] ? mscratch : 0);
						else if (csr_inputs_r[47-:12] == 12'h341)
							selected_csr = (CONFIG[1209] ? mepc : 0);
						else if (csr_inputs_r[47-:12] == 12'h342)
							selected_csr = (CONFIG[1209] ? mcause : 0);
						else if (csr_inputs_r[47-:12] == 12'h343)
							selected_csr = (CONFIG[1209] ? mtval : 0);
						else if (csr_inputs_r[47-:12] == 12'h344)
							selected_csr = (CONFIG[1209] ? mip : 0);
						else if ((12'h3ef <= csr_inputs_r[47-:12]) && (12'h3a0 >= csr_inputs_r[47-:12]))
							selected_csr = 0;
						else if (csr_inputs_r[47-:12] == 12'hb00)
							selected_csr = (CONFIG[1209] ? mcycle[31:0] : 0);
						else if (csr_inputs_r[47-:12] == 12'hb02)
							selected_csr = (CONFIG[1209] ? minst_ret[31:0] : 0);
						else if ((12'hb03 <= csr_inputs_r[47-:12]) && (12'hb1f >= csr_inputs_r[47-:12]))
							selected_csr = 0;
						else if (csr_inputs_r[47-:12] == 12'hb80)
							selected_csr = (CONFIG[1209] ? sv2v_cast_32(mcycle[CONFIG[1072-:32] - 1:riscv_types_XLEN]) : 0);
						else if (csr_inputs_r[47-:12] == 12'hb82)
							selected_csr = (CONFIG[1209] ? sv2v_cast_32(minst_ret[CONFIG[1072-:32] - 1:riscv_types_XLEN]) : 0);
						else if ((12'hb83 <= csr_inputs_r[47-:12]) && (12'hb9f >= csr_inputs_r[47-:12]))
							selected_csr = 0;
						else if ((12'h320 <= csr_inputs_r[47-:12]) && (12'h33f >= csr_inputs_r[47-:12]))
							selected_csr = 0;
						else if (csr_inputs_r[47-:12] == 12'h100)
							selected_csr = (CONFIG[1208] ? mstatus & sstatus_mask : {32 {1'sb0}});
						else if (csr_inputs_r[47-:12] == 12'h102)
							selected_csr = 0;
						else if (csr_inputs_r[47-:12] == 12'h103)
							selected_csr = 0;
						else if (csr_inputs_r[47-:12] == 12'h104)
							selected_csr = (CONFIG[1208] ? mie & sie_mask : {32 {1'sb0}});
						else if (csr_inputs_r[47-:12] == 12'h105)
							selected_csr = (CONFIG[1208] ? stvec : {32 {1'sb0}});
						else if (csr_inputs_r[47-:12] == 12'h106)
							selected_csr = 0;
						else if (csr_inputs_r[47-:12] == 12'h140)
							selected_csr = (CONFIG[1208] ? sscratch : {32 {1'sb0}});
						else if (csr_inputs_r[47-:12] == 12'h141)
							selected_csr = (CONFIG[1208] ? sscratch : {32 {1'sb0}});
						else if (csr_inputs_r[47-:12] == 12'h142)
							selected_csr = (CONFIG[1208] ? sscratch : {32 {1'sb0}});
						else if (csr_inputs_r[47-:12] == 12'h143)
							selected_csr = (CONFIG[1208] ? sscratch : {32 {1'sb0}});
						else if (csr_inputs_r[47-:12] == 12'h144)
							selected_csr = (CONFIG[1208] ? mip & sip_mask : {32 {1'sb0}});
						else if (csr_inputs_r[47-:12] == 12'h180)
							selected_csr = (CONFIG[1208] ? satp : {32 {1'sb0}});
						else if (csr_inputs_r[47-:12] == 12'h001)
							selected_csr = 0;
						else if (csr_inputs_r[47-:12] == 12'h002)
							selected_csr = 0;
						else if (csr_inputs_r[47-:12] == 12'h003)
							selected_csr = 0;
						else if (csr_inputs_r[47-:12] == 12'hc00)
							selected_csr = mcycle[31:0];
						else if (csr_inputs_r[47-:12] == 12'hc01)
							selected_csr = mcycle[31:0];
						else if (csr_inputs_r[47-:12] == 12'hc02)
							selected_csr = minst_ret[31:0];
						else if ((12'hc03 <= csr_inputs_r[47-:12]) && (12'hc1f >= csr_inputs_r[47-:12]))
							selected_csr = 0;
						else if (csr_inputs_r[47-:12] == 12'hc80)
							selected_csr = sv2v_cast_32(mcycle[CONFIG[1072-:32] - 1:riscv_types_XLEN]);
						else if (csr_inputs_r[47-:12] == 12'hc81)
							selected_csr = sv2v_cast_32(mcycle[CONFIG[1072-:32] - 1:riscv_types_XLEN]);
						else if (csr_inputs_r[47-:12] == 12'hc82)
							selected_csr = sv2v_cast_32(minst_ret[CONFIG[1072-:32] - 1:riscv_types_XLEN]);
						else if ((12'hc83 <= csr_inputs_r[47-:12]) && (12'hc9f >= csr_inputs_r[47-:12]))
							selected_csr = 0;
						else
							selected_csr = 0;
					end
					always @(posedge clk)
						if (commit)
							selected_csr_r <= selected_csr;
					initial _sv2v_0 = 0;
				end
				assign csr_unit_block.clk = clk;
				assign csr_unit_block.rst = rst;
				assign csr_unit_block.csr_inputs = csr_inputs;
				assign current_privilege = csr_unit_block.current_privilege;
				assign csr_unit_block.interrupt_taken = interrupt_taken;
				assign interrupt_pending = csr_unit_block.interrupt_pending;
				assign processing_csr = csr_unit_block.processing_csr;
				assign tlb_on = csr_unit_block.tlb_on;
				assign asid = csr_unit_block.asid;
				assign csr_unit_block.exception = gc[105-:73];
				assign exception_target_pc = csr_unit_block.exception_target_pc;
				assign csr_unit_block.mret = mret;
				assign csr_unit_block.sret = sret;
				assign epc = csr_unit_block.epc;
				assign csr_unit_block.retire = retire;
				assign csr_unit_block.retire_ids = retire_ids;
				assign csr_unit_block.s_interrupt = s_interrupt;
				assign csr_unit_block.m_interrupt = m_interrupt;
			end
			localparam _bbase_FA6DF_issue = UNIT_IDS[31-:32];
			localparam _bbase_FA6DF_exception = 0;
			localparam _param_FA6DF_CONFIG = CONFIG;
			if (1) begin : gc_unit_block
				reg _sv2v_0;
				localparam [1209:0] cva5_config_EXAMPLE_CONFIG = 1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002;
				localparam [1209:0] CONFIG = _param_FA6DF_CONFIG;
				wire clk;
				wire rst;
				localparam _mbase_issue = _bbase_FA6DF_issue;
				wire [34:0] gc_inputs;
				wire issue_stage_valid;
				wire branch_flush;
				localparam cva5_config_NUM_EXCEPTION_SOURCES = 3;
				localparam _mbase_exception = 0;
				wire [31:0] exception_target_pc;
				wire [31:0] oldest_pc;
				wire mret;
				wire sret;
				wire [31:0] epc;
				localparam cva5_config_RETIRE_PORTS = 2;
				localparam cva5_types_LOG2_RETIRE_PORTS = 1;
				localparam cva5_config_MAX_IDS = 8;
				localparam cva5_types_LOG2_MAX_IDS = 3;
				wire [5:0] retire;
				wire [5:0] retire_ids;
				wire [5:0] retire_ids_next;
				wire [1:0] current_exception_unit;
				wire interrupt_pending;
				wire interrupt_taken;
				wire processing_csr;
				localparam riscv_types_ECODE_W = 5;
				reg [115:0] gc;
				wire [2:0] load_store_status;
				wire [cva5_types_LOG2_MAX_IDS:0] post_issue_count;
				localparam signed [31:0] TLB_CLEAR_DEPTH = (CONFIG[452-:32] > CONFIG[743-:32] ? CONFIG[452-:32] : CONFIG[743-:32]);
				localparam signed [31:0] INIT_CLEAR_DEPTH = (CONFIG[1208] ? (TLB_CLEAR_DEPTH > 64 ? TLB_CLEAR_DEPTH : 64) : 64);
				reg [31:0] state;
				reg [31:0] next_state;
				wire init_clear_done;
				wire tlb_clear_done;
				reg [34:0] gc_inputs_r;
				wire post_issue_idle;
				reg ifence_in_progress;
				reg ret_in_progress;
				reg gc_init_clear;
				reg gc_fetch_hold;
				reg gc_rename_hold;
				reg gc_issue_hold;
				wire gc_fetch_flush;
				reg gc_writeback_supress;
				reg gc_retire_hold;
				reg gc_tlb_flush;
				reg gc_sq_flush;
				reg gc_pc_override;
				reg [31:0] gc_pc;
				always @(posedge clk)
					if (cva5_wrapper.cva5.unit_issue[_mbase_issue].new_request)
						gc_inputs_r <= gc_inputs;
				always @(posedge clk)
					if (rst)
						ret_in_progress <= 0;
					else
						ret_in_progress <= (ret_in_progress & ~(next_state == 32'd7)) | (cva5_wrapper.cva5.unit_issue[_mbase_issue].new_request & (gc_inputs[1] | gc_inputs[0]));
				always @(posedge clk)
					if (rst)
						ifence_in_progress <= 0;
					else
						ifence_in_progress <= (ifence_in_progress & ~(next_state == 32'd7)) | (cva5_wrapper.cva5.unit_issue[_mbase_issue].new_request & gc_inputs[2]);
				assign post_issue_idle = (post_issue_count == 0) & load_store_status[2];
				wire [1:1] sv2v_tmp_1347E;
				assign sv2v_tmp_1347E = branch_flush | gc_pc_override;
				always @(*) gc[111] = sv2v_tmp_1347E;
				always @(posedge clk) begin
					gc_fetch_hold <= |{next_state == 32'd1, next_state == 32'd2, next_state == 32'd6, next_state == 32'd7};
					gc_rename_hold <= next_state == 32'd8;
					gc_issue_hold <= processing_csr | (|{next_state == 32'd1, next_state == 32'd2, next_state == 32'd4, next_state == 32'd5, next_state == 32'd6, next_state == 32'd7, next_state == 32'd8});
					gc_writeback_supress <= |{next_state == 32'd1, next_state == 32'd2, next_state == 32'd8};
					gc_retire_hold <= next_state == 32'd7;
					gc_init_clear <= next_state == 32'd2;
					gc_tlb_flush <= |{next_state == 32'd2, next_state == 32'd4};
					gc_sq_flush <= (state == 32'd8) & (next_state == 32'd3);
				end
				wire [1:1] sv2v_tmp_01786;
				assign sv2v_tmp_01786 = gc_fetch_hold;
				always @(*) gc[114] = sv2v_tmp_01786;
				wire [1:1] sv2v_tmp_3DAB0;
				assign sv2v_tmp_3DAB0 = gc_rename_hold;
				always @(*) gc[113] = sv2v_tmp_3DAB0;
				wire [1:1] sv2v_tmp_4A98D;
				assign sv2v_tmp_4A98D = gc_issue_hold;
				always @(*) gc[112] = sv2v_tmp_4A98D;
				wire [1:1] sv2v_tmp_8B6CB;
				assign sv2v_tmp_8B6CB = CONFIG[1209] & gc_writeback_supress;
				always @(*) gc[110] = sv2v_tmp_8B6CB;
				wire [1:1] sv2v_tmp_CAAED;
				assign sv2v_tmp_CAAED = gc_retire_hold;
				always @(*) gc[109] = sv2v_tmp_CAAED;
				wire [1:1] sv2v_tmp_92BE1;
				assign sv2v_tmp_92BE1 = gc_init_clear;
				always @(*) gc[115] = sv2v_tmp_92BE1;
				wire [1:1] sv2v_tmp_85A77;
				assign sv2v_tmp_85A77 = CONFIG[1208] & gc_tlb_flush;
				always @(*) gc[107] = sv2v_tmp_85A77;
				wire [1:1] sv2v_tmp_75043;
				assign sv2v_tmp_75043 = CONFIG[1209] & gc_sq_flush;
				always @(*) gc[108] = sv2v_tmp_75043;
				always @(posedge clk)
					if (rst)
						state <= 32'd0;
					else
						state <= next_state;
				wire possible_exception;
				assign possible_exception = post_issue_count != {4 {1'sb0}};
				always @(*) begin
					if (_sv2v_0)
						;
					next_state = state;
					case (state)
						32'd0: next_state = 32'd1;
						32'd1: next_state = 32'd2;
						32'd2:
							if (init_clear_done)
								next_state = 32'd3;
						32'd3:
							if (gc[105])
								next_state = 32'd7;
							else if (cva5_wrapper.cva5.unit_issue[_mbase_issue].new_request | gc[106])
								next_state = 32'd6;
							else if (interrupt_pending)
								next_state = 32'd5;
						32'd5:
							if (gc[105])
								next_state = 32'd7;
							else if (gc[106])
								next_state = 32'd6;
							else if (~interrupt_pending)
								next_state = 32'd3;
							else if (((~possible_exception & issue_stage_valid) & ~branch_flush) & post_issue_idle)
								next_state = 32'd7;
						32'd4:
							if (tlb_clear_done)
								next_state = 32'd3;
						32'd6:
							if (((ifence_in_progress | ret_in_progress) & post_issue_idle) | gc[105])
								next_state = 32'd7;
						32'd7: next_state = 32'd8;
						32'd8:
							if (((post_issue_count == 0) & load_store_status[1]) & cva5_wrapper.scaiev.no_writebacks_pending)
								next_state = 32'd3;
						default: next_state = 32'd0;
					endcase
				end
				reg [$clog2(INIT_CLEAR_DEPTH):0] state_counter;
				always @(posedge clk)
					if (rst | (next_state == 32'd3))
						state_counter <= 0;
					else if (|{next_state == 32'd2, next_state == 32'd4})
						state_counter <= state_counter + 1;
				assign init_clear_done = state_counter[$clog2(INIT_CLEAR_DEPTH)];
				assign tlb_clear_done = state_counter[$clog2(TLB_CLEAR_DEPTH)];
				if (CONFIG[1209]) begin : gen_gc_m_mode
					wire [2:0] exception_pending;
					wire [14:0] exception_code;
					wire [8:0] exception_id;
					wire [95:0] exception_tval;
					wire exception_ack;
					genvar _gv_i_5;
					for (_gv_i_5 = 0; _gv_i_5 < cva5_config_NUM_EXCEPTION_SOURCES; _gv_i_5 = _gv_i_5 + 1) begin : genblk1
						localparam i = _gv_i_5;
						assign exception_pending[i] = cva5_wrapper.cva5.exception[i + _mbase_exception].valid;
						assign exception_code[i * riscv_types_ECODE_W+:riscv_types_ECODE_W] = cva5_wrapper.cva5.exception[i + _mbase_exception].code;
						assign exception_id[i * cva5_types_LOG2_MAX_IDS+:cva5_types_LOG2_MAX_IDS] = cva5_wrapper.cva5.exception[i + _mbase_exception].id;
						assign exception_tval[i * 32+:32] = cva5_wrapper.cva5.exception[i + _mbase_exception].tval;
						assign cva5_wrapper.cva5.exception[i + _mbase_exception].ack = exception_ack;
					end
					always @(*) begin
						if (_sv2v_0)
							;
						gc[106] = |exception_pending;
						gc[105] = (retire_ids_next[cva5_types_LOG2_MAX_IDS+:cva5_types_LOG2_MAX_IDS] == exception_id[current_exception_unit * cva5_types_LOG2_MAX_IDS+:cva5_types_LOG2_MAX_IDS]) & exception_pending[current_exception_unit];
						gc[67-:32] = oldest_pc;
						gc[104-:5] = exception_code[current_exception_unit * riscv_types_ECODE_W+:riscv_types_ECODE_W];
						gc[99-:32] = exception_tval[current_exception_unit * 32+:32];
					end
					assign exception_ack = gc[105];
					assign interrupt_taken = (interrupt_pending & (next_state == 32'd7)) & ~((ifence_in_progress | ret_in_progress) | gc[105]);
					assign mret = (gc_inputs_r[1] & ret_in_progress) & (next_state == 32'd7);
					assign sret = (gc_inputs_r[0] & ret_in_progress) & (next_state == 32'd7);
				end
				if (CONFIG[1209] || CONFIG[1203]) begin : gen_gc_pc_override
					always @(posedge clk) begin
						gc_pc_override <= |{next_state == 32'd7, next_state == 32'd2};
						gc_pc <= (gc[105] | interrupt_taken ? exception_target_pc : (gc_inputs_r[2] ? gc_inputs_r[34-:32] : epc));
					end
					wire [1:1] sv2v_tmp_BABAF;
					assign sv2v_tmp_BABAF = gc_pc_override;
					always @(*) gc[32] = sv2v_tmp_BABAF;
					wire [32:1] sv2v_tmp_A0C24;
					assign sv2v_tmp_A0C24 = gc_pc;
					always @(*) gc[31-:32] = sv2v_tmp_A0C24;
				end
				assign cva5_wrapper.cva5.unit_issue[_mbase_issue].ready = 1;
				initial _sv2v_0 = 0;
			end
			assign gc_unit_block.clk = clk;
			assign gc_unit_block.rst = rst;
			assign gc_unit_block.gc_inputs = gc_inputs;
			assign gc_unit_block.issue_stage_valid = issue[6];
			assign gc_unit_block.branch_flush = branch_flush;
			assign gc_unit_block.exception_target_pc = exception_target_pc;
			assign gc_unit_block.current_exception_unit = current_exception_unit;
			assign gc = gc_unit_block.gc;
			assign gc_unit_block.oldest_pc = oldest_pc;
			assign mret = gc_unit_block.mret;
			assign sret = gc_unit_block.sret;
			assign gc_unit_block.epc = epc;
			assign gc_unit_block.retire = retire;
			assign gc_unit_block.retire_ids = retire_ids;
			assign gc_unit_block.retire_ids_next = retire_ids_next;
			assign interrupt_taken = gc_unit_block.interrupt_taken;
			assign gc_unit_block.interrupt_pending = interrupt_pending;
			assign gc_unit_block.processing_csr = processing_csr;
			assign gc_unit_block.load_store_status = load_store_status;
			assign gc_unit_block.post_issue_count = post_issue_count;
			if (CONFIG[1206]) begin : gen_mul
				localparam _bbase_9E930_issue = UNIT_IDS[159-:32];
				localparam _bbase_9E930_wb = UNIT_IDS[159-:32];
				if (1) begin : mul_unit_block
					wire clk;
					wire rst;
					localparam riscv_types_XLEN = 32;
					wire [65:0] mul_inputs;
					localparam _mbase_issue = _bbase_9E930_issue;
					localparam _mbase_wb = _bbase_9E930_wb;
					reg signed [63:0] result;
					reg mulh [0:1];
					reg valid [0:1];
					localparam cva5_config_MAX_IDS = 8;
					localparam cva5_types_LOG2_MAX_IDS = 3;
					reg [2:0] id [0:1];
					wire rs1_is_signed;
					wire rs2_is_signed;
					wire signed [32:0] rs1_ext;
					wire signed [32:0] rs2_ext;
					reg signed [32:0] rs1_r;
					reg signed [32:0] rs2_r;
					wire stage1_advance;
					wire stage2_advance;
					assign rs1_is_signed = |{((3'b001[1:0] ^ (mul_inputs[1:0] ^ mul_inputs[1:0])) === (mul_inputs[1:0] ^ (3'b001[1:0] ^ 3'b001[1:0]))) & ((((mul_inputs[1:0] ^ mul_inputs[1:0]) ^ (3'b001[1:0] ^ 3'b001[1:0])) === (3'b001[1:0] ^ 3'b001[1:0])) | 1'bx), ((3'b010[1:0] ^ (mul_inputs[1:0] ^ mul_inputs[1:0])) === (mul_inputs[1:0] ^ (3'b010[1:0] ^ 3'b010[1:0]))) & ((((mul_inputs[1:0] ^ mul_inputs[1:0]) ^ (3'b010[1:0] ^ 3'b010[1:0])) === (3'b010[1:0] ^ 3'b010[1:0])) | 1'bx)};
					assign rs2_is_signed = |{((3'b000[1:0] ^ (mul_inputs[1:0] ^ mul_inputs[1:0])) === (mul_inputs[1:0] ^ (3'b000[1:0] ^ 3'b000[1:0]))) & ((((mul_inputs[1:0] ^ mul_inputs[1:0]) ^ (3'b000[1:0] ^ 3'b000[1:0])) === (3'b000[1:0] ^ 3'b000[1:0])) | 1'bx), ((3'b001[1:0] ^ (mul_inputs[1:0] ^ mul_inputs[1:0])) === (mul_inputs[1:0] ^ (3'b001[1:0] ^ 3'b001[1:0]))) & ((((mul_inputs[1:0] ^ mul_inputs[1:0]) ^ (3'b001[1:0] ^ 3'b001[1:0])) === (3'b001[1:0] ^ 3'b001[1:0])) | 1'bx)};
					assign rs1_ext = $signed({mul_inputs[65] & rs1_is_signed, mul_inputs[65-:32]});
					assign rs2_ext = $signed({mul_inputs[33] & rs2_is_signed, mul_inputs[33-:32]});
					assign cva5_wrapper.cva5.unit_issue[_mbase_issue].ready = stage1_advance;
					assign stage1_advance = ~valid[0] | stage2_advance;
					assign stage2_advance = ~valid[1] | cva5_wrapper.cva5.unit_wb[_mbase_wb].ack;
					always @(posedge clk) begin
						if (stage1_advance) begin
							rs1_r <= rs1_ext;
							rs2_r <= rs2_ext;
						end
						if (stage2_advance)
							result <= sv2v_cast_64_signed(rs1_r * rs2_r);
					end
					always @(posedge clk) begin
						if (stage1_advance) begin
							mulh[0] <= mul_inputs[1:0] != 3'b000[1:0];
							id[0] <= cva5_wrapper.cva5.unit_issue[_mbase_issue].id;
						end
						if (stage2_advance) begin
							mulh[1] <= mulh[0];
							id[1] <= id[0];
						end
					end
					always @(posedge clk)
						if (rst) begin
							valid[0] <= 1'b0;
							valid[1] <= 1'b0;
						end
						else begin
							valid[0] <= (stage1_advance ? cva5_wrapper.cva5.unit_issue[_mbase_issue].new_request : valid[0]);
							valid[1] <= (stage2_advance ? valid[0] : valid[1]);
						end
					assign cva5_wrapper.cva5.unit_wb[_mbase_wb].rd = (mulh[1] ? result[63:32] : result[31:0]);
					wire [1:1] sv2v_tmp_CF3F8;
					assign sv2v_tmp_CF3F8 = valid[1];
					always @(*) cva5_wrapper.cva5.unit_wb[_mbase_wb].done = sv2v_tmp_CF3F8;
					wire [3:1] sv2v_tmp_D5EA5;
					assign sv2v_tmp_D5EA5 = id[1];
					always @(*) cva5_wrapper.cva5.unit_wb[_mbase_wb].id = sv2v_tmp_D5EA5;
				end
				assign mul_unit_block.clk = clk;
				assign mul_unit_block.rst = rst;
				assign mul_unit_block.mul_inputs = mul_inputs;
			end
			if (CONFIG[1205]) begin : gen_div
				localparam _bbase_C47FF_issue = UNIT_IDS[127-:32];
				localparam _bbase_C47FF_wb = UNIT_IDS[127-:32];
				if (1) begin : div_unit_block
					wire clk;
					wire rst;
					localparam riscv_types_XLEN = 32;
					wire [66:0] div_inputs;
					localparam _mbase_issue = _bbase_C47FF_issue;
					localparam _mbase_wb = _bbase_C47FF_wb;
					wire signed_divop;
					wire negate_quotient;
					wire negate_remainder;
					wire negate_dividend;
					wire negate_divisor;
					wire remainder_op;
					wire [31:0] unsigned_dividend;
					wire [31:0] unsigned_divisor;
					wire [4:0] dividend_CLZ;
					wire [4:0] divisor_CLZ;
					wire divisor_is_zero;
					localparam cva5_config_MAX_IDS = 8;
					localparam cva5_types_LOG2_MAX_IDS = 3;
					wire [80:0] issue_fifo_inputs;
					wire [80:0] div_stage;
					reg [6:0] wb_attr;
					localparam _param_A43C5_DATA_WIDTH = 32;
					if (1) begin : div_core
						localparam DATA_WIDTH = _param_A43C5_DATA_WIDTH;
						wire start;
						wire [31:0] dividend;
						wire [4:0] dividend_CLZ;
						wire [31:0] divisor;
						wire [4:0] divisor_CLZ;
						reg [31:0] remainder;
						reg [31:0] quotient;
						wire done;
						wire divisor_is_zero;
					end
					wire in_progress;
					wire div_done;
					localparam _param_29143_DATA_WIDTH = 81;
					if (1) begin : input_fifo
						localparam DATA_WIDTH = _param_29143_DATA_WIDTH;
						wire push;
						wire pop;
						wire [80:0] data_in;
						reg [80:0] data_out;
						reg valid;
						wire full;
						wire potential_push;
					end
					localparam _param_B366D_DATA_WIDTH = riscv_types_XLEN;
					if (1) begin : wb_fifo
						localparam DATA_WIDTH = _param_B366D_DATA_WIDTH;
						wire push;
						wire pop;
						wire [31:0] data_in;
						wire [31:0] data_out;
						wire valid;
						wire full;
						wire potential_push;
					end
					function [31:0] negate_if;
						input reg [31:0] a;
						input reg b;
						negate_if = ({32 {b}} ^ a) + sv2v_cast_32(b);
					endfunction
					assign signed_divop = ~div_inputs[1];
					assign negate_dividend = signed_divop & div_inputs[66];
					assign negate_divisor = signed_divop & div_inputs[34];
					assign negate_quotient = signed_divop & (div_inputs[66] ^ div_inputs[34]);
					assign negate_remainder = signed_divop & div_inputs[66];
					assign unsigned_dividend = negate_if(div_inputs[66-:32], negate_dividend);
					assign unsigned_divisor = negate_if(div_inputs[34-:32], negate_divisor);
					clz dividend_clz_block(
						.clz_input(unsigned_dividend),
						.clz(dividend_CLZ)
					);
					clz divisor_clz_block(
						.clz_input(unsigned_divisor),
						.clz(divisor_CLZ)
					);
					assign divisor_is_zero = &divisor_CLZ & ~div_inputs[3];
					assign issue_fifo_inputs[80-:32] = unsigned_dividend;
					assign issue_fifo_inputs[48-:32] = unsigned_divisor;
					assign issue_fifo_inputs[16-:5] = (divisor_is_zero ? {5 {1'sb0}} : dividend_CLZ);
					assign issue_fifo_inputs[11-:5] = divisor_CLZ;
					assign issue_fifo_inputs[6] = div_inputs[2];
					assign issue_fifo_inputs[5] = (div_inputs[2] ? negate_remainder : negate_quotient & ~divisor_is_zero);
					assign issue_fifo_inputs[4] = divisor_is_zero;
					assign issue_fifo_inputs[3] = div_inputs[0];
					assign issue_fifo_inputs[2-:cva5_types_LOG2_MAX_IDS] = cva5_wrapper.cva5.unit_issue[_mbase_issue].id;
					localparam _param_41690_DATA_WIDTH = 81;
					localparam _param_41690_FIFO_DEPTH = 1;
					if (1) begin : div_input_fifo
						localparam DATA_WIDTH = _param_41690_DATA_WIDTH;
						localparam FIFO_DEPTH = _param_41690_FIFO_DEPTH;
						wire clk;
						wire rst;
						localparam LOG2_FIFO_DEPTH = 0;
						if (1) begin : gen_width_one
							always @(posedge clk)
								if (rst)
									cva5_wrapper.cva5.gen_div.div_unit_block.input_fifo.valid <= 0;
								else
									cva5_wrapper.cva5.gen_div.div_unit_block.input_fifo.valid <= cva5_wrapper.cva5.gen_div.div_unit_block.input_fifo.push | (cva5_wrapper.cva5.gen_div.div_unit_block.input_fifo.valid & ~cva5_wrapper.cva5.gen_div.div_unit_block.input_fifo.pop);
							assign cva5_wrapper.cva5.gen_div.div_unit_block.input_fifo.full = cva5_wrapper.cva5.gen_div.div_unit_block.input_fifo.valid;
							always @(posedge clk)
								if (cva5_wrapper.cva5.gen_div.div_unit_block.input_fifo.potential_push)
									cva5_wrapper.cva5.gen_div.div_unit_block.input_fifo.data_out <= cva5_wrapper.cva5.gen_div.div_unit_block.input_fifo.data_in;
						end
					end
					assign div_input_fifo.clk = clk;
					assign div_input_fifo.rst = rst;
					wire div_ready;
					assign div_ready = ~in_progress | cva5_wrapper.cva5.unit_wb[_mbase_wb].ack;
					assign input_fifo.data_in = issue_fifo_inputs;
					assign input_fifo.push = cva5_wrapper.cva5.unit_issue[_mbase_issue].new_request;
					assign input_fifo.potential_push = cva5_wrapper.cva5.unit_issue[_mbase_issue].possible_issue;
					assign cva5_wrapper.cva5.unit_issue[_mbase_issue].ready = ~input_fifo.full | ~in_progress;
					assign input_fifo.pop = input_fifo.valid & div_ready;
					assign div_stage = input_fifo.data_out;
					assign div_core.start = input_fifo.pop & ~div_stage[3];
					assign div_done = div_core.done | (input_fifo.pop & div_stage[3]);
					set_clr_reg_with_rst #(
						.SET_OVER_CLR(1),
						.WIDTH(1),
						.RST_VALUE(1'sb0)
					) in_progress_m(
						.clk(clk),
						.rst(rst),
						.set(input_fifo.pop),
						.clr(cva5_wrapper.cva5.unit_wb[_mbase_wb].ack),
						.result(in_progress)
					);
					always @(posedge clk)
						if (input_fifo.pop)
							wb_attr <= div_stage[6-:7];
					assign div_core.dividend = div_stage[80-:32];
					assign div_core.divisor = div_stage[48-:32];
					assign div_core.dividend_CLZ = div_stage[16-:5];
					assign div_core.divisor_CLZ = div_stage[11-:5];
					assign div_core.divisor_is_zero = div_stage[4];
					localparam _param_6DE45_DIV_WIDTH = 32;
					if (1) begin : divider_block
						localparam DIV_WIDTH = _param_6DE45_DIV_WIDTH;
						wire clk;
						wire rst;
						localparam CLZ_W = 5;
						wire [4:0] CLZ_delta;
						wire divisor_greater_than_dividend;
						reg [31:0] shifted_divisor;
						wire [1:0] new_quotient_bits;
						wire [31:0] sub_1x;
						wire [31:0] sub_2x;
						wire sub_1x_overflow;
						wire sub_2x_overflow;
						reg [3:0] cycles_remaining;
						wire [3:0] cycles_remaining_next;
						reg running;
						wire terminate;
						assign {divisor_greater_than_dividend, CLZ_delta} = cva5_wrapper.cva5.gen_div.div_unit_block.div_core.divisor_CLZ - cva5_wrapper.cva5.gen_div.div_unit_block.div_core.dividend_CLZ;
						always @(posedge clk)
							if (running)
								shifted_divisor <= {2'b00, shifted_divisor[31:2]};
							else
								shifted_divisor <= cva5_wrapper.cva5.gen_div.div_unit_block.div_core.divisor << {CLZ_delta[4:1], 1'b0};
						wire sub2x_toss;
						assign {sub_2x_overflow, sub2x_toss, sub_2x} = {1'b0, cva5_wrapper.cva5.gen_div.div_unit_block.div_core.remainder} - {shifted_divisor, 1'b0};
						assign {sub_1x_overflow, sub_1x} = (sub_2x_overflow ? {sub2x_toss, sub_2x} + {1'b0, shifted_divisor} : {sub2x_toss, sub_2x} - {1'b0, shifted_divisor});
						assign new_quotient_bits[1] = ~sub_2x_overflow;
						assign new_quotient_bits[0] = ~sub_1x_overflow;
						always @(posedge clk)
							if (cva5_wrapper.cva5.gen_div.div_unit_block.div_core.start)
								cva5_wrapper.cva5.gen_div.div_unit_block.div_core.quotient <= 1'sb0;
							else if (running)
								cva5_wrapper.cva5.gen_div.div_unit_block.div_core.quotient <= {cva5_wrapper.cva5.gen_div.div_unit_block.div_core.quotient[29:0], new_quotient_bits};
						always @(posedge clk)
							if (cva5_wrapper.cva5.gen_div.div_unit_block.div_core.start | (running & |new_quotient_bits))
								case ({~running, sub_1x_overflow})
									0: cva5_wrapper.cva5.gen_div.div_unit_block.div_core.remainder <= sub_1x;
									1: cva5_wrapper.cva5.gen_div.div_unit_block.div_core.remainder <= sub_2x;
									default: cva5_wrapper.cva5.gen_div.div_unit_block.div_core.remainder <= cva5_wrapper.cva5.gen_div.div_unit_block.div_core.dividend;
								endcase
						assign {terminate, cycles_remaining_next} = cycles_remaining - 1;
						always @(posedge clk) cycles_remaining <= (running ? cycles_remaining_next : CLZ_delta[4:1]);
						always @(posedge clk)
							if (rst)
								running <= 0;
							else
								running <= (running & ~terminate) | (cva5_wrapper.cva5.gen_div.div_unit_block.div_core.start & ~divisor_greater_than_dividend);
						assign cva5_wrapper.cva5.gen_div.div_unit_block.div_core.done = (running & terminate) | (cva5_wrapper.cva5.gen_div.div_unit_block.div_core.start & divisor_greater_than_dividend);
					end
					assign divider_block.clk = clk;
					assign divider_block.rst = rst;
					assign cva5_wrapper.cva5.unit_wb[_mbase_wb].rd = negate_if((wb_attr[6] ? div_core.remainder : div_core.quotient), wb_attr[5]);
					always @(posedge clk)
						if (rst)
							cva5_wrapper.cva5.unit_wb[_mbase_wb].done <= 0;
						else
							cva5_wrapper.cva5.unit_wb[_mbase_wb].done <= (cva5_wrapper.cva5.unit_wb[_mbase_wb].done & ~cva5_wrapper.cva5.unit_wb[_mbase_wb].ack) | div_done;
					wire [3:1] sv2v_tmp_FCF83;
					assign sv2v_tmp_FCF83 = wb_attr[2-:cva5_types_LOG2_MAX_IDS];
					always @(*) cva5_wrapper.cva5.unit_wb[_mbase_wb].id = sv2v_tmp_FCF83;
				end
				assign div_unit_block.clk = clk;
				assign div_unit_block.rst = rst;
				assign div_unit_block.div_inputs = div_inputs;
			end
			if (CONFIG[1204]) begin : gen_scaiev
				localparam _bbase_D7BB4_issue = UNIT_IDS[95-:32];
				localparam _bbase_D7BB4_wb = UNIT_IDS[95-:32];
				if (1) begin : scaiev_unit_block
					wire clk;
					wire rst;
					localparam riscv_types_XLEN = 32;
					wire [160:0] scaiev_inputs;
					localparam _mbase_issue = _bbase_D7BB4_issue;
					localparam _mbase_wb = _bbase_D7BB4_wb;
					localparam cva5_config_MAX_IDS = 8;
					localparam cva5_types_LOG2_MAX_IDS = 3;
					wire [98:0] ls_inputs_scaiev;
					wire ls_issue_scaiev_stage;
					wire ls_wb_scaiev_stage;
					wire ls_exception_valid;
					wire [2:0] ls_exception_id;
					wire stall_issue;
					wire branch_flush;
					localparam cva5_config_MAX_IDS_FETCH = 8;
					localparam cva5_types_LOG2_MAX_IDS_FETCH = 3;
					wire [74:0] br_results;
					wire br_results_override;
					reg [31:0] execute_rs1;
					reg [31:0] execute_rs2;
					reg [31:0] execute_rd_as_rs;
					reg [31:0] execute_instruction;
					reg [31:0] execute_pc;
					reg [2:0] execute_id;
					reg [2:0] execute_id_or_counter;
					reg execute_valid;
					reg [2:0] execute_nonrd_idcounter_next;
					reg [2:0] execute_nonrd_idcounter_min;
					wire execute_stall_idcounter_full;
					reg execute_expects_rd;
					reg execute_rd_valid;
					reg [31:0] execute_rd_data;
					wire execute_stall;
					wire execute_missingWriteback;
					assign execute_missingWriteback = (execute_expects_rd && !execute_rd_valid) && !cva5_wrapper.scaiev.execute_wrRD;
					assign execute_stall_idcounter_full = !execute_expects_rd && (execute_nonrd_idcounter_next == execute_nonrd_idcounter_min);
					assign execute_stall = (cva5_wrapper.scaiev.execute_stall || (execute_missingWriteback && !cva5_wrapper.scaiev.execute_deq)) || execute_stall_idcounter_full;
					assign cva5_wrapper.scaiev.execute_isStalling_reason_isax = execute_missingWriteback;
					assign cva5_wrapper.scaiev.execute_isStalling_reason_core = (((cva5_wrapper.cva5.unit_wb[_mbase_wb].done && !cva5_wrapper.scaiev.execute_commitNow) && !cva5_wrapper.cva5.unit_wb[_mbase_wb].ack) || !execute_valid) || execute_stall_idcounter_full;
					assign cva5_wrapper.scaiev.execute_isStalling = cva5_wrapper.scaiev.execute_isStalling_reason_isax || cva5_wrapper.scaiev.execute_isStalling_reason_core;
					assign cva5_wrapper.cva5.unit_issue[_mbase_issue].ready = !execute_valid || !(execute_stall || ((cva5_wrapper.cva5.unit_wb[_mbase_wb].done && !cva5_wrapper.scaiev.execute_commitNow) && !cva5_wrapper.cva5.unit_wb[_mbase_wb].ack));
					always @(posedge clk)
						if (rst) begin
							execute_rs1 <= 1'sbx;
							execute_rs2 <= 1'sbx;
							execute_rd_as_rs <= 1'sbx;
							execute_instruction <= 1'sbx;
							execute_pc <= 1'sbx;
							execute_id <= 1'sbx;
							execute_id_or_counter <= 1'sbx;
							execute_expects_rd <= 1'sbx;
							execute_valid <= 0;
							execute_nonrd_idcounter_next <= 0;
						end
						else if (cva5_wrapper.cva5.unit_issue[_mbase_issue].ready) begin
							execute_rs1 <= scaiev_inputs[160-:32];
							execute_rs2 <= scaiev_inputs[128-:32];
							execute_rd_as_rs <= scaiev_inputs[96-:32];
							execute_instruction <= scaiev_inputs[64-:32];
							execute_pc <= scaiev_inputs[32-:32];
							execute_id <= cva5_wrapper.cva5.unit_issue[_mbase_issue].id;
							execute_id_or_counter <= cva5_wrapper.cva5.unit_issue[_mbase_issue].id;
							execute_expects_rd <= cva5_wrapper.cva5.unit_issue[_mbase_issue].new_request && scaiev_inputs[0];
							if (cva5_wrapper.cva5.unit_issue[_mbase_issue].new_request && !scaiev_inputs[0]) begin
								execute_id_or_counter <= execute_nonrd_idcounter_next;
								execute_nonrd_idcounter_next <= execute_nonrd_idcounter_next + 1;
							end
							execute_valid <= cva5_wrapper.cva5.unit_issue[_mbase_issue].new_request;
						end
						else if (cva5_wrapper.scaiev.execute_deq) begin
							execute_rs1 <= 1'sbx;
							execute_rs2 <= 1'sbx;
							execute_rd_as_rs <= 1'sbx;
							execute_instruction <= 1'sbx;
							execute_pc <= 1'sbx;
							execute_id <= 1'sbx;
							execute_id_or_counter <= 1'sbx;
							execute_expects_rd <= 1'sbx;
							execute_valid <= 0;
						end
					always @(posedge clk)
						if (rst)
							execute_nonrd_idcounter_min <= 0;
						else if ((cva5_wrapper.scaiev.execute_commitNow ? !cva5_wrapper.scaiev.execute_commitNow_expects_rd : (execute_valid && !execute_expects_rd) && !execute_stall))
							execute_nonrd_idcounter_min <= execute_nonrd_idcounter_min + 1;
					assign cva5_wrapper.scaiev.execute_PC = execute_pc;
					assign cva5_wrapper.scaiev.execute_Instr = execute_instruction;
					assign cva5_wrapper.scaiev.execute_RS1 = execute_rs1;
					assign cva5_wrapper.scaiev.execute_RS2 = execute_rs2;
					assign cva5_wrapper.scaiev.execute_RD_AS_RS = execute_rd_as_rs;
					assign cva5_wrapper.scaiev.execute_ID = execute_id;
					assign cva5_wrapper.scaiev.execute_ID_or_counter = execute_id_or_counter;
					assign cva5_wrapper.scaiev.execute_expects_rd = execute_expects_rd;
					assign cva5_wrapper.scaiev.execute_valid = execute_valid && !execute_stall_idcounter_full;
					always @(posedge clk)
						if (rst || cva5_wrapper.cva5.unit_issue[_mbase_issue].ready) begin
							execute_rd_valid <= 0;
							execute_rd_data <= 1'sbx;
						end
						else if (cva5_wrapper.scaiev.execute_wrRD) begin
							execute_rd_valid <= 1;
							execute_rd_data <= cva5_wrapper.scaiev.execute_wrRD_data;
						end
					reg ls_wb_ack_r;
					always @(posedge clk) ls_wb_ack_r <= cva5_wrapper.cva5.ls_wb_scaiev.done;
					assign cva5_wrapper.cva5.ls_wb_scaiev.ack = ls_wb_ack_r;
					assign ls_inputs_scaiev[98-:32] = (cva5_wrapper.scaiev.execute_injectLS_potentiallyValid ? cva5_wrapper.scaiev.execute_injectLS_addr : cva5_wrapper.scaiev.issue_injectLS_addr);
					assign ls_inputs_scaiev[66-:32] = (cva5_wrapper.scaiev.execute_injectLS_potentiallyValid ? cva5_wrapper.scaiev.execute_injectLS_storeVal : cva5_wrapper.scaiev.issue_injectLS_storeVal);
					assign ls_inputs_scaiev[34-:12] = 1'sb0;
					assign ls_inputs_scaiev[22-:3] = (cva5_wrapper.scaiev.execute_injectLS_potentiallyValid ? cva5_wrapper.scaiev.execute_Instr[14:12] : scaiev_inputs[47:45]);
					assign ls_inputs_scaiev[19] = (cva5_wrapper.scaiev.execute_injectLS_potentiallyValid ? cva5_wrapper.scaiev.execute_injectLS_rnw : cva5_wrapper.scaiev.issue_injectLS_rnw);
					assign ls_inputs_scaiev[18] = ~(cva5_wrapper.scaiev.execute_injectLS_potentiallyValid ? cva5_wrapper.scaiev.execute_injectLS_rnw : cva5_wrapper.scaiev.issue_injectLS_rnw);
					assign ls_inputs_scaiev[16] = 0;
					assign ls_inputs_scaiev[15] = 0;
					assign ls_inputs_scaiev[17] = (cva5_wrapper.scaiev.execute_injectLS_potentiallyValid ? cva5_wrapper.scaiev.execute_injectLS_relaxedOrdering : cva5_wrapper.scaiev.issue_injectLS_potentiallyValid);
					assign ls_inputs_scaiev[14-:7] = 1'sbx;
					assign ls_inputs_scaiev[7] = 0;
					assign ls_inputs_scaiev[6] = 0;
					assign ls_inputs_scaiev[5] = 0;
					assign ls_inputs_scaiev[4-:5] = 1'sbx;
					assign cva5_wrapper.cva5.ls_issue_scaiev.possible_issue = cva5_wrapper.scaiev.execute_injectLS_potentiallyValid || cva5_wrapper.scaiev.issue_injectLS_potentiallyValid;
					assign cva5_wrapper.cva5.ls_issue_scaiev.new_request = (cva5_wrapper.scaiev.execute_injectLS_valid || cva5_wrapper.scaiev.issue_injectLS_valid) && cva5_wrapper.cva5.ls_issue_scaiev.ready;
					assign cva5_wrapper.cva5.ls_issue_scaiev.id = (cva5_wrapper.scaiev.execute_injectLS_potentiallyValid ? execute_id : cva5_wrapper.cva5.unit_issue[_mbase_issue].id);
					assign ls_issue_scaiev_stage = (cva5_wrapper.scaiev.execute_injectLS_potentiallyValid ? 1'd1 : 1'd0);
					assign cva5_wrapper.scaiev.injectLS_ready = cva5_wrapper.cva5.ls_issue_scaiev.ready;
					assign cva5_wrapper.scaiev.issue_injectLS_done = cva5_wrapper.cva5.ls_wb_scaiev.done && (ls_wb_scaiev_stage == 1'd0);
					assign cva5_wrapper.scaiev.execute_injectLS_done = cva5_wrapper.cva5.ls_wb_scaiev.done && (ls_wb_scaiev_stage == 1'd1);
					assign cva5_wrapper.scaiev.injectLS_readData = cva5_wrapper.cva5.ls_wb_scaiev.rd;
					assign branch_flush = 0;
					assign br_results[74-:3] = 1'sbx;
					assign br_results[71-:3] = 1'sbx;
					assign br_results[68] = 0;
					assign br_results[67-:32] = 1'sbx;
					assign br_results[35-:32] = 1'sbx;
					assign br_results[3] = 0;
					assign br_results[2] = 0;
					assign br_results[1] = 0;
					assign br_results[0] = 0;
					assign br_results_override = 0;
					assign stall_issue = 0;
					assign cva5_wrapper.cva5.unit_wb[_mbase_wb].rd = (cva5_wrapper.scaiev.execute_wrRD ? cva5_wrapper.scaiev.execute_wrRD_data : execute_rd_data);
					wire [1:1] sv2v_tmp_F06D6;
					assign sv2v_tmp_F06D6 = (cva5_wrapper.scaiev.execute_commitNow ? cva5_wrapper.scaiev.execute_commitNow_expects_rd && (execute_rd_valid || cva5_wrapper.scaiev.execute_wrRD) : (execute_valid && execute_expects_rd) && !(execute_stall || execute_missingWriteback));
					always @(*) cva5_wrapper.cva5.unit_wb[_mbase_wb].done = sv2v_tmp_F06D6;
					wire [3:1] sv2v_tmp_3D212;
					assign sv2v_tmp_3D212 = (cva5_wrapper.scaiev.execute_commitNow ? cva5_wrapper.scaiev.execute_commitNow_ID : execute_id);
					always @(*) cva5_wrapper.cva5.unit_wb[_mbase_wb].id = sv2v_tmp_3D212;
					assign cva5_wrapper.scaiev.execute_commitNow_resp = !cva5_wrapper.scaiev.execute_commitNow_expects_rd || (cva5_wrapper.cva5.unit_wb[_mbase_wb].done && cva5_wrapper.cva5.unit_wb[_mbase_wb].ack);
				end
				assign scaiev_unit_block.clk = clk;
				assign scaiev_unit_block.rst = rst;
				assign scaiev_unit_block.scaiev_inputs = scaiev_inputs;
				assign ls_inputs_scaiev = scaiev_unit_block.ls_inputs_scaiev;
				assign ls_issue_scaiev_meta[0] = scaiev_unit_block.ls_issue_scaiev_stage;
				assign scaiev_unit_block.ls_wb_scaiev_stage = ls_wb_scaiev_meta[0];
				assign scaiev_unit_block.ls_exception_valid = exception[2'd0].valid;
				assign scaiev_unit_block.ls_exception_id = exception[2'd0].id;
				assign scaiev_stall_issue = scaiev_unit_block.stall_issue;
				assign branch_flush_scaiev = scaiev_unit_block.branch_flush;
				assign br_results_scaiev = scaiev_unit_block.br_results;
				assign br_results_scaiev_override = scaiev_unit_block.br_results_override;
			end
			else begin : genblk9
				assign scaiev_stall_issue = 0;
			end
			localparam [(CONFIG[31-:32] * 32) - 1:0] NUM_UNITS_PER_PORT = {NUM_WB_UNITS_GROUP_1, NUM_WB_UNITS_GROUP_2};
			localparam _bbase_59DA3_unit_wb = 0;
			localparam _param_59DA3_CONFIG = CONFIG;
			localparam _param_59DA3_NUM_UNITS = NUM_UNITS_PER_PORT;
			localparam _param_59DA3_NUM_WB_UNITS = NUM_WB_UNITS;
			if (1) begin : writeback_block
				localparam [1209:0] cva5_config_EXAMPLE_CONFIG = 1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002;
				localparam [1209:0] CONFIG = _param_59DA3_CONFIG;
				localparam [(CONFIG[31-:32] * 32) - 1:0] NUM_UNITS = _param_59DA3_NUM_UNITS;
				localparam [31:0] NUM_WB_UNITS = _param_59DA3_NUM_WB_UNITS;
				wire clk;
				wire rst;
				localparam _mbase_unit_wb = 0;
				localparam cva5_config_MAX_IDS = 8;
				localparam cva5_types_LOG2_MAX_IDS = 3;
				wire [(CONFIG[31-:32] * 36) - 1:0] wb_packet;
				reg [39:0] wb_snoop;
				wire [NUM_WB_UNITS - 1:0] unit_ack [0:CONFIG[31-:32] - 1];
				wire [(NUM_WB_UNITS * cva5_types_LOG2_MAX_IDS) - 1:0] unit_instruction_id [0:CONFIG[31-:32] - 1];
				wire [NUM_WB_UNITS - 1:0] unit_done [0:CONFIG[31-:32] - 1];
				localparam riscv_types_XLEN = 32;
				wire [31:0] unit_rd [0:CONFIG[31-:32] - 1][0:NUM_WB_UNITS - 1];
				wire [$clog2(NUM_WB_UNITS) - 1:0] unit_sel [0:CONFIG[31-:32] - 1];
				genvar _gv_g_1;
				for (_gv_g_1 = 0; _gv_g_1 < CONFIG[31-:32]; _gv_g_1 = _gv_g_1 + 1) begin : isaac_wb_defaults
					localparam g = _gv_g_1;
					genvar _gv_u_1;
					for (_gv_u_1 = NUM_UNITS[((CONFIG[31-:32] - 1) - g) * 32+:32]; _gv_u_1 < NUM_WB_UNITS; _gv_u_1 = _gv_u_1 + 1) begin : padding
						localparam u = _gv_u_1;
						assign unit_instruction_id[g][u * cva5_types_LOG2_MAX_IDS+:cva5_types_LOG2_MAX_IDS] = 1'sb0;
						assign unit_done[g][u] = 1'b0;
						assign unit_rd[g][u] = 1'sb0;
					end
					genvar _gv_b_1;
					for (_gv_b_1 = (NUM_UNITS[((CONFIG[31-:32] - 1) - g) * 32+:32] == 1 ? 1 : $clog2(NUM_UNITS[((1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32] - 1) - g) * 32+:32])); _gv_b_1 < $clog2(NUM_WB_UNITS); _gv_b_1 = _gv_b_1 + 1) begin : select_padding
						localparam b = _gv_b_1;
						assign unit_sel[g][b] = 1'b0;
					end
				end
				function [(CONFIG[31-:32] * 32) - 1:0] get_cumulative_unit_count;
					input reg _sv2v_unused;
					reg [(CONFIG[31-:32] * 32) - 1:0] counts;
					reg [31:0] cumulative_count;
					begin
						cumulative_count = 0;
						begin : sv2v_autoblock_81
							reg signed [31:0] i;
							for (i = 0; i < CONFIG[31-:32]; i = i + 1)
								begin
									counts[((CONFIG[31-:32] - 1) - i) * 32+:32] = cumulative_count;
									cumulative_count = cumulative_count + NUM_UNITS[((CONFIG[31-:32] - 1) - i) * 32+:32];
								end
						end
						get_cumulative_unit_count = counts;
					end
				endfunction
				localparam [(CONFIG[31-:32] * 32) - 1:0] CUMULATIVE_NUM_UNITS = get_cumulative_unit_count(0);
				genvar _gv_i_19;
				genvar _gv_j_2;
				for (_gv_i_19 = 0; _gv_i_19 < CONFIG[31-:32]; _gv_i_19 = _gv_i_19 + 1) begin : gen_wb_group_unpacking
					localparam i = _gv_i_19;
					for (_gv_j_2 = 0; _gv_j_2 < NUM_UNITS[((CONFIG[31-:32] - 1) - i) * 32+:32]; _gv_j_2 = _gv_j_2 + 1) begin : gen_wb_unit_unpacking
						localparam j = _gv_j_2;
						assign unit_instruction_id[i][j * cva5_types_LOG2_MAX_IDS+:cva5_types_LOG2_MAX_IDS] = cva5_wrapper.cva5.unit_wb[(CUMULATIVE_NUM_UNITS[((CONFIG[31-:32] - 1) - i) * 32+:32] + j) + _mbase_unit_wb].id;
						assign unit_done[i][j] = cva5_wrapper.cva5.unit_wb[(CUMULATIVE_NUM_UNITS[((CONFIG[31-:32] - 1) - i) * 32+:32] + j) + _mbase_unit_wb].done;
						assign cva5_wrapper.cva5.unit_wb[(CUMULATIVE_NUM_UNITS[((CONFIG[31-:32] - 1) - i) * 32+:32] + j) + _mbase_unit_wb].ack = unit_ack[i][j];
					end
				end
				for (_gv_i_19 = 0; _gv_i_19 < CONFIG[31-:32]; _gv_i_19 = _gv_i_19 + 1) begin : gen_wb_port_grouping
					localparam i = _gv_i_19;
					for (_gv_j_2 = 0; _gv_j_2 < NUM_UNITS[((CONFIG[31-:32] - 1) - i) * 32+:32]; _gv_j_2 = _gv_j_2 + 1) begin : gen_wb_unit_grouping
						localparam j = _gv_j_2;
						assign unit_rd[i][j] = cva5_wrapper.cva5.unit_wb[(CUMULATIVE_NUM_UNITS[((CONFIG[31-:32] - 1) - i) * 32+:32] + j) + _mbase_unit_wb].rd;
					end
				end
				for (_gv_i_19 = 0; _gv_i_19 < CONFIG[31-:32]; _gv_i_19 = _gv_i_19 + 1) begin : gen_wb_mux
					localparam i = _gv_i_19;
					priority_encoder #(.WIDTH(NUM_UNITS[((CONFIG[31-:32] - 1) - i) * 32+:32])) unit_done_encoder(
						.priority_vector(unit_done[i][NUM_UNITS[((CONFIG[31-:32] - 1) - i) * 32+:32] - 1:0]),
						.encoded_result(unit_sel[i][(NUM_UNITS[((CONFIG[31-:32] - 1) - i) * 32+:32] == 1 ? 0 : $clog2(NUM_UNITS[((1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[31-:32] - 1) - i) * 32+:32]) - 1):0])
					);
					assign wb_packet[(((CONFIG[31-:32] - 1) - i) * 36) + 32] = ((i != 1) || !cva5_wrapper.scaiev.rf_wrReg) & |unit_done[i];
					assign wb_packet[(((CONFIG[31-:32] - 1) - i) * 36) + 35-:3] = unit_instruction_id[i][unit_sel[i] * cva5_types_LOG2_MAX_IDS+:cva5_types_LOG2_MAX_IDS];
					assign wb_packet[(((CONFIG[31-:32] - 1) - i) * 36) + 31-:32] = unit_rd[i][unit_sel[i]];
					function automatic [NUM_WB_UNITS - 1:0] sv2v_cast_DC71F;
						input reg [NUM_WB_UNITS - 1:0] inp;
						sv2v_cast_DC71F = inp;
					endfunction
					assign unit_ack[i] = sv2v_cast_DC71F(wb_packet[(((CONFIG[31-:32] - 1) - i) * 36) + 32]) << unit_sel[i];
				end
				always @(posedge clk)
					if (rst)
						wb_snoop[32] <= 0;
					else
						wb_snoop[32] <= cva5_wrapper.scaiev.rf_wrReg || wb_packet[((CONFIG[31-:32] - 2) * 36) + 32];
				always @(posedge clk) begin
					wb_snoop[31-:32] <= (cva5_wrapper.scaiev.rf_wrReg ? cva5_wrapper.scaiev.rf_wrReg_data : wb_packet[((CONFIG[31-:32] - 2) * 36) + 31-:32]);
					wb_snoop[39] <= !cva5_wrapper.scaiev.rf_wrReg;
					wb_snoop[38-:6] <= 1'sbx;
					if (cva5_wrapper.scaiev.rf_wrReg)
						wb_snoop[38-:6] <= cva5_wrapper.scaiev.rf_wrReg_phys_RD;
					else
						wb_snoop[38-:3] <= wb_packet[((CONFIG[31-:32] - 2) * 36) + 35-:3];
				end
			end
			assign writeback_block.clk = clk;
			assign writeback_block.rst = rst;
			assign wb_packet = writeback_block.wb_packet;
			assign wb_snoop = writeback_block.wb_snoop;
			localparam cva5_config_ENABLE_TRACE_INTERFACE = 1;
			if (cva5_config_ENABLE_TRACE_INTERFACE) begin : gen_cva5_trace
				always @(posedge clk) begin
					tr[25] <= tr_early_branch_correction;
					tr[24] <= tr_operand_stall;
					tr[23] <= tr_unit_stall;
					tr[22] <= tr_no_id_stall;
					tr[21] <= tr_no_instruction_stall;
					tr[20] <= tr_other_stall;
					tr[19] <= tr_instruction_issued_dec;
					tr[18] <= tr_branch_operand_stall;
					tr[17] <= tr_alu_operand_stall;
					tr[16] <= tr_ls_operand_stall;
					tr[15] <= tr_div_operand_stall;
					tr[14] <= tr_alu_op;
					tr[13] <= tr_branch_or_jump_op;
					tr[12] <= tr_load_op;
					tr[11] <= tr_store_op;
					tr[10] <= tr_mul_op;
					tr[9] <= tr_div_op;
					tr[8] <= tr_misc_op;
					tr[7] <= tr_branch_correct;
					tr[6] <= tr_branch_misspredict;
					tr[5] <= tr_return_correct;
					tr[4] <= tr_return_misspredict;
					tr[3] <= tr_load_conflict_delay;
					tr[2] <= tr_rs1_forwarding_needed;
					tr[1] <= tr_rs2_forwarding_needed;
					tr[0] <= tr_rs1_and_rs2_forwarding_needed;
					tr[89-:32] <= tr_instruction_pc_dec;
					tr[57-:32] <= tr_instruction_data_dec;
				end
			end
			genvar _gv_i_26;
			for (_gv_i_26 = 0; _gv_i_26 < cva5_config_L1_CONNECTIONS; _gv_i_26 = _gv_i_26 + 1) begin : isaac_disabled_cache
				localparam i = _gv_i_26;
				if (((i == 2'd2) && !CONFIG[1002]) || ((i == 2'd0) && !CONFIG[711])) begin : inactive
					assign l1_request[i].request = 1'b0;
					wire [32:1] sv2v_tmp_6ABC4;
					assign sv2v_tmp_6ABC4 = 1'sb0;
					always @(*) l1_request[i].addr = sv2v_tmp_6ABC4;
					assign l1_request[i].data = 1'sb0;
					assign l1_request[i].rnw = 1'b1;
					assign l1_request[i].be = 1'sb0;
					assign l1_request[i].size = 1'sb0;
					assign l1_request[i].is_amo = 1'b0;
					assign l1_request[i].amo = 1'sb0;
				end
			end
		end
	endgenerate
	assign cva5.clk = clk;
	assign cva5.rst = rst;
	assign tr = cva5.tr;
	assign cva5.s_interrupt = 0;
	assign cva5.m_interrupt = m_interrupt;
	localparam _bbase_52255_request = 0;
	function automatic signed [0:0] sv2v_cast_1_signed;
		input reg signed [0:0] inp;
		sv2v_cast_1_signed = inp;
	endfunction
	generate
		if (1) begin : l2_arb
			reg _sv2v_0;
			wire clk;
			wire rst;
			localparam l2_config_and_types_L2_NUM_PORTS = 2;
			localparam _mbase_request = 0;
			if (1) begin : arb
				localparam l2_config_and_types_L2_NUM_PORTS = 2;
				wire [1:0] requests;
				wire [0:0] grantee_i;
				wire [1:0] grantee_v;
				wire grantee_valid;
				wire strobe;
			end
			localparam l2_config_and_types_L2_SUB_ID_W = 2;
			localparam _param_40661_DATA_WIDTH = 43;
			genvar _arr_40661;
			for (_arr_40661 = 1; _arr_40661 >= 0; _arr_40661 = _arr_40661 - 1) begin : input_fifos
				localparam DATA_WIDTH = _param_40661_DATA_WIDTH;
				wire push;
				wire pop;
				wire [42:0] data_in;
				wire [42:0] data_out;
				wire valid;
				wire full;
				wire potential_push;
			end
			localparam _param_08B23_DATA_WIDTH = 32;
			genvar _arr_08B23;
			for (_arr_08B23 = 1; _arr_08B23 >= 0; _arr_08B23 = _arr_08B23 - 1) begin : input_data_fifos
				localparam DATA_WIDTH = _param_08B23_DATA_WIDTH;
				wire push;
				wire pop;
				wire [31:0] data_in;
				wire [31:0] data_out;
				wire valid;
				wire full;
				wire potential_push;
			end
			localparam _param_37781_DATA_WIDTH = 30;
			genvar _arr_37781;
			for (_arr_37781 = 1; _arr_37781 >= 0; _arr_37781 = _arr_37781 - 1) begin : inv_response_fifos
				localparam DATA_WIDTH = _param_37781_DATA_WIDTH;
				wire push;
				wire pop;
				wire [29:0] data_in;
				wire [29:0] data_out;
				wire valid;
				wire full;
				wire potential_push;
			end
			localparam _param_CFD80_DATA_WIDTH = 34;
			genvar _arr_CFD80;
			for (_arr_CFD80 = 1; _arr_CFD80 >= 0; _arr_CFD80 = _arr_CFD80 - 1) begin : returndata_fifos
				localparam DATA_WIDTH = _param_CFD80_DATA_WIDTH;
				wire push;
				wire pop;
				wire [33:0] data_in;
				reg [33:0] data_out;
				reg valid;
				wire full;
				wire potential_push;
			end
			localparam l2_config_and_types_L2_ID_W = 3;
			localparam _param_B9263_DATA_WIDTH = 44;
			if (1) begin : mem_addr_fifo
				localparam DATA_WIDTH = _param_B9263_DATA_WIDTH;
				wire push;
				wire pop;
				wire [43:0] data_in;
				wire [43:0] data_out;
				wire valid;
				wire full;
				wire potential_push;
			end
			localparam _param_85890_DATA_WIDTH = 32;
			if (1) begin : mem_data_fifo
				localparam DATA_WIDTH = _param_85890_DATA_WIDTH;
				wire push;
				wire pop;
				wire [31:0] data_in;
				wire [31:0] data_out;
				wire valid;
				wire full;
				wire potential_push;
			end
			localparam _param_12A91_DATA_WIDTH = 7;
			if (1) begin : data_attributes
				localparam DATA_WIDTH = _param_12A91_DATA_WIDTH;
				wire push;
				wire pop;
				wire [6:0] data_in;
				wire [6:0] data_out;
				wire valid;
				wire full;
				wire potential_push;
			end
			localparam _param_F725C_DATA_WIDTH = 35;
			if (1) begin : mem_returndata_fifo
				localparam DATA_WIDTH = _param_F725C_DATA_WIDTH;
				wire push;
				wire pop;
				wire [34:0] data_in;
				wire [34:0] data_out;
				wire valid;
				wire full;
				wire potential_push;
			end
			wire [43:0] mem_addr_fifo_data_out;
			wire [42:0] requests_in [1:0];
			wire advance;
			wire [42:0] arb_request;
			wire [43:0] mem_request;
			reg reserv_valid;
			wire reserv_lr;
			wire reserv_sc;
			wire reserv_store;
			wire [42:0] requests [1:0];
			reg [42:0] reserv_request;
			reg [0:0] reserv_id;
			reg [1:0] reserv_id_v;
			wire write_done;
			reg [4:0] burst_count;
			wire [6:0] new_attr;
			wire [6:0] current_attr;
			wire [31:0] input_data [1:0];
			wire [34:0] mem_return_data;
			wire [33:0] return_data [1:0];
			reg [1:0] return_push;
			wire wr_clk;
			wire rd_clk;
			assign wr_clk = clk;
			assign rd_clk = clk;
			genvar _gv_i_20;
			localparam l2_config_and_types_L2_INPUT_FIFO_DEPTHS = 16;
			for (_gv_i_20 = 0; _gv_i_20 < l2_config_and_types_L2_NUM_PORTS; _gv_i_20 = _gv_i_20 + 1) begin : gen_requests
				localparam i = _gv_i_20;
				assign input_fifos[i].push = cva5_wrapper.l2[i + _mbase_request].request_push;
				assign input_fifos[i].potential_push = cva5_wrapper.l2[i + _mbase_request].request_push;
				assign requests_in[i][42-:30] = cva5_wrapper.l2[i + _mbase_request].addr;
				assign requests_in[i][12-:4] = cva5_wrapper.l2[i + _mbase_request].be;
				assign requests_in[i][8] = cva5_wrapper.l2[i + _mbase_request].rnw;
				assign requests_in[i][7] = cva5_wrapper.l2[i + _mbase_request].is_amo;
				assign requests_in[i][6-:5] = cva5_wrapper.l2[i + _mbase_request].amo_type_or_burst_size;
				assign requests_in[i][1-:l2_config_and_types_L2_SUB_ID_W] = cva5_wrapper.l2[i + _mbase_request].sub_id;
				assign input_fifos[i].data_in = requests_in[i];
				assign input_fifos[i].pop = (input_fifos[i].valid & arb.grantee_v[i]) & ~mem_addr_fifo.full;
				assign cva5_wrapper.l2[i + _mbase_request].request_full = input_fifos[i].full;
				localparam _bbase_66B7B_fifo = _gv_i_20;
				localparam _param_66B7B_DATA_WIDTH = 43;
				localparam _param_66B7B_FIFO_DEPTH = l2_config_and_types_L2_INPUT_FIFO_DEPTHS;
				if (1) begin : input_fifo
					localparam DATA_WIDTH = _param_66B7B_DATA_WIDTH;
					localparam FIFO_DEPTH = _param_66B7B_FIFO_DEPTH;
					wire clk;
					wire rst;
					localparam _mbase_fifo = _bbase_66B7B_fifo;
					localparam LOG2_FIFO_DEPTH = 4;
					if (1) begin : gen_width_3_plus
						wire [42:0] lut_ram [0:15];
						wire [3:0] write_index;
						wire [3:0] read_index;
						reg [LOG2_FIFO_DEPTH:0] inflight_count;
						always @(posedge clk)
							if (rst)
								inflight_count <= 0;
							else
								inflight_count <= (inflight_count + sv2v_cast_5(cva5_wrapper.l2_arb.input_fifos[_mbase_fifo].pop)) - sv2v_cast_5(cva5_wrapper.l2_arb.input_fifos[_mbase_fifo].push);
						assign cva5_wrapper.l2_arb.input_fifos[_mbase_fifo].valid = inflight_count[LOG2_FIFO_DEPTH];
						assign cva5_wrapper.l2_arb.input_fifos[_mbase_fifo].full = cva5_wrapper.l2_arb.input_fifos[_mbase_fifo].valid & ~|inflight_count[3:0];
						lfsr #(
							.WIDTH(LOG2_FIFO_DEPTH),
							.NEEDS_RESET(1)
						) lfsr_read_index(
							.clk(clk),
							.rst(rst),
							.en(cva5_wrapper.l2_arb.input_fifos[_mbase_fifo].pop),
							.value(read_index)
						);
						lfsr #(
							.WIDTH(LOG2_FIFO_DEPTH),
							.NEEDS_RESET(1)
						) lfsr_write_index(
							.clk(clk),
							.rst(rst),
							.en(cva5_wrapper.l2_arb.input_fifos[_mbase_fifo].push),
							.value(write_index)
						);
						lutram_1w_1r #(
							.WIDTH(DATA_WIDTH),
							.DEPTH(FIFO_DEPTH)
						) write_port(
							.clk(clk),
							.waddr(write_index),
							.raddr(read_index),
							.ram_write(cva5_wrapper.l2_arb.input_fifos[_mbase_fifo].potential_push),
							.new_ram_data(cva5_wrapper.l2_arb.input_fifos[_mbase_fifo].data_in),
							.ram_data_out(cva5_wrapper.l2_arb.input_fifos[_mbase_fifo].data_out)
						);
					end
				end
				assign input_fifo.clk = clk;
				assign input_fifo.rst = rst;
				assign requests[i] = input_fifos[i].data_out;
				assign arb.requests[i] = input_fifos[i].valid;
			end
			for (_gv_i_20 = 0; _gv_i_20 < l2_config_and_types_L2_NUM_PORTS; _gv_i_20 = _gv_i_20 + 1) begin : gen_input_fifos
				localparam i = _gv_i_20;
				assign input_data_fifos[i].push = cva5_wrapper.l2[i + _mbase_request].wr_data_push;
				assign input_data_fifos[i].potential_push = cva5_wrapper.l2[i + _mbase_request].wr_data_push;
				assign input_data_fifos[i].data_in = cva5_wrapper.l2[i + _mbase_request].wr_data;
				assign cva5_wrapper.l2[i + _mbase_request].data_full = input_data_fifos[i].full;
				localparam _bbase_2B1B2_fifo = _gv_i_20;
				localparam _param_2B1B2_DATA_WIDTH = 32;
				localparam _param_2B1B2_FIFO_DEPTH = l2_config_and_types_L2_INPUT_FIFO_DEPTHS;
				if (1) begin : input_data_fifo
					localparam DATA_WIDTH = _param_2B1B2_DATA_WIDTH;
					localparam FIFO_DEPTH = _param_2B1B2_FIFO_DEPTH;
					wire clk;
					wire rst;
					localparam _mbase_fifo = _bbase_2B1B2_fifo;
					localparam LOG2_FIFO_DEPTH = 4;
					if (1) begin : gen_width_3_plus
						wire [31:0] lut_ram [0:15];
						wire [3:0] write_index;
						wire [3:0] read_index;
						reg [LOG2_FIFO_DEPTH:0] inflight_count;
						always @(posedge clk)
							if (rst)
								inflight_count <= 0;
							else
								inflight_count <= (inflight_count + sv2v_cast_5(cva5_wrapper.l2_arb.input_data_fifos[_mbase_fifo].pop)) - sv2v_cast_5(cva5_wrapper.l2_arb.input_data_fifos[_mbase_fifo].push);
						assign cva5_wrapper.l2_arb.input_data_fifos[_mbase_fifo].valid = inflight_count[LOG2_FIFO_DEPTH];
						assign cva5_wrapper.l2_arb.input_data_fifos[_mbase_fifo].full = cva5_wrapper.l2_arb.input_data_fifos[_mbase_fifo].valid & ~|inflight_count[3:0];
						lfsr #(
							.WIDTH(LOG2_FIFO_DEPTH),
							.NEEDS_RESET(1)
						) lfsr_read_index(
							.clk(clk),
							.rst(rst),
							.en(cva5_wrapper.l2_arb.input_data_fifos[_mbase_fifo].pop),
							.value(read_index)
						);
						lfsr #(
							.WIDTH(LOG2_FIFO_DEPTH),
							.NEEDS_RESET(1)
						) lfsr_write_index(
							.clk(clk),
							.rst(rst),
							.en(cva5_wrapper.l2_arb.input_data_fifos[_mbase_fifo].push),
							.value(write_index)
						);
						lutram_1w_1r #(
							.WIDTH(DATA_WIDTH),
							.DEPTH(FIFO_DEPTH)
						) write_port(
							.clk(clk),
							.waddr(write_index),
							.raddr(read_index),
							.ram_write(cva5_wrapper.l2_arb.input_data_fifos[_mbase_fifo].potential_push),
							.new_ram_data(cva5_wrapper.l2_arb.input_data_fifos[_mbase_fifo].data_in),
							.ram_data_out(cva5_wrapper.l2_arb.input_data_fifos[_mbase_fifo].data_out)
						);
					end
				end
				assign input_data_fifo.clk = clk;
				assign input_data_fifo.rst = rst;
				assign input_data_fifos[i].pop = (data_attributes.valid && (current_attr[6-:1] == i)) && ~mem_data_fifo.full;
				assign input_data[i] = input_data_fifos[i].data_out;
			end
			if (1) begin : rr
				reg _sv2v_0;
				wire clk;
				wire rst;
				localparam l2_config_and_types_L2_NUM_PORTS = 2;
				reg [0:0] state;
				reg [0:0] muxes [1:0];
				if (1) begin : gen_width_2plus
					always @(posedge clk)
						if (rst)
							state <= 0;
						else if (cva5_wrapper.l2_arb.arb.strobe)
							state <= cva5_wrapper.l2_arb.arb.grantee_i;
					always @(*) begin
						if (_sv2v_0)
							;
						begin : sv2v_autoblock_82
							reg signed [31:0] i;
							for (i = 0; i < l2_config_and_types_L2_NUM_PORTS; i = i + 1)
								begin
									muxes[i] = sv2v_cast_1_signed(i);
									begin : sv2v_autoblock_83
										reg signed [31:0] j;
										for (j = 0; j < l2_config_and_types_L2_NUM_PORTS; j = j + 1)
											if (cva5_wrapper.l2_arb.arb.requests[(i + j) % l2_config_and_types_L2_NUM_PORTS])
												muxes[i] = sv2v_cast_1_signed((i + j) % l2_config_and_types_L2_NUM_PORTS);
									end
								end
						end
					end
					assign cva5_wrapper.l2_arb.arb.grantee_i = muxes[state];
					assign cva5_wrapper.l2_arb.arb.grantee_v = 1 << cva5_wrapper.l2_arb.arb.grantee_i;
					assign cva5_wrapper.l2_arb.arb.grantee_valid = |cva5_wrapper.l2_arb.arb.requests;
				end
				initial _sv2v_0 = 0;
			end
			assign rr.clk = clk;
			assign rr.rst = rst;
			assign advance = arb.grantee_valid & ~mem_addr_fifo.full;
			assign arb.strobe = advance;
			assign mem_addr_fifo.push = advance;
			assign mem_addr_fifo.potential_push = advance;
			assign mem_addr_fifo.pop = cva5_wrapper.arb_mem.request_pop;
			assign cva5_wrapper.arb_mem.request_valid = mem_addr_fifo.valid;
			assign arb_request = requests[arb.grantee_i];
			assign mem_request[43-:30] = arb_request[42-:30];
			assign mem_request[13-:4] = arb_request[12-:4];
			assign mem_request[9] = arb_request[8];
			assign mem_request[8] = arb_request[7];
			assign mem_request[7-:5] = arb_request[6-:5];
			assign mem_request[2-:l2_config_and_types_L2_ID_W] = {arb.grantee_i, arb_request[1-:l2_config_and_types_L2_SUB_ID_W]};
			assign mem_addr_fifo.data_in = mem_request;
			assign mem_addr_fifo_data_out = mem_addr_fifo.data_out;
			assign cva5_wrapper.arb_mem.addr = mem_addr_fifo_data_out[43-:30];
			assign cva5_wrapper.arb_mem.rnw = mem_addr_fifo_data_out[9];
			assign cva5_wrapper.arb_mem.be = mem_addr_fifo_data_out[13-:4];
			assign cva5_wrapper.arb_mem.is_amo = mem_addr_fifo_data_out[8];
			assign cva5_wrapper.arb_mem.amo_type_or_burst_size = mem_addr_fifo_data_out[7-:5];
			assign cva5_wrapper.arb_mem.id = mem_addr_fifo_data_out[2-:l2_config_and_types_L2_ID_W];
			localparam l2_config_and_types_L2_MEM_ADDR_FIFO_DEPTH = 16;
			localparam _param_30FD0_DATA_WIDTH = 44;
			localparam _param_30FD0_FIFO_DEPTH = l2_config_and_types_L2_MEM_ADDR_FIFO_DEPTH;
			if (1) begin : input_fifo
				localparam DATA_WIDTH = _param_30FD0_DATA_WIDTH;
				localparam FIFO_DEPTH = _param_30FD0_FIFO_DEPTH;
				wire clk;
				wire rst;
				localparam LOG2_FIFO_DEPTH = 4;
				if (1) begin : gen_width_3_plus
					wire [43:0] lut_ram [0:15];
					wire [3:0] write_index;
					wire [3:0] read_index;
					reg [LOG2_FIFO_DEPTH:0] inflight_count;
					always @(posedge clk)
						if (rst)
							inflight_count <= 0;
						else
							inflight_count <= (inflight_count + sv2v_cast_5(cva5_wrapper.l2_arb.mem_addr_fifo.pop)) - sv2v_cast_5(cva5_wrapper.l2_arb.mem_addr_fifo.push);
					assign cva5_wrapper.l2_arb.mem_addr_fifo.valid = inflight_count[LOG2_FIFO_DEPTH];
					assign cva5_wrapper.l2_arb.mem_addr_fifo.full = cva5_wrapper.l2_arb.mem_addr_fifo.valid & ~|inflight_count[3:0];
					lfsr #(
						.WIDTH(LOG2_FIFO_DEPTH),
						.NEEDS_RESET(1)
					) lfsr_read_index(
						.clk(clk),
						.rst(rst),
						.en(cva5_wrapper.l2_arb.mem_addr_fifo.pop),
						.value(read_index)
					);
					lfsr #(
						.WIDTH(LOG2_FIFO_DEPTH),
						.NEEDS_RESET(1)
					) lfsr_write_index(
						.clk(clk),
						.rst(rst),
						.en(cva5_wrapper.l2_arb.mem_addr_fifo.push),
						.value(write_index)
					);
					lutram_1w_1r #(
						.WIDTH(DATA_WIDTH),
						.DEPTH(FIFO_DEPTH)
					) write_port(
						.clk(clk),
						.waddr(write_index),
						.raddr(read_index),
						.ram_write(cva5_wrapper.l2_arb.mem_addr_fifo.potential_push),
						.new_ram_data(cva5_wrapper.l2_arb.mem_addr_fifo.data_in),
						.ram_data_out(cva5_wrapper.l2_arb.mem_addr_fifo.data_out)
					);
				end
			end
			assign input_fifo.clk = clk;
			assign input_fifo.rst = rst;
			always @(posedge clk)
				if (advance) begin
					reserv_request <= requests[arb.grantee_i];
					reserv_id <= arb.grantee_i;
					reserv_id_v <= arb.grantee_v;
				end
			always @(posedge clk)
				if (rst)
					reserv_valid <= 0;
				else
					reserv_valid <= advance;
			assign reserv_lr = reserv_request[7] && (reserv_request[6-:5] == 5'b00010);
			assign reserv_sc = reserv_request[7] && (reserv_request[6-:5] == 5'b00011);
			assign reserv_store = ~reserv_request[8] | (reserv_request[7] && (reserv_request[6-:5] != 5'b00010));
			l2_reservation_logic reserv(
				.clk(clk),
				.rst(rst),
				.addr(reserv_request[42-:30]),
				.id(reserv_id),
				.strobe(reserv_valid),
				.lr(reserv_lr),
				.sc(reserv_sc),
				.store(reserv_store),
				.abort_request(cva5_wrapper.arb_mem.abort_request)
			);
			for (_gv_i_20 = 0; _gv_i_20 < l2_config_and_types_L2_NUM_PORTS; _gv_i_20 = _gv_i_20 + 1) begin : gen_sc_response
				localparam i = _gv_i_20;
				always @(posedge clk)
					if (rst) begin
						cva5_wrapper.l2[i + _mbase_request].con_result <= 0;
						cva5_wrapper.l2[i + _mbase_request].con_valid <= 0;
					end
					else begin
						cva5_wrapper.l2[i + _mbase_request].con_result <= ~cva5_wrapper.arb_mem.abort_request;
						cva5_wrapper.l2[i + _mbase_request].con_valid <= (reserv_sc & reserv_valid) & reserv_id_v[i];
					end
			end
			localparam l2_config_and_types_L2_INVALIDATION_FIFO_DEPTHS = 16;
			for (_gv_i_20 = 0; _gv_i_20 < l2_config_and_types_L2_NUM_PORTS; _gv_i_20 = _gv_i_20 + 1) begin : gen_inv_response
				localparam i = _gv_i_20;
				assign inv_response_fifos[i].pop = cva5_wrapper.l2[i + _mbase_request].inv_ack;
				assign cva5_wrapper.l2[i + _mbase_request].inv_addr = inv_response_fifos[i].data_out;
				assign cva5_wrapper.l2[i + _mbase_request].inv_valid = inv_response_fifos[i].valid;
				localparam _bbase_F23DA_fifo = _gv_i_20;
				localparam _param_F23DA_DATA_WIDTH = 30;
				localparam _param_F23DA_FIFO_DEPTH = l2_config_and_types_L2_INVALIDATION_FIFO_DEPTHS;
				if (1) begin : inv_response_fifo
					localparam DATA_WIDTH = _param_F23DA_DATA_WIDTH;
					localparam FIFO_DEPTH = _param_F23DA_FIFO_DEPTH;
					wire clk;
					wire rst;
					localparam _mbase_fifo = _bbase_F23DA_fifo;
					localparam LOG2_FIFO_DEPTH = 4;
					if (1) begin : gen_width_3_plus
						wire [29:0] lut_ram [0:15];
						wire [3:0] write_index;
						wire [3:0] read_index;
						reg [LOG2_FIFO_DEPTH:0] inflight_count;
						always @(posedge clk)
							if (rst)
								inflight_count <= 0;
							else
								inflight_count <= (inflight_count + sv2v_cast_5(cva5_wrapper.l2_arb.inv_response_fifos[_mbase_fifo].pop)) - sv2v_cast_5(cva5_wrapper.l2_arb.inv_response_fifos[_mbase_fifo].push);
						assign cva5_wrapper.l2_arb.inv_response_fifos[_mbase_fifo].valid = inflight_count[LOG2_FIFO_DEPTH];
						assign cva5_wrapper.l2_arb.inv_response_fifos[_mbase_fifo].full = cva5_wrapper.l2_arb.inv_response_fifos[_mbase_fifo].valid & ~|inflight_count[3:0];
						lfsr #(
							.WIDTH(LOG2_FIFO_DEPTH),
							.NEEDS_RESET(1)
						) lfsr_read_index(
							.clk(clk),
							.rst(rst),
							.en(cva5_wrapper.l2_arb.inv_response_fifos[_mbase_fifo].pop),
							.value(read_index)
						);
						lfsr #(
							.WIDTH(LOG2_FIFO_DEPTH),
							.NEEDS_RESET(1)
						) lfsr_write_index(
							.clk(clk),
							.rst(rst),
							.en(cva5_wrapper.l2_arb.inv_response_fifos[_mbase_fifo].push),
							.value(write_index)
						);
						lutram_1w_1r #(
							.WIDTH(DATA_WIDTH),
							.DEPTH(FIFO_DEPTH)
						) write_port(
							.clk(clk),
							.waddr(write_index),
							.raddr(read_index),
							.ram_write(cva5_wrapper.l2_arb.inv_response_fifos[_mbase_fifo].potential_push),
							.new_ram_data(cva5_wrapper.l2_arb.inv_response_fifos[_mbase_fifo].data_in),
							.ram_data_out(cva5_wrapper.l2_arb.inv_response_fifos[_mbase_fifo].data_out)
						);
					end
				end
				assign inv_response_fifo.clk = clk;
				assign inv_response_fifo.rst = rst;
				assign inv_response_fifos[i].push = (reserv_valid & reserv_store) & ~reserv_id_v[i];
				assign inv_response_fifos[i].potential_push = (reserv_valid & reserv_store) & ~reserv_id_v[i];
				assign inv_response_fifos[i].data_in = requests[i][42-:30];
			end
			assign new_attr[6-:1] = reserv_id;
			assign new_attr[5-:5] = reserv_request[6-:5];
			assign new_attr[0] = cva5_wrapper.arb_mem.abort_request;
			assign data_attributes.data_in = new_attr;
			assign data_attributes.push = (reserv_valid & ~reserv_request[8]) & ~cva5_wrapper.arb_mem.abort_request;
			assign data_attributes.potential_push = (reserv_valid & ~reserv_request[8]) & ~cva5_wrapper.arb_mem.abort_request;
			localparam l2_config_and_types_L2_DATA_ATTRIBUTES_FIFO_DEPTH = 32;
			localparam _param_A053C_DATA_WIDTH = 7;
			localparam _param_A053C_FIFO_DEPTH = l2_config_and_types_L2_DATA_ATTRIBUTES_FIFO_DEPTH;
			if (1) begin : data_attributes_fifo
				localparam DATA_WIDTH = _param_A053C_DATA_WIDTH;
				localparam FIFO_DEPTH = _param_A053C_FIFO_DEPTH;
				wire clk;
				wire rst;
				localparam LOG2_FIFO_DEPTH = 5;
				if (1) begin : gen_width_3_plus
					wire [6:0] lut_ram [0:31];
					wire [4:0] write_index;
					wire [4:0] read_index;
					reg [LOG2_FIFO_DEPTH:0] inflight_count;
					always @(posedge clk)
						if (rst)
							inflight_count <= 0;
						else
							inflight_count <= (inflight_count + sv2v_cast_6(cva5_wrapper.l2_arb.data_attributes.pop)) - sv2v_cast_6(cva5_wrapper.l2_arb.data_attributes.push);
					assign cva5_wrapper.l2_arb.data_attributes.valid = inflight_count[LOG2_FIFO_DEPTH];
					assign cva5_wrapper.l2_arb.data_attributes.full = cva5_wrapper.l2_arb.data_attributes.valid & ~|inflight_count[4:0];
					lfsr #(
						.WIDTH(LOG2_FIFO_DEPTH),
						.NEEDS_RESET(1)
					) lfsr_read_index(
						.clk(clk),
						.rst(rst),
						.en(cva5_wrapper.l2_arb.data_attributes.pop),
						.value(read_index)
					);
					lfsr #(
						.WIDTH(LOG2_FIFO_DEPTH),
						.NEEDS_RESET(1)
					) lfsr_write_index(
						.clk(clk),
						.rst(rst),
						.en(cva5_wrapper.l2_arb.data_attributes.push),
						.value(write_index)
					);
					lutram_1w_1r #(
						.WIDTH(DATA_WIDTH),
						.DEPTH(FIFO_DEPTH)
					) write_port(
						.clk(clk),
						.waddr(write_index),
						.raddr(read_index),
						.ram_write(cva5_wrapper.l2_arb.data_attributes.potential_push),
						.new_ram_data(cva5_wrapper.l2_arb.data_attributes.data_in),
						.ram_data_out(cva5_wrapper.l2_arb.data_attributes.data_out)
					);
				end
			end
			assign data_attributes_fifo.clk = clk;
			assign data_attributes_fifo.rst = rst;
			assign data_attributes.pop = write_done;
			assign current_attr = data_attributes.data_out;
			always @(posedge clk)
				if (rst)
					burst_count <= 0;
				else if (write_done)
					burst_count <= 0;
				else if (data_attributes.valid & ~mem_data_fifo.full)
					burst_count <= burst_count + 1;
			assign write_done = (data_attributes.valid & ~mem_data_fifo.full) & (burst_count == current_attr[5-:5]);
			localparam _param_F0F2B_DATA_WIDTH = 32;
			localparam _param_F0F2B_FIFO_DEPTH = l2_config_and_types_L2_MEM_ADDR_FIFO_DEPTH;
			if (1) begin : mem_data
				localparam DATA_WIDTH = _param_F0F2B_DATA_WIDTH;
				localparam FIFO_DEPTH = _param_F0F2B_FIFO_DEPTH;
				wire clk;
				wire rst;
				localparam LOG2_FIFO_DEPTH = 4;
				if (1) begin : gen_width_3_plus
					wire [31:0] lut_ram [0:15];
					wire [3:0] write_index;
					wire [3:0] read_index;
					reg [LOG2_FIFO_DEPTH:0] inflight_count;
					always @(posedge clk)
						if (rst)
							inflight_count <= 0;
						else
							inflight_count <= (inflight_count + sv2v_cast_5(cva5_wrapper.l2_arb.mem_data_fifo.pop)) - sv2v_cast_5(cva5_wrapper.l2_arb.mem_data_fifo.push);
					assign cva5_wrapper.l2_arb.mem_data_fifo.valid = inflight_count[LOG2_FIFO_DEPTH];
					assign cva5_wrapper.l2_arb.mem_data_fifo.full = cva5_wrapper.l2_arb.mem_data_fifo.valid & ~|inflight_count[3:0];
					lfsr #(
						.WIDTH(LOG2_FIFO_DEPTH),
						.NEEDS_RESET(1)
					) lfsr_read_index(
						.clk(clk),
						.rst(rst),
						.en(cva5_wrapper.l2_arb.mem_data_fifo.pop),
						.value(read_index)
					);
					lfsr #(
						.WIDTH(LOG2_FIFO_DEPTH),
						.NEEDS_RESET(1)
					) lfsr_write_index(
						.clk(clk),
						.rst(rst),
						.en(cva5_wrapper.l2_arb.mem_data_fifo.push),
						.value(write_index)
					);
					lutram_1w_1r #(
						.WIDTH(DATA_WIDTH),
						.DEPTH(FIFO_DEPTH)
					) write_port(
						.clk(clk),
						.waddr(write_index),
						.raddr(read_index),
						.ram_write(cva5_wrapper.l2_arb.mem_data_fifo.potential_push),
						.new_ram_data(cva5_wrapper.l2_arb.mem_data_fifo.data_in),
						.ram_data_out(cva5_wrapper.l2_arb.mem_data_fifo.data_out)
					);
				end
			end
			assign mem_data.clk = clk;
			assign mem_data.rst = rst;
			assign mem_data_fifo.push = (data_attributes.valid & ~mem_data_fifo.full) & ~current_attr[0];
			assign mem_data_fifo.potential_push = (data_attributes.valid & ~mem_data_fifo.full) & ~current_attr[0];
			assign mem_data_fifo.data_in = input_data[current_attr[6-:1]];
			assign cva5_wrapper.arb_mem.wr_data = mem_data_fifo.data_out;
			assign cva5_wrapper.arb_mem.wr_data_valid = mem_data_fifo.valid;
			assign mem_data_fifo.pop = cva5_wrapper.arb_mem.wr_data_read;
			localparam _param_9E89B_DATA_WIDTH = 35;
			localparam _param_9E89B_FIFO_DEPTH = l2_config_and_types_L2_MEM_ADDR_FIFO_DEPTH;
			if (1) begin : mem_returndata
				localparam DATA_WIDTH = _param_9E89B_DATA_WIDTH;
				localparam FIFO_DEPTH = _param_9E89B_FIFO_DEPTH;
				wire clk;
				wire rst;
				localparam LOG2_FIFO_DEPTH = 4;
				if (1) begin : gen_width_3_plus
					wire [34:0] lut_ram [0:15];
					wire [3:0] write_index;
					wire [3:0] read_index;
					reg [LOG2_FIFO_DEPTH:0] inflight_count;
					always @(posedge clk)
						if (rst)
							inflight_count <= 0;
						else
							inflight_count <= (inflight_count + sv2v_cast_5(cva5_wrapper.l2_arb.mem_returndata_fifo.pop)) - sv2v_cast_5(cva5_wrapper.l2_arb.mem_returndata_fifo.push);
					assign cva5_wrapper.l2_arb.mem_returndata_fifo.valid = inflight_count[LOG2_FIFO_DEPTH];
					assign cva5_wrapper.l2_arb.mem_returndata_fifo.full = cva5_wrapper.l2_arb.mem_returndata_fifo.valid & ~|inflight_count[3:0];
					lfsr #(
						.WIDTH(LOG2_FIFO_DEPTH),
						.NEEDS_RESET(1)
					) lfsr_read_index(
						.clk(clk),
						.rst(rst),
						.en(cva5_wrapper.l2_arb.mem_returndata_fifo.pop),
						.value(read_index)
					);
					lfsr #(
						.WIDTH(LOG2_FIFO_DEPTH),
						.NEEDS_RESET(1)
					) lfsr_write_index(
						.clk(clk),
						.rst(rst),
						.en(cva5_wrapper.l2_arb.mem_returndata_fifo.push),
						.value(write_index)
					);
					lutram_1w_1r #(
						.WIDTH(DATA_WIDTH),
						.DEPTH(FIFO_DEPTH)
					) write_port(
						.clk(clk),
						.waddr(write_index),
						.raddr(read_index),
						.ram_write(cva5_wrapper.l2_arb.mem_returndata_fifo.potential_push),
						.new_ram_data(cva5_wrapper.l2_arb.mem_returndata_fifo.data_in),
						.ram_data_out(cva5_wrapper.l2_arb.mem_returndata_fifo.data_out)
					);
				end
			end
			assign mem_returndata.clk = clk;
			assign mem_returndata.rst = rst;
			assign mem_returndata_fifo.push = cva5_wrapper.arb_mem.rd_data_valid;
			assign mem_returndata_fifo.potential_push = cva5_wrapper.arb_mem.rd_data_valid;
			assign mem_returndata_fifo.data_in = {cva5_wrapper.arb_mem.rd_id, cva5_wrapper.arb_mem.rd_data};
			assign mem_return_data = mem_returndata_fifo.data_out;
			assign mem_returndata_fifo.pop = mem_returndata_fifo.valid;
			always @(*) begin
				if (_sv2v_0)
					;
				return_push = 1'sb0;
				return_push[mem_return_data[34-:1]] = mem_returndata_fifo.valid;
			end
			localparam l2_config_and_types_L2_READ_RETURN_FIFO_DEPTHS = 1;
			for (_gv_i_20 = 0; _gv_i_20 < l2_config_and_types_L2_NUM_PORTS; _gv_i_20 = _gv_i_20 + 1) begin : gen_return_data
				localparam i = _gv_i_20;
				assign returndata_fifos[i].pop = cva5_wrapper.l2[i + _mbase_request].rd_data_ack;
				assign return_data[i] = returndata_fifos[i].data_out;
				assign cva5_wrapper.l2[i + _mbase_request].rd_data = return_data[i][31-:32];
				assign cva5_wrapper.l2[i + _mbase_request].rd_sub_id = return_data[i][33-:2];
				assign cva5_wrapper.l2[i + _mbase_request].rd_data_valid = returndata_fifos[i].valid;
				localparam _bbase_1B6A8_fifo = _gv_i_20;
				localparam _param_1B6A8_DATA_WIDTH = 34;
				localparam _param_1B6A8_FIFO_DEPTH = l2_config_and_types_L2_READ_RETURN_FIFO_DEPTHS;
				if (1) begin : returndata_fifo
					localparam DATA_WIDTH = _param_1B6A8_DATA_WIDTH;
					localparam FIFO_DEPTH = _param_1B6A8_FIFO_DEPTH;
					wire clk;
					wire rst;
					localparam _mbase_fifo = _bbase_1B6A8_fifo;
					localparam LOG2_FIFO_DEPTH = 0;
					if (1) begin : gen_width_one
						always @(posedge clk)
							if (rst)
								cva5_wrapper.l2_arb.returndata_fifos[_mbase_fifo].valid <= 0;
							else
								cva5_wrapper.l2_arb.returndata_fifos[_mbase_fifo].valid <= cva5_wrapper.l2_arb.returndata_fifos[_mbase_fifo].push | (cva5_wrapper.l2_arb.returndata_fifos[_mbase_fifo].valid & ~cva5_wrapper.l2_arb.returndata_fifos[_mbase_fifo].pop);
						assign cva5_wrapper.l2_arb.returndata_fifos[_mbase_fifo].full = cva5_wrapper.l2_arb.returndata_fifos[_mbase_fifo].valid;
						always @(posedge clk)
							if (cva5_wrapper.l2_arb.returndata_fifos[_mbase_fifo].potential_push)
								cva5_wrapper.l2_arb.returndata_fifos[_mbase_fifo].data_out <= cva5_wrapper.l2_arb.returndata_fifos[_mbase_fifo].data_in;
					end
				end
				assign returndata_fifo.clk = clk;
				assign returndata_fifo.rst = rst;
				assign returndata_fifos[i].push = return_push[i];
				assign returndata_fifos[i].potential_push = return_push[i];
				assign returndata_fifos[i].data_in = {mem_return_data[33-:2], mem_return_data[31-:32]};
			end
			initial _sv2v_0 = 0;
		end
	endgenerate
	assign l2_arb.clk = clk;
	assign l2_arb.rst = rst;
	function automatic [7:0] sv2v_cast_8;
		input reg [7:0] inp;
		sv2v_cast_8 = inp;
	endfunction
	generate
		if (1) begin : l2_to_mem
			wire clk;
			wire rst;
			wire axi_arready;
			reg axi_arvalid;
			wire [31:0] axi_araddr;
			wire [7:0] axi_arlen;
			wire [2:0] axi_arsize;
			wire [1:0] axi_arburst;
			wire [2:0] axi_arprot;
			wire [3:0] axi_arcache;
			wire [5:0] axi_arid;
			wire axi_rready;
			wire axi_rvalid;
			wire [31:0] axi_rdata;
			wire [1:0] axi_rresp;
			wire axi_rlast;
			wire [5:0] axi_rid;
			wire axi_awready;
			reg axi_awvalid;
			wire [31:0] axi_awaddr;
			wire [7:0] axi_awlen;
			wire [2:0] axi_awsize;
			wire [1:0] axi_awburst;
			wire [3:0] axi_awcache;
			wire [2:0] axi_awprot;
			wire axi_wready;
			wire axi_wvalid;
			wire [31:0] axi_wdata;
			wire [3:0] axi_wstrb;
			wire axi_wlast;
			wire axi_bready;
			wire axi_bvalid;
			wire [1:0] axi_bresp;
			wire pop_request;
			wire read_modify_write;
			reg read_modify_write_in_progress;
			reg address_phase_complete;
			wire [31:0] amo_result;
			reg [31:0] amo_result_r;
			localparam [1209:0] cva5_config_EXAMPLE_CONFIG = 1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002;
			reg [$clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[678-:32]) - 1:0] read_count;
			reg amo_write_ready;
			wire [4:0] write_reference_burst_count;
			localparam riscv_types_XLEN = 32;
			wire [68:0] amo_alu_inputs;
			reg write_in_progress;
			reg write_transfer_complete;
			wire pop;
			reg [4:0] write_burst_count;
			wire [4:0] burst_count;
			wire [4:0] burst_count_r;
			reg on_last_burst;
			assign read_modify_write = cva5_wrapper.arb_mem.is_amo && ((cva5_wrapper.arb_mem.amo_type_or_burst_size != 5'b00010) || (cva5_wrapper.arb_mem.amo_type_or_burst_size != 5'b00011));
			always @(posedge clk)
				if (rst)
					read_modify_write_in_progress <= 0;
				else if (axi_bvalid)
					read_modify_write_in_progress <= 0;
				else if (cva5_wrapper.arb_mem.request_valid & read_modify_write)
					read_modify_write_in_progress <= 1;
			always @(posedge clk)
				if (rst)
					address_phase_complete <= 0;
				else if (pop)
					address_phase_complete <= 0;
				else if (axi_arvalid & axi_arready)
					address_phase_complete <= 1;
			always @(posedge clk)
				if (rst)
					read_count <= 0;
				else if (axi_rvalid && (axi_rid == sv2v_cast_6(cva5_wrapper.arb_mem.id)))
					read_count <= read_count + 1;
			assign amo_alu_inputs[68-:32] = axi_rdata;
			assign amo_alu_inputs[36-:32] = cva5_wrapper.arb_mem.wr_data;
			assign amo_alu_inputs[4-:5] = cva5_wrapper.arb_mem.amo_type_or_burst_size;
			amo_alu amo_unit(
				.amo_alu_inputs(amo_alu_inputs),
				.result(amo_result)
			);
			always @(posedge clk)
				if (axi_rvalid && (read_count == cva5_wrapper.arb_mem.addr[$clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[678-:32]) - 1:0]))
					amo_result_r <= amo_result;
			always @(posedge clk)
				if (rst)
					amo_write_ready <= 0;
				else if (pop)
					amo_write_ready <= 0;
				else if ((cva5_wrapper.arb_mem.is_amo && axi_rvalid) && (read_count == cva5_wrapper.arb_mem.addr[$clog2(1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002[678-:32]) - 1:0]))
					amo_write_ready <= 1;
			assign burst_count = cva5_wrapper.arb_mem.amo_type_or_burst_size;
			assign axi_arlen = sv2v_cast_8(burst_count);
			assign axi_arburst = 2'b01;
			assign axi_rready = 1;
			assign axi_arsize = 3'b010;
			assign axi_arcache = 4'b0011;
			assign axi_arprot = 1'sb0;
			assign axi_arid = sv2v_cast_6(cva5_wrapper.arb_mem.id);
			assign axi_araddr = {cva5_wrapper.arb_mem.addr, 2'b00} & {25'h1ffffff, ~burst_count, 2'b00};
			assign write_reference_burst_count = (read_modify_write ? 0 : burst_count);
			assign axi_awlen = sv2v_cast_8(write_reference_burst_count);
			assign axi_awburst = 2'b01;
			assign axi_awsize = 3'b010;
			assign axi_bready = 1;
			assign axi_awcache = 4'b0011;
			assign axi_awprot = 1'sb0;
			assign axi_awaddr = {cva5_wrapper.arb_mem.addr, 2'b00};
			assign axi_wdata = (read_modify_write ? amo_result_r : cva5_wrapper.arb_mem.wr_data);
			assign axi_wstrb = (read_modify_write ? {4 {1'sb1}} : cva5_wrapper.arb_mem.be);
			assign pop = ((axi_arvalid & axi_arready) & ~read_modify_write) | (axi_awvalid & axi_awready);
			assign cva5_wrapper.arb_mem.request_pop = pop;
			always @(posedge clk)
				if (rst)
					axi_arvalid <= 0;
				else if (axi_arvalid & axi_arready)
					axi_arvalid <= 0;
				else if ((cva5_wrapper.arb_mem.request_valid & cva5_wrapper.arb_mem.rnw) & ~address_phase_complete)
					axi_arvalid <= 1;
			always @(posedge clk)
				if (rst)
					axi_awvalid <= 0;
				else if (((cva5_wrapper.arb_mem.wr_data_valid & cva5_wrapper.arb_mem.request_valid) & (~cva5_wrapper.arb_mem.rnw | amo_write_ready)) & ~write_in_progress)
					axi_awvalid <= 1;
				else if (axi_awready)
					axi_awvalid <= 0;
			always @(posedge clk)
				if (rst)
					write_in_progress <= 0;
				else if (axi_bvalid)
					write_in_progress <= 0;
				else if ((cva5_wrapper.arb_mem.wr_data_valid & cva5_wrapper.arb_mem.request_valid) & (~cva5_wrapper.arb_mem.rnw | amo_write_ready))
					write_in_progress <= 1;
			always @(posedge clk)
				if (rst)
					write_burst_count <= 0;
				else if (axi_bvalid)
					write_burst_count <= 0;
				else if ((axi_wvalid && axi_wready) && (write_reference_burst_count != write_burst_count))
					write_burst_count <= write_burst_count + 1;
			always @(posedge clk)
				if (rst)
					on_last_burst <= 0;
				else if (axi_bvalid)
					on_last_burst <= 0;
				else if ((~write_in_progress && (write_reference_burst_count == 0)) || (write_in_progress && (write_reference_burst_count == write_burst_count)))
					on_last_burst <= 1;
			always @(posedge clk)
				if (rst)
					write_transfer_complete <= 0;
				else if (axi_bvalid)
					write_transfer_complete <= 0;
				else if (axi_wlast && axi_wready)
					write_transfer_complete <= 1;
			assign axi_wvalid = (write_in_progress & cva5_wrapper.arb_mem.wr_data_valid) & ~write_transfer_complete;
			assign axi_wlast = ((on_last_burst & write_in_progress) & cva5_wrapper.arb_mem.wr_data_valid) & ~write_transfer_complete;
			assign cva5_wrapper.arb_mem.wr_data_read = (write_in_progress & axi_wready) & ~write_transfer_complete;
			assign cva5_wrapper.arb_mem.rd_data = axi_rdata;
			localparam l2_config_and_types_L2_NUM_PORTS = 2;
			localparam l2_config_and_types_L2_SUB_ID_W = 2;
			localparam l2_config_and_types_L2_ID_W = 3;
			assign cva5_wrapper.arb_mem.rd_id = axi_rid[2:0];
			assign cva5_wrapper.arb_mem.rd_data_valid = axi_rvalid;
		end
	endgenerate
	assign l2_to_mem.clk = clk;
	assign l2_to_mem.rst = rst;
	assign l2_to_mem.axi_arready = axi_arready;
	assign axi_arvalid = l2_to_mem.axi_arvalid;
	assign axi_araddr = l2_to_mem.axi_araddr;
	assign axi_arlen = l2_to_mem.axi_arlen;
	assign axi_arsize = l2_to_mem.axi_arsize;
	assign axi_arburst = l2_to_mem.axi_arburst;
	assign axi_arprot = l2_to_mem.axi_arprot;
	assign axi_arcache = l2_to_mem.axi_arcache;
	assign axi_arid = l2_to_mem.axi_arid;
	assign axi_rready = l2_to_mem.axi_rready;
	assign l2_to_mem.axi_rvalid = axi_rvalid;
	assign l2_to_mem.axi_rdata = axi_rdata;
	assign l2_to_mem.axi_rresp = axi_rresp;
	assign l2_to_mem.axi_rlast = axi_rlast;
	assign l2_to_mem.axi_rid = axi_rid;
	assign l2_to_mem.axi_awready = axi_awready;
	assign axi_awvalid = l2_to_mem.axi_awvalid;
	assign axi_awaddr = l2_to_mem.axi_awaddr;
	assign axi_awlen = l2_to_mem.axi_awlen;
	assign axi_awsize = l2_to_mem.axi_awsize;
	assign axi_awburst = l2_to_mem.axi_awburst;
	assign axi_awcache = l2_to_mem.axi_awcache;
	assign axi_awprot = l2_to_mem.axi_awprot;
	assign l2_to_mem.axi_wready = axi_wready;
	assign axi_wvalid = l2_to_mem.axi_wvalid;
	assign axi_wdata = l2_to_mem.axi_wdata;
	assign axi_wstrb = l2_to_mem.axi_wstrb;
	assign axi_wlast = l2_to_mem.axi_wlast;
	assign axi_bready = l2_to_mem.axi_bready;
	assign l2_to_mem.axi_bvalid = axi_bvalid;
	assign l2_to_mem.axi_bresp = axi_bresp;
	generate
		if (1) begin : scaiev_glue
			reg _sv2v_0;
			localparam [1209:0] cva5_config_EXAMPLE_CONFIG = 1210'h3fc0000000000000001000000011e00000000000043f800000020000008000000001000000008700000007fffffff800000008fffffff00000002000000400000010000000002000000010e0000000ffffffff000000011ffffffe0000000400000081800000008fffffffc000000047ffffff980000001bffffffec0000000dffffffe0000000100000002000002000000000800000002;
			localparam [1209:0] CONFIG = cva5_config_EXAMPLE_CONFIG;
			wire clk;
			wire rst;
			wire [12:0] WrRD_spawn_issue_addr_o;
			wire RdPipeInto_stage_executesv1_2_o;
			wire RdPipeInto_stage_executecva_2_o;
			wire glueToSCAL_IValid_cond_all_1_o;
			wire glueToSCAL_IValid_cond_all_2_o;
			wire glueToSCAL_IValid_cond_all_3_o;
			wire [12:0] glueToSCAL_WrRD_spawn_addr_2_o;
			wire [12:0] glueToSCAL_WrRD_spawn_addr_1_o;
			wire decode_wrReg_hold;
			wire decode_rdReg_RD;
			wire decode_isRepeated_RdRD;
			wire issue_isFirst_RdRD;
			wire execute_isFirst_RdRD;
			wire issue_stall_before_mem;
			wire execute_stall_mem;
			wire mem_read_pending;
			reg set_mem_read_pending;
			wire fetch_wrPCValid_r;
			wire [31:0] fetch_wrPC_r;
			wire issue_stall_before_cf;
			reg wrPC_after_fetch_valid;
			reg [31:0] wrPC_after_fetch;
			reg hazard_unit_scaiev_decode_stall_set;
			wire decode_valid_regular = cva5_wrapper.scaiev.decode_valid && !(cva5_wrapper.scaiev.decode_wrReg || cva5_wrapper.scaiev.decode_rdReg);
			wire decode_is_isax_decoupled_wb = 0;
			wire issue_is_isax_decoupled_wb = (!cva5_wrapper.scaiev.issue_isStalling && !cva5_wrapper.scaiev.issue_stall) && 0;
			wire unlock_all_registers = 0;
			wire decode_wrReg_cancel;
			localparam scaiev_config_ENABLE_SCAIEV_REGHAZARD = 0;
			if (scaiev_config_ENABLE_SCAIEV_REGHAZARD) begin : genblk1
				reg [4:0] rd_last_locked;
				reg rd_inuse_bitmap [0:31];
				always @(posedge clk) begin
					if (cva5_wrapper.scaiev.issue_isFlushing && (rd_last_locked != {5 {1'sb0}}))
						rd_inuse_bitmap[rd_last_locked] <= 0;
					if (cva5_wrapper.scaiev.issue_isFlushing || ((cva5_wrapper.scaiev.issue_valid && !cva5_wrapper.scaiev.issue_stall) && !cva5_wrapper.scaiev.issue_isStalling))
						rd_last_locked <= 1'sb0;
					if (rst || unlock_all_registers) begin : sv2v_autoblock_84
						reg signed [31:0] i;
						for (i = 0; i < 32; i = i + 1)
							rd_inuse_bitmap[i] <= 0;
					end
					else if ((((((decode_valid_regular && decode_is_isax_decoupled_wb) && (cva5_wrapper.scaiev.decode_RD_id != {5 {1'sb0}})) && !cva5_wrapper.scaiev.decode_stall) && !cva5_wrapper.scaiev.decode_flush) && !cva5_wrapper.scaiev.decode_isStalling) && !cva5_wrapper.scaiev.decode_isFlushing) begin
						rd_inuse_bitmap[cva5_wrapper.scaiev.decode_RD_id] <= 1'sb1;
						rd_last_locked <= cva5_wrapper.scaiev.decode_RD_id;
					end
					else if (((cva5_wrapper.scaiev.decode_wrReg && !cva5_wrapper.scaiev.decode_stall) || decode_wrReg_cancel) && (cva5_wrapper.scaiev.decode_wrReg_RD != {5 {1'sb0}}))
						rd_inuse_bitmap[cva5_wrapper.scaiev.decode_wrReg_RD] <= 0;
				end
				reg rs1_conflict;
				reg rs2_conflict;
				reg rd_as_rs_conflict;
				reg rd_conflict;
				always @(*) begin
					if (_sv2v_0)
						;
					rs1_conflict = cva5_wrapper.scaiev.decode_RS1_valid && rd_inuse_bitmap[cva5_wrapper.scaiev.decode_RS1_id];
					rs2_conflict = cva5_wrapper.scaiev.decode_RS2_valid && rd_inuse_bitmap[cva5_wrapper.scaiev.decode_RS2_id];
					rd_as_rs_conflict = cva5_wrapper.scaiev.decode_RD_AS_RS_valid && rd_inuse_bitmap[cva5_wrapper.scaiev.decode_RD_AS_RS_id];
					rd_conflict = cva5_wrapper.scaiev.decode_RD_valid && rd_inuse_bitmap[cva5_wrapper.scaiev.decode_RD_id];
					hazard_unit_scaiev_decode_stall_set = decode_valid_regular && (((rs1_conflict || rs2_conflict) || rd_as_rs_conflict) || rd_conflict);
				end
			end
			else begin : genblk1
				wire [1:1] sv2v_tmp_30C81;
				assign sv2v_tmp_30C81 = 0;
				always @(*) hazard_unit_scaiev_decode_stall_set = sv2v_tmp_30C81;
			end
			wire explicit_free_reg;
			wire [5:0] explicit_free_reg_addr;
			localparam scaiev_config_ENABLE_DECOUPLED_WRITEBACK = 0;
			localparam scaiev_config_ENABLE_DECOUPLED_WRITEBACK_WAW = 1;
			if (1) begin : genblk2
				assign cva5_wrapper.scaiev.renamer_addtofree_skip = 1'b0;
				assign explicit_free_reg = 0;
				assign explicit_free_reg_addr = 1'sb0;
			end
			assign WrRD_spawn_issue_addr_o = {cva5_wrapper.scaiev.issue_prev_phys_RD_decoupled, cva5_wrapper.scaiev.issue_phys_RD_decoupled};
			wire ISAX_wrPCValid_0_s = 0;
			wire ISAX_wrPCValid_1_s = 0;
			wire ISAX_wrPCValid_2_s = 0;
			wire ISAX_wrPCValid_3_s = 0;
			assign cva5_wrapper.scaiev.decode_isSCAIEV = 1'b0;
			assign cva5_wrapper.scaiev.decode_isSCAIEV_stdencoding = 1'b0;
			assign cva5_wrapper.scaiev.decode_isSCAIEV_usesRS1 = 1'b0;
			assign cva5_wrapper.scaiev.decode_isSCAIEV_usesRS2 = 1'b0;
			assign cva5_wrapper.scaiev.decode_isSCAIEV_usesRD_AS_RS = 1'b0;
			assign cva5_wrapper.scaiev.decode_isSCAIEV_usesRD = 1'b0;
			assign cva5_wrapper.scaiev.decode_isSCAIEV_usesRD_decoupled = 1'b0;
			assign glueToSCAL_IValid_cond_all_1_o = (cva5_wrapper.scaiev.decode_valid && !cva5_wrapper.scaiev.decode_wrReg) && !cva5_wrapper.scaiev.decode_rdReg;
			assign glueToSCAL_IValid_cond_all_2_o = cva5_wrapper.scaiev.issue_valid;
			assign glueToSCAL_IValid_cond_all_3_o = cva5_wrapper.scaiev.execute_valid;
			assign decode_isRepeated_RdRD = 1'b0;
			assign decode_rdReg_RD = 1'b0;
			assign issue_isFirst_RdRD = 1'b0;
			assign execute_isFirst_RdRD = 1'b0;
			assign cva5_wrapper.scaiev.decode_repeat_next = 1'b0;
			assign cva5_wrapper.scaiev.decode_rdReg = 1'b0;
			assign cva5_wrapper.scaiev.decode_rdReg_RS1 = 5'd0;
			assign cva5_wrapper.scaiev.decode_rdReg_RS2 = 5'd0;
			assign cva5_wrapper.scaiev.decode_skip_wb = 1'b0;
			assign cva5_wrapper.scaiev.decode_RS1_override = 1'b0;
			assign cva5_wrapper.scaiev.decode_RS2_override = 1'b0;
			assign cva5_wrapper.scaiev.decode_RD_AS_RS_override = 1'b0;
			assign decode_wrReg_hold = 1'b0;
			assign cva5_wrapper.scaiev.fetch_stall = 0;
			assign cva5_wrapper.scaiev.decode_stall = hazard_unit_scaiev_decode_stall_set || 0;
			assign cva5_wrapper.scaiev.issue_stall = (((cva5_wrapper.scaiev.issue_injectLS_potentiallyValid || cva5_wrapper.scaiev.execute_injectLS_potentiallyValid) || issue_stall_before_mem) || issue_stall_before_cf) || 0;
			assign cva5_wrapper.scaiev.execute_stall = execute_stall_mem || 0;
			assign cva5_wrapper.scaiev.execute_flush = 1'b0;
			assign cva5_wrapper.scaiev.issue_flush = 1'b0;
			assign cva5_wrapper.scaiev.decode_flush = 1'b0;
			assign cva5_wrapper.scaiev.fetch_flush = fetch_wrPCValid_r;
			assign cva5_wrapper.scaiev.execute_wrRD = 1'b0;
			assign cva5_wrapper.scaiev.execute_wrRD_data = 1'sbx;
			assign glueToSCAL_WrRD_spawn_addr_2_o = {cva5_wrapper.scaiev.issue_prev_phys_RD_decoupled, cva5_wrapper.scaiev.issue_phys_RD_decoupled};
			assign glueToSCAL_WrRD_spawn_addr_1_o = {cva5_wrapper.scaiev.decode_prev_phys_RD_decoupled, cva5_wrapper.scaiev.decode_phys_RD_decoupled};
			always @(*) begin
				if (_sv2v_0)
					;
				cva5_wrapper.scaiev.rf_wrReg = 1'b0;
				cva5_wrapper.scaiev.rf_wrReg_cancel = 1'b0;
				cva5_wrapper.scaiev.rf_wrReg_phys_RD = 1'sbx;
				cva5_wrapper.scaiev.rf_wrReg_prev_phys_RD = 1'sbx;
				cva5_wrapper.scaiev.rf_wrReg_data = 1'sbx;
				cva5_wrapper.scaiev.rf_isDecoupledWB = 0;
			end
			assign cva5_wrapper.scaiev.decode_wrReg = 1'b0;
			assign decode_wrReg_cancel = 1'b0;
			assign cva5_wrapper.scaiev.decode_wrReg_RD = 5'd0;
			assign cva5_wrapper.scaiev.decode_wrReg_data = 32'd0;
			assign issue_stall_before_mem = 0;
			assign execute_stall_mem = 0;
			assign mem_read_pending = 0;
			always @(*) begin
				if (_sv2v_0)
					;
				cva5_wrapper.scaiev.execute_injectLS_potentiallyValid = 1'b0;
				cva5_wrapper.scaiev.execute_injectLS_valid = 1'b0;
				cva5_wrapper.scaiev.execute_injectLS_rnw = 1'sbx;
				cva5_wrapper.scaiev.execute_injectLS_relaxedOrdering = 1'sbx;
				cva5_wrapper.scaiev.execute_injectLS_addr = 1'sbx;
				cva5_wrapper.scaiev.execute_injectLS_storeVal = 1'sbx;
				set_mem_read_pending = 1'b0;
			end
			assign cva5_wrapper.scaiev.issue_injectLS_potentiallyValid = 1'b0;
			assign cva5_wrapper.scaiev.issue_injectLS_valid = 1'b0;
			assign cva5_wrapper.scaiev.issue_injectLS_rnw = 1'b0;
			assign cva5_wrapper.scaiev.issue_injectLS_relaxedOrdering = 1'b0;
			assign cva5_wrapper.scaiev.issue_injectLS_addr = 1'sb0;
			assign cva5_wrapper.scaiev.issue_injectLS_storeVal = 1'sb0;
			assign issue_stall_before_cf = 0;
			assign fetch_wrPCValid_r = 1'b0;
			assign fetch_wrPC_r = 1'sbx;
			always @(*) begin
				if (_sv2v_0)
					;
				wrPC_after_fetch_valid = fetch_wrPCValid_r;
				wrPC_after_fetch = fetch_wrPC_r;
				cva5_wrapper.scaiev.fetch_wrPCValid = fetch_wrPCValid_r;
				cva5_wrapper.scaiev.fetch_wrPC = fetch_wrPC_r;
			end
			assign RdPipeInto_stage_executesv1_2_o = cva5_wrapper.scaiev.issue_isSCAIEV;
			assign RdPipeInto_stage_executecva_2_o = !cva5_wrapper.scaiev.issue_isSCAIEV;
			assign cva5_wrapper.scaiev.execute_deq = 0;
			assign cva5_wrapper.scaiev.execute_commitNow = 1'b0;
			assign cva5_wrapper.scaiev.execute_commitNow_ID = 1'sb0;
			assign cva5_wrapper.scaiev.execute_commitNow_expects_rd = 1'b0;
			initial _sv2v_0 = 0;
		end
	endgenerate
	assign scaiev_glue.clk = clk;
	assign scaiev_glue.rst = rst;
	assign RdPipeInto_stage_executesv1_2_o = scaiev_glue.RdPipeInto_stage_executesv1_2_o;
	assign RdPipeInto_stage_executecva_2_o = scaiev_glue.RdPipeInto_stage_executecva_2_o;
	assign glueToSCAL_IValid_cond_all_1_o = scaiev_glue.glueToSCAL_IValid_cond_all_1_o;
	assign glueToSCAL_IValid_cond_all_2_o = scaiev_glue.glueToSCAL_IValid_cond_all_2_o;
	assign glueToSCAL_IValid_cond_all_3_o = scaiev_glue.glueToSCAL_IValid_cond_all_3_o;
	assign glueToSCAL_WrRD_spawn_addr_2_o = scaiev_glue.glueToSCAL_WrRD_spawn_addr_2_o;
	assign glueToSCAL_WrRD_spawn_addr_1_o = scaiev_glue.glueToSCAL_WrRD_spawn_addr_1_o;
endmodule
module cva5_wrapper_verilog (
	clk,
	rst,
	instruction_bram_addr,
	instruction_bram_en,
	instruction_bram_we,
	instruction_bram_din,
	instruction_bram_dout,
	data_bram_addr,
	data_bram_en,
	data_bram_we,
	data_bram_din,
	data_bram_dout,
	m_axi_awvalid,
	m_axi_awready,
	m_axi_awaddr,
	m_axi_awlen,
	m_axi_awsize,
	m_axi_awburst,
	m_axi_awcache,
	m_axi_wvalid,
	m_axi_wready,
	m_axi_wdata,
	m_axi_wstrb,
	m_axi_wlast,
	m_axi_bvalid,
	m_axi_bready,
	m_axi_bresp,
	m_axi_arvalid,
	m_axi_arready,
	m_axi_araddr,
	m_axi_arlen,
	m_axi_arsize,
	m_axi_arburst,
	m_axi_arcache,
	m_axi_rvalid,
	m_axi_rready,
	m_axi_rdata,
	m_axi_rresp,
	m_axi_rlast,
	m_axi_cache_awvalid,
	m_axi_cache_awready,
	m_axi_cache_awid,
	m_axi_cache_awaddr,
	m_axi_cache_awlen,
	m_axi_cache_awsize,
	m_axi_cache_awburst,
	m_axi_cache_awcache,
	m_axi_cache_awprot,
	m_axi_cache_wvalid,
	m_axi_cache_wready,
	m_axi_cache_wdata,
	m_axi_cache_wstrb,
	m_axi_cache_wlast,
	m_axi_cache_bvalid,
	m_axi_cache_bready,
	m_axi_cache_bresp,
	m_axi_cache_bid,
	m_axi_cache_arvalid,
	m_axi_cache_arready,
	m_axi_cache_arid,
	m_axi_cache_araddr,
	m_axi_cache_arlen,
	m_axi_cache_arsize,
	m_axi_cache_arburst,
	m_axi_cache_arcache,
	m_axi_cache_arprot,
	m_axi_cache_rvalid,
	m_axi_cache_rready,
	m_axi_cache_rid,
	m_axi_cache_rdata,
	m_axi_cache_rresp,
	m_axi_cache_rlast,
	RdPipeInto_stage_executesv1_2_o,
	RdPipeInto_stage_executecva_2_o,
	glueToSCAL_IValid_cond_all_1_o,
	glueToSCAL_IValid_cond_all_2_o,
	glueToSCAL_IValid_cond_all_3_o
);
	input wire clk;
	input wire rst;
	(* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 instruction_bram ADDR" *) output wire [29:0] instruction_bram_addr;
	(* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 instruction_bram EN" *) output wire instruction_bram_en;
	(* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 instruction_bram WE" *) output wire [3:0] instruction_bram_we;
	(* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 instruction_bram DIN" *) output wire [31:0] instruction_bram_din;
	(* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 instruction_bram DOUT" *) input wire [31:0] instruction_bram_dout;
	(* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 data_bram ADDR" *) output wire [29:0] data_bram_addr;
	(* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 data_bram EN" *) output wire data_bram_en;
	(* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 data_bram WE" *) output wire [3:0] data_bram_we;
	(* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 data_bram DIN" *) output wire [31:0] data_bram_din;
	(* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 data_bram DOUT" *) input wire [31:0] data_bram_dout;
	output wire m_axi_awvalid;
	input wire m_axi_awready;
	output wire [31:0] m_axi_awaddr;
	output wire [7:0] m_axi_awlen;
	output wire [2:0] m_axi_awsize;
	output wire [1:0] m_axi_awburst;
	output wire [3:0] m_axi_awcache;
	output wire m_axi_wvalid;
	input wire m_axi_wready;
	output wire [31:0] m_axi_wdata;
	output wire [3:0] m_axi_wstrb;
	output wire m_axi_wlast;
	input wire m_axi_bvalid;
	output wire m_axi_bready;
	input wire [1:0] m_axi_bresp;
	output wire m_axi_arvalid;
	input wire m_axi_arready;
	output wire [31:0] m_axi_araddr;
	output wire [7:0] m_axi_arlen;
	output wire [2:0] m_axi_arsize;
	output wire [1:0] m_axi_arburst;
	output wire [3:0] m_axi_arcache;
	input wire m_axi_rvalid;
	output wire m_axi_rready;
	input wire [31:0] m_axi_rdata;
	input wire [1:0] m_axi_rresp;
	input wire m_axi_rlast;
	output wire m_axi_cache_awvalid;
	input wire m_axi_cache_awready;
	output wire [5:0] m_axi_cache_awid;
	output wire [31:0] m_axi_cache_awaddr;
	output wire [7:0] m_axi_cache_awlen;
	output wire [2:0] m_axi_cache_awsize;
	output wire [1:0] m_axi_cache_awburst;
	output wire [3:0] m_axi_cache_awcache;
	output wire [2:0] m_axi_cache_awprot;
	output wire m_axi_cache_wvalid;
	input wire m_axi_cache_wready;
	output wire [31:0] m_axi_cache_wdata;
	output wire [3:0] m_axi_cache_wstrb;
	output wire m_axi_cache_wlast;
	input wire m_axi_cache_bvalid;
	output wire m_axi_cache_bready;
	input wire [1:0] m_axi_cache_bresp;
	input wire [5:0] m_axi_cache_bid;
	output wire m_axi_cache_arvalid;
	input wire m_axi_cache_arready;
	output wire [5:0] m_axi_cache_arid;
	output wire [31:0] m_axi_cache_araddr;
	output wire [7:0] m_axi_cache_arlen;
	output wire [2:0] m_axi_cache_arsize;
	output wire [1:0] m_axi_cache_arburst;
	output wire [3:0] m_axi_cache_arcache;
	output wire [2:0] m_axi_cache_arprot;
	input wire m_axi_cache_rvalid;
	output wire m_axi_cache_rready;
	input wire [5:0] m_axi_cache_rid;
	input wire [31:0] m_axi_cache_rdata;
	input wire [1:0] m_axi_cache_rresp;
	input wire m_axi_cache_rlast;
	output wire RdPipeInto_stage_executesv1_2_o;
	output wire RdPipeInto_stage_executecva_2_o;
	output wire glueToSCAL_IValid_cond_all_1_o;
	output wire glueToSCAL_IValid_cond_all_2_o;
	output wire glueToSCAL_IValid_cond_all_3_o;
	wire [12:0] glueToSCAL_WrRD_spawn_addr_2_s;
	wire [12:0] glueToSCAL_WrRD_spawn_addr_1_s;
	wire instruction_bram_clk;
	assign instruction_bram_clk = clk;
	wire instruction_bram_rst;
	assign instruction_bram_rst = rst;
	wire data_bram_clk;
	assign data_bram_clk = clk;
	wire data_bram_rst;
	assign data_bram_rst = rst;
	wire [5:0] m_axi_awid;
	wire [5:0] m_axi_bid;
	wire [5:0] m_axi_arid;
	wire [5:0] m_axi_rid;
	wire [31:0] instruction_bram_addr_long;
	assign instruction_bram_addr = instruction_bram_addr_long[29:0];
	wire [31:0] data_bram_addr_long;
	assign data_bram_addr = data_bram_addr_long[29:0];
	cva5_wrapper cva5_wrapper(
		.clk(clk),
		.rst(rst),
		.instruction_bram_addr(instruction_bram_addr_long),
		.instruction_bram_en(instruction_bram_en),
		.instruction_bram_we(instruction_bram_we),
		.instruction_bram_din(instruction_bram_din),
		.instruction_bram_dout(instruction_bram_dout),
		.data_bram_addr(data_bram_addr_long),
		.data_bram_en(data_bram_en),
		.data_bram_we(data_bram_we),
		.data_bram_din(data_bram_din),
		.data_bram_dout(data_bram_dout),
		.m_axi_awvalid(m_axi_awvalid),
		.m_axi_awready(m_axi_awready),
		.m_axi_awid(m_axi_awid),
		.m_axi_awaddr(m_axi_awaddr),
		.m_axi_awlen(m_axi_awlen),
		.m_axi_awsize(m_axi_awsize),
		.m_axi_awburst(m_axi_awburst),
		.m_axi_awcache(m_axi_awcache),
		.m_axi_wvalid(m_axi_wvalid),
		.m_axi_wready(m_axi_wready),
		.m_axi_wdata(m_axi_wdata),
		.m_axi_wstrb(m_axi_wstrb),
		.m_axi_wlast(m_axi_wlast),
		.m_axi_bvalid(m_axi_bvalid),
		.m_axi_bready(m_axi_bready),
		.m_axi_bresp(m_axi_bresp),
		.m_axi_bid(m_axi_bid),
		.m_axi_arvalid(m_axi_arvalid),
		.m_axi_arready(m_axi_arready),
		.m_axi_arid(m_axi_arid),
		.m_axi_araddr(m_axi_araddr),
		.m_axi_arlen(m_axi_arlen),
		.m_axi_arsize(m_axi_arsize),
		.m_axi_arburst(m_axi_arburst),
		.m_axi_arcache(m_axi_arcache),
		.m_axi_rvalid(m_axi_rvalid),
		.m_axi_rready(m_axi_rready),
		.m_axi_rid(m_axi_rid),
		.m_axi_rdata(m_axi_rdata),
		.m_axi_rresp(m_axi_rresp),
		.m_axi_rlast(m_axi_rlast),
		.axi_awvalid(m_axi_cache_awvalid),
		.axi_awready(m_axi_cache_awready),
		.axi_awid(m_axi_cache_awid),
		.axi_awaddr(m_axi_cache_awaddr),
		.axi_awlen(m_axi_cache_awlen),
		.axi_awsize(m_axi_cache_awsize),
		.axi_awburst(m_axi_cache_awburst),
		.axi_awcache(m_axi_cache_awcache),
		.axi_awprot(m_axi_cache_awprot),
		.axi_wvalid(m_axi_cache_wvalid),
		.axi_wready(m_axi_cache_wready),
		.axi_wdata(m_axi_cache_wdata),
		.axi_wstrb(m_axi_cache_wstrb),
		.axi_wlast(m_axi_cache_wlast),
		.axi_bvalid(m_axi_cache_bvalid),
		.axi_bready(m_axi_cache_bready),
		.axi_bresp(m_axi_cache_bresp),
		.axi_bid(m_axi_cache_bid),
		.axi_arvalid(m_axi_cache_arvalid),
		.axi_arready(m_axi_cache_arready),
		.axi_arid(m_axi_cache_arid),
		.axi_araddr(m_axi_cache_araddr),
		.axi_arlen(m_axi_cache_arlen),
		.axi_arsize(m_axi_cache_arsize),
		.axi_arburst(m_axi_cache_arburst),
		.axi_arcache(m_axi_cache_arcache),
		.axi_arprot(m_axi_cache_arprot),
		.axi_rvalid(m_axi_cache_rvalid),
		.axi_rready(m_axi_cache_rready),
		.axi_rid(m_axi_cache_rid),
		.axi_rdata(m_axi_cache_rdata),
		.axi_rresp(m_axi_cache_rresp),
		.axi_rlast(m_axi_cache_rlast),
		.timer_interrupt(0),
		.interrupt(0),
		.RdPipeInto_stage_executesv1_2_o(RdPipeInto_stage_executesv1_2_o),
		.RdPipeInto_stage_executecva_2_o(RdPipeInto_stage_executecva_2_o),
		.glueToSCAL_IValid_cond_all_1_o(glueToSCAL_IValid_cond_all_1_o),
		.glueToSCAL_IValid_cond_all_2_o(glueToSCAL_IValid_cond_all_2_o),
		.glueToSCAL_IValid_cond_all_3_o(glueToSCAL_IValid_cond_all_3_o),
		.glueToSCAL_WrRD_spawn_addr_2_o(glueToSCAL_WrRD_spawn_addr_2_s),
		.glueToSCAL_WrRD_spawn_addr_1_o(glueToSCAL_WrRD_spawn_addr_1_s)
	);
endmodule
module cva5_top (
	clk,
	rst,
	m_axi_awvalid,
	m_axi_awready,
	m_axi_awaddr,
	m_axi_awlen,
	m_axi_awsize,
	m_axi_awburst,
	m_axi_awcache,
	m_axi_wvalid,
	m_axi_wready,
	m_axi_wdata,
	m_axi_wstrb,
	m_axi_wlast,
	m_axi_bvalid,
	m_axi_bready,
	m_axi_bresp,
	m_axi_arvalid,
	m_axi_arready,
	m_axi_araddr,
	m_axi_arlen,
	m_axi_arsize,
	m_axi_arburst,
	m_axi_arcache,
	m_axi_rvalid,
	m_axi_rready,
	m_axi_rdata,
	m_axi_rresp,
	m_axi_rlast,
	m_axi_cache_awvalid,
	m_axi_cache_awready,
	m_axi_cache_awid,
	m_axi_cache_awaddr,
	m_axi_cache_awlen,
	m_axi_cache_awsize,
	m_axi_cache_awburst,
	m_axi_cache_awcache,
	m_axi_cache_awprot,
	m_axi_cache_wvalid,
	m_axi_cache_wready,
	m_axi_cache_wdata,
	m_axi_cache_wstrb,
	m_axi_cache_wlast,
	m_axi_cache_bvalid,
	m_axi_cache_bready,
	m_axi_cache_bresp,
	m_axi_cache_bid,
	m_axi_cache_arvalid,
	m_axi_cache_arready,
	m_axi_cache_arid,
	m_axi_cache_araddr,
	m_axi_cache_arlen,
	m_axi_cache_arsize,
	m_axi_cache_arburst,
	m_axi_cache_arcache,
	m_axi_cache_arprot,
	m_axi_cache_rvalid,
	m_axi_cache_rready,
	m_axi_cache_rid,
	m_axi_cache_rdata,
	m_axi_cache_rresp,
	m_axi_cache_rlast
);
	input wire clk;
	input wire rst;
	output wire m_axi_awvalid;
	input wire m_axi_awready;
	output wire [31:0] m_axi_awaddr;
	output wire [7:0] m_axi_awlen;
	output wire [2:0] m_axi_awsize;
	output wire [1:0] m_axi_awburst;
	output wire [3:0] m_axi_awcache;
	output wire m_axi_wvalid;
	input wire m_axi_wready;
	output wire [31:0] m_axi_wdata;
	output wire [3:0] m_axi_wstrb;
	output wire m_axi_wlast;
	input wire m_axi_bvalid;
	output wire m_axi_bready;
	input wire [1:0] m_axi_bresp;
	output wire m_axi_arvalid;
	input wire m_axi_arready;
	output wire [31:0] m_axi_araddr;
	output wire [7:0] m_axi_arlen;
	output wire [2:0] m_axi_arsize;
	output wire [1:0] m_axi_arburst;
	output wire [3:0] m_axi_arcache;
	input wire m_axi_rvalid;
	output wire m_axi_rready;
	input wire [31:0] m_axi_rdata;
	input wire [1:0] m_axi_rresp;
	input wire m_axi_rlast;
	output wire m_axi_cache_awvalid;
	input wire m_axi_cache_awready;
	output wire [5:0] m_axi_cache_awid;
	output wire [31:0] m_axi_cache_awaddr;
	output wire [7:0] m_axi_cache_awlen;
	output wire [2:0] m_axi_cache_awsize;
	output wire [1:0] m_axi_cache_awburst;
	output wire [3:0] m_axi_cache_awcache;
	output wire [2:0] m_axi_cache_awprot;
	output wire m_axi_cache_wvalid;
	input wire m_axi_cache_wready;
	output wire [31:0] m_axi_cache_wdata;
	output wire [3:0] m_axi_cache_wstrb;
	output wire m_axi_cache_wlast;
	input wire m_axi_cache_bvalid;
	output wire m_axi_cache_bready;
	input wire [1:0] m_axi_cache_bresp;
	input wire [5:0] m_axi_cache_bid;
	output wire m_axi_cache_arvalid;
	input wire m_axi_cache_arready;
	output wire [5:0] m_axi_cache_arid;
	output wire [31:0] m_axi_cache_araddr;
	output wire [7:0] m_axi_cache_arlen;
	output wire [2:0] m_axi_cache_arsize;
	output wire [1:0] m_axi_cache_arburst;
	output wire [3:0] m_axi_cache_arcache;
	output wire [2:0] m_axi_cache_arprot;
	input wire m_axi_cache_rvalid;
	output wire m_axi_cache_rready;
	input wire [5:0] m_axi_cache_rid;
	input wire [31:0] m_axi_cache_rdata;
	input wire [1:0] m_axi_cache_rresp;
	input wire m_axi_cache_rlast;
	wire [31:0] instruction_bram_addr;
	wire instruction_bram_en;
	wire [3:0] instruction_bram_we;
	wire [31:0] instruction_bram_din;
	wire [31:0] instruction_bram_dout;
	wire [31:0] data_bram_addr;
	wire data_bram_en;
	wire [3:0] data_bram_we;
	wire [31:0] data_bram_din;
	wire [31:0] data_bram_dout;
	blk_mem_gen_0 instruction_bram(
		.clka(clk),
		.ena(instruction_bram_en),
		.wea(instruction_bram_we),
		.addra(instruction_bram_addr[17:2]),
		.dina(instruction_bram_din),
		.douta(instruction_bram_dout)
	);
	blk_mem_gen_0 data_bram(
		.clka(clk),
		.ena(data_bram_en),
		.wea(data_bram_we),
		.addra(data_bram_addr[17:2]),
		.dina(data_bram_din),
		.douta(data_bram_dout)
	);
	cva5_wrapper_verilog cva5(
		.clk(clk),
		.rst(rst),
		.instruction_bram_addr(instruction_bram_addr),
		.instruction_bram_en(instruction_bram_en),
		.instruction_bram_we(instruction_bram_we),
		.instruction_bram_din(instruction_bram_din),
		.instruction_bram_dout(instruction_bram_dout),
		.data_bram_addr(data_bram_addr),
		.data_bram_en(data_bram_en),
		.data_bram_we(data_bram_we),
		.data_bram_din(data_bram_din),
		.data_bram_dout(data_bram_dout),
		.m_axi_awvalid(m_axi_awvalid),
		.m_axi_awready(m_axi_awready),
		.m_axi_awaddr(m_axi_awaddr),
		.m_axi_awlen(m_axi_awlen),
		.m_axi_awsize(m_axi_awsize),
		.m_axi_awburst(m_axi_awburst),
		.m_axi_awcache(m_axi_awcache),
		.m_axi_wvalid(m_axi_wvalid),
		.m_axi_wready(m_axi_wready),
		.m_axi_wdata(m_axi_wdata),
		.m_axi_wstrb(m_axi_wstrb),
		.m_axi_wlast(m_axi_wlast),
		.m_axi_bvalid(m_axi_bvalid),
		.m_axi_bready(m_axi_bready),
		.m_axi_bresp(m_axi_bresp),
		.m_axi_arvalid(m_axi_arvalid),
		.m_axi_arready(m_axi_arready),
		.m_axi_araddr(m_axi_araddr),
		.m_axi_arlen(m_axi_arlen),
		.m_axi_arsize(m_axi_arsize),
		.m_axi_arburst(m_axi_arburst),
		.m_axi_arcache(m_axi_arcache),
		.m_axi_rvalid(m_axi_rvalid),
		.m_axi_rready(m_axi_rready),
		.m_axi_rdata(m_axi_rdata),
		.m_axi_rresp(m_axi_rresp),
		.m_axi_rlast(m_axi_rlast),
		.m_axi_cache_awvalid(m_axi_cache_awvalid),
		.m_axi_cache_awready(m_axi_cache_awready),
		.m_axi_cache_awid(m_axi_cache_awid),
		.m_axi_cache_awaddr(m_axi_cache_awaddr),
		.m_axi_cache_awlen(m_axi_cache_awlen),
		.m_axi_cache_awsize(m_axi_cache_awsize),
		.m_axi_cache_awburst(m_axi_cache_awburst),
		.m_axi_cache_awcache(m_axi_cache_awcache),
		.m_axi_cache_awprot(m_axi_cache_awprot),
		.m_axi_cache_wvalid(m_axi_cache_wvalid),
		.m_axi_cache_wready(m_axi_cache_wready),
		.m_axi_cache_wdata(m_axi_cache_wdata),
		.m_axi_cache_wstrb(m_axi_cache_wstrb),
		.m_axi_cache_wlast(m_axi_cache_wlast),
		.m_axi_cache_bvalid(m_axi_cache_bvalid),
		.m_axi_cache_bready(m_axi_cache_bready),
		.m_axi_cache_bresp(m_axi_cache_bresp),
		.m_axi_cache_bid(m_axi_cache_bid),
		.m_axi_cache_arvalid(m_axi_cache_arvalid),
		.m_axi_cache_arready(m_axi_cache_arready),
		.m_axi_cache_arid(m_axi_cache_arid),
		.m_axi_cache_araddr(m_axi_cache_araddr),
		.m_axi_cache_arlen(m_axi_cache_arlen),
		.m_axi_cache_arsize(m_axi_cache_arsize),
		.m_axi_cache_arburst(m_axi_cache_arburst),
		.m_axi_cache_arcache(m_axi_cache_arcache),
		.m_axi_cache_arprot(m_axi_cache_arprot),
		.m_axi_cache_rvalid(m_axi_cache_rvalid),
		.m_axi_cache_rready(m_axi_cache_rready),
		.m_axi_cache_rid(m_axi_cache_rid),
		.m_axi_cache_rdata(m_axi_cache_rdata),
		.m_axi_cache_rresp(m_axi_cache_rresp),
		.m_axi_cache_rlast(m_axi_cache_rlast)
	);
	SCAL scal(
		.clk_i(clk),
		.rst_i(rst)
	);
endmodule
module SCAL (
	clk_i,
	rst_i
);
	input clk_i;
	input rst_i;
endmodule
module blk_mem_gen_0 (
	clka,
	ena,
	wea,
	addra,
	dina,
	douta
);
	input wire clka;
	input wire ena;
	input wire [3:0] wea;
	input wire [15:0] addra;
	input wire [31:0] dina;
	output wire [31:0] douta;
	wire [31:0] bank_data [0:1];
	reg read_bank;
	always @(posedge clka)
		if (ena)
			read_bank <= addra[15];
	assign douta = bank_data[read_bank];
	genvar _gv_bank_1;
	genvar _gv_lane_1;
	generate
		for (_gv_bank_1 = 0; _gv_bank_1 < 2; _gv_bank_1 = _gv_bank_1 + 1) begin : banks
			localparam bank = _gv_bank_1;
			(* ram_style = "block" *) reg [31:0] memory [0:32767];
			reg [31:0] data;
			assign bank_data[bank] = data;
			if (bank == 0) begin : init_low
				initial $readmemh("firmware-0.hex", memory);
			end
			else begin : init_high
				initial $readmemh("firmware-1.hex", memory);
			end
			for (_gv_lane_1 = 0; _gv_lane_1 < 4; _gv_lane_1 = _gv_lane_1 + 1) begin : bytes
				localparam lane = _gv_lane_1;
				always @(posedge clka)
					if (ena && (addra[15] == bank)) begin
						if (wea[lane]) begin
							memory[addra[14:0]][lane * 8+:8] <= dina[lane * 8+:8];
							data[lane * 8+:8] <= dina[lane * 8+:8];
						end
						else
							data[lane * 8+:8] <= memory[addra[14:0]][lane * 8+:8];
					end
			end
		end
	endgenerate
endmodule
module cva5_arty_top (
	clk100,
	reset_button,
	uart_rx,
	uart_tx
);
	input wire clk100;
	input wire reset_button;
	input wire uart_rx;
	output wire uart_tx;
	wire clk_input;
	wire clk_feedback;
	wire clk_feedback_buf;
	wire clk20_raw;
	wire clk20;
	wire locked;
	IBUF input_clock(
		.I(clk100),
		.O(clk_input)
	);
	PLLE2_ADV #(
		.CLKIN1_PERIOD(10.0),
		.CLKFBOUT_MULT(10),
		.DIVCLK_DIVIDE(1),
		.CLKOUT0_DIVIDE(50),
		.STARTUP_WAIT("FALSE")
	) clock_manager(
		.CLKIN1(clk_input),
		.CLKIN2(1'b0),
		.CLKINSEL(1'b1),
		.DADDR(7'b0000000),
		.DCLK(1'b0),
		.DEN(1'b0),
		.DI(16'b0000000000000000),
		.DWE(1'b0),
		.CLKFBIN(clk_feedback_buf),
		.CLKFBOUT(clk_feedback),
		.CLKOUT0(clk20_raw),
		.LOCKED(locked),
		.RST(reset_button),
		.PWRDWN(1'b0)
	);
	BUFG feedback_clock(
		.I(clk_feedback),
		.O(clk_feedback_buf)
	);
	BUFG core_clock(
		.I(clk20_raw),
		.O(clk20)
	);
	(* ASYNC_REG = "TRUE" *) reg [3:0] reset_pipe = 4'b1111;
	always @(posedge clk20 or negedge locked)
		if (!locked)
			reset_pipe <= 4'b1111;
		else
			reset_pipe <= {reset_pipe[2:0], 1'b0};
	wire reset = reset_pipe[3];
	wire awvalid;
	wire awready;
	wire wvalid;
	wire wready;
	wire bvalid;
	wire bready;
	wire arvalid;
	wire arready;
	wire rvalid;
	wire rready;
	wire [31:0] awaddr;
	wire [31:0] araddr;
	wire [31:0] wdata;
	wire [31:0] rdata;
	wire [3:0] wstrb;
	wire [1:0] bresp;
	wire [1:0] rresp;
	cva5_top cpu(
		.clk(clk20),
		.rst(reset),
		.m_axi_awvalid(awvalid),
		.m_axi_awready(awready),
		.m_axi_awaddr(awaddr),
		.m_axi_wvalid(wvalid),
		.m_axi_wready(wready),
		.m_axi_wdata(wdata),
		.m_axi_wstrb(wstrb),
		.m_axi_bvalid(bvalid),
		.m_axi_bready(bready),
		.m_axi_bresp(bresp),
		.m_axi_arvalid(arvalid),
		.m_axi_arready(arready),
		.m_axi_araddr(araddr),
		.m_axi_rvalid(rvalid),
		.m_axi_rready(rready),
		.m_axi_rdata(rdata),
		.m_axi_rresp(rresp),
		.m_axi_rlast(1'b1),
		.m_axi_cache_awready(1'b0),
		.m_axi_cache_wready(1'b0),
		.m_axi_cache_bvalid(1'b0),
		.m_axi_cache_bresp(2'b00),
		.m_axi_cache_bid(6'b000000),
		.m_axi_cache_arready(1'b0),
		.m_axi_cache_rvalid(1'b0),
		.m_axi_cache_rdata(32'b00000000000000000000000000000000),
		.m_axi_cache_rresp(2'b00),
		.m_axi_cache_rid(6'b000000),
		.m_axi_cache_rlast(1'b0)
	);
	isaac_uart uart(
		.s_axi_aclk(clk20),
		.s_axi_aresetn(!reset),
		.s_axi_awaddr(awaddr[3:0]),
		.s_axi_awvalid(awvalid),
		.s_axi_awready(awready),
		.s_axi_wdata(wdata),
		.s_axi_wstrb(wstrb),
		.s_axi_wvalid(wvalid),
		.s_axi_wready(wready),
		.s_axi_bresp(bresp),
		.s_axi_bvalid(bvalid),
		.s_axi_bready(bready),
		.s_axi_araddr(araddr[3:0]),
		.s_axi_arvalid(arvalid),
		.s_axi_arready(arready),
		.s_axi_rdata(rdata),
		.s_axi_rresp(rresp),
		.s_axi_rvalid(rvalid),
		.s_axi_rready(rready),
		.rx(uart_rx),
		.tx(uart_tx),
		.interrupt()
	);
endmodule
module isaac_uart (
	s_axi_aclk,
	s_axi_aresetn,
	s_axi_awaddr,
	s_axi_awvalid,
	s_axi_awready,
	s_axi_wdata,
	s_axi_wstrb,
	s_axi_wvalid,
	s_axi_wready,
	s_axi_bresp,
	s_axi_bvalid,
	s_axi_bready,
	s_axi_araddr,
	s_axi_arvalid,
	s_axi_arready,
	s_axi_rdata,
	s_axi_rresp,
	s_axi_rvalid,
	s_axi_rready,
	rx,
	tx,
	interrupt
);
	parameter integer CLOCK_HZ = 20000000;
	parameter integer BAUD = 115200;
	input wire s_axi_aclk;
	input wire s_axi_aresetn;
	input wire [3:0] s_axi_awaddr;
	input wire s_axi_awvalid;
	output wire s_axi_awready;
	input wire [31:0] s_axi_wdata;
	input wire [3:0] s_axi_wstrb;
	input wire s_axi_wvalid;
	output wire s_axi_wready;
	output wire [1:0] s_axi_bresp;
	output reg s_axi_bvalid;
	input wire s_axi_bready;
	input wire [3:0] s_axi_araddr;
	input wire s_axi_arvalid;
	output wire s_axi_arready;
	output reg [31:0] s_axi_rdata;
	output wire [1:0] s_axi_rresp;
	output reg s_axi_rvalid;
	input wire s_axi_rready;
	input wire rx;
	output wire tx;
	output wire interrupt;
	localparam integer DIV = (CLOCK_HZ + (BAUD / 2)) / BAUD;
	reg aw_pending;
	reg w_pending;
	reg [3:0] awaddr;
	reg [31:0] wdata;
	reg [3:0] wstrb;
	assign s_axi_awready = !aw_pending && !s_axi_bvalid;
	assign s_axi_wready = !w_pending && !s_axi_bvalid;
	assign s_axi_arready = !s_axi_rvalid;
	assign s_axi_bresp = 2'b00;
	assign s_axi_rresp = 2'b00;
	wire write_fire = (aw_pending && w_pending) && !s_axi_bvalid;
	wire read_fire = s_axi_arvalid && s_axi_arready;
	wire control_write = (write_fire && (awaddr[3:2] == 3)) && wstrb[0];
	wire reset_tx = control_write && wdata[0];
	wire reset_rx = control_write && wdata[1];
	reg irq_enable;
	reg [7:0] tx_fifo [0:15];
	reg [7:0] rx_fifo [0:15];
	reg [3:0] tx_wr;
	reg [3:0] tx_rd;
	reg [3:0] rx_wr;
	reg [3:0] rx_rd;
	reg [4:0] tx_count;
	reg [4:0] rx_count;
	reg [9:0] tx_shift;
	reg [3:0] tx_bits;
	reg [31:0] tx_timer;
	reg [31:0] rx_timer;
	reg [3:0] rx_bits;
	reg [7:0] rx_shift;
	(* ASYNC_REG = "TRUE" *) reg [1:0] rx_sync;
	reg rx_busy;
	reg overrun;
	reg framing;
	wire tx_pop = (tx_bits == 0) && (tx_count != 0);
	wire tx_push = ((write_fire && (awaddr[3:2] == 1)) && wstrb[0]) && (tx_count < 16);
	wire rx_pop = (read_fire && (s_axi_araddr[3:2] == 0)) && (rx_count != 0);
	wire rx_done = (rx_busy && (rx_timer == 0)) && (rx_bits == 9);
	wire rx_push = (rx_done && rx_sync[1]) && (rx_count < 16);
	assign tx = (tx_bits == 0 ? 1'b1 : tx_shift[0]);
	assign interrupt = irq_enable && ((rx_count != 0) || ((tx_count == 0) && (tx_bits == 0)));
	always @(posedge s_axi_aclk)
		if (!s_axi_aresetn) begin
			aw_pending <= 0;
			w_pending <= 0;
			s_axi_bvalid <= 0;
			s_axi_rvalid <= 0;
			s_axi_rdata <= 0;
			awaddr <= 0;
			wdata <= 0;
			wstrb <= 0;
			irq_enable <= 0;
			tx_wr <= 0;
			tx_rd <= 0;
			tx_count <= 0;
			tx_bits <= 0;
			tx_shift <= 10'h3ff;
			tx_timer <= 0;
			rx_wr <= 0;
			rx_rd <= 0;
			rx_count <= 0;
			rx_bits <= 0;
			rx_timer <= 0;
			rx_busy <= 0;
			rx_shift <= 0;
			rx_sync <= 3;
			overrun <= 0;
			framing <= 0;
		end
		else begin
			rx_sync <= {rx_sync[0], rx};
			if (s_axi_awvalid && s_axi_awready) begin
				awaddr <= s_axi_awaddr;
				aw_pending <= 1;
			end
			if (s_axi_wvalid && s_axi_wready) begin
				wdata <= s_axi_wdata;
				wstrb <= s_axi_wstrb;
				w_pending <= 1;
			end
			if (s_axi_bvalid && s_axi_bready)
				s_axi_bvalid <= 0;
			if (write_fire) begin
				aw_pending <= 0;
				w_pending <= 0;
				s_axi_bvalid <= 1;
			end
			if (s_axi_rvalid && s_axi_rready)
				s_axi_rvalid <= 0;
			if (read_fire) begin
				s_axi_rvalid <= 1;
				case (s_axi_araddr[3:2])
					0: s_axi_rdata <= (rx_count != 0 ? {24'b000000000000000000000000, rx_fifo[rx_rd]} : 0);
					2: s_axi_rdata <= {25'b0000000000000000000000000, framing, overrun, irq_enable, tx_count == 16, (tx_count == 0) && (tx_bits == 0), rx_count == 16, rx_count != 0};
					default: s_axi_rdata <= 0;
				endcase
			end
			if (control_write)
				irq_enable <= wdata[4];
			if (read_fire && (s_axi_araddr[3:2] == 2)) begin
				overrun <= 0;
				framing <= 0;
			end
			if (tx_push) begin
				tx_fifo[tx_wr] <= wdata[7:0];
				tx_wr <= tx_wr + 1'b1;
			end
			if (tx_pop) begin
				tx_shift <= {1'b1, tx_fifo[tx_rd], 1'b0};
				tx_rd <= tx_rd + 1'b1;
				tx_bits <= 10;
				tx_timer <= DIV - 1;
			end
			else if (tx_bits != 0) begin
				if (tx_timer == 0) begin
					tx_shift <= {1'b1, tx_shift[9:1]};
					tx_bits <= tx_bits - 1'b1;
					tx_timer <= DIV - 1;
				end
				else
					tx_timer <= tx_timer - 1'b1;
			end
			case ({tx_push, tx_pop})
				2'b10: tx_count <= tx_count + 1'b1;
				2'b01: tx_count <= tx_count - 1'b1;
				default:
					;
			endcase
			if (!rx_busy) begin
				if (!rx_sync[1]) begin
					rx_busy <= 1;
					rx_bits <= 0;
					rx_timer <= (DIV / 2) - 1;
				end
			end
			else if (rx_timer != 0)
				rx_timer <= rx_timer - 1'b1;
			else begin
				rx_timer <= DIV - 1;
				if ((rx_bits == 0) && rx_sync[1])
					rx_busy <= 0;
				else if (rx_bits == 9) begin
					rx_busy <= 0;
					if (!rx_sync[1])
						framing <= 1;
					else if (rx_count == 16)
						overrun <= 1;
				end
				else begin
					if (rx_bits != 0)
						rx_shift[rx_bits - 1] <= rx_sync[1];
					rx_bits <= rx_bits + 1'b1;
				end
			end
			if (rx_push) begin
				rx_fifo[rx_wr] <= rx_shift;
				rx_wr <= rx_wr + 1'b1;
			end
			if (rx_pop)
				rx_rd <= rx_rd + 1'b1;
			case ({rx_push, rx_pop})
				2'b10: rx_count <= rx_count + 1'b1;
				2'b01: rx_count <= rx_count - 1'b1;
				default:
					;
			endcase
			if (reset_tx) begin
				tx_wr <= 0;
				tx_rd <= 0;
				tx_count <= 0;
				tx_bits <= 0;
			end
			if (reset_rx) begin
				rx_wr <= 0;
				rx_rd <= 0;
				rx_count <= 0;
				rx_busy <= 0;
				framing <= 0;
				overrun <= 0;
			end
		end
endmodule