let Predicates = [HasStdExtXIsaac, IsRV32] in {

let hasSideEffects = 0, mayLoad = 0, mayStore = 0, isBranch = 0, isTerminator = 0, isCodeGenOnly = 1, Constraints = "" in def CUSTOM45_ : RVInst_CUSTOM45<(outs GPR:$rd), (ins GPR:$rs1, GPR:$rs2, GPR:$rs3)>;

def : Pat<
	(i32 (xor (xor GPR:$rs2, GPR:$rs1), (or (i32 (shl (i32 GPR:$rs3), (i32 (i32 15)))), (i32 (srl (i32 GPR:$rs3), (i32 (i32 17))))))),
	(CUSTOM45_ GPR:$rs1, GPR:$rs2, GPR:$rs3)>;

}
