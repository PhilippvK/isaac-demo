let Predicates = [HasStdExtXIsaac, IsRV32] in {

let hasSideEffects = 0, mayLoad = 0, mayStore = 0, isBranch = 0, isTerminator = 0, isCodeGenOnly = 1, Constraints = "" in def CUSTOM12_ : RVInst_CUSTOM12<(outs GPR:$rd), (ins GPR:$rs1, GPR:$rs2, seal5_uimm5:$uimm5)>;

def : Pat<
	(i32 (xor (or (i32 (shl (i32 GPR:$rs2), (i32 (i32 21)))), (i32 (srl (i32 GPR:$rs2), (i32 (i32 seal5_uimm5:$uimm5))))), GPR:$rs1)),
	(CUSTOM12_ GPR:$rs1, GPR:$rs2, seal5_uimm5:$uimm5)>;

}
