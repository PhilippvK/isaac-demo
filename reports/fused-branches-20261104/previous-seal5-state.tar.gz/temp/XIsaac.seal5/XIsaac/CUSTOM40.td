let Predicates = [HasStdExtXIsaac, IsRV32] in {

let hasSideEffects = 0, mayLoad = 0, mayStore = 0, isBranch = 0, isTerminator = 0, isCodeGenOnly = 1, Constraints = "" in def CUSTOM40_ : RVInst_CUSTOM40<(outs GPR:$rd), (ins GPR:$rs1, GPR:$rs2, GPR:$rs3)>;

def : Pat<
	(i32 (xor (or (i32 (shl (i32 GPR:$rs3), (i32 (i32 15)))), GPR:$rs2), (or (i32 (shl (i32 GPR:$rs3), (i32 (i32 13)))), GPR:$rs1))),
	(CUSTOM40_ GPR:$rs1, GPR:$rs2, GPR:$rs3)>;

}
