let Predicates = [HasStdExtXIsaac, IsRV32] in {

let hasSideEffects = 0, mayLoad = 0, mayStore = 0, isBranch = 0, isTerminator = 0, isCodeGenOnly = 1, Constraints = "" in def CUSTOM104_ : RVInst_CUSTOM104<(outs GPR:$rd), (ins GPR:$rs1, seal5_uimm5:$uimm5)>;

def : Pat<
	(i32 (or (i32 (shl (i32 GPR:$rs1), (i32 (i32 25)))), (i32 (srl (i32 GPR:$rs1), (i32 (i32 seal5_uimm5:$uimm5)))))),
	(CUSTOM104_ GPR:$rs1, seal5_uimm5:$uimm5)>;

}
