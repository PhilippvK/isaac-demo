; ModuleID = 'mod'
source_filename = "mod"
target datalayout = "e-m:e-p:32:32-i64:64-n32-S128"
target triple = "riscv32-unknown-linux-gnu"

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: readwrite)
define void @implCUSTOM59(ptr noalias writeonly captures(none) initializes((0, 4)) %rd, ptr readonly captures(none) %rs1, ptr readonly captures(none) %rs2, ptr readonly captures(none) %rs3) local_unnamed_addr #0 {
  %rs1.v = load i32, ptr %rs1, align 4
  %rs3.v = load i32, ptr %rs3, align 4
  %rs2.v = load i32, ptr %rs2, align 4
  %1 = and i32 %rs2.v, %rs1.v
  %2 = xor i32 %1, %rs3.v
  store i32 %2, ptr %rd, align 4
  ret void
}

attributes #0 = { mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: readwrite) }
