let Predicates = [HasStdExtXIsaac, IsRV32] in {

let hasSideEffects = 0, mayLoad = 0, mayStore = 0, isBranch = 0, isTerminator = 0, isCodeGenOnly = 1, Constraints = "" in def CUSTOM75_ : RVInst_CUSTOM75<(outs GPR:$rd), (ins GPR:$rs1, GPR:$rs2, seal5_uimm4:$uimm4)>;

def : Pat<
	(i32 (xor (or (i32 (shl (i32 GPR:$rs2), (i32 (i32 25)))), (i32 (srl (i32 GPR:$rs2), (i32 (i32 seal5_uimm4:$uimm4))))), GPR:$rs1)),
	(CUSTOM75_ GPR:$rs1, GPR:$rs2, seal5_uimm4:$uimm4)>;

}
