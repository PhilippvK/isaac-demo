let Predicates = [HasStdExtXIsaac, IsRV32] in {

let hasSideEffects = 0, mayLoad = 0, mayStore = 0, isBranch = 0, isTerminator = 0, isCodeGenOnly = 1, Constraints = "" in def CUSTOM52_ : RVInst_CUSTOM52<(outs GPR:$rd), (ins GPR:$rs1, GPR:$rs2)>;

def : Pat<
	(i32 (or (i32 (shl (i32 GPR:$rs2), (i32 (i32 26)))), GPR:$rs1)),
	(CUSTOM52_ GPR:$rs1, GPR:$rs2)>;

}
