let Predicates = [HasStdExtXIsaac, IsRV32] in {

let hasSideEffects = 0, mayLoad = 0, mayStore = 0, isBranch = 0, isTerminator = 0, isCodeGenOnly = 1, Constraints = "" in def CUSTOM55_ : RVInst_CUSTOM55<(outs GPR:$rd), (ins GPR:$rs1, GPR:$rs2, GPR:$rs3)>;

def : Pat<
	(i32 (and (xor GPR:$rs3, GPR:$rs2), GPR:$rs1)),
	(CUSTOM55_ GPR:$rs1, GPR:$rs2, GPR:$rs3)>;

}
