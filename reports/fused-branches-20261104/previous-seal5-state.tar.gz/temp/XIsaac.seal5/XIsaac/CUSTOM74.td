let Predicates = [HasStdExtXIsaac, IsRV32] in {

let hasSideEffects = 0, mayLoad = 0, mayStore = 0, isBranch = 0, isTerminator = 0, isCodeGenOnly = 1, Constraints = "" in def CUSTOM74_ : RVInst_CUSTOM74<(outs GPR:$rd), (ins GPR:$rs1, GPR:$rs2)>;

def : Pat<
	(i32 (xor GPR:$rs1, (or (i32 (shl (i32 GPR:$rs2), (i32 (i32 14)))), (i32 (srl (i32 GPR:$rs2), (i32 (i32 18))))))),
	(CUSTOM74_ GPR:$rs1, GPR:$rs2)>;

}
