; ModuleID = 'mod'
source_filename = "mod"
target datalayout = "e-m:e-p:32:32-i64:64-n32-S128"
target triple = "riscv32-unknown-linux-gnu"

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: readwrite, inaccessiblemem: write)
define void @implCUSTOM104(ptr noalias writeonly captures(none) initializes((0, 4)) %rd, ptr readonly captures(none) %rs1, i32 %uimm5) local_unnamed_addr #0 {
  %1 = icmp ult i32 %uimm5, 32
  tail call void @llvm.assume(i1 %1)
  %rs1.v = load i32, ptr %rs1, align 4
  %2 = shl i32 %rs1.v, 25
  %3 = lshr i32 %rs1.v, %uimm5
  %4 = or i32 %2, %3
  store i32 %4, ptr %rd, align 4
  ret void
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: write)
declare void @llvm.assume(i1 noundef) #1

attributes #0 = { mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: readwrite, inaccessiblemem: write) }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: write) }
