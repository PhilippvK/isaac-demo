let Predicates = [HasStdExtXIsaac, IsRV32] in {

let hasSideEffects = 0, mayLoad = 0, mayStore = 0, isBranch = 0, isTerminator = 0, isCodeGenOnly = 1, Constraints = "" in def CUSTOM16_ : RVInst_CUSTOM16<(outs GPR:$rd), (ins GPR:$rs1, GPR:$rs2, GPR:$rs3)>;

def : Pat<
	(i32 (xor (xor GPR:$rs2, GPR:$rs1), GPR:$rs3)),
	(CUSTOM16_ GPR:$rs1, GPR:$rs2, GPR:$rs3)>;

}
