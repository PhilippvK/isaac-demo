let Predicates = [HasStdExtXIsaac, IsRV32] in {

let hasSideEffects = 0, mayLoad = 0, mayStore = 0, isBranch = 0, isTerminator = 0, isCodeGenOnly = 1, Constraints = "" in def CUSTOM7_ : RVInst_CUSTOM7<(outs GPR:$rd), (ins GPR:$rs1, GPR:$rs2, GPR:$rs3)>;

def : Pat<
	(i32 (xor (or (i32 (shl (i32 GPR:$rs3), (i32 (i32 26)))), GPR:$rs2), (or (i32 (shl (i32 GPR:$rs3), (i32 (i32 21)))), GPR:$rs1))),
	(CUSTOM7_ GPR:$rs1, GPR:$rs2, GPR:$rs3)>;

}
