let Predicates = [HasStdExtXIsaac, IsRV32] in {

let hasSideEffects = 0, mayLoad = 0, mayStore = 0, isBranch = 0, isTerminator = 0, isCodeGenOnly = 1, Constraints = "" in def CUSTOM0_ : RVInst_CUSTOM0<(outs GPR:$rd), (ins GPR:$rs1, GPR:$rs2, GPR:$rs3)>;

def : Pat<
	(i32 (xor (or GPR:$rs3, GPR:$rs2), GPR:$rs1)),
	(CUSTOM0_ GPR:$rs1, GPR:$rs2, GPR:$rs3)>;

}
