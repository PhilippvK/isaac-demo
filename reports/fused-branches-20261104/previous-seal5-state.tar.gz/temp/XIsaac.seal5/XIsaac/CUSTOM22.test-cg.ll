; RUN: llc -mtriple=riscv32 -stop-after=instruction-select -mattr=+m,+fast-unaligned-access,+xisaac %s -global-isel=1 -o - \
  ; RUN: | FileCheck -check-prefix=RV32-MIR %s
  ; RUN: llc -mtriple=riscv32 -mattr=+m,+fast-unaligned-access,+xisaac %s -global-isel=1 -o - \
  ; RUN: | FileCheck -check-prefix=RV32-ASM %s
; ModuleID = 'mod'
source_filename = "mod"
target datalayout = "e-m:e-p:32:32-i64:64-n32-S128"
target triple = "riscv32-unknown-linux-gnu"

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: readwrite)
define void @implCUSTOM22(ptr noalias writeonly captures(none) initializes((0, 4)) %rd, ptr readonly captures(none) %rs1, ptr readonly captures(none) %rs2, ptr readonly captures(none) %rs3) local_unnamed_addr #0 {
  ; RV32-MIR-LABEL: name: implCUSTOM22
  ; RV32-MIR: CUSTOM22
  ; RV32-MIR-NEXT: SW
  ; RV32-MIR-NEXT: PseudoRET
  ; RV32-ASM-LABEL: implCUSTOM22:
  ; RV32-ASM: custom22
  ; RV32-ASM-NEXT: sw
  ; RV32-ASM-NEXT: ret
  %rs3.v = load i32, ptr %rs3, align 4
  %rs1.v = load i32, ptr %rs1, align 4
  %rs2.v = load i32, ptr %rs2, align 4
  %1 = lshr i32 %rs3.v, 6
  %2 = or i32 %rs2.v, %1
  %3 = xor i32 %2, %rs1.v
  store i32 %3, ptr %rd, align 4
  ret void
}

attributes #0 = { mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: readwrite) }