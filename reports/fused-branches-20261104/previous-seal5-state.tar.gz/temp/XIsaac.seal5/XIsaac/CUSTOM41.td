let Predicates = [HasStdExtXIsaac, IsRV32] in {

let hasSideEffects = 0, mayLoad = 0, mayStore = 0, isBranch = 0, isTerminator = 0, isCodeGenOnly = 1, Constraints = "" in def CUSTOM41_ : RVInst_CUSTOM41<(outs GPR:$rd), (ins GPR:$rs1, GPR:$rs2, GPR:$rs3)>;

def : Pat<
	(i32 (xor (xor (i32 (srl (i32 GPR:$rs3), (i32 (i32 10)))), GPR:$rs1), (or (i32 (srl (i32 GPR:$rs3), (i32 (i32 19)))), GPR:$rs2))),
	(CUSTOM41_ GPR:$rs1, GPR:$rs2, GPR:$rs3)>;

}
