let Predicates = [HasStdExtXIsaac, IsRV32] in {

let hasSideEffects = 0, mayLoad = 0, mayStore = 0, isBranch = 0, isTerminator = 0, isCodeGenOnly = 1, Constraints = "" in def CUSTOM25_ : RVInst_CUSTOM25<(outs GPR:$rd), (ins GPR:$rs1, GPR:$rs2, GPR:$rs3)>;

def : Pat<
	(i32 (xor (or GPR:$rs2, (i32 (srl (i32 GPR:$rs3), (i32 (i32 11))))), GPR:$rs1)),
	(CUSTOM25_ GPR:$rs1, GPR:$rs2, GPR:$rs3)>;

}
