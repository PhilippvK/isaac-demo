let Predicates = [HasStdExtXIsaac, IsRV32] in {

let hasSideEffects = 0, mayLoad = 0, mayStore = 0, isBranch = 0, isTerminator = 0, isCodeGenOnly = 1, Constraints = "" in def CUSTOM28_ : RVInst_CUSTOM28<(outs GPR:$rd), (ins GPR:$rs1, seal5_uimm7:$uimm7)>;

def : Pat<
	(i32 (or (i32 (shl (i32 GPR:$rs1), (i32 (i32 7)))), (i32 (srl (i32 GPR:$rs1), (i32 (i32 seal5_uimm7:$uimm7)))))),
	(CUSTOM28_ GPR:$rs1, seal5_uimm7:$uimm7)>;

}
