let Predicates = [HasStdExtXIsaac, IsRV32] in {

let hasSideEffects = 0, mayLoad = 0, mayStore = 0, isBranch = 0, isTerminator = 0, isCodeGenOnly = 1, Constraints = "" in def CUSTOM58_ : RVInst_CUSTOM58<(outs GPR:$rd), (ins GPR:$rs1, GPR:$rs2)>;

def : Pat<
	(i32 (or (i32 (shl (i32 GPR:$rs2), (i32 (i32 21)))), GPR:$rs1)),
	(CUSTOM58_ GPR:$rs1, GPR:$rs2)>;

}
