let Predicates = [HasStdExtXIsaac, IsRV32] in {

let hasSideEffects = 0, mayLoad = 0, mayStore = 0, isBranch = 0, isTerminator = 0, isCodeGenOnly = 1, Constraints = "" in def CUSTOM67_ : RVInst_CUSTOM67<(outs GPR:$rd), (ins GPR:$rs1, GPR:$rs2, GPR:$rs3)>;

def : Pat<
	(i32 (xor (or GPR:$rs2, (i32 (srl (i32 GPR:$rs3), (i32 (i32 2))))), (or GPR:$rs1, (i32 (srl (i32 GPR:$rs3), (i32 (i32 13))))))),
	(CUSTOM67_ GPR:$rs1, GPR:$rs2, GPR:$rs3)>;

}
