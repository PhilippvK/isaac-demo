let Predicates = [HasStdExtXIsaac, IsRV32] in {

let hasSideEffects = 0, mayLoad = 0, mayStore = 0, isBranch = 0, isTerminator = 0, isCodeGenOnly = 1, Constraints = "" in def CUSTOM78_ : RVInst_CUSTOM78<(outs GPR:$rd), (ins GPR:$rs1, GPR:$rs2)>;

def : Pat<
	(i32 (xor GPR:$rs1, (or (i32 (shl (i32 GPR:$rs2), (i32 (i32 19)))), (i32 (srl (i32 GPR:$rs2), (i32 (i32 13))))))),
	(CUSTOM78_ GPR:$rs1, GPR:$rs2)>;

}
