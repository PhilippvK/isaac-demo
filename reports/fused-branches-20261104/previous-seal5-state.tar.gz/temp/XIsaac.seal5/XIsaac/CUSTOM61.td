let Predicates = [HasStdExtXIsaac, IsRV32] in {

let hasSideEffects = 0, mayLoad = 0, mayStore = 0, isBranch = 0, isTerminator = 0, isCodeGenOnly = 1, Constraints = "" in def CUSTOM61_ : RVInst_CUSTOM61<(outs GPR:$rd), (ins GPR:$rs1, GPR:$rs2, seal5_uimm5:$uimm5)>;

def : Pat<
	(i32 (or GPR:$rs1, (i32 (srl (i32 GPR:$rs2), (i32 (i32 seal5_uimm5:$uimm5)))))),
	(CUSTOM61_ GPR:$rs1, GPR:$rs2, seal5_uimm5:$uimm5)>;

}
