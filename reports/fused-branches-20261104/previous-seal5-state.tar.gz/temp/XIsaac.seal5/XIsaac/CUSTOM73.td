let Predicates = [HasStdExtXIsaac, IsRV32] in {

let hasSideEffects = 0, mayLoad = 0, mayStore = 0, isBranch = 0, isTerminator = 0, isCodeGenOnly = 1, Constraints = "" in def CUSTOM73_ : RVInst_CUSTOM73<(outs GPR:$rd), (ins GPR:$rs1, GPR:$rs2)>;

def : Pat<
	(i32 (xor (or (i32 (shl (i32 GPR:$rs2), (i32 (i32 15)))), (i32 (srl (i32 GPR:$rs2), (i32 (i32 17))))), GPR:$rs1)),
	(CUSTOM73_ GPR:$rs1, GPR:$rs2)>;

}
