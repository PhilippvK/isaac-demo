let Predicates = [HasStdExtXIsaac, IsRV32] in {

let hasSideEffects = 0, mayLoad = 0, mayStore = 0, isBranch = 0, isTerminator = 0, isCodeGenOnly = 1, Constraints = "" in def CUSTOM70_ : RVInst_CUSTOM70<(outs GPR:$rd), (ins GPR:$rs1, GPR:$rs2, GPR:$rs3)>;

def : Pat<
	(i32 (add (xor GPR:$rs2, (or (i32 (shl (i32 GPR:$rs3), (i32 (i32 10)))), (i32 (srl (i32 GPR:$rs3), (i32 (i32 22)))))), GPR:$rs1)),
	(CUSTOM70_ GPR:$rs1, GPR:$rs2, GPR:$rs3)>;

}
