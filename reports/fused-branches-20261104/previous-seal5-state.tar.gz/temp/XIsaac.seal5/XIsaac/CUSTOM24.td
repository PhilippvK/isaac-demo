let Predicates = [HasStdExtXIsaac, IsRV32] in {

let hasSideEffects = 0, mayLoad = 0, mayStore = 0, isBranch = 0, isTerminator = 0, isCodeGenOnly = 1, Constraints = "" in def CUSTOM24_ : RVInst_CUSTOM24<(outs GPR:$rd), (ins GPR:$rs1, GPR:$rs2, GPR:$rs3)>;

def : Pat<
	(i32 (xor (or GPR:$rs2, (i32 (shl (i32 GPR:$rs3), (i32 (i32 21))))), GPR:$rs1)),
	(CUSTOM24_ GPR:$rs1, GPR:$rs2, GPR:$rs3)>;

}
