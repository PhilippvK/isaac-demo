let Predicates = [HasStdExtXIsaac, IsRV32] in {

let hasSideEffects = 0, mayLoad = 0, mayStore = 0, isBranch = 0, isTerminator = 0, isCodeGenOnly = 1, Constraints = "" in def CUSTOM47_ : RVInst_CUSTOM47<(outs GPR:$rd), (ins GPR:$rs1, GPR:$rs2, GPR:$rs3)>;

def : Pat<
	(i32 (xor (or (i32 (shl (i32 GPR:$rs3), (i32 (i32 15)))), GPR:$rs2), (or GPR:$rs1, (i32 (srl (i32 GPR:$rs3), (i32 (i32 19))))))),
	(CUSTOM47_ GPR:$rs1, GPR:$rs2, GPR:$rs3)>;

}
