# Empty compiler generated dependencies file for microtvm_rpc_common.
# This may be replaced when dependencies are built.
