CMakeFiles/memory.dir/src/runtime/crt/memory/stack_allocator.c.o: \
 /var/tmp/ga87puy/cfu_tvm/tumeda-new/fau-tum-cfu-collab/tvm/build_gcc12/standalone_crt/src/runtime/crt/memory/stack_allocator.c \
 /usr/include/stdc-predef.h \
 /var/tmp/ga87puy/cfu_tvm/tumeda-new/fau-tum-cfu-collab/tvm/build_gcc12/standalone_crt/include/tvm/runtime/crt/stack_allocator.h \
 /usr/lib/gcc/x86_64-linux-gnu/12/include/stddef.h \
 /usr/lib/gcc/x86_64-linux-gnu/12/include/stdint.h /usr/include/stdint.h \
 /usr/include/x86_64-linux-gnu/bits/libc-header-start.h \
 /usr/include/features.h /usr/include/features-time64.h \
 /usr/include/x86_64-linux-gnu/bits/wordsize.h \
 /usr/include/x86_64-linux-gnu/bits/timesize.h \
 /usr/include/x86_64-linux-gnu/sys/cdefs.h \
 /usr/include/x86_64-linux-gnu/bits/long-double.h \
 /usr/include/x86_64-linux-gnu/gnu/stubs.h \
 /usr/include/x86_64-linux-gnu/gnu/stubs-64.h \
 /usr/include/x86_64-linux-gnu/bits/types.h \
 /usr/include/x86_64-linux-gnu/bits/typesizes.h \
 /usr/include/x86_64-linux-gnu/bits/time64.h \
 /usr/include/x86_64-linux-gnu/bits/wchar.h \
 /usr/include/x86_64-linux-gnu/bits/stdint-intn.h \
 /usr/include/x86_64-linux-gnu/bits/stdint-uintn.h \
 /var/tmp/ga87puy/cfu_tvm/tumeda-new/fau-tum-cfu-collab/tvm/build_gcc12/standalone_crt/../crt_config/crt_config.h \
 /var/tmp/ga87puy/cfu_tvm/tumeda-new/fau-tum-cfu-collab/tvm/build_gcc12/standalone_crt/include/tvm/runtime/crt/error_codes.h
