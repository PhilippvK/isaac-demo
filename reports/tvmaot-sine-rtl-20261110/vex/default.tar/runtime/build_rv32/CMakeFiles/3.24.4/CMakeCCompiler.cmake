set(CMAKE_C_COMPILER "/var/tmp/ga87puy/cfu_tvm/tumeda-new/fau-tum-cfu-collab/tvm/build_gcc12/standalone_crt/../../../install/gnu/bin/riscv32-unknown-elf-gcc")
set(CMAKE_C_COMPILER_ARG1 "")
set(CMAKE_C_COMPILER_ID "GNU")
set(CMAKE_C_COMPILER_VERSION "15.1.0")
set(CMAKE_C_COMPILER_VERSION_INTERNAL "")
set(CMAKE_C_COMPILER_WRAPPER "")
set(CMAKE_C_STANDARD_COMPUTED_DEFAULT "23")
set(CMAKE_C_EXTENSIONS_COMPUTED_DEFAULT "ON")
set(CMAKE_C_COMPILE_FEATURES "c_std_90;c_function_prototypes;c_std_99;c_restrict;c_variadic_macros;c_std_11;c_static_assert;c_std_17;c_std_23")
set(CMAKE_C90_COMPILE_FEATURES "c_std_90;c_function_prototypes")
set(CMAKE_C99_COMPILE_FEATURES "c_std_99;c_restrict;c_variadic_macros")
set(CMAKE_C11_COMPILE_FEATURES "c_std_11;c_static_assert")
set(CMAKE_C17_COMPILE_FEATURES "c_std_17")
set(CMAKE_C23_COMPILE_FEATURES "c_std_23")

set(CMAKE_C_PLATFORM_ID "")
set(CMAKE_C_SIMULATE_ID "")
set(CMAKE_C_COMPILER_FRONTEND_VARIANT "")
set(CMAKE_C_SIMULATE_VERSION "")




set(CMAKE_AR "/var/tmp/ga87puy/cfu_tvm/tumeda-new/fau-tum-cfu-collab/install/gnu/bin/riscv32-unknown-elf-ar")
set(CMAKE_C_COMPILER_AR "/var/tmp/ga87puy/cfu_tvm/tumeda-new/fau-tum-cfu-collab/install/gnu/bin/riscv32-unknown-elf-gcc-ar")
set(CMAKE_RANLIB "/var/tmp/ga87puy/cfu_tvm/tumeda-new/fau-tum-cfu-collab/install/gnu/bin/riscv32-unknown-elf-ranlib")
set(CMAKE_C_COMPILER_RANLIB "/var/tmp/ga87puy/cfu_tvm/tumeda-new/fau-tum-cfu-collab/install/gnu/bin/riscv32-unknown-elf-gcc-ranlib")
set(CMAKE_LINKER "/var/tmp/ga87puy/cfu_tvm/tumeda-new/fau-tum-cfu-collab/install/gnu/bin/riscv32-unknown-elf-ld")
set(CMAKE_MT "")
set(CMAKE_COMPILER_IS_GNUCC 1)
set(CMAKE_C_COMPILER_LOADED 1)
set(CMAKE_C_COMPILER_WORKS TRUE)
set(CMAKE_C_ABI_COMPILED TRUE)

set(CMAKE_C_COMPILER_ENV_VAR "CC")

set(CMAKE_C_COMPILER_ID_RUN 1)
set(CMAKE_C_SOURCE_FILE_EXTENSIONS c;m)
set(CMAKE_C_IGNORE_EXTENSIONS h;H;o;O;obj;OBJ;def;DEF;rc;RC)
set(CMAKE_C_LINKER_PREFERENCE 10)

# Save compiler ABI information.
set(CMAKE_C_SIZEOF_DATA_PTR "4")
set(CMAKE_C_COMPILER_ABI "ELF")
set(CMAKE_C_BYTE_ORDER "LITTLE_ENDIAN")
set(CMAKE_C_LIBRARY_ARCHITECTURE "")

if(CMAKE_C_SIZEOF_DATA_PTR)
  set(CMAKE_SIZEOF_VOID_P "${CMAKE_C_SIZEOF_DATA_PTR}")
endif()

if(CMAKE_C_COMPILER_ABI)
  set(CMAKE_INTERNAL_PLATFORM_ABI "${CMAKE_C_COMPILER_ABI}")
endif()

if(CMAKE_C_LIBRARY_ARCHITECTURE)
  set(CMAKE_LIBRARY_ARCHITECTURE "")
endif()

set(CMAKE_C_CL_SHOWINCLUDES_PREFIX "")
if(CMAKE_C_CL_SHOWINCLUDES_PREFIX)
  set(CMAKE_CL_SHOWINCLUDES_PREFIX "${CMAKE_C_CL_SHOWINCLUDES_PREFIX}")
endif()





set(CMAKE_C_IMPLICIT_INCLUDE_DIRECTORIES "/var/tmp/ga87puy/cfu_tvm/tumeda-new/fau-tum-cfu-collab/install/gnu/lib/gcc/riscv32-unknown-elf/15.1.0/include;/var/tmp/ga87puy/cfu_tvm/tumeda-new/fau-tum-cfu-collab/install/gnu/lib/gcc/riscv32-unknown-elf/15.1.0/include-fixed;/var/tmp/ga87puy/cfu_tvm/tumeda-new/fau-tum-cfu-collab/install/gnu/riscv32-unknown-elf/include")
set(CMAKE_C_IMPLICIT_LINK_LIBRARIES "gcc;c;gloss;gcc")
set(CMAKE_C_IMPLICIT_LINK_DIRECTORIES "/var/tmp/ga87puy/cfu_tvm/tumeda-new/fau-tum-cfu-collab/install/gnu/lib/gcc/riscv32-unknown-elf/15.1.0;/var/tmp/ga87puy/cfu_tvm/tumeda-new/fau-tum-cfu-collab/install/gnu/lib/gcc;/var/tmp/ga87puy/cfu_tvm/tumeda-new/fau-tum-cfu-collab/install/gnu/riscv32-unknown-elf/lib")
set(CMAKE_C_IMPLICIT_LINK_FRAMEWORK_DIRECTORIES "")
