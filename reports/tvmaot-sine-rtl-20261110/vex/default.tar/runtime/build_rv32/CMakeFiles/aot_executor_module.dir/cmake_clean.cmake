file(REMOVE_RECURSE
  "CMakeFiles/aot_executor_module.dir/src/runtime/crt/aot_executor_module/aot_executor_module.c.o"
  "CMakeFiles/aot_executor_module.dir/src/runtime/crt/aot_executor_module/aot_executor_module.c.o.d"
  "libaot_executor_module.a"
  "libaot_executor_module.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/aot_executor_module.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
