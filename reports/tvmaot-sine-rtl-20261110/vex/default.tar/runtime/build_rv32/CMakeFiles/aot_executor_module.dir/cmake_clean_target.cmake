file(REMOVE_RECURSE
  "libaot_executor_module.a"
)
