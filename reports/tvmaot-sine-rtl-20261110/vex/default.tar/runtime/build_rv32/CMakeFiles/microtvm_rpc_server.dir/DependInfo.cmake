
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "/var/tmp/ga87puy/cfu_tvm/tumeda-new/fau-tum-cfu-collab/tvm/build_gcc12/standalone_crt/src/runtime/crt/microtvm_rpc_server/rpc_server.cc" "CMakeFiles/microtvm_rpc_server.dir/src/runtime/crt/microtvm_rpc_server/rpc_server.cc.o" "gcc" "CMakeFiles/microtvm_rpc_server.dir/src/runtime/crt/microtvm_rpc_server/rpc_server.cc.o.d"
  )

# Targets to which this target links.
set(CMAKE_TARGET_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
