# Empty dependencies file for microtvm_rpc_server.
# This may be replaced when dependencies are built.
