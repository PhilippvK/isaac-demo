file(REMOVE_RECURSE
  "libmicrotvm_rpc_server.a"
)
