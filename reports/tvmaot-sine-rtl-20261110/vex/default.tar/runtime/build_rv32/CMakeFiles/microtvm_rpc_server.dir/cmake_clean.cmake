file(REMOVE_RECURSE
  "CMakeFiles/microtvm_rpc_server.dir/src/runtime/crt/microtvm_rpc_server/rpc_server.cc.o"
  "CMakeFiles/microtvm_rpc_server.dir/src/runtime/crt/microtvm_rpc_server/rpc_server.cc.o.d"
  "libmicrotvm_rpc_server.a"
  "libmicrotvm_rpc_server.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/microtvm_rpc_server.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
