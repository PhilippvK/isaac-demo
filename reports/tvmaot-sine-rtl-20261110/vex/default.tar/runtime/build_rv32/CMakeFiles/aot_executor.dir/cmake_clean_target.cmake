file(REMOVE_RECURSE
  "libaot_executor.a"
)
