file(REMOVE_RECURSE
  "CMakeFiles/aot_executor.dir/src/runtime/crt/aot_executor/aot_executor.c.o"
  "CMakeFiles/aot_executor.dir/src/runtime/crt/aot_executor/aot_executor.c.o.d"
  "libaot_executor.a"
  "libaot_executor.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/aot_executor.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
