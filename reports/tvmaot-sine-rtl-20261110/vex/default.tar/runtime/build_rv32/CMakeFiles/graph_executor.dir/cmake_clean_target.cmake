file(REMOVE_RECURSE
  "libgraph_executor.a"
)
