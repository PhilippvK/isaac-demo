
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "/var/tmp/ga87puy/cfu_tvm/tumeda-new/fau-tum-cfu-collab/tvm/build_gcc12/standalone_crt/src/runtime/crt/common/crt_backend_api.c" "CMakeFiles/common.dir/src/runtime/crt/common/crt_backend_api.c.o" "gcc" "CMakeFiles/common.dir/src/runtime/crt/common/crt_backend_api.c.o.d"
  "/var/tmp/ga87puy/cfu_tvm/tumeda-new/fau-tum-cfu-collab/tvm/build_gcc12/standalone_crt/src/runtime/crt/common/crt_runtime_api.c" "CMakeFiles/common.dir/src/runtime/crt/common/crt_runtime_api.c.o" "gcc" "CMakeFiles/common.dir/src/runtime/crt/common/crt_runtime_api.c.o.d"
  "/var/tmp/ga87puy/cfu_tvm/tumeda-new/fau-tum-cfu-collab/tvm/build_gcc12/standalone_crt/src/runtime/crt/common/func_registry.c" "CMakeFiles/common.dir/src/runtime/crt/common/func_registry.c.o" "gcc" "CMakeFiles/common.dir/src/runtime/crt/common/func_registry.c.o.d"
  "/var/tmp/ga87puy/cfu_tvm/tumeda-new/fau-tum-cfu-collab/tvm/build_gcc12/standalone_crt/src/runtime/crt/common/ndarray.c" "CMakeFiles/common.dir/src/runtime/crt/common/ndarray.c.o" "gcc" "CMakeFiles/common.dir/src/runtime/crt/common/ndarray.c.o.d"
  "/var/tmp/ga87puy/cfu_tvm/tumeda-new/fau-tum-cfu-collab/tvm/build_gcc12/standalone_crt/src/runtime/crt/common/packed_func.c" "CMakeFiles/common.dir/src/runtime/crt/common/packed_func.c.o" "gcc" "CMakeFiles/common.dir/src/runtime/crt/common/packed_func.c.o.d"
  )

# Targets to which this target links.
set(CMAKE_TARGET_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
