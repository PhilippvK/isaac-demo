file(REMOVE_RECURSE
  "CMakeFiles/common.dir/src/runtime/crt/common/crt_backend_api.c.o"
  "CMakeFiles/common.dir/src/runtime/crt/common/crt_backend_api.c.o.d"
  "CMakeFiles/common.dir/src/runtime/crt/common/crt_runtime_api.c.o"
  "CMakeFiles/common.dir/src/runtime/crt/common/crt_runtime_api.c.o.d"
  "CMakeFiles/common.dir/src/runtime/crt/common/func_registry.c.o"
  "CMakeFiles/common.dir/src/runtime/crt/common/func_registry.c.o.d"
  "CMakeFiles/common.dir/src/runtime/crt/common/ndarray.c.o"
  "CMakeFiles/common.dir/src/runtime/crt/common/ndarray.c.o.d"
  "CMakeFiles/common.dir/src/runtime/crt/common/packed_func.c.o"
  "CMakeFiles/common.dir/src/runtime/crt/common/packed_func.c.o.d"
  "libcommon.a"
  "libcommon.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/common.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
