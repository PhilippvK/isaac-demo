file(REMOVE_RECURSE
  "libgraph_executor_module.a"
)
