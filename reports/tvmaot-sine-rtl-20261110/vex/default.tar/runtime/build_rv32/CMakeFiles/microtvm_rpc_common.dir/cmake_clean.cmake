file(REMOVE_RECURSE
  "CMakeFiles/microtvm_rpc_common.dir/src/runtime/crt/microtvm_rpc_common/crcccitt.c.o"
  "CMakeFiles/microtvm_rpc_common.dir/src/runtime/crt/microtvm_rpc_common/crcccitt.c.o.d"
  "CMakeFiles/microtvm_rpc_common.dir/src/runtime/crt/microtvm_rpc_common/frame_buffer.cc.o"
  "CMakeFiles/microtvm_rpc_common.dir/src/runtime/crt/microtvm_rpc_common/frame_buffer.cc.o.d"
  "CMakeFiles/microtvm_rpc_common.dir/src/runtime/crt/microtvm_rpc_common/framing.cc.o"
  "CMakeFiles/microtvm_rpc_common.dir/src/runtime/crt/microtvm_rpc_common/framing.cc.o.d"
  "CMakeFiles/microtvm_rpc_common.dir/src/runtime/crt/microtvm_rpc_common/session.cc.o"
  "CMakeFiles/microtvm_rpc_common.dir/src/runtime/crt/microtvm_rpc_common/session.cc.o.d"
  "CMakeFiles/microtvm_rpc_common.dir/src/runtime/crt/microtvm_rpc_common/write_stream.cc.o"
  "CMakeFiles/microtvm_rpc_common.dir/src/runtime/crt/microtvm_rpc_common/write_stream.cc.o.d"
  "libmicrotvm_rpc_common.a"
  "libmicrotvm_rpc_common.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang C CXX)
  include(CMakeFiles/microtvm_rpc_common.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
