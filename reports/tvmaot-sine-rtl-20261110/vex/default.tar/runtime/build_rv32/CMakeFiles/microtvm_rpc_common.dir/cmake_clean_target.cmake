file(REMOVE_RECURSE
  "libmicrotvm_rpc_common.a"
)
