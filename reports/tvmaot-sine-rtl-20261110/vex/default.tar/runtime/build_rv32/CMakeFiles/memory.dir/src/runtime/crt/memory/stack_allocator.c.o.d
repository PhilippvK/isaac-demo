CMakeFiles/memory.dir/src/runtime/crt/memory/stack_allocator.c.o: \
 /var/tmp/ga87puy/cfu_tvm/tumeda-new/fau-tum-cfu-collab/tvm/build_gcc12/standalone_crt/src/runtime/crt/memory/stack_allocator.c \
 /var/tmp/ga87puy/cfu_tvm/tumeda-new/fau-tum-cfu-collab/tvm/build_gcc12/standalone_crt/include/tvm/runtime/crt/stack_allocator.h \
 /var/tmp/ga87puy/cfu_tvm/tumeda-new/fau-tum-cfu-collab/install/gnu/lib/gcc/riscv32-unknown-elf/15.1.0/include/stddef.h \
 /var/tmp/ga87puy/cfu_tvm/tumeda-new/fau-tum-cfu-collab/install/gnu/lib/gcc/riscv32-unknown-elf/15.1.0/include/stdint.h \
 /var/tmp/ga87puy/cfu_tvm/tumeda-new/fau-tum-cfu-collab/install/gnu/riscv32-unknown-elf/include/stdint.h \
 /var/tmp/ga87puy/cfu_tvm/tumeda-new/fau-tum-cfu-collab/install/gnu/riscv32-unknown-elf/include/machine/_default_types.h \
 /var/tmp/ga87puy/cfu_tvm/tumeda-new/fau-tum-cfu-collab/install/gnu/riscv32-unknown-elf/include/sys/features.h \
 /var/tmp/ga87puy/cfu_tvm/tumeda-new/fau-tum-cfu-collab/install/gnu/riscv32-unknown-elf/include/_newlib_version.h \
 /var/tmp/ga87puy/cfu_tvm/tumeda-new/fau-tum-cfu-collab/install/gnu/riscv32-unknown-elf/include/sys/_intsup.h \
 /var/tmp/ga87puy/cfu_tvm/tumeda-new/fau-tum-cfu-collab/install/gnu/riscv32-unknown-elf/include/sys/_stdint.h \
 /var/tmp/ga87puy/cfu_tvm/tumeda-new/fau-tum-cfu-collab/tvm/build_gcc12/standalone_crt/../crt_config/crt_config.h \
 /var/tmp/ga87puy/cfu_tvm/tumeda-new/fau-tum-cfu-collab/tvm/build_gcc12/standalone_crt/include/tvm/runtime/crt/error_codes.h
