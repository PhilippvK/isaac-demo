file(REMOVE_RECURSE
  "CMakeFiles/memory.dir/src/runtime/crt/memory/page_allocator.c.o"
  "CMakeFiles/memory.dir/src/runtime/crt/memory/page_allocator.c.o.d"
  "CMakeFiles/memory.dir/src/runtime/crt/memory/stack_allocator.c.o"
  "CMakeFiles/memory.dir/src/runtime/crt/memory/stack_allocator.c.o.d"
  "libmemory.a"
  "libmemory.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/memory.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
