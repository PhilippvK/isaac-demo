let Predicates = [HasStdExtXMem, IsRV32] in {
class RVInst_MEM_STOREXOR_SH<dag outs, dag ins> : Instruction, Sched<[]> {
    // General
    let Namespace = "RISCV";
    let DecoderNamespace = "XMem";
    let Size = 4;
    bits<32> SoftFail = 0;
    bits<32> Inst;

    // Operands
    bits<5> rs1;
    bits<5> rs2;
    bits<5> rs3;

    // Attributes
    let hasSideEffects = 1;
    let mayLoad = 0;
    let mayStore = 1;
    let isTerminator = 0;

    // Encoding

    let Inst{31} = 0b0;

    let Inst{30} = 0b0;

    let Inst{29-25} = rs3;

    let Inst{24-20} = rs2;

    let Inst{19-15} = rs1;

    let Inst{14} = 0b1;

    let Inst{13} = 0b0;

    let Inst{12} = 0b0;

    let Inst{11} = 0b0;

    let Inst{10} = 0b0;

    let Inst{9} = 0b0;

    let Inst{8} = 0b0;

    let Inst{7} = 0b0;

    let Inst{6} = 0b0;

    let Inst{5} = 0b0;

    let Inst{4} = 0b0;

    let Inst{3} = 0b1;

    let Inst{2} = 0b0;

    let Inst{1} = 0b1;

    let Inst{0} = 0b1;

    dag OutOperandList = outs;
    dag InOperandList = ins;

    // Assembly
    let AsmString = "mem_storexor_sh\t$rs1, $rs2, $rs3";

}
def MEM_STOREXOR_SH : RVInst_MEM_STOREXOR_SH<(outs ), (ins GPR:$rs1, GPR:$rs2, GPR:$rs3)>;

}