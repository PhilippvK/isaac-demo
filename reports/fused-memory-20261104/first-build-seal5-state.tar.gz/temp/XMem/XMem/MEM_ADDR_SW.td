let Predicates = [HasStdExtXMem, IsRV32] in {

let hasSideEffects = 0, mayLoad = 0, mayStore = 1, isBranch = 0, isTerminator = 0, isCodeGenOnly = 1, Constraints = "" in def MEM_ADDR_SW_ : RVInst_MEM_ADDR_SW<(outs ), (ins GPR:$rs1, GPR:$rs2, GPR:$rs3)>;

let GISelShouldIgnore = 1 in def : Pat<
	(store (XLenVT GPR:$rs3), (iPTR (add GPR:$rs2, GPR:$rs1))),
	(MEM_ADDR_SW_ GPR:$rs1, GPR:$rs2, GPR:$rs3)>, GISelFlags { let GIIgnoreCopies = 1; }

}
