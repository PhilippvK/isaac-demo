; ModuleID = 'mod'
source_filename = "mod"
target datalayout = "e-m:e-p:32:32-i64:64-n32-S128"
target triple = "riscv32-unknown-linux-gnu"

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: readwrite, inaccessiblemem: none, target_mem0: none, target_mem1: none)
define void @implMEM_LOADADD_LW(ptr noalias writeonly captures(none) initializes((0, 4)) %rd, ptr readonly captures(none) %rs1, ptr readonly captures(none) %rs2) local_unnamed_addr #0 {
  %rs1.v = load i32, ptr %rs1, align 4
  %rs2.v = load i32, ptr %rs2, align 4
  %1 = inttoptr i32 %rs1.v to ptr
  %.v2 = load i32, ptr %1, align 4
  %2 = add i32 %.v2, %rs2.v
  store i32 %2, ptr %rd, align 4
  ret void
}

attributes #0 = { mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: readwrite, inaccessiblemem: none, target_mem0: none, target_mem1: none) }
