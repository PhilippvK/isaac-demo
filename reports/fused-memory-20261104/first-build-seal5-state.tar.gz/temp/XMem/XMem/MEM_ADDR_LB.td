let Predicates = [HasStdExtXMem, IsRV32] in {

let hasSideEffects = 0, mayLoad = 1, mayStore = 0, isBranch = 0, isTerminator = 0, isCodeGenOnly = 1, Constraints = "" in def MEM_ADDR_LB_ : RVInst_MEM_ADDR_LB<(outs GPR:$rd), (ins GPR:$rs1, GPR:$rs2)>;

let GISelShouldIgnore = 1 in def : Pat<
	(i32 (i32 (sextloadi8 (add GPR:$rs2, GPR:$rs1)))),
	(MEM_ADDR_LB_ GPR:$rs1, GPR:$rs2)>, GISelFlags { let GIIgnoreCopies = 1; }

}
