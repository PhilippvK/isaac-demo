; RUN: llc -mtriple=riscv32 -stop-after=instruction-select -mattr=+fast-unaligned-access,+xmem,+m %s -global-isel=1 -o - \
  ; RUN: | FileCheck -check-prefix=RV32-MIR %s
  ; RUN: llc -mtriple=riscv32 -mattr=+fast-unaligned-access,+xmem,+m %s -global-isel=1 -o - \
  ; RUN: | FileCheck -check-prefix=RV32-ASM %s
; ModuleID = 'mod'
source_filename = "mod"
target datalayout = "e-m:e-p:32:32-i64:64-n32-S128"
target triple = "riscv32-unknown-linux-gnu"

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: readwrite, inaccessiblemem: none, target_mem0: none, target_mem1: none)
define void @implMEM_ADDR_SW(ptr readonly captures(none) %rs1, ptr readonly captures(none) %rs2, ptr readonly captures(none) %rs3) local_unnamed_addr #0 {
  ; RV32-MIR-LABEL: name: implMEM_ADDR_SW
  ; RV32-MIR: MEM_ADDR_SW
  ; RV32-MIR-NEXT: PseudoRET
  ; RV32-ASM-LABEL: implMEM_ADDR_SW:
  ; RV32-ASM: mem_addr_sw
  ; RV32-ASM-NEXT: ret
  %rs1.v = load i32, ptr %rs1, align 4
  %rs2.v = load i32, ptr %rs2, align 4
  %rs3.v = load i32, ptr %rs3, align 4
  %1 = add i32 %rs2.v, %rs1.v
  %2 = inttoptr i32 %1 to ptr
  store i32 %rs3.v, ptr %2, align 4
  ret void
}

attributes #0 = { mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: readwrite, inaccessiblemem: none, target_mem0: none, target_mem1: none) }