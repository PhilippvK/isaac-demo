let Predicates = [HasStdExtXMem, IsRV32] in {

let hasSideEffects = 0, mayLoad = 1, mayStore = 0, isBranch = 0, isTerminator = 0, isCodeGenOnly = 1, Constraints = "" in def MEM_LOADADD_LBU_ : RVInst_MEM_LOADADD_LBU<(outs GPR:$rd), (ins GPR:$rs1, GPR:$rs2)>;
}
def MEM_LOADADD_LBU_singleuse_zextloadi8 : PatFrag<(ops node:$ptr), (zextloadi8 node:$ptr)> { let HasOneUse = 1; }
let Predicates = [HasStdExtXMem, IsRV32] in {

let GISelShouldIgnore = 1 in def : Pat<
	(i32 (add GPR:$rs2, (i32 (MEM_LOADADD_LBU_singleuse_zextloadi8 GPR:$rs1)))),
	(MEM_LOADADD_LBU_ GPR:$rs1, GPR:$rs2)>, GISelFlags { let GIIgnoreCopies = 1; }

}
