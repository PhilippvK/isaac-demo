let Predicates = [HasStdExtXMem, IsRV32] in {

let hasSideEffects = 0, mayLoad = 1, mayStore = 0, isBranch = 0, isTerminator = 0, isCodeGenOnly = 1, Constraints = "" in def MEM_LOADADD_LH_ : RVInst_MEM_LOADADD_LH<(outs GPR:$rd), (ins GPR:$rs1, GPR:$rs2)>;
}
def MEM_LOADADD_LH_singleuse_sextloadi16 : PatFrag<(ops node:$ptr), (sextloadi16 node:$ptr)> { let HasOneUse = 1; }
let Predicates = [HasStdExtXMem, IsRV32] in {

let GISelShouldIgnore = 1 in def : Pat<
	(i32 (add GPR:$rs2, (i32 (MEM_LOADADD_LH_singleuse_sextloadi16 GPR:$rs1)))),
	(MEM_LOADADD_LH_ GPR:$rs1, GPR:$rs2)>, GISelFlags { let GIIgnoreCopies = 1; }

}
