; ModuleID = 'mod'
source_filename = "mod"
target datalayout = "e-m:e-p:32:32-i64:64-n32-S128"
target triple = "riscv32-unknown-linux-gnu"

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: readwrite, inaccessiblemem: none, target_mem0: none, target_mem1: none)
define void @implMEM_STOREXOR_SH(ptr readonly captures(none) %rs1, ptr readonly captures(none) %rs2, ptr readonly captures(none) %rs3) local_unnamed_addr #0 {
  %rs1.v = load i32, ptr %rs1, align 4
  %rs2.v = load i32, ptr %rs2, align 4
  %rs3.v = load i32, ptr %rs3, align 4
  %1 = inttoptr i32 %rs1.v to ptr
  %2 = xor i32 %rs3.v, %rs2.v
  %3 = trunc i32 %2 to i16
  store i16 %3, ptr %1, align 2
  ret void
}

attributes #0 = { mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: readwrite, inaccessiblemem: none, target_mem0: none, target_mem1: none) }
