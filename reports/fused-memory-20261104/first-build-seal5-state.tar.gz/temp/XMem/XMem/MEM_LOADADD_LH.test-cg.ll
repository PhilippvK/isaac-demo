; RUN: llc -mtriple=riscv32 -stop-after=instruction-select -mattr=+fast-unaligned-access,+xmem,+m %s -global-isel=1 -o - \
  ; RUN: | FileCheck -check-prefix=RV32-MIR %s
  ; RUN: llc -mtriple=riscv32 -mattr=+fast-unaligned-access,+xmem,+m %s -global-isel=1 -o - \
  ; RUN: | FileCheck -check-prefix=RV32-ASM %s
; ModuleID = 'mod'
source_filename = "mod"
target datalayout = "e-m:e-p:32:32-i64:64-n32-S128"
target triple = "riscv32-unknown-linux-gnu"

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: readwrite, inaccessiblemem: none, target_mem0: none, target_mem1: none)
define i32 @implMEM_LOADADD_LH(ptr noalias writeonly captures(none) initializes((0, 4)) %rd, ptr readonly captures(none) %rs1, ptr readonly captures(none) %rs2) local_unnamed_addr #0 {
  ; RV32-MIR-LABEL: name: implMEM_LOADADD_LH
  ; RV32-MIR: MEM_LOADADD_LH
  ; RV32-MIR: PseudoRET
  ; RV32-ASM-LABEL: implMEM_LOADADD_LH:
  ; RV32-ASM: mem_loadadd_lh
  ; RV32-ASM: ret
  %rs1.v = load i32, ptr %rs1, align 4
  %rs2.v = load i32, ptr %rs2, align 4
  %1 = inttoptr i32 %rs1.v to ptr
  %.v2 = load i16, ptr %1, align 2
  %2 = sext i16 %.v2 to i32
  %3 = add i32 %rs2.v, %2
  ret i32 %3
}

attributes #0 = { mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: readwrite, inaccessiblemem: none, target_mem0: none, target_mem1: none) }