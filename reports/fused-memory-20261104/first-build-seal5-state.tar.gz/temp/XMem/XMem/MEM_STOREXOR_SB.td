let Predicates = [HasStdExtXMem, IsRV32] in {

let hasSideEffects = 0, mayLoad = 0, mayStore = 1, isBranch = 0, isTerminator = 0, isCodeGenOnly = 1, Constraints = "" in def MEM_STOREXOR_SB_ : RVInst_MEM_STOREXOR_SB<(outs ), (ins GPR:$rs1, GPR:$rs2, GPR:$rs3)>;

let GISelShouldIgnore = 1 in def : Pat<
	(truncstorei8 (XLenVT (xor GPR:$rs3, GPR:$rs2)), (iPTR GPR:$rs1)),
	(MEM_STOREXOR_SB_ GPR:$rs1, GPR:$rs2, GPR:$rs3)>, GISelFlags { let GIIgnoreCopies = 1; }

}
