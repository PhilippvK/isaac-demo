let Predicates = [HasStdExtXMem, IsRV32] in {

let hasSideEffects = 0, mayLoad = 1, mayStore = 0, isBranch = 0, isTerminator = 0, isCodeGenOnly = 1, Constraints = "" in def MEM_LOADADD_LW_ : RVInst_MEM_LOADADD_LW<(outs GPR:$rd), (ins GPR:$rs1, GPR:$rs2)>;
}
def MEM_LOADADD_LW_singleuse_load : PatFrag<(ops node:$ptr), (load node:$ptr)> { let HasOneUse = 1; }
let Predicates = [HasStdExtXMem, IsRV32] in {

let GISelShouldIgnore = 1 in def : Pat<
	(i32 (add (i32 (MEM_LOADADD_LW_singleuse_load GPR:$rs1)), GPR:$rs2)),
	(MEM_LOADADD_LW_ GPR:$rs1, GPR:$rs2)>, GISelFlags { let GIIgnoreCopies = 1; }

}
