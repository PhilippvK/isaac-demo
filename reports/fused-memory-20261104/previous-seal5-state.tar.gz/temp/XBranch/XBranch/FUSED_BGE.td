let Predicates = [HasStdExtXBranch, IsRV32] in {

let hasSideEffects = 0, mayLoad = 0, mayStore = 0, isBranch = 1, isTerminator = 1, isCodeGenOnly = 1, Format = InstFormatB, Constraints = "" in def FUSED_BGE_ : RVInst_FUSED_BGE<(outs ), (ins GPR:$rs1, GPR:$rs2, patterngen_btarget:$offset)>;

let GISelShouldIgnore = 1 in def : Pat<
	(riscv_brcc (i32 (i32 6)), (i32 (and GPR:$rs2, GPR:$rs1)), SETLT, bb:$offset),
	(FUSED_BGE_ GPR:$rs1, GPR:$rs2, bb:$offset)>;

}
