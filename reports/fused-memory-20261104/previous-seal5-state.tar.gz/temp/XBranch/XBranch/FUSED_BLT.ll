; ModuleID = 'mod'
source_filename = "mod"
target datalayout = "e-m:e-p:32:32-i64:64-n32-S128"
target triple = "riscv32-unknown-linux-gnu"

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn
define void @implFUSED_BLT(i32 %offset, ptr readonly captures(none) %rs1, ptr readonly captures(none) %rs2) local_unnamed_addr #0 {
  %rs1.v = load i32, ptr %rs1, align 4
  %rs2.v = load i32, ptr %rs2, align 4
  %1 = and i32 %rs2.v, %rs1.v
  %2 = icmp slt i32 %1, 7
  %3 = zext i1 %2 to i32
  %4 = tail call i32 @llvm.riscv.pg.branch.i32(i32 %3)
  ret void
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn
declare i32 @llvm.riscv.pg.branch.i32(i32) #1

attributes #0 = { mustprogress nofree norecurse nosync nounwind willreturn }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn }
