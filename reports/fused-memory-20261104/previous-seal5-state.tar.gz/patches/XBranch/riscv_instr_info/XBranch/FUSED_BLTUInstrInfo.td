let Predicates = [HasStdExtXBranch, IsRV32] in {
class RVInst_FUSED_BLTU<dag outs, dag ins> : Instruction, Sched<[]> {
    // General
    let Namespace = "RISCV";
    let DecoderNamespace = "XBranch";
    let Size = 4;
    bits<32> SoftFail = 0;
    bits<32> Inst;
    InstFormat Format = InstFormatB;
    let TSFlags{4-0} = Format.Value;

    // Operands
    bits<13> offset;
    bits<5> rs1;
    bits<5> rs2;

    // Attributes
    let hasSideEffects = 1;
    let mayLoad = 0;
    let mayStore = 0;
    let isTerminator = 1;
    let isBranch = 1;

    // Encoding

    let Inst{31} = offset{12};

    let Inst{30-25} = offset{10-5};

    let Inst{24-20} = rs2;

    let Inst{19-15} = rs1;

    let Inst{14} = 0b0;

    let Inst{13} = 0b0;

    let Inst{12} = 0b1;

    let Inst{11-8} = offset{4-1};

    let Inst{7} = offset{11};

    let Inst{6} = 0b0;

    let Inst{5} = 0b0;

    let Inst{4} = 0b0;

    let Inst{3} = 0b1;

    let Inst{2} = 0b0;

    let Inst{1} = 0b1;

    let Inst{0} = 0b1;

    dag OutOperandList = outs;
    dag InOperandList = ins;

    // Assembly
    let AsmString = "fused_bltu\t$rs1, $rs2, $offset";

}
def FUSED_BLTU : RVInst_FUSED_BLTU<(outs ), (ins GPR:$rs1, GPR:$rs2, patterngen_btarget:$offset)>;

}