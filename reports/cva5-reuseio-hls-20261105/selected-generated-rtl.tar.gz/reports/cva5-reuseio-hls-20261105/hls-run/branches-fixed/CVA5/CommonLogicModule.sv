 

// SystemVerilog file 
 
module SCAL (
    // Interface to the ISAX Module
    
    output [32 -1 : 0] RdPC_2_o,// ISAX
    output  RdStall_FUSED_BGEU_2_o,// ISAX
    output  RdStall_FUSED_BNE_2_o,// ISAX
    output  RdStall_FUSED_BLT_2_o,// ISAX
    output  RdStall_FUSED_BLTU_2_o,// ISAX
    output  RdStall_FUSED_BEQ_2_o,// ISAX
    output  RdStall_FUSED_BGE_2_o,// ISAX
    output [32 -1 : 0] RdInstr_2_o,// ISAX
    input [32 -1 : 0] WrPC_FUSED_BGEU_2_i,// ISAX
    input  WrPC_validReq_FUSED_BGEU_2_i,// ISAX
    input [32 -1 : 0] WrPC_FUSED_BNE_2_i,// ISAX
    input  WrPC_validReq_FUSED_BNE_2_i,// ISAX
    input [32 -1 : 0] WrPC_FUSED_BLT_2_i,// ISAX
    input  WrPC_validReq_FUSED_BLT_2_i,// ISAX
    input [32 -1 : 0] WrPC_FUSED_BLTU_2_i,// ISAX
    input  WrPC_validReq_FUSED_BLTU_2_i,// ISAX
    input [32 -1 : 0] WrPC_FUSED_BEQ_2_i,// ISAX
    input  WrPC_validReq_FUSED_BEQ_2_i,// ISAX
    input [32 -1 : 0] WrPC_FUSED_BGE_2_i,// ISAX
    input  WrPC_validReq_FUSED_BGE_2_i,// ISAX
    output [32 -1 : 0] RdRS1_2_o,// ISAX
    output [32 -1 : 0] RdRS2_2_o,// ISAX
    output  RdIValid_FUSED_BGEU_1_o,// ISAX
    output  RdIValid_FUSED_BNE_1_o,// ISAX
    output  RdIValid_FUSED_BLT_1_o,// ISAX
    output  RdIValid_FUSED_BLTU_1_o,// ISAX
    output  RdIValid_FUSED_BEQ_1_o,// ISAX
    output  RdIValid_FUSED_BGE_1_o,// ISAX
    output  RdIValid_FUSED_BGEU_2_o,// ISAX
    output  RdIValid_FUSED_BNE_2_o,// ISAX
    output  RdIValid_FUSED_BLT_2_o,// ISAX
    output  RdIValid_FUSED_BLTU_2_o,// ISAX
    output  RdIValid_FUSED_BEQ_2_o,// ISAX
    output  RdIValid_FUSED_BGE_2_o,// ISAX

    
    // Interface to the Core
    
    input [32 -1 : 0] RdPC_2_i,// ISAX
    input  RdStall_2_i,// ISAX
    input [32 -1 : 0] RdInstr_2_i,// ISAX
    input  RdFlush_2_i,// ISAX
    output  WrFlush_1_o,// ISAX
    input  RdInStageValid_2_i,// ISAX
    input  glueToSCAL_IValid_cond_all_2_i,// ISAX
    input  RdFlush_1_i,// ISAX
    input  RdInStageValid_1_i,// ISAX
    input  glueToSCAL_IValid_cond_all_1_i,// ISAX
    input [32 -1 : 0] RdInstr_1_i,// ISAX
    input  RdStall_1_i,// ISAX
    output [32 -1 : 0] WrPC_2_o,// ISAX
    output  WrPC_validReq_2_o,// ISAX
    input [32 -1 : 0] RdRS1_2_i,// ISAX
    input [32 -1 : 0] RdRS2_2_i,// ISAX
    output  core_RdIValid_FUSED_BGEU_1_o,// ISAX
    output  core_RdIValid_FUSED_BNE_1_o,// ISAX
    output  core_RdIValid_FUSED_BLT_1_o,// ISAX
    output  core_RdIValid_FUSED_BLTU_1_o,// ISAX
    output  core_RdIValid_FUSED_BEQ_1_o,// ISAX
    output  core_RdIValid_FUSED_BGE_1_o,// ISAX
    input  core_RdPipeInto_stage_executesv1_2_i,// ISAX
    input  glueToSCAL_IValid_cond_all_3_i,// ISAX
    input  RdInStageValid_3_i,// ISAX
    input  RdStall_3_i,// ISAX
    input  RdFlush_3_i,// ISAX
    output  core_RdIValid_FUSED_BGEU_3_o,// ISAX
    output  core_RdIValid_FUSED_BNE_3_o,// ISAX
    output  core_RdIValid_FUSED_BLT_3_o,// ISAX
    output  core_RdIValid_FUSED_BLTU_3_o,// ISAX
    output  core_RdIValid_FUSED_BEQ_3_o,// ISAX
    output  core_RdIValid_FUSED_BGE_3_o,// ISAX
    
    input clk_i,
    input rst_i

    
);
// Declare local signals
//Declarations - StallFlushDeqStrategy (RdStall_FUSED_BGEU_2)(285)
wire RdStall_FUSED_BGEU_2_s;
//Declarations - StallFlushDeqStrategy (RdStall_FUSED_BNE_2)(287)
wire RdStall_FUSED_BNE_2_s;
//Declarations - StallFlushDeqStrategy (RdStall_FUSED_BLT_2)(289)
wire RdStall_FUSED_BLT_2_s;
//Declarations - StallFlushDeqStrategy (RdStall_FUSED_BLTU_2)(291)
wire RdStall_FUSED_BLTU_2_s;
//Declarations - StallFlushDeqStrategy (RdStall_FUSED_BEQ_2)(293)
wire RdStall_FUSED_BEQ_2_s;
//Declarations - StallFlushDeqStrategy (RdStall_FUSED_BGE_2)(295)
wire RdStall_FUSED_BGE_2_s;
//Declarations - ValidMuxStrategy (WrPC_validReq_2)(297)
reg  WrPC_validReq_2_s;
//Declarations - StallFlushDeqStrategy (WrFlush_1)(314)
wire WrFlush_1_s;
//Declarations - RdInStageValidStrategy_RdInStageValid_2(310)
wire RdInStageValid_2_s;
//Declarations - RdInStageValidStrategy_RdInStageValid_1(308)
wire RdInStageValid_1_s;
//Declarations - PipeliningRdIValidStrategy(RdIValid_FUSED_BGE_1)(187)
wire RdIValid_FUSED_BGE_1_s;
//Declarations - PipeliningRdIValidStrategy(RdIValid_FUSED_BGE_2)(235)
reg  RdIValid_FUSED_BGE_2_regpipein;
wire RdIValid_FUSED_BGE_2_s;
//Declarations - PipeliningRdIValidStrategy(RdIValid_FUSED_BGEU_1)(147)
wire RdIValid_FUSED_BGEU_1_s;
//Declarations - PipeliningRdIValidStrategy(RdIValid_FUSED_BGEU_2)(195)
reg  RdIValid_FUSED_BGEU_2_regpipein;
wire RdIValid_FUSED_BGEU_2_s;
//Declarations - PipeliningRdIValidStrategy(RdIValid_FUSED_BNE_1)(155)
wire RdIValid_FUSED_BNE_1_s;
//Declarations - PipeliningRdIValidStrategy(RdIValid_FUSED_BNE_2)(203)
reg  RdIValid_FUSED_BNE_2_regpipein;
wire RdIValid_FUSED_BNE_2_s;
//Declarations - PipeliningRdIValidStrategy(RdIValid_FUSED_BLTU_1)(171)
wire RdIValid_FUSED_BLTU_1_s;
//Declarations - PipeliningRdIValidStrategy(RdIValid_FUSED_BLTU_2)(219)
reg  RdIValid_FUSED_BLTU_2_regpipein;
wire RdIValid_FUSED_BLTU_2_s;
//Declarations - PipeliningRdIValidStrategy(RdIValid_FUSED_BEQ_1)(179)
wire RdIValid_FUSED_BEQ_1_s;
//Declarations - PipeliningRdIValidStrategy(RdIValid_FUSED_BEQ_2)(227)
reg  RdIValid_FUSED_BEQ_2_regpipein;
wire RdIValid_FUSED_BEQ_2_s;
//Declarations - PipeliningRdIValidStrategy(RdIValid_FUSED_BLT_1)(163)
wire RdIValid_FUSED_BLT_1_s;
//Declarations - PipeliningRdIValidStrategy(RdIValid_FUSED_BLT_2)(211)
reg  RdIValid_FUSED_BLT_2_regpipein;
wire RdIValid_FUSED_BLT_2_s;
//Declarations - ValidMuxStrategy (WrPC_2)(296)
reg [ 32 -1 : 0 ] WrPC_2_s;
//Declarations - RdInStageValidStrategy_RdInStageValid_3(312)
wire RdInStageValid_3_s;
//Declarations - PipeliningRdIValidStrategy(RdIValid_FUSED_BGEU_3)(243)
reg  RdIValid_FUSED_BGEU_3_regpipein;
wire RdIValid_FUSED_BGEU_3_s;
//Declarations - PipeliningRdIValidStrategy(RdIValid_FUSED_BNE_3)(251)
reg  RdIValid_FUSED_BNE_3_regpipein;
wire RdIValid_FUSED_BNE_3_s;
//Declarations - PipeliningRdIValidStrategy(RdIValid_FUSED_BLT_3)(259)
reg  RdIValid_FUSED_BLT_3_regpipein;
wire RdIValid_FUSED_BLT_3_s;
//Declarations - PipeliningRdIValidStrategy(RdIValid_FUSED_BLTU_3)(267)
reg  RdIValid_FUSED_BLTU_3_regpipein;
wire RdIValid_FUSED_BLTU_3_s;
//Declarations - PipeliningRdIValidStrategy(RdIValid_FUSED_BEQ_3)(275)
reg  RdIValid_FUSED_BEQ_3_regpipein;
wire RdIValid_FUSED_BEQ_3_s;
//Declarations - PipeliningRdIValidStrategy(RdIValid_FUSED_BGE_3)(283)
reg  RdIValid_FUSED_BGE_3_regpipein;
wire RdIValid_FUSED_BGE_3_s;


// Logic
//Logic - SCALInputOutputStrategy (RdPC_2)(80)
assign RdPC_2_o = RdPC_2_i;
//Logic - StallFlushDeqStrategy (RdStall_FUSED_BGEU_2)(285)
assign RdStall_FUSED_BGEU_2_s = (RdStall_2_i);
//Logic - SCALInputOutputStrategy (RdStall_FUSED_BGEU_2)(82)
assign RdStall_FUSED_BGEU_2_o = RdStall_FUSED_BGEU_2_s;
//Logic - StallFlushDeqStrategy (RdStall_FUSED_BNE_2)(287)
assign RdStall_FUSED_BNE_2_s = (RdStall_2_i);
//Logic - SCALInputOutputStrategy (RdStall_FUSED_BNE_2)(83)
assign RdStall_FUSED_BNE_2_o = RdStall_FUSED_BNE_2_s;
//Logic - StallFlushDeqStrategy (RdStall_FUSED_BLT_2)(289)
assign RdStall_FUSED_BLT_2_s = (RdStall_2_i);
//Logic - SCALInputOutputStrategy (RdStall_FUSED_BLT_2)(84)
assign RdStall_FUSED_BLT_2_o = RdStall_FUSED_BLT_2_s;
//Logic - StallFlushDeqStrategy (RdStall_FUSED_BLTU_2)(291)
assign RdStall_FUSED_BLTU_2_s = (RdStall_2_i);
//Logic - SCALInputOutputStrategy (RdStall_FUSED_BLTU_2)(85)
assign RdStall_FUSED_BLTU_2_o = RdStall_FUSED_BLTU_2_s;
//Logic - StallFlushDeqStrategy (RdStall_FUSED_BEQ_2)(293)
assign RdStall_FUSED_BEQ_2_s = (RdStall_2_i);
//Logic - SCALInputOutputStrategy (RdStall_FUSED_BEQ_2)(86)
assign RdStall_FUSED_BEQ_2_o = RdStall_FUSED_BEQ_2_s;
//Logic - StallFlushDeqStrategy (RdStall_FUSED_BGE_2)(295)
assign RdStall_FUSED_BGE_2_s = (RdStall_2_i);
//Logic - SCALInputOutputStrategy (RdStall_FUSED_BGE_2)(87)
assign RdStall_FUSED_BGE_2_o = RdStall_FUSED_BGE_2_s;
//Logic - SCALInputOutputStrategy (RdInstr_2)(89)
assign RdInstr_2_o = RdInstr_2_i;
//Logic - SCALInputOutputStrategy (WrFlush_1)(345)
assign WrFlush_1_o = WrFlush_1_s;
//Logic - ValidMuxStrategy (WrPC_validReq_2)(297)
always_comb begin 
    case(1'b1)
        RdIValid_FUSED_BGEU_2_s: WrPC_validReq_2_s = WrPC_validReq_FUSED_BGEU_2_i;
        RdIValid_FUSED_BNE_2_s: WrPC_validReq_2_s = WrPC_validReq_FUSED_BNE_2_i;
        RdIValid_FUSED_BLT_2_s: WrPC_validReq_2_s = WrPC_validReq_FUSED_BLT_2_i;
        RdIValid_FUSED_BLTU_2_s: WrPC_validReq_2_s = WrPC_validReq_FUSED_BLTU_2_i;
        RdIValid_FUSED_BEQ_2_s: WrPC_validReq_2_s = WrPC_validReq_FUSED_BEQ_2_i;
        RdIValid_FUSED_BGE_2_s: WrPC_validReq_2_s = WrPC_validReq_FUSED_BGE_2_i;
        default: WrPC_validReq_2_s = 0;
    endcase
end
//Logic - StallFlushDeqStrategy (WrFlush_1)(314)
assign WrFlush_1_s = (WrPC_validReq_2_s);
//Logic - RdInStageValidStrategy_RdInStageValid_2(310)
assign RdInStageValid_2_s = RdInStageValid_2_i;
//Logic - RdInStageValidStrategy_RdInStageValid_1(308)
assign RdInStageValid_1_s = RdInStageValid_1_i;
//Logic - PipeliningRdIValidStrategy(RdIValid_FUSED_BGE_1)(187)
assign RdIValid_FUSED_BGE_1_s = ((RdInstr_1_i[6 : 0] == 7'b0001011) && (RdInstr_1_i[14 : 12] == 3'b100)) && !RdFlush_1_i && glueToSCAL_IValid_cond_all_1_i && RdInStageValid_1_s;
//Logic - PipeliningRdIValidStrategy(RdIValid_FUSED_BGE_2)(235)
always@(posedge clk_i) begin
    if (rst_i)
        RdIValid_FUSED_BGE_2_regpipein <= 0;
    else if (!((RdStall_1_i)))
        RdIValid_FUSED_BGE_2_regpipein <= ((RdFlush_1_i) || WrFlush_1_s) ? 0 : RdIValid_FUSED_BGE_1_s;
    else if (!((RdStall_2_i)))
        RdIValid_FUSED_BGE_2_regpipein <= 0;
    else if ((RdFlush_2_i))
        RdIValid_FUSED_BGE_2_regpipein <= 0;
end
assign RdIValid_FUSED_BGE_2_s = RdIValid_FUSED_BGE_2_regpipein && !RdFlush_2_i && glueToSCAL_IValid_cond_all_2_i && RdInStageValid_2_s;
//Logic - PipeliningRdIValidStrategy(RdIValid_FUSED_BGEU_1)(147)
assign RdIValid_FUSED_BGEU_1_s = ((RdInstr_1_i[6 : 0] == 7'b0001011) && (RdInstr_1_i[14 : 12] == 3'b010)) && !RdFlush_1_i && glueToSCAL_IValid_cond_all_1_i && RdInStageValid_1_s;
//Logic - PipeliningRdIValidStrategy(RdIValid_FUSED_BGEU_2)(195)
always@(posedge clk_i) begin
    if (rst_i)
        RdIValid_FUSED_BGEU_2_regpipein <= 0;
    else if (!((RdStall_1_i)))
        RdIValid_FUSED_BGEU_2_regpipein <= ((RdFlush_1_i) || WrFlush_1_s) ? 0 : RdIValid_FUSED_BGEU_1_s;
    else if (!((RdStall_2_i)))
        RdIValid_FUSED_BGEU_2_regpipein <= 0;
    else if ((RdFlush_2_i))
        RdIValid_FUSED_BGEU_2_regpipein <= 0;
end
assign RdIValid_FUSED_BGEU_2_s = RdIValid_FUSED_BGEU_2_regpipein && !RdFlush_2_i && glueToSCAL_IValid_cond_all_2_i && RdInStageValid_2_s;
//Logic - PipeliningRdIValidStrategy(RdIValid_FUSED_BNE_1)(155)
assign RdIValid_FUSED_BNE_1_s = ((RdInstr_1_i[6 : 0] == 7'b0001011) && (RdInstr_1_i[14 : 12] == 3'b101)) && !RdFlush_1_i && glueToSCAL_IValid_cond_all_1_i && RdInStageValid_1_s;
//Logic - PipeliningRdIValidStrategy(RdIValid_FUSED_BNE_2)(203)
always@(posedge clk_i) begin
    if (rst_i)
        RdIValid_FUSED_BNE_2_regpipein <= 0;
    else if (!((RdStall_1_i)))
        RdIValid_FUSED_BNE_2_regpipein <= ((RdFlush_1_i) || WrFlush_1_s) ? 0 : RdIValid_FUSED_BNE_1_s;
    else if (!((RdStall_2_i)))
        RdIValid_FUSED_BNE_2_regpipein <= 0;
    else if ((RdFlush_2_i))
        RdIValid_FUSED_BNE_2_regpipein <= 0;
end
assign RdIValid_FUSED_BNE_2_s = RdIValid_FUSED_BNE_2_regpipein && !RdFlush_2_i && glueToSCAL_IValid_cond_all_2_i && RdInStageValid_2_s;
//Logic - PipeliningRdIValidStrategy(RdIValid_FUSED_BLTU_1)(171)
assign RdIValid_FUSED_BLTU_1_s = ((RdInstr_1_i[6 : 0] == 7'b0001011) && (RdInstr_1_i[14 : 12] == 3'b001)) && !RdFlush_1_i && glueToSCAL_IValid_cond_all_1_i && RdInStageValid_1_s;
//Logic - PipeliningRdIValidStrategy(RdIValid_FUSED_BLTU_2)(219)
always@(posedge clk_i) begin
    if (rst_i)
        RdIValid_FUSED_BLTU_2_regpipein <= 0;
    else if (!((RdStall_1_i)))
        RdIValid_FUSED_BLTU_2_regpipein <= ((RdFlush_1_i) || WrFlush_1_s) ? 0 : RdIValid_FUSED_BLTU_1_s;
    else if (!((RdStall_2_i)))
        RdIValid_FUSED_BLTU_2_regpipein <= 0;
    else if ((RdFlush_2_i))
        RdIValid_FUSED_BLTU_2_regpipein <= 0;
end
assign RdIValid_FUSED_BLTU_2_s = RdIValid_FUSED_BLTU_2_regpipein && !RdFlush_2_i && glueToSCAL_IValid_cond_all_2_i && RdInStageValid_2_s;
//Logic - PipeliningRdIValidStrategy(RdIValid_FUSED_BEQ_1)(179)
assign RdIValid_FUSED_BEQ_1_s = ((RdInstr_1_i[6 : 0] == 7'b0001011) && (RdInstr_1_i[14 : 12] == 3'b000)) && !RdFlush_1_i && glueToSCAL_IValid_cond_all_1_i && RdInStageValid_1_s;
//Logic - PipeliningRdIValidStrategy(RdIValid_FUSED_BEQ_2)(227)
always@(posedge clk_i) begin
    if (rst_i)
        RdIValid_FUSED_BEQ_2_regpipein <= 0;
    else if (!((RdStall_1_i)))
        RdIValid_FUSED_BEQ_2_regpipein <= ((RdFlush_1_i) || WrFlush_1_s) ? 0 : RdIValid_FUSED_BEQ_1_s;
    else if (!((RdStall_2_i)))
        RdIValid_FUSED_BEQ_2_regpipein <= 0;
    else if ((RdFlush_2_i))
        RdIValid_FUSED_BEQ_2_regpipein <= 0;
end
assign RdIValid_FUSED_BEQ_2_s = RdIValid_FUSED_BEQ_2_regpipein && !RdFlush_2_i && glueToSCAL_IValid_cond_all_2_i && RdInStageValid_2_s;
//Logic - PipeliningRdIValidStrategy(RdIValid_FUSED_BLT_1)(163)
assign RdIValid_FUSED_BLT_1_s = ((RdInstr_1_i[6 : 0] == 7'b0001011) && (RdInstr_1_i[14 : 12] == 3'b110)) && !RdFlush_1_i && glueToSCAL_IValid_cond_all_1_i && RdInStageValid_1_s;
//Logic - PipeliningRdIValidStrategy(RdIValid_FUSED_BLT_2)(211)
always@(posedge clk_i) begin
    if (rst_i)
        RdIValid_FUSED_BLT_2_regpipein <= 0;
    else if (!((RdStall_1_i)))
        RdIValid_FUSED_BLT_2_regpipein <= ((RdFlush_1_i) || WrFlush_1_s) ? 0 : RdIValid_FUSED_BLT_1_s;
    else if (!((RdStall_2_i)))
        RdIValid_FUSED_BLT_2_regpipein <= 0;
    else if ((RdFlush_2_i))
        RdIValid_FUSED_BLT_2_regpipein <= 0;
end
assign RdIValid_FUSED_BLT_2_s = RdIValid_FUSED_BLT_2_regpipein && !RdFlush_2_i && glueToSCAL_IValid_cond_all_2_i && RdInStageValid_2_s;
//Logic - ValidMuxStrategy (WrPC_2)(296)
always_comb begin 
    case(1'b1)
        RdIValid_FUSED_BGEU_2_s: WrPC_2_s = WrPC_FUSED_BGEU_2_i;
        RdIValid_FUSED_BNE_2_s: WrPC_2_s = WrPC_FUSED_BNE_2_i;
        RdIValid_FUSED_BLT_2_s: WrPC_2_s = WrPC_FUSED_BLT_2_i;
        RdIValid_FUSED_BLTU_2_s: WrPC_2_s = WrPC_FUSED_BLTU_2_i;
        RdIValid_FUSED_BEQ_2_s: WrPC_2_s = WrPC_FUSED_BEQ_2_i;
        default: WrPC_2_s = WrPC_FUSED_BGE_2_i;
    endcase
end
//Logic - SCALInputOutputStrategy (WrPC_2)(103)
assign WrPC_2_o = WrPC_2_s;
//Logic - SCALInputOutputStrategy (WrPC_validReq_2)(104)
assign WrPC_validReq_2_o = WrPC_validReq_2_s;
//Logic - SCALInputOutputStrategy (RdRS1_2)(105)
assign RdRS1_2_o = RdRS1_2_i;
//Logic - SCALInputOutputStrategy (RdRS2_2)(107)
assign RdRS2_2_o = RdRS2_2_i;
//Logic - SCALInputOutputStrategy (RdIValid_FUSED_BGEU_1)(109)
assign RdIValid_FUSED_BGEU_1_o = RdIValid_FUSED_BGEU_1_s;
//Logic - SCALInputOutputStrategy (RdIValid_FUSED_BGEU_1)(110)
assign core_RdIValid_FUSED_BGEU_1_o = RdIValid_FUSED_BGEU_1_s;
//Logic - SCALInputOutputStrategy (RdIValid_FUSED_BNE_1)(111)
assign RdIValid_FUSED_BNE_1_o = RdIValid_FUSED_BNE_1_s;
//Logic - SCALInputOutputStrategy (RdIValid_FUSED_BNE_1)(112)
assign core_RdIValid_FUSED_BNE_1_o = RdIValid_FUSED_BNE_1_s;
//Logic - SCALInputOutputStrategy (RdIValid_FUSED_BLT_1)(113)
assign RdIValid_FUSED_BLT_1_o = RdIValid_FUSED_BLT_1_s;
//Logic - SCALInputOutputStrategy (RdIValid_FUSED_BLT_1)(114)
assign core_RdIValid_FUSED_BLT_1_o = RdIValid_FUSED_BLT_1_s;
//Logic - SCALInputOutputStrategy (RdIValid_FUSED_BLTU_1)(115)
assign RdIValid_FUSED_BLTU_1_o = RdIValid_FUSED_BLTU_1_s;
//Logic - SCALInputOutputStrategy (RdIValid_FUSED_BLTU_1)(116)
assign core_RdIValid_FUSED_BLTU_1_o = RdIValid_FUSED_BLTU_1_s;
//Logic - SCALInputOutputStrategy (RdIValid_FUSED_BEQ_1)(117)
assign RdIValid_FUSED_BEQ_1_o = RdIValid_FUSED_BEQ_1_s;
//Logic - SCALInputOutputStrategy (RdIValid_FUSED_BEQ_1)(118)
assign core_RdIValid_FUSED_BEQ_1_o = RdIValid_FUSED_BEQ_1_s;
//Logic - SCALInputOutputStrategy (RdIValid_FUSED_BGE_1)(119)
assign RdIValid_FUSED_BGE_1_o = RdIValid_FUSED_BGE_1_s;
//Logic - SCALInputOutputStrategy (RdIValid_FUSED_BGE_1)(120)
assign core_RdIValid_FUSED_BGE_1_o = RdIValid_FUSED_BGE_1_s;
//Logic - SCALInputOutputStrategy (RdIValid_FUSED_BGEU_2)(121)
assign RdIValid_FUSED_BGEU_2_o = RdIValid_FUSED_BGEU_2_s;
//Logic - SCALInputOutputStrategy (RdIValid_FUSED_BNE_2)(122)
assign RdIValid_FUSED_BNE_2_o = RdIValid_FUSED_BNE_2_s;
//Logic - SCALInputOutputStrategy (RdIValid_FUSED_BLT_2)(123)
assign RdIValid_FUSED_BLT_2_o = RdIValid_FUSED_BLT_2_s;
//Logic - SCALInputOutputStrategy (RdIValid_FUSED_BLTU_2)(124)
assign RdIValid_FUSED_BLTU_2_o = RdIValid_FUSED_BLTU_2_s;
//Logic - SCALInputOutputStrategy (RdIValid_FUSED_BEQ_2)(125)
assign RdIValid_FUSED_BEQ_2_o = RdIValid_FUSED_BEQ_2_s;
//Logic - SCALInputOutputStrategy (RdIValid_FUSED_BGE_2)(126)
assign RdIValid_FUSED_BGE_2_o = RdIValid_FUSED_BGE_2_s;
//Logic - RdInStageValidStrategy_RdInStageValid_3(312)
assign RdInStageValid_3_s = RdInStageValid_3_i;
//Logic - PipeliningRdIValidStrategy(RdIValid_FUSED_BGEU_3)(243)
always@(posedge clk_i) begin
    if (rst_i)
        RdIValid_FUSED_BGEU_3_regpipein <= 0;
    else if (!((RdStall_2_i)) && core_RdPipeInto_stage_executesv1_2_i)
        RdIValid_FUSED_BGEU_3_regpipein <= ((RdFlush_2_i)) ? 0 : RdIValid_FUSED_BGEU_2_s;
    else if (!((RdStall_3_i)))
        RdIValid_FUSED_BGEU_3_regpipein <= 0;
    else if ((RdFlush_3_i))
        RdIValid_FUSED_BGEU_3_regpipein <= 0;
end
assign RdIValid_FUSED_BGEU_3_s = RdIValid_FUSED_BGEU_3_regpipein && !RdFlush_3_i && glueToSCAL_IValid_cond_all_3_i && RdInStageValid_3_s;
//Logic - SCALInputOutputStrategy (RdIValid_FUSED_BGEU_3)(132)
assign core_RdIValid_FUSED_BGEU_3_o = RdIValid_FUSED_BGEU_3_s;
//Logic - PipeliningRdIValidStrategy(RdIValid_FUSED_BNE_3)(251)
always@(posedge clk_i) begin
    if (rst_i)
        RdIValid_FUSED_BNE_3_regpipein <= 0;
    else if (!((RdStall_2_i)) && core_RdPipeInto_stage_executesv1_2_i)
        RdIValid_FUSED_BNE_3_regpipein <= ((RdFlush_2_i)) ? 0 : RdIValid_FUSED_BNE_2_s;
    else if (!((RdStall_3_i)))
        RdIValid_FUSED_BNE_3_regpipein <= 0;
    else if ((RdFlush_3_i))
        RdIValid_FUSED_BNE_3_regpipein <= 0;
end
assign RdIValid_FUSED_BNE_3_s = RdIValid_FUSED_BNE_3_regpipein && !RdFlush_3_i && glueToSCAL_IValid_cond_all_3_i && RdInStageValid_3_s;
//Logic - SCALInputOutputStrategy (RdIValid_FUSED_BNE_3)(133)
assign core_RdIValid_FUSED_BNE_3_o = RdIValid_FUSED_BNE_3_s;
//Logic - PipeliningRdIValidStrategy(RdIValid_FUSED_BLT_3)(259)
always@(posedge clk_i) begin
    if (rst_i)
        RdIValid_FUSED_BLT_3_regpipein <= 0;
    else if (!((RdStall_2_i)) && core_RdPipeInto_stage_executesv1_2_i)
        RdIValid_FUSED_BLT_3_regpipein <= ((RdFlush_2_i)) ? 0 : RdIValid_FUSED_BLT_2_s;
    else if (!((RdStall_3_i)))
        RdIValid_FUSED_BLT_3_regpipein <= 0;
    else if ((RdFlush_3_i))
        RdIValid_FUSED_BLT_3_regpipein <= 0;
end
assign RdIValid_FUSED_BLT_3_s = RdIValid_FUSED_BLT_3_regpipein && !RdFlush_3_i && glueToSCAL_IValid_cond_all_3_i && RdInStageValid_3_s;
//Logic - SCALInputOutputStrategy (RdIValid_FUSED_BLT_3)(134)
assign core_RdIValid_FUSED_BLT_3_o = RdIValid_FUSED_BLT_3_s;
//Logic - PipeliningRdIValidStrategy(RdIValid_FUSED_BLTU_3)(267)
always@(posedge clk_i) begin
    if (rst_i)
        RdIValid_FUSED_BLTU_3_regpipein <= 0;
    else if (!((RdStall_2_i)) && core_RdPipeInto_stage_executesv1_2_i)
        RdIValid_FUSED_BLTU_3_regpipein <= ((RdFlush_2_i)) ? 0 : RdIValid_FUSED_BLTU_2_s;
    else if (!((RdStall_3_i)))
        RdIValid_FUSED_BLTU_3_regpipein <= 0;
    else if ((RdFlush_3_i))
        RdIValid_FUSED_BLTU_3_regpipein <= 0;
end
assign RdIValid_FUSED_BLTU_3_s = RdIValid_FUSED_BLTU_3_regpipein && !RdFlush_3_i && glueToSCAL_IValid_cond_all_3_i && RdInStageValid_3_s;
//Logic - SCALInputOutputStrategy (RdIValid_FUSED_BLTU_3)(135)
assign core_RdIValid_FUSED_BLTU_3_o = RdIValid_FUSED_BLTU_3_s;
//Logic - PipeliningRdIValidStrategy(RdIValid_FUSED_BEQ_3)(275)
always@(posedge clk_i) begin
    if (rst_i)
        RdIValid_FUSED_BEQ_3_regpipein <= 0;
    else if (!((RdStall_2_i)) && core_RdPipeInto_stage_executesv1_2_i)
        RdIValid_FUSED_BEQ_3_regpipein <= ((RdFlush_2_i)) ? 0 : RdIValid_FUSED_BEQ_2_s;
    else if (!((RdStall_3_i)))
        RdIValid_FUSED_BEQ_3_regpipein <= 0;
    else if ((RdFlush_3_i))
        RdIValid_FUSED_BEQ_3_regpipein <= 0;
end
assign RdIValid_FUSED_BEQ_3_s = RdIValid_FUSED_BEQ_3_regpipein && !RdFlush_3_i && glueToSCAL_IValid_cond_all_3_i && RdInStageValid_3_s;
//Logic - SCALInputOutputStrategy (RdIValid_FUSED_BEQ_3)(136)
assign core_RdIValid_FUSED_BEQ_3_o = RdIValid_FUSED_BEQ_3_s;
//Logic - PipeliningRdIValidStrategy(RdIValid_FUSED_BGE_3)(283)
always@(posedge clk_i) begin
    if (rst_i)
        RdIValid_FUSED_BGE_3_regpipein <= 0;
    else if (!((RdStall_2_i)) && core_RdPipeInto_stage_executesv1_2_i)
        RdIValid_FUSED_BGE_3_regpipein <= ((RdFlush_2_i)) ? 0 : RdIValid_FUSED_BGE_2_s;
    else if (!((RdStall_3_i)))
        RdIValid_FUSED_BGE_3_regpipein <= 0;
    else if ((RdFlush_3_i))
        RdIValid_FUSED_BGE_3_regpipein <= 0;
end
assign RdIValid_FUSED_BGE_3_s = RdIValid_FUSED_BGE_3_regpipein && !RdFlush_3_i && glueToSCAL_IValid_cond_all_3_i && RdInStageValid_3_s;
//Logic - SCALInputOutputStrategy (RdIValid_FUSED_BGE_3)(137)
assign core_RdIValid_FUSED_BGE_3_o = RdIValid_FUSED_BGE_3_s;


endmodule





