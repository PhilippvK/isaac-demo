create_clock -period 50 -waveform {0 25} clk20
create_clock -period 50 -waveform {0 25} clk20_raw
create_clock -period 10 -waveform {0 5} clk_input
create_clock -period 50 -waveform {0 25} dut.VexRiscv_inst.IBusSimplePlugin_rspJoin_rspBuffer_c.clk
