 
  package vexriscv.plugin
  import vexriscv._
  import spinal.core._
  import spinal.lib._
  import scala.collection.mutable.ArrayBuffer
  import scala.collection.mutable
  import scala.collection.JavaConverters._

object DEMO {
    object IS_ISAX extends Stageable(Bool)
}
class DEMO(writeRfInMemoryStage: Boolean = false)extends Plugin[VexRiscv] {
    import DEMO._
    
    // Setup phase.
    override def setup(pipeline: VexRiscv): Unit = {
    import pipeline._
        import pipeline.config._
        val decoderService = pipeline.service(classOf[DecoderService])
        decoderService.addDefault(IS_ISAX, False)
        
        
    }
    
    // Build phase.
    override def build(pipeline: VexRiscv): Unit = {
        import pipeline._
        import pipeline.config._
    }
}
