 
  package vexriscv.plugin
  import vexriscv._
  import spinal.core._
  import spinal.lib._
  import scala.collection.mutable.ArrayBuffer
  import scala.collection.mutable
  import scala.collection.JavaConverters._

object DEMO {
    object IS_ISAX extends Stageable(Bool)
}
class DEMO(writeRfInMemoryStage: Boolean = false)extends Plugin[VexRiscv] {
    import DEMO._
    var jumpInterface_2: Flow[UInt] = null
    
    // Setup phase.
    override def setup(pipeline: VexRiscv): Unit = {
    import pipeline._
        import pipeline.config._
        val decoderService = pipeline.service(classOf[DecoderService])
        decoderService.addDefault(IS_ISAX, False)
        
                decoderService.add(
                    key = M"-----------------010-----0001011",
                    List(
                        IS_ISAX                  -> True,
                        SRC1_CTRL                -> Src1CtrlEnum.RS,
                        SRC2_CTRL                -> Src2CtrlEnum.RS,
                        REGFILE_WRITE_VALID      -> False,
                        RS1_USE                  -> True,
                        RS2_USE                  -> True
                    )
                )
        
                decoderService.add(
                    key = M"-----------------101-----0001011",
                    List(
                        IS_ISAX                  -> True,
                        SRC1_CTRL                -> Src1CtrlEnum.RS,
                        SRC2_CTRL                -> Src2CtrlEnum.RS,
                        REGFILE_WRITE_VALID      -> False,
                        RS1_USE                  -> True,
                        RS2_USE                  -> True
                    )
                )
        
                decoderService.add(
                    key = M"-----------------110-----0001011",
                    List(
                        IS_ISAX                  -> True,
                        SRC1_CTRL                -> Src1CtrlEnum.RS,
                        SRC2_CTRL                -> Src2CtrlEnum.RS,
                        REGFILE_WRITE_VALID      -> False,
                        RS1_USE                  -> True,
                        RS2_USE                  -> True
                    )
                )
        
                decoderService.add(
                    key = M"-----------------001-----0001011",
                    List(
                        IS_ISAX                  -> True,
                        SRC1_CTRL                -> Src1CtrlEnum.RS,
                        SRC2_CTRL                -> Src2CtrlEnum.RS,
                        REGFILE_WRITE_VALID      -> False,
                        RS1_USE                  -> True,
                        RS2_USE                  -> True
                    )
                )
        
                decoderService.add(
                    key = M"-----------------000-----0001011",
                    List(
                        IS_ISAX                  -> True,
                        SRC1_CTRL                -> Src1CtrlEnum.RS,
                        SRC2_CTRL                -> Src2CtrlEnum.RS,
                        REGFILE_WRITE_VALID      -> False,
                        RS1_USE                  -> True,
                        RS2_USE                  -> True
                    )
                )
        
                decoderService.add(
                    key = M"-----------------100-----0001011",
                    List(
                        IS_ISAX                  -> True,
                        SRC1_CTRL                -> Src1CtrlEnum.RS,
                        SRC2_CTRL                -> Src2CtrlEnum.RS,
                        REGFILE_WRITE_VALID      -> False,
                        RS1_USE                  -> True,
                        RS2_USE                  -> True
                    )
                )
        
        val flushStage_2 = if (memory != null) memory else execute
        val pcManagerService_2 = pipeline.service(classOf[JumpService])
        jumpInterface_2 = pcManagerService_2.createJumpInterface(flushStage_2)
        
    }
    
    // Build phase.
    override def build(pipeline: VexRiscv): Unit = {
        import pipeline._
        import pipeline.config._
         
        decode plug new Area {
        import decode._
            val io = new Bundle {
                val RdFlush_1_o = out Bool()
                RdFlush_1_o.setName("RdFlush_1_o")
                val RdStall_1_o = out Bool()
                RdStall_1_o.setName("RdStall_1_o")
                val RdInstr_1_o = out Bits(32 bits)
                RdInstr_1_o.setName("RdInstr_1_o")
                val WrFlush_1_i = in Bool()
                WrFlush_1_i.setName("WrFlush_1_i")
                val RdInStageValid_1_o = out Bool()
                RdInStageValid_1_o.setName("RdInStageValid_1_o")
                
            }
            io.RdFlush_1_o := decode.arbitration.isFlushedNonSV;
            io.RdStall_1_o := decode.arbitration.isStuck || (!decode.arbitration.isValid);
            io.RdInstr_1_o := decode.input(INSTRUCTION);
            when(io.WrFlush_1_i) {
                decode.arbitration.flushItSV := True;
            }
            io.RdInStageValid_1_o := decode.arbitration.isValid;
            
            
            
            
        }
         
        execute plug new Area {
        import execute._
            val io = new Bundle {
                val RdFlush_2_o = out Bool()
                RdFlush_2_o.setName("RdFlush_2_o")
                val RdPC_2_o = out UInt(32 bits)
                RdPC_2_o.setName("RdPC_2_o")
                val RdStall_2_o = out Bool()
                RdStall_2_o.setName("RdStall_2_o")
                val RdInstr_2_o = out Bits(32 bits)
                RdInstr_2_o.setName("RdInstr_2_o")
                val WrPC_2_i = in UInt(32 bits)
                WrPC_2_i.setName("WrPC_2_i")
                val WrPC_validReq_2_i = in Bool()
                WrPC_validReq_2_i.setName("WrPC_validReq_2_i")
                val WrFlush_2_i = in Bool()
                WrFlush_2_i.setName("WrFlush_2_i")
                val RdInStageValid_2_o = out Bool()
                RdInStageValid_2_o.setName("RdInStageValid_2_o")
                val RdRS1_2_o = out Bits(32 bits)
                RdRS1_2_o.setName("RdRS1_2_o")
                val RdRS2_2_o = out Bits(32 bits)
                RdRS2_2_o.setName("RdRS2_2_o")
                
            }
            io.RdFlush_2_o := execute.arbitration.isFlushedNonSV;
            io.RdPC_2_o := execute.input(PC);
            io.RdStall_2_o := execute.arbitration.isStuck || (!execute.arbitration.isValid);
            io.RdInstr_2_o := execute.input(INSTRUCTION);
            jumpInterface_2.payload := io.WrPC_2_i;
            io.RdInStageValid_2_o := execute.arbitration.isValid;
            io.RdRS1_2_o := execute.input(RS1);
            io.RdRS2_2_o := execute.input(RS2);
            jumpInterface_2.valid := io.WrPC_validReq_2_i && !arbitration.isStuckByOthers
            arbitration.flushNext setWhen (jumpInterface_2.valid);
            
            
            
        }
         
        memory plug new Area {
        import memory._
            val io = new Bundle {
                val RdFlush_3_o = out Bool()
                RdFlush_3_o.setName("RdFlush_3_o")
                val RdStall_3_o = out Bool()
                RdStall_3_o.setName("RdStall_3_o")
                val WrFlush_3_i = in Bool()
                WrFlush_3_i.setName("WrFlush_3_i")
                val RdInStageValid_3_o = out Bool()
                RdInStageValid_3_o.setName("RdInStageValid_3_o")
                
            }
            io.RdFlush_3_o := memory.arbitration.isFlushedNonSV;
            io.RdStall_3_o := memory.arbitration.isStuck || (!memory.arbitration.isValid);
            io.RdInStageValid_3_o := memory.arbitration.isValid;
            
            
            
            
        }
    }
}
