module top( 
	input         		clk,
    input         		rst,
	input               debug_bus_cmd_valid,
	output reg          debug_bus_cmd_ready,
	input               debug_bus_cmd_payload_wr,
	input      [7:0]    debug_bus_cmd_payload_address,
	input      [31:0]   debug_bus_cmd_payload_data,
	output reg [31:0]   debug_bus_rsp_data,
	output              debug_resetOut,
	input               timerInterrupt,
	input               externalInterrupt,
	input               softwareInterrupt,
	output     [31:0]   iBusAhbLite3_HADDR,
	output              iBusAhbLite3_HWRITE,
	output     [2:0]    iBusAhbLite3_HSIZE,
	output     [2:0]    iBusAhbLite3_HBURST,
	output     [3:0]    iBusAhbLite3_HPROT,
	output     [1:0]    iBusAhbLite3_HTRANS,
	output              iBusAhbLite3_HMASTLOCK,
	output     [31:0]   iBusAhbLite3_HWDATA,
	input      [31:0]   iBusAhbLite3_HRDATA,
	input               iBusAhbLite3_HREADY,
	input               iBusAhbLite3_HRESP,
	output     [31:0]   dBusAhbLite3_HADDR,
	output              dBusAhbLite3_HWRITE,
	output     [2:0]    dBusAhbLite3_HSIZE,
	output     [2:0]    dBusAhbLite3_HBURST,
	output     [3:0]    dBusAhbLite3_HPROT,
	output reg [1:0]    dBusAhbLite3_HTRANS,
	output              dBusAhbLite3_HMASTLOCK,
	output     [31:0]   dBusAhbLite3_HWDATA,
	input      [31:0]   dBusAhbLite3_HRDATA,
	input               dBusAhbLite3_HREADY,
	input               dBusAhbLite3_HRESP, 
	input				debugReset);

    wire core_RdInStageValid_1_to_scal;
    wire [32-1:0] core_RdInstr_2_to_scal;
    wire core_WrFlush_1_from_scal;
    wire core_RdInStageValid_3_to_scal;
    wire [32-1:0] core_RdRS1_2_to_scal;
    wire core_RdStall_1_to_scal;
    wire core_WrPC_validReq_2_from_scal;
    wire core_RdStall_3_to_scal;
    wire core_RdFlush_2_to_scal;
    wire core_RdFlush_3_to_scal;
    wire [32-1:0] core_RdRS2_2_to_scal;
    wire [32-1:0] core_RdInstr_1_to_scal;
    wire core_RdInStageValid_2_to_scal;
    wire [32-1:0] core_WrPC_2_from_scal;
    wire core_RdStall_2_to_scal;
    wire [32-1:0] core_RdPC_2_to_scal;
    wire core_RdFlush_1_to_scal;
    
    VexRiscv VexRiscv_inst(
        .debug_bus_cmd_valid(debug_bus_cmd_valid),
        .debug_bus_cmd_ready(debug_bus_cmd_ready),
        .debug_bus_cmd_payload_wr(debug_bus_cmd_payload_wr),
        .debug_bus_cmd_payload_address(debug_bus_cmd_payload_address),
        .debug_bus_cmd_payload_data(debug_bus_cmd_payload_data),
        .debug_bus_rsp_data(debug_bus_rsp_data),
        .debug_resetOut(debug_resetOut),
        .timerInterrupt(timerInterrupt),
        .externalInterrupt(externalInterrupt),
        .softwareInterrupt(softwareInterrupt),

        .iBusAhbLite3_HADDR        (iBusAhbLite3_HADDR     ),
        .iBusAhbLite3_HWRITE       (iBusAhbLite3_HWRITE    ),
        .iBusAhbLite3_HSIZE        (iBusAhbLite3_HSIZE     ),
        .iBusAhbLite3_HBURST       (iBusAhbLite3_HBURST    ),
        .iBusAhbLite3_HPROT        (iBusAhbLite3_HPROT     ),
        .iBusAhbLite3_HTRANS       (iBusAhbLite3_HTRANS    ),
        .iBusAhbLite3_HMASTLOCK    (iBusAhbLite3_HMASTLOCK ),
        .iBusAhbLite3_HWDATA       (iBusAhbLite3_HWDATA    ),
        .iBusAhbLite3_HRDATA       (iBusAhbLite3_HRDATA    ),
        .iBusAhbLite3_HREADY       (iBusAhbLite3_HREADY    ),
        .iBusAhbLite3_HRESP        (iBusAhbLite3_HRESP     ),
        .dBusAhbLite3_HADDR        (dBusAhbLite3_HADDR     ),
        .dBusAhbLite3_HWRITE       (dBusAhbLite3_HWRITE    ),
        .dBusAhbLite3_HSIZE        (dBusAhbLite3_HSIZE     ),
        .dBusAhbLite3_HBURST       (dBusAhbLite3_HBURST    ),
        .dBusAhbLite3_HPROT        (dBusAhbLite3_HPROT     ),
        .dBusAhbLite3_HTRANS       (dBusAhbLite3_HTRANS    ),
        .dBusAhbLite3_HMASTLOCK    (dBusAhbLite3_HMASTLOCK ),
        .dBusAhbLite3_HWDATA       (dBusAhbLite3_HWDATA    ),
        .dBusAhbLite3_HRDATA       (dBusAhbLite3_HRDATA    ),
        .dBusAhbLite3_HREADY       (dBusAhbLite3_HREADY    ),
        .dBusAhbLite3_HRESP        (dBusAhbLite3_HRESP     ),
        .clk                       (clk),
        .reset                     (rst),
        .debugReset                (debugReset)
        ,.RdInStageValid_1_o(core_RdInStageValid_1_to_scal)
        ,.RdInstr_2_o(core_RdInstr_2_to_scal)
        ,.WrFlush_1_i(core_WrFlush_1_from_scal)
        ,.RdInStageValid_3_o(core_RdInStageValid_3_to_scal)
        ,.RdRS1_2_o(core_RdRS1_2_to_scal)
        ,.RdStall_1_o(core_RdStall_1_to_scal)
        ,.WrPC_validReq_2_i(core_WrPC_validReq_2_from_scal)
        ,.RdStall_3_o(core_RdStall_3_to_scal)
        ,.RdFlush_2_o(core_RdFlush_2_to_scal)
        ,.RdFlush_3_o(core_RdFlush_3_to_scal)
        ,.RdRS2_2_o(core_RdRS2_2_to_scal)
        ,.RdInstr_1_o(core_RdInstr_1_to_scal)
        ,.RdInStageValid_2_o(core_RdInStageValid_2_to_scal)
        ,.WrPC_2_i(core_WrPC_2_from_scal)
        ,.RdStall_2_o(core_RdStall_2_to_scal)
        ,.RdPC_2_o(core_RdPC_2_to_scal)
        ,.RdFlush_1_o(core_RdFlush_1_to_scal)
    );

    wire [32-1:0] isax_RdRS1_2_from_scal;
    wire isax_RdStall_FUSED_BGE_2_from_scal;
    wire isax_WrPC_validReq_FUSED_BLTU_2_to_scal;
    wire isax_RdIValid_FUSED_BEQ_2_from_scal;
    wire [32-1:0] isax_RdPC_2_from_scal;
    wire isax_RdIValid_FUSED_BGEU_1_from_scal;
    wire isax_RdStall_FUSED_BLTU_2_from_scal;
    wire [32-1:0] isax_RdInstr_2_from_scal;
    wire isax_RdIValid_FUSED_BNE_2_from_scal;
    wire [32-1:0] isax_RdRS2_2_from_scal;
    wire isax_RdIValid_FUSED_BGE_3_from_scal;
    wire isax_WrPC_validReq_FUSED_BGE_2_to_scal;
    wire [32-1:0] isax_WrPC_FUSED_BGE_2_to_scal;
    wire isax_RdIValid_FUSED_BGE_2_from_scal;
    wire [32-1:0] isax_WrPC_FUSED_BLTU_2_to_scal;
    wire isax_RdStall_FUSED_BGE_3_from_scal;
    wire isax_RdIValid_FUSED_BEQ_1_from_scal;
    wire [32-1:0] isax_WrPC_FUSED_BNE_2_to_scal;
    wire isax_RdIValid_FUSED_BLTU_1_from_scal;
    wire isax_RdStall_FUSED_BGEU_3_from_scal;
    wire isax_WrPC_validReq_FUSED_BGEU_2_to_scal;
    wire isax_RdStall_FUSED_BNE_3_from_scal;
    wire isax_RdIValid_FUSED_BLT_1_from_scal;
    wire isax_RdStall_FUSED_BGEU_2_from_scal;
    wire isax_RdIValid_FUSED_BGE_1_from_scal;
    wire isax_RdIValid_FUSED_BNE_3_from_scal;
    wire [32-1:0] isax_WrPC_FUSED_BGEU_2_to_scal;
    wire isax_WrPC_validReq_FUSED_BLT_2_to_scal;
    wire isax_WrPC_validReq_FUSED_BNE_2_to_scal;
    wire isax_RdStall_FUSED_BEQ_3_from_scal;
    wire [32-1:0] isax_WrPC_FUSED_BLT_2_to_scal;
    wire isax_RdIValid_FUSED_BLTU_2_from_scal;
    wire isax_RdIValid_FUSED_BLT_2_from_scal;
    wire isax_RdStall_FUSED_BLT_2_from_scal;
    wire isax_RdStall_FUSED_BNE_2_from_scal;
    wire isax_RdIValid_FUSED_BGEU_3_from_scal;
    wire isax_RdIValid_FUSED_BEQ_3_from_scal;
    wire isax_RdIValid_FUSED_BLT_3_from_scal;
    wire isax_RdStall_FUSED_BEQ_2_from_scal;
    wire isax_RdStall_FUSED_BLTU_3_from_scal;
    wire isax_RdIValid_FUSED_BGEU_2_from_scal;
    wire isax_RdStall_FUSED_BLT_3_from_scal;
    wire isax_RdIValid_FUSED_BNE_1_from_scal;
    wire [32-1:0] isax_WrPC_FUSED_BEQ_2_to_scal;
    wire isax_RdIValid_FUSED_BLTU_3_from_scal;
    wire isax_WrPC_validReq_FUSED_BEQ_2_to_scal;
    
    SCAL scal (
        .clk_i(clk)
        ,.rst_i(rst)
        ,.RdRS1_2_o(isax_RdRS1_2_from_scal)
        ,.RdStall_FUSED_BGE_2_o(isax_RdStall_FUSED_BGE_2_from_scal)
        ,.RdInStageValid_1_i(core_RdInStageValid_1_to_scal)
        ,.WrPC_validReq_FUSED_BLTU_2_i(isax_WrPC_validReq_FUSED_BLTU_2_to_scal)
        ,.RdInstr_2_i(core_RdInstr_2_to_scal)
        ,.RdIValid_FUSED_BEQ_2_o(isax_RdIValid_FUSED_BEQ_2_from_scal)
        ,.RdPC_2_o(isax_RdPC_2_from_scal)
        ,.RdIValid_FUSED_BGEU_1_o(isax_RdIValid_FUSED_BGEU_1_from_scal)
        ,.RdStall_FUSED_BLTU_2_o(isax_RdStall_FUSED_BLTU_2_from_scal)
        ,.RdInstr_2_o(isax_RdInstr_2_from_scal)
        ,.RdIValid_FUSED_BNE_2_o(isax_RdIValid_FUSED_BNE_2_from_scal)
        ,.RdRS2_2_o(isax_RdRS2_2_from_scal)
        ,.RdIValid_FUSED_BGE_3_o(isax_RdIValid_FUSED_BGE_3_from_scal)
        ,.WrPC_validReq_FUSED_BGE_2_i(isax_WrPC_validReq_FUSED_BGE_2_to_scal)
        ,.WrFlush_1_o(core_WrFlush_1_from_scal)
        ,.WrPC_FUSED_BGE_2_i(isax_WrPC_FUSED_BGE_2_to_scal)
        ,.RdInStageValid_3_i(core_RdInStageValid_3_to_scal)
        ,.RdIValid_FUSED_BGE_2_o(isax_RdIValid_FUSED_BGE_2_from_scal)
        ,.RdRS1_2_i(core_RdRS1_2_to_scal)
        ,.RdStall_1_i(core_RdStall_1_to_scal)
        ,.WrPC_FUSED_BLTU_2_i(isax_WrPC_FUSED_BLTU_2_to_scal)
        ,.RdStall_FUSED_BGE_3_o(isax_RdStall_FUSED_BGE_3_from_scal)
        ,.RdIValid_FUSED_BEQ_1_o(isax_RdIValid_FUSED_BEQ_1_from_scal)
        ,.WrPC_FUSED_BNE_2_i(isax_WrPC_FUSED_BNE_2_to_scal)
        ,.WrPC_validReq_2_o(core_WrPC_validReq_2_from_scal)
        ,.RdIValid_FUSED_BLTU_1_o(isax_RdIValid_FUSED_BLTU_1_from_scal)
        ,.RdStall_3_i(core_RdStall_3_to_scal)
        ,.RdStall_FUSED_BGEU_3_o(isax_RdStall_FUSED_BGEU_3_from_scal)
        ,.RdFlush_2_i(core_RdFlush_2_to_scal)
        ,.WrPC_validReq_FUSED_BGEU_2_i(isax_WrPC_validReq_FUSED_BGEU_2_to_scal)
        ,.RdStall_FUSED_BNE_3_o(isax_RdStall_FUSED_BNE_3_from_scal)
        ,.RdIValid_FUSED_BLT_1_o(isax_RdIValid_FUSED_BLT_1_from_scal)
        ,.RdStall_FUSED_BGEU_2_o(isax_RdStall_FUSED_BGEU_2_from_scal)
        ,.RdIValid_FUSED_BGE_1_o(isax_RdIValid_FUSED_BGE_1_from_scal)
        ,.RdIValid_FUSED_BNE_3_o(isax_RdIValid_FUSED_BNE_3_from_scal)
        ,.WrPC_FUSED_BGEU_2_i(isax_WrPC_FUSED_BGEU_2_to_scal)
        ,.RdFlush_3_i(core_RdFlush_3_to_scal)
        ,.RdRS2_2_i(core_RdRS2_2_to_scal)
        ,.WrPC_validReq_FUSED_BLT_2_i(isax_WrPC_validReq_FUSED_BLT_2_to_scal)
        ,.WrPC_validReq_FUSED_BNE_2_i(isax_WrPC_validReq_FUSED_BNE_2_to_scal)
        ,.RdStall_FUSED_BEQ_3_o(isax_RdStall_FUSED_BEQ_3_from_scal)
        ,.RdInstr_1_i(core_RdInstr_1_to_scal)
        ,.WrPC_FUSED_BLT_2_i(isax_WrPC_FUSED_BLT_2_to_scal)
        ,.RdIValid_FUSED_BLTU_2_o(isax_RdIValid_FUSED_BLTU_2_from_scal)
        ,.RdIValid_FUSED_BLT_2_o(isax_RdIValid_FUSED_BLT_2_from_scal)
        ,.RdStall_FUSED_BLT_2_o(isax_RdStall_FUSED_BLT_2_from_scal)
        ,.RdStall_FUSED_BNE_2_o(isax_RdStall_FUSED_BNE_2_from_scal)
        ,.RdInStageValid_2_i(core_RdInStageValid_2_to_scal)
        ,.RdIValid_FUSED_BGEU_3_o(isax_RdIValid_FUSED_BGEU_3_from_scal)
        ,.WrPC_2_o(core_WrPC_2_from_scal)
        ,.RdIValid_FUSED_BEQ_3_o(isax_RdIValid_FUSED_BEQ_3_from_scal)
        ,.RdIValid_FUSED_BLT_3_o(isax_RdIValid_FUSED_BLT_3_from_scal)
        ,.RdStall_FUSED_BEQ_2_o(isax_RdStall_FUSED_BEQ_2_from_scal)
        ,.RdStall_FUSED_BLTU_3_o(isax_RdStall_FUSED_BLTU_3_from_scal)
        ,.RdStall_2_i(core_RdStall_2_to_scal)
        ,.RdPC_2_i(core_RdPC_2_to_scal)
        ,.RdIValid_FUSED_BGEU_2_o(isax_RdIValid_FUSED_BGEU_2_from_scal)
        ,.RdStall_FUSED_BLT_3_o(isax_RdStall_FUSED_BLT_3_from_scal)
        ,.RdIValid_FUSED_BNE_1_o(isax_RdIValid_FUSED_BNE_1_from_scal)
        ,.WrPC_FUSED_BEQ_2_i(isax_WrPC_FUSED_BEQ_2_to_scal)
        ,.RdIValid_FUSED_BLTU_3_o(isax_RdIValid_FUSED_BLTU_3_from_scal)
        ,.WrPC_validReq_FUSED_BEQ_2_i(isax_WrPC_validReq_FUSED_BEQ_2_to_scal)
        ,.RdFlush_1_i(core_RdFlush_1_to_scal)
    );
    
    ISAX_XBranch isax_xbranch (
        .clk_i(clk)
        ,.rst_i(rst)
        ,.RdRS1_FUSED_BGE_2_i(isax_RdRS1_2_from_scal)
        ,.RdStall_FUSED_BGE_2_i(isax_RdStall_FUSED_BGE_2_from_scal)
        ,.WrPC_validReq_FUSED_BLTU_2_o(isax_WrPC_validReq_FUSED_BLTU_2_to_scal)
        ,.RdIValid_FUSED_BEQ_2_i(isax_RdIValid_FUSED_BEQ_2_from_scal)
        ,.RdPC_FUSED_BLT_2_i(isax_RdPC_2_from_scal)
        ,.RdIValid_FUSED_BGEU_1_i(isax_RdIValid_FUSED_BGEU_1_from_scal)
        ,.RdStall_FUSED_BLTU_2_i(isax_RdStall_FUSED_BLTU_2_from_scal)
        ,.RdInstr_FUSED_BNE_2_i(isax_RdInstr_2_from_scal)
        ,.RdIValid_FUSED_BNE_2_i(isax_RdIValid_FUSED_BNE_2_from_scal)
        ,.RdInstr_FUSED_BEQ_2_i(isax_RdInstr_2_from_scal)
        ,.RdRS2_FUSED_BNE_2_i(isax_RdRS2_2_from_scal)
        ,.RdIValid_FUSED_BGE_3_i(isax_RdIValid_FUSED_BGE_3_from_scal)
        ,.WrPC_validReq_FUSED_BGE_2_o(isax_WrPC_validReq_FUSED_BGE_2_to_scal)
        ,.WrPC_FUSED_BGE_2_o(isax_WrPC_FUSED_BGE_2_to_scal)
        ,.RdIValid_FUSED_BGE_2_i(isax_RdIValid_FUSED_BGE_2_from_scal)
        ,.RdPC_FUSED_BGEU_2_i(isax_RdPC_2_from_scal)
        ,.WrPC_FUSED_BLTU_2_o(isax_WrPC_FUSED_BLTU_2_to_scal)
        ,.RdStall_FUSED_BGE_3_i(isax_RdStall_FUSED_BGE_3_from_scal)
        ,.RdIValid_FUSED_BEQ_1_i(isax_RdIValid_FUSED_BEQ_1_from_scal)
        ,.WrPC_FUSED_BNE_2_o(isax_WrPC_FUSED_BNE_2_to_scal)
        ,.RdIValid_FUSED_BLTU_1_i(isax_RdIValid_FUSED_BLTU_1_from_scal)
        ,.RdRS2_FUSED_BEQ_2_i(isax_RdRS2_2_from_scal)
        ,.RdStall_FUSED_BGEU_3_i(isax_RdStall_FUSED_BGEU_3_from_scal)
        ,.RdRS2_FUSED_BGEU_2_i(isax_RdRS2_2_from_scal)
        ,.RdPC_FUSED_BGE_2_i(isax_RdPC_2_from_scal)
        ,.WrPC_validReq_FUSED_BGEU_2_o(isax_WrPC_validReq_FUSED_BGEU_2_to_scal)
        ,.RdRS1_FUSED_BLT_2_i(isax_RdRS1_2_from_scal)
        ,.RdStall_FUSED_BNE_3_i(isax_RdStall_FUSED_BNE_3_from_scal)
        ,.RdIValid_FUSED_BLT_1_i(isax_RdIValid_FUSED_BLT_1_from_scal)
        ,.RdRS2_FUSED_BLTU_2_i(isax_RdRS2_2_from_scal)
        ,.RdStall_FUSED_BGEU_2_i(isax_RdStall_FUSED_BGEU_2_from_scal)
        ,.RdIValid_FUSED_BGE_1_i(isax_RdIValid_FUSED_BGE_1_from_scal)
        ,.RdIValid_FUSED_BNE_3_i(isax_RdIValid_FUSED_BNE_3_from_scal)
        ,.WrPC_FUSED_BGEU_2_o(isax_WrPC_FUSED_BGEU_2_to_scal)
        ,.WrPC_validReq_FUSED_BLT_2_o(isax_WrPC_validReq_FUSED_BLT_2_to_scal)
        ,.RdPC_FUSED_BLTU_2_i(isax_RdPC_2_from_scal)
        ,.RdRS2_FUSED_BLT_2_i(isax_RdRS2_2_from_scal)
        ,.WrPC_validReq_FUSED_BNE_2_o(isax_WrPC_validReq_FUSED_BNE_2_to_scal)
        ,.RdRS1_FUSED_BGEU_2_i(isax_RdRS1_2_from_scal)
        ,.RdStall_FUSED_BEQ_3_i(isax_RdStall_FUSED_BEQ_3_from_scal)
        ,.RdInstr_FUSED_BGE_2_i(isax_RdInstr_2_from_scal)
        ,.WrPC_FUSED_BLT_2_o(isax_WrPC_FUSED_BLT_2_to_scal)
        ,.RdInstr_FUSED_BLTU_2_i(isax_RdInstr_2_from_scal)
        ,.RdIValid_FUSED_BLTU_2_i(isax_RdIValid_FUSED_BLTU_2_from_scal)
        ,.RdIValid_FUSED_BLT_2_i(isax_RdIValid_FUSED_BLT_2_from_scal)
        ,.RdStall_FUSED_BLT_2_i(isax_RdStall_FUSED_BLT_2_from_scal)
        ,.RdStall_FUSED_BNE_2_i(isax_RdStall_FUSED_BNE_2_from_scal)
        ,.RdRS1_FUSED_BEQ_2_i(isax_RdRS1_2_from_scal)
        ,.RdPC_FUSED_BNE_2_i(isax_RdPC_2_from_scal)
        ,.RdIValid_FUSED_BGEU_3_i(isax_RdIValid_FUSED_BGEU_3_from_scal)
        ,.RdInstr_FUSED_BGEU_2_i(isax_RdInstr_2_from_scal)
        ,.RdIValid_FUSED_BEQ_3_i(isax_RdIValid_FUSED_BEQ_3_from_scal)
        ,.RdRS1_FUSED_BLTU_2_i(isax_RdRS1_2_from_scal)
        ,.RdIValid_FUSED_BLT_3_i(isax_RdIValid_FUSED_BLT_3_from_scal)
        ,.RdPC_FUSED_BEQ_2_i(isax_RdPC_2_from_scal)
        ,.RdInstr_FUSED_BLT_2_i(isax_RdInstr_2_from_scal)
        ,.RdStall_FUSED_BEQ_2_i(isax_RdStall_FUSED_BEQ_2_from_scal)
        ,.RdStall_FUSED_BLTU_3_i(isax_RdStall_FUSED_BLTU_3_from_scal)
        ,.RdRS1_FUSED_BNE_2_i(isax_RdRS1_2_from_scal)
        ,.RdRS2_FUSED_BGE_2_i(isax_RdRS2_2_from_scal)
        ,.RdIValid_FUSED_BGEU_2_i(isax_RdIValid_FUSED_BGEU_2_from_scal)
        ,.RdStall_FUSED_BLT_3_i(isax_RdStall_FUSED_BLT_3_from_scal)
        ,.RdIValid_FUSED_BNE_1_i(isax_RdIValid_FUSED_BNE_1_from_scal)
        ,.WrPC_FUSED_BEQ_2_o(isax_WrPC_FUSED_BEQ_2_to_scal)
        ,.RdIValid_FUSED_BLTU_3_i(isax_RdIValid_FUSED_BLTU_3_from_scal)
        ,.WrPC_validReq_FUSED_BEQ_2_o(isax_WrPC_validReq_FUSED_BEQ_2_to_scal)
    );

    	
endmodule
