 
  package vexriscv.plugin
  import vexriscv._
  import spinal.core._
  import spinal.lib._
  import scala.collection.mutable.ArrayBuffer
  import scala.collection.mutable
  import scala.collection.JavaConverters._

object DEMO {
    object IS_ISAX extends Stageable(Bool)
}
class DEMO(writeRfInMemoryStage: Boolean = false)extends Plugin[VexRiscv] {
    import DEMO._
    var dBusAccess : DBusAccess = null
    
    // Setup phase.
    override def setup(pipeline: VexRiscv): Unit = {
    import pipeline._
        import pipeline.config._
        val decoderService = pipeline.service(classOf[DecoderService])
        decoderService.addDefault(IS_ISAX, False)
        
                decoderService.add(
                    key = M"0000000----------010-----0101011",
                    List(
                        IS_ISAX                  -> True,
                        SRC1_CTRL                -> Src1CtrlEnum.RS,
                        SRC2_CTRL                -> Src2CtrlEnum.RS,
                        REGFILE_WRITE_VALID      -> False,
                        RS1_USE                  -> True,
                        RS2_USE                  -> True
                    )
                )
        
                decoderService.add(
                    key = M"0000000----------001-----0101011",
                    List(
                        IS_ISAX                  -> True,
                        SRC1_CTRL                -> Src1CtrlEnum.RS,
                        SRC2_CTRL                -> Src2CtrlEnum.RS,
                        REGFILE_WRITE_VALID      -> False,
                        RS1_USE                  -> True,
                        RS2_USE                  -> True
                    )
                )
        
                decoderService.add(
                    key = M"0000000----------000-----0101011",
                    List(
                        IS_ISAX                  -> True,
                        SRC1_CTRL                -> Src1CtrlEnum.RS,
                        SRC2_CTRL                -> Src2CtrlEnum.RS,
                        REGFILE_WRITE_VALID      -> False,
                        RS1_USE                  -> True,
                        RS2_USE                  -> True
                    )
                )
        
        // Get service for memory transfers
        dBusAccess = pipeline.service(classOf[DBusAccessService]).newDBusAccess();
        
    }
    
    // Build phase.
    override def build(pipeline: VexRiscv): Unit = {
        import pipeline._
        import pipeline.config._
         
        decode plug new Area {
        import decode._
            val io = new Bundle {
                val RdFlush_1_o = out Bool()
                RdFlush_1_o.setName("RdFlush_1_o")
                val RdStall_1_o = out Bool()
                RdStall_1_o.setName("RdStall_1_o")
                val RdInstr_1_o = out Bits(32 bits)
                RdInstr_1_o.setName("RdInstr_1_o")
                val RdInStageValid_1_o = out Bool()
                RdInStageValid_1_o.setName("RdInStageValid_1_o")
                
            }
            io.RdFlush_1_o := decode.arbitration.isFlushedNonSV;
            io.RdStall_1_o := decode.arbitration.isStuck || (!decode.arbitration.isValid);
            io.RdInstr_1_o := decode.input(INSTRUCTION);
            io.RdInStageValid_1_o := decode.arbitration.isValid;
            
            
            
            
        }
         
        execute plug new Area {
        import execute._
            val io = new Bundle {
                val RdFlush_2_o = out Bool()
                RdFlush_2_o.setName("RdFlush_2_o")
                val WrMem_2_i = in Bits(32 bits)
                WrMem_2_i.setName("WrMem_2_i")
                val WrMem_validReq_2_i = in Bool()
                WrMem_validReq_2_i.setName("WrMem_validReq_2_i")
                val WrMem_addr_2_i = in UInt(32 bits)
                WrMem_addr_2_i.setName("WrMem_addr_2_i")
                val WrMem_addr_valid_2_i = in Bool()
                WrMem_addr_valid_2_i.setName("WrMem_addr_valid_2_i")
                val WrMem_size_2_i = in UInt(3 bits)
                WrMem_size_2_i.setName("WrMem_size_2_i")
                val RdStall_2_o = out Bool()
                RdStall_2_o.setName("RdStall_2_o")
                val RdInstr_2_o = out Bits(32 bits)
                RdInstr_2_o.setName("RdInstr_2_o")
                val RdInStageValid_2_o = out Bool()
                RdInStageValid_2_o.setName("RdInStageValid_2_o")
                val RdRS1_2_o = out Bits(32 bits)
                RdRS1_2_o.setName("RdRS1_2_o")
                val RdRS2_2_o = out Bits(32 bits)
                RdRS2_2_o.setName("RdRS2_2_o")
                val WrMem_validReq_1_i = in Bool()
                WrMem_validReq_1_i.setName("WrMem_validReq_1_i")
                
            }
            io.RdFlush_2_o := execute.arbitration.isFlushedNonSV;
            io.RdStall_2_o := execute.arbitration.isStuck || (!execute.arbitration.isValid);
            io.RdInstr_2_o := execute.input(INSTRUCTION);
            io.RdInStageValid_2_o := execute.arbitration.isValid;
            io.RdRS1_2_o := execute.input(RS1);
            io.RdRS2_2_o := execute.input(RS2);
            
            
            
            
                        val State = new SpinalEnum{
                            val IDLE, CMD  = newElement()
                        }
                        val state = RegInit(State.IDLE)
                        
            	                      // Define some default values for memory FSM
                        dBusAccess.cmd.valid := False
                        dBusAccess.cmd.write := False
                        dBusAccess.cmd.size := 0 
                        dBusAccess.cmd.address.assignDontCare() 
                        dBusAccess.cmd.data.assignDontCare() 
                        dBusAccess.cmd.writeMask.assignDontCare()
                        
                        val ldst_in_decode = Bool()		    
                        when(state !==  State.IDLE) {
                            when(ldst_in_decode) {
                                decode.arbitration.haltItself := True;
                            }
                        }
                        ldst_in_decode := ((io.WrMem_validReq_1_i) && decode.input(IS_ISAX))
                        switch(state){
                            is(State.IDLE){
                                when(ldst_in_decode && decode.arbitration.isFiring ) { 
                                    state := State.CMD
                                }
                            }
                            is(State.CMD){
                                when(~(io.WrMem_validReq_2_i)) {
                                        state := State.IDLE
                                }.otherwise {
                                 when(execute.arbitration.isValid ) {
                                    dBusAccess.cmd.valid   := True 
                                    dBusAccess.cmd.size    := execute.input(INSTRUCTION)(13 downto 12).asUInt	
            
                                    when(io.WrMem_validReq_2_i) {
                                        dBusAccess.cmd.data := dBusAccess.cmd.size.mux(
                                            U(0) -> (io.WrMem_2_i(7 downto 0) ## io.WrMem_2_i(7 downto 0) ## io.WrMem_2_i(7 downto 0) ## io.WrMem_2_i(7 downto 0)),
                                            U(1) -> (io.WrMem_2_i(15 downto 0) ## io.WrMem_2_i(15 downto 0)),
                                            default -> io.WrMem_2_i
                                        )
                                    }
            
                                    dBusAccess.cmd.write   := io.WrMem_validReq_2_i
                                    dBusAccess.cmd.address := execute.input(SRC_ADD).asUInt  
            			               when(io.WrMem_addr_valid_2_i) { // set to 0 if no ISAX needs it and removed by synth tool 
            			                  dBusAccess.cmd.address := io.WrMem_addr_2_i
            			               }
                                    when(dBusAccess.cmd.ready) {// Next state 
                                        when (io.WrMem_validReq_2_i) {
                                            state := State.IDLE
                                        }
            
            
                                    }.otherwise {
                                        execute.arbitration.haltItself := True
                                    }
                                 }
                                }
                            }
                        }
            
        }
    }
}
