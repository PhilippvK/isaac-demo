module top( 
	input         		clk,
    input         		rst,
	input               debug_bus_cmd_valid,
	output reg          debug_bus_cmd_ready,
	input               debug_bus_cmd_payload_wr,
	input      [7:0]    debug_bus_cmd_payload_address,
	input      [31:0]   debug_bus_cmd_payload_data,
	output reg [31:0]   debug_bus_rsp_data,
	output              debug_resetOut,
	input               timerInterrupt,
	input               externalInterrupt,
	input               softwareInterrupt,
	output     [31:0]   iBusAhbLite3_HADDR,
	output              iBusAhbLite3_HWRITE,
	output     [2:0]    iBusAhbLite3_HSIZE,
	output     [2:0]    iBusAhbLite3_HBURST,
	output     [3:0]    iBusAhbLite3_HPROT,
	output     [1:0]    iBusAhbLite3_HTRANS,
	output              iBusAhbLite3_HMASTLOCK,
	output     [31:0]   iBusAhbLite3_HWDATA,
	input      [31:0]   iBusAhbLite3_HRDATA,
	input               iBusAhbLite3_HREADY,
	input               iBusAhbLite3_HRESP,
	output     [31:0]   dBusAhbLite3_HADDR,
	output              dBusAhbLite3_HWRITE,
	output     [2:0]    dBusAhbLite3_HSIZE,
	output     [2:0]    dBusAhbLite3_HBURST,
	output     [3:0]    dBusAhbLite3_HPROT,
	output reg [1:0]    dBusAhbLite3_HTRANS,
	output              dBusAhbLite3_HMASTLOCK,
	output     [31:0]   dBusAhbLite3_HWDATA,
	input      [31:0]   dBusAhbLite3_HRDATA,
	input               dBusAhbLite3_HREADY,
	input               dBusAhbLite3_HRESP, 
	input				debugReset);

    wire [3-1:0] core_WrMem_size_2_from_scal;
    wire [32-1:0] core_RdRS2_2_to_scal;
    wire core_RdInStageValid_1_to_scal;
    wire core_WrMem_addr_valid_2_from_scal;
    wire [32-1:0] core_WrMem_2_from_scal;
    wire [32-1:0] core_RdInstr_2_to_scal;
    wire [32-1:0] core_RdInstr_1_to_scal;
    wire core_WrMem_validReq_1_from_scal;
    wire core_RdInStageValid_2_to_scal;
    wire [32-1:0] core_RdRS1_2_to_scal;
    wire core_RdStall_1_to_scal;
    wire core_RdStall_2_to_scal;
    wire [32-1:0] core_WrMem_addr_2_from_scal;
    wire core_WrMem_validReq_2_from_scal;
    wire core_RdFlush_2_to_scal;
    wire core_RdFlush_1_to_scal;
    
    VexRiscv VexRiscv_inst(
        .debug_bus_cmd_valid(debug_bus_cmd_valid),
        .debug_bus_cmd_ready(debug_bus_cmd_ready),
        .debug_bus_cmd_payload_wr(debug_bus_cmd_payload_wr),
        .debug_bus_cmd_payload_address(debug_bus_cmd_payload_address),
        .debug_bus_cmd_payload_data(debug_bus_cmd_payload_data),
        .debug_bus_rsp_data(debug_bus_rsp_data),
        .debug_resetOut(debug_resetOut),
        .timerInterrupt(timerInterrupt),
        .externalInterrupt(externalInterrupt),
        .softwareInterrupt(softwareInterrupt),

        .iBusAhbLite3_HADDR        (iBusAhbLite3_HADDR     ),
        .iBusAhbLite3_HWRITE       (iBusAhbLite3_HWRITE    ),
        .iBusAhbLite3_HSIZE        (iBusAhbLite3_HSIZE     ),
        .iBusAhbLite3_HBURST       (iBusAhbLite3_HBURST    ),
        .iBusAhbLite3_HPROT        (iBusAhbLite3_HPROT     ),
        .iBusAhbLite3_HTRANS       (iBusAhbLite3_HTRANS    ),
        .iBusAhbLite3_HMASTLOCK    (iBusAhbLite3_HMASTLOCK ),
        .iBusAhbLite3_HWDATA       (iBusAhbLite3_HWDATA    ),
        .iBusAhbLite3_HRDATA       (iBusAhbLite3_HRDATA    ),
        .iBusAhbLite3_HREADY       (iBusAhbLite3_HREADY    ),
        .iBusAhbLite3_HRESP        (iBusAhbLite3_HRESP     ),
        .dBusAhbLite3_HADDR        (dBusAhbLite3_HADDR     ),
        .dBusAhbLite3_HWRITE       (dBusAhbLite3_HWRITE    ),
        .dBusAhbLite3_HSIZE        (dBusAhbLite3_HSIZE     ),
        .dBusAhbLite3_HBURST       (dBusAhbLite3_HBURST    ),
        .dBusAhbLite3_HPROT        (dBusAhbLite3_HPROT     ),
        .dBusAhbLite3_HTRANS       (dBusAhbLite3_HTRANS    ),
        .dBusAhbLite3_HMASTLOCK    (dBusAhbLite3_HMASTLOCK ),
        .dBusAhbLite3_HWDATA       (dBusAhbLite3_HWDATA    ),
        .dBusAhbLite3_HRDATA       (dBusAhbLite3_HRDATA    ),
        .dBusAhbLite3_HREADY       (dBusAhbLite3_HREADY    ),
        .dBusAhbLite3_HRESP        (dBusAhbLite3_HRESP     ),
        .clk                       (clk),
        .reset                     (rst),
        .debugReset                (debugReset)
        ,.WrMem_size_2_i(core_WrMem_size_2_from_scal)
        ,.RdRS2_2_o(core_RdRS2_2_to_scal)
        ,.RdInStageValid_1_o(core_RdInStageValid_1_to_scal)
        ,.WrMem_addr_valid_2_i(core_WrMem_addr_valid_2_from_scal)
        ,.WrMem_2_i(core_WrMem_2_from_scal)
        ,.RdInstr_2_o(core_RdInstr_2_to_scal)
        ,.RdInstr_1_o(core_RdInstr_1_to_scal)
        ,.WrMem_validReq_1_i(core_WrMem_validReq_1_from_scal)
        ,.RdInStageValid_2_o(core_RdInStageValid_2_to_scal)
        ,.RdRS1_2_o(core_RdRS1_2_to_scal)
        ,.RdStall_1_o(core_RdStall_1_to_scal)
        ,.RdStall_2_o(core_RdStall_2_to_scal)
        ,.WrMem_addr_2_i(core_WrMem_addr_2_from_scal)
        ,.WrMem_validReq_2_i(core_WrMem_validReq_2_from_scal)
        ,.RdFlush_2_o(core_RdFlush_2_to_scal)
        ,.RdFlush_1_o(core_RdFlush_1_to_scal)
    );

    wire isax_WrMem_validReq_STORE_XOR_SH_2_to_scal;
    wire [32-1:0] isax_RdRS2_2_from_scal;
    wire [32-1:0] isax_RdRS1_2_from_scal;
    wire [32-1:0] isax_WrMem_STORE_XOR_SB_2_to_scal;
    wire isax_RdIValid_STORE_XOR_SW_2_from_scal;
    wire [32-1:0] isax_WrMem_STORE_XOR_SW_2_to_scal;
    wire isax_RdStall_STORE_XOR_SW_2_from_scal;
    wire isax_RdStall_STORE_XOR_SB_2_from_scal;
    wire isax_WrMem_validReq_STORE_XOR_SB_2_to_scal;
    wire [32-1:0] isax_WrMem_addr_STORE_XOR_SB_2_to_scal;
    wire [32-1:0] isax_WrMem_STORE_XOR_SH_2_to_scal;
    wire isax_RdIValid_STORE_XOR_SH_2_from_scal;
    wire isax_RdStall_STORE_XOR_SH_2_from_scal;
    wire [32-1:0] isax_WrMem_addr_STORE_XOR_SW_2_to_scal;
    wire isax_WrMem_validReq_STORE_XOR_SW_2_to_scal;
    wire isax_RdIValid_STORE_XOR_SB_2_from_scal;
    wire [32-1:0] isax_WrMem_addr_STORE_XOR_SH_2_to_scal;
    
    SCAL scal (
        .clk_i(clk)
        ,.rst_i(rst)
        ,.WrMem_validReq_STORE_XOR_SH_2_i(isax_WrMem_validReq_STORE_XOR_SH_2_to_scal)
        ,.RdRS2_2_o(isax_RdRS2_2_from_scal)
        ,.WrMem_size_2_o(core_WrMem_size_2_from_scal)
        ,.RdRS1_2_o(isax_RdRS1_2_from_scal)
        ,.RdRS2_2_i(core_RdRS2_2_to_scal)
        ,.WrMem_STORE_XOR_SB_2_i(isax_WrMem_STORE_XOR_SB_2_to_scal)
        ,.RdInStageValid_1_i(core_RdInStageValid_1_to_scal)
        ,.WrMem_addr_valid_2_o(core_WrMem_addr_valid_2_from_scal)
        ,.WrMem_2_o(core_WrMem_2_from_scal)
        ,.RdInstr_2_i(core_RdInstr_2_to_scal)
        ,.RdIValid_STORE_XOR_SW_2_o(isax_RdIValid_STORE_XOR_SW_2_from_scal)
        ,.WrMem_STORE_XOR_SW_2_i(isax_WrMem_STORE_XOR_SW_2_to_scal)
        ,.RdStall_STORE_XOR_SW_2_o(isax_RdStall_STORE_XOR_SW_2_from_scal)
        ,.RdInstr_1_i(core_RdInstr_1_to_scal)
        ,.RdStall_STORE_XOR_SB_2_o(isax_RdStall_STORE_XOR_SB_2_from_scal)
        ,.WrMem_validReq_1_o(core_WrMem_validReq_1_from_scal)
        ,.WrMem_validReq_STORE_XOR_SB_2_i(isax_WrMem_validReq_STORE_XOR_SB_2_to_scal)
        ,.RdInStageValid_2_i(core_RdInStageValid_2_to_scal)
        ,.WrMem_addr_STORE_XOR_SB_2_i(isax_WrMem_addr_STORE_XOR_SB_2_to_scal)
        ,.RdRS1_2_i(core_RdRS1_2_to_scal)
        ,.RdStall_1_i(core_RdStall_1_to_scal)
        ,.WrMem_STORE_XOR_SH_2_i(isax_WrMem_STORE_XOR_SH_2_to_scal)
        ,.RdIValid_STORE_XOR_SH_2_o(isax_RdIValid_STORE_XOR_SH_2_from_scal)
        ,.RdStall_2_i(core_RdStall_2_to_scal)
        ,.RdStall_STORE_XOR_SH_2_o(isax_RdStall_STORE_XOR_SH_2_from_scal)
        ,.WrMem_addr_2_o(core_WrMem_addr_2_from_scal)
        ,.WrMem_addr_STORE_XOR_SW_2_i(isax_WrMem_addr_STORE_XOR_SW_2_to_scal)
        ,.WrMem_validReq_2_o(core_WrMem_validReq_2_from_scal)
        ,.WrMem_validReq_STORE_XOR_SW_2_i(isax_WrMem_validReq_STORE_XOR_SW_2_to_scal)
        ,.RdFlush_2_i(core_RdFlush_2_to_scal)
        ,.RdIValid_STORE_XOR_SB_2_o(isax_RdIValid_STORE_XOR_SB_2_from_scal)
        ,.WrMem_addr_STORE_XOR_SH_2_i(isax_WrMem_addr_STORE_XOR_SH_2_to_scal)
        ,.RdFlush_1_i(core_RdFlush_1_to_scal)
    );
    
    ISAX_XStoreProbe isax_xstoreprobe (
        .clk_i(clk)
        ,.rst_i(rst)
        ,.WrMem_validReq_STORE_XOR_SH_2_o(isax_WrMem_validReq_STORE_XOR_SH_2_to_scal)
        ,.RdRS2_STORE_XOR_SH_2_i(isax_RdRS2_2_from_scal)
        ,.RdRS1_STORE_XOR_SH_2_i(isax_RdRS1_2_from_scal)
        ,.WrMem_STORE_XOR_SB_2_o(isax_WrMem_STORE_XOR_SB_2_to_scal)
        ,.RdIValid_STORE_XOR_SW_2_i(isax_RdIValid_STORE_XOR_SW_2_from_scal)
        ,.WrMem_STORE_XOR_SW_2_o(isax_WrMem_STORE_XOR_SW_2_to_scal)
        ,.RdStall_STORE_XOR_SW_2_i(isax_RdStall_STORE_XOR_SW_2_from_scal)
        ,.RdStall_STORE_XOR_SB_2_i(isax_RdStall_STORE_XOR_SB_2_from_scal)
        ,.WrMem_validReq_STORE_XOR_SB_2_o(isax_WrMem_validReq_STORE_XOR_SB_2_to_scal)
        ,.RdRS1_STORE_XOR_SB_2_i(isax_RdRS1_2_from_scal)
        ,.RdRS2_STORE_XOR_SB_2_i(isax_RdRS2_2_from_scal)
        ,.WrMem_addr_STORE_XOR_SB_2_o(isax_WrMem_addr_STORE_XOR_SB_2_to_scal)
        ,.WrMem_STORE_XOR_SH_2_o(isax_WrMem_STORE_XOR_SH_2_to_scal)
        ,.RdIValid_STORE_XOR_SH_2_i(isax_RdIValid_STORE_XOR_SH_2_from_scal)
        ,.RdStall_STORE_XOR_SH_2_i(isax_RdStall_STORE_XOR_SH_2_from_scal)
        ,.RdRS2_STORE_XOR_SW_2_i(isax_RdRS2_2_from_scal)
        ,.WrMem_addr_STORE_XOR_SW_2_o(isax_WrMem_addr_STORE_XOR_SW_2_to_scal)
        ,.RdRS1_STORE_XOR_SW_2_i(isax_RdRS1_2_from_scal)
        ,.WrMem_validReq_STORE_XOR_SW_2_o(isax_WrMem_validReq_STORE_XOR_SW_2_to_scal)
        ,.RdIValid_STORE_XOR_SB_2_i(isax_RdIValid_STORE_XOR_SB_2_from_scal)
        ,.WrMem_addr_STORE_XOR_SH_2_o(isax_WrMem_addr_STORE_XOR_SH_2_to_scal)
    );

    	
endmodule
