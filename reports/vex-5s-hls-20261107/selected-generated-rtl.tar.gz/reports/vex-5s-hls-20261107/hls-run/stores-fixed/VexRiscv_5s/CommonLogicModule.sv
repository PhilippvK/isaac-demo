 

// SystemVerilog file 
 
module SCAL (
    // Interface to the ISAX Module
    
    input [32 -1 : 0] WrMem_STORE_XOR_SW_2_i,// ISAX
    input  WrMem_validReq_STORE_XOR_SW_2_i,// ISAX
    input [32 -1 : 0] WrMem_addr_STORE_XOR_SW_2_i,// ISAX
    input [32 -1 : 0] WrMem_STORE_XOR_SH_2_i,// ISAX
    input  WrMem_validReq_STORE_XOR_SH_2_i,// ISAX
    input [32 -1 : 0] WrMem_addr_STORE_XOR_SH_2_i,// ISAX
    input [32 -1 : 0] WrMem_STORE_XOR_SB_2_i,// ISAX
    input  WrMem_validReq_STORE_XOR_SB_2_i,// ISAX
    input [32 -1 : 0] WrMem_addr_STORE_XOR_SB_2_i,// ISAX
    output  RdStall_STORE_XOR_SW_2_o,// ISAX
    output  RdStall_STORE_XOR_SH_2_o,// ISAX
    output  RdStall_STORE_XOR_SB_2_o,// ISAX
    output [32 -1 : 0] RdRS1_2_o,// ISAX
    output [32 -1 : 0] RdRS2_2_o,// ISAX
    output  RdIValid_STORE_XOR_SW_2_o,// ISAX
    output  RdIValid_STORE_XOR_SH_2_o,// ISAX
    output  RdIValid_STORE_XOR_SB_2_o,// ISAX

    
    // Interface to the Core
    
    input  RdInStageValid_1_i,// ISAX
    input  RdFlush_1_i,// ISAX
    input [32 -1 : 0] RdInstr_1_i,// ISAX
    output  WrMem_validReq_1_o,// ISAX
    input  RdInStageValid_2_i,// ISAX
    input  RdFlush_2_i,// ISAX
    input  RdStall_2_i,// ISAX
    input  RdStall_1_i,// ISAX
    output [32 -1 : 0] WrMem_2_o,// ISAX
    output  WrMem_validReq_2_o,// ISAX
    output [32 -1 : 0] WrMem_addr_2_o,// ISAX
    output  WrMem_addr_valid_2_o,// ISAX
    input [32 -1 : 0] RdInstr_2_i,// ISAX
    output [3 -1 : 0] WrMem_size_2_o,// ISAX
    input [32 -1 : 0] RdRS1_2_i,// ISAX
    input [32 -1 : 0] RdRS2_2_i,// ISAX
    
    input clk_i,
    input rst_i

    
);
// Declare local signals
//Declarations - RdInStageValidStrategy_RdInStageValid_1(140)
wire RdInStageValid_1_s;
//Declarations - PipeliningRdIValidStrategy(RdIValid_STORE_XOR_SW_1)(120)
wire RdIValid_STORE_XOR_SW_1_s;
//Declarations - PipeliningRdIValidStrategy(RdIValid_STORE_XOR_SH_1)(112)
wire RdIValid_STORE_XOR_SH_1_s;
//Declarations - PipeliningRdIValidStrategy(RdIValid_STORE_XOR_SB_1)(104)
wire RdIValid_STORE_XOR_SB_1_s;
//Declarations - EarlyValidStrategy (WrMem_validReq_1)(86)
reg WrMem_validReq_1_reg;
//Declarations - RdInStageValidStrategy_RdInStageValid_2(122)
wire RdInStageValid_2_s;
//Declarations - PipeliningRdIValidStrategy(RdIValid_STORE_XOR_SH_2)(71)
reg  RdIValid_STORE_XOR_SH_2_regpipein;
wire RdIValid_STORE_XOR_SH_2_s;
//Declarations - PipeliningRdIValidStrategy(RdIValid_STORE_XOR_SW_2)(63)
reg  RdIValid_STORE_XOR_SW_2_regpipein;
wire RdIValid_STORE_XOR_SW_2_s;
//Declarations - PipeliningRdIValidStrategy(RdIValid_STORE_XOR_SB_2)(79)
reg  RdIValid_STORE_XOR_SB_2_regpipein;
wire RdIValid_STORE_XOR_SB_2_s;
//Declarations - ValidMuxStrategy (WrMem_2)(88)
reg [ 32 -1 : 0 ] WrMem_2_s;
//Declarations - ValidMuxStrategy (WrMem_validReq_2)(128)
reg  WrMem_validReq_2_s;
//Declarations - EarlyValidStrategy (WrMem_validReq_2)(87)
reg WrMem_validReq_2_reg;
//Declarations - ValidMuxStrategy (WrMem_addr_2)(89)
reg [ 32 -1 : 0 ] WrMem_addr_2_s;
//Declarations - DefaultValidCancelReqStrategy_WrMem_addr_valid_STORE_XOR_SH_2(182)
wire WrMem_addr_valid_STORE_XOR_SH_2_default_s;
//Declarations - DefaultValidCancelReqStrategy_WrMem_addr_valid_STORE_XOR_SW_2(181)
wire WrMem_addr_valid_STORE_XOR_SW_2_default_s;
//Declarations - DefaultValidCancelReqStrategy_WrMem_addr_valid_STORE_XOR_SB_2(180)
wire WrMem_addr_valid_STORE_XOR_SB_2_default_s;
//Declarations - ValidMuxStrategy (WrMem_addr_valid_2)(90)
reg  WrMem_addr_valid_2_s;
//Declarations - Triggerable-NodeRegPipelineStrategy||Direct (WrMem_size_2)(179)
wire [3-1:0] WrMem_size_2_default;
//Declarations - ValidMuxStrategy (WrMem_size_2)(91)
reg [ 3 -1 : 0 ] WrMem_size_2_s;
//Declarations - StallFlushDeqStrategy (RdStall_STORE_XOR_SW_2)(81)
wire RdStall_STORE_XOR_SW_2_s;
//Declarations - StallFlushDeqStrategy (RdStall_STORE_XOR_SH_2)(83)
wire RdStall_STORE_XOR_SH_2_s;
//Declarations - StallFlushDeqStrategy (RdStall_STORE_XOR_SB_2)(85)
wire RdStall_STORE_XOR_SB_2_s;


// Logic
//Logic - RdInStageValidStrategy_RdInStageValid_1(140)
assign RdInStageValid_1_s = RdInStageValid_1_i;
//Logic - PipeliningRdIValidStrategy(RdIValid_STORE_XOR_SW_1)(120)
assign RdIValid_STORE_XOR_SW_1_s = ((RdInstr_1_i[6 : 0] == 7'b0101011) && (RdInstr_1_i[14 : 12] == 3'b010) && (RdInstr_1_i[31 : 25] == 7'b0000000)) && !RdFlush_1_i && RdInStageValid_1_s;
//Logic - PipeliningRdIValidStrategy(RdIValid_STORE_XOR_SH_1)(112)
assign RdIValid_STORE_XOR_SH_1_s = ((RdInstr_1_i[6 : 0] == 7'b0101011) && (RdInstr_1_i[14 : 12] == 3'b001) && (RdInstr_1_i[31 : 25] == 7'b0000000)) && !RdFlush_1_i && RdInStageValid_1_s;
//Logic - PipeliningRdIValidStrategy(RdIValid_STORE_XOR_SB_1)(104)
assign RdIValid_STORE_XOR_SB_1_s = ((RdInstr_1_i[6 : 0] == 7'b0101011) && (RdInstr_1_i[14 : 12] == 3'b000) && (RdInstr_1_i[31 : 25] == 7'b0000000)) && !RdFlush_1_i && RdInStageValid_1_s;
//Logic - EarlyValidStrategy (WrMem_validReq_1)(86)
always_comb begin 
    case(1'b1)
        RdIValid_STORE_XOR_SW_1_s : WrMem_validReq_1_reg = 1'b1;
        RdIValid_STORE_XOR_SH_1_s : WrMem_validReq_1_reg = 1'b1;
        RdIValid_STORE_XOR_SB_1_s : WrMem_validReq_1_reg = 1'b1;
        default : WrMem_validReq_1_reg = 1'b0;
    endcase
end
//Logic - SCALInputOutputStrategy (WrMem_validReq_1)(30)
assign WrMem_validReq_1_o = WrMem_validReq_1_reg;
//Logic - RdInStageValidStrategy_RdInStageValid_2(122)
assign RdInStageValid_2_s = RdInStageValid_2_i;
//Logic - PipeliningRdIValidStrategy(RdIValid_STORE_XOR_SH_2)(71)
always@(posedge clk_i) begin
    if (rst_i)
        RdIValid_STORE_XOR_SH_2_regpipein <= 0;
    else if (!((RdStall_1_i)))
        RdIValid_STORE_XOR_SH_2_regpipein <= ((RdFlush_1_i)) ? 0 : RdIValid_STORE_XOR_SH_1_s;
    else if (!((RdStall_2_i)))
        RdIValid_STORE_XOR_SH_2_regpipein <= 0;
    else if ((RdFlush_2_i))
        RdIValid_STORE_XOR_SH_2_regpipein <= 0;
end
assign RdIValid_STORE_XOR_SH_2_s = RdIValid_STORE_XOR_SH_2_regpipein && !RdFlush_2_i && RdInStageValid_2_s;
//Logic - PipeliningRdIValidStrategy(RdIValid_STORE_XOR_SW_2)(63)
always@(posedge clk_i) begin
    if (rst_i)
        RdIValid_STORE_XOR_SW_2_regpipein <= 0;
    else if (!((RdStall_1_i)))
        RdIValid_STORE_XOR_SW_2_regpipein <= ((RdFlush_1_i)) ? 0 : RdIValid_STORE_XOR_SW_1_s;
    else if (!((RdStall_2_i)))
        RdIValid_STORE_XOR_SW_2_regpipein <= 0;
    else if ((RdFlush_2_i))
        RdIValid_STORE_XOR_SW_2_regpipein <= 0;
end
assign RdIValid_STORE_XOR_SW_2_s = RdIValid_STORE_XOR_SW_2_regpipein && !RdFlush_2_i && RdInStageValid_2_s;
//Logic - PipeliningRdIValidStrategy(RdIValid_STORE_XOR_SB_2)(79)
always@(posedge clk_i) begin
    if (rst_i)
        RdIValid_STORE_XOR_SB_2_regpipein <= 0;
    else if (!((RdStall_1_i)))
        RdIValid_STORE_XOR_SB_2_regpipein <= ((RdFlush_1_i)) ? 0 : RdIValid_STORE_XOR_SB_1_s;
    else if (!((RdStall_2_i)))
        RdIValid_STORE_XOR_SB_2_regpipein <= 0;
    else if ((RdFlush_2_i))
        RdIValid_STORE_XOR_SB_2_regpipein <= 0;
end
assign RdIValid_STORE_XOR_SB_2_s = RdIValid_STORE_XOR_SB_2_regpipein && !RdFlush_2_i && RdInStageValid_2_s;
//Logic - ValidMuxStrategy (WrMem_2)(88)
always_comb begin 
    case(1'b1)
        RdIValid_STORE_XOR_SW_2_s: WrMem_2_s = WrMem_STORE_XOR_SW_2_i;
        RdIValid_STORE_XOR_SH_2_s: WrMem_2_s = WrMem_STORE_XOR_SH_2_i;
        default: WrMem_2_s = WrMem_STORE_XOR_SB_2_i;
    endcase
end
//Logic - SCALInputOutputStrategy (WrMem_2)(40)
assign WrMem_2_o = WrMem_2_s;
//Logic - ValidMuxStrategy (WrMem_validReq_2)(128)
always_comb begin 
    case(1'b1)
        RdIValid_STORE_XOR_SW_2_s: WrMem_validReq_2_s = WrMem_validReq_STORE_XOR_SW_2_i;
        RdIValid_STORE_XOR_SH_2_s: WrMem_validReq_2_s = WrMem_validReq_STORE_XOR_SH_2_i;
        RdIValid_STORE_XOR_SB_2_s: WrMem_validReq_2_s = WrMem_validReq_STORE_XOR_SB_2_i;
        default: WrMem_validReq_2_s = 0;
    endcase
end
//Logic - EarlyValidStrategy (WrMem_validReq_2)(87)
always_comb begin 
    case(1'b1)
        default : WrMem_validReq_2_reg = WrMem_validReq_2_s && !(RdFlush_2_i);
    endcase
end
//Logic - SCALInputOutputStrategy (WrMem_validReq_2)(41)
assign WrMem_validReq_2_o = WrMem_validReq_2_reg;
//Logic - ValidMuxStrategy (WrMem_addr_2)(89)
always_comb begin 
    case(1'b1)
        RdIValid_STORE_XOR_SW_2_s: WrMem_addr_2_s = WrMem_addr_STORE_XOR_SW_2_i;
        RdIValid_STORE_XOR_SH_2_s: WrMem_addr_2_s = WrMem_addr_STORE_XOR_SH_2_i;
        default: WrMem_addr_2_s = WrMem_addr_STORE_XOR_SB_2_i;
    endcase
end
//Logic - SCALInputOutputStrategy (WrMem_addr_2)(42)
assign WrMem_addr_2_o = WrMem_addr_2_s;
//Logic - DefaultValidCancelReqStrategy_WrMem_addr_valid_STORE_XOR_SH_2(182)
assign WrMem_addr_valid_STORE_XOR_SH_2_default_s = WrMem_validReq_STORE_XOR_SH_2_i;
//Logic - DefaultValidCancelReqStrategy_WrMem_addr_valid_STORE_XOR_SW_2(181)
assign WrMem_addr_valid_STORE_XOR_SW_2_default_s = WrMem_validReq_STORE_XOR_SW_2_i;
//Logic - DefaultValidCancelReqStrategy_WrMem_addr_valid_STORE_XOR_SB_2(180)
assign WrMem_addr_valid_STORE_XOR_SB_2_default_s = WrMem_validReq_STORE_XOR_SB_2_i;
//Logic - ValidMuxStrategy (WrMem_addr_valid_2)(90)
always_comb begin 
    case(1'b1)
        RdIValid_STORE_XOR_SW_2_s: WrMem_addr_valid_2_s = WrMem_addr_valid_STORE_XOR_SW_2_default_s;
        RdIValid_STORE_XOR_SH_2_s: WrMem_addr_valid_2_s = WrMem_addr_valid_STORE_XOR_SH_2_default_s;
        RdIValid_STORE_XOR_SB_2_s: WrMem_addr_valid_2_s = WrMem_addr_valid_STORE_XOR_SB_2_default_s;
        default: WrMem_addr_valid_2_s = 0;
    endcase
end
//Logic - SCALInputOutputStrategy (WrMem_addr_valid_2)(43)
assign WrMem_addr_valid_2_o = WrMem_addr_valid_2_s;
//Logic - Triggerable-NodeRegPipelineStrategy||Direct (WrMem_size_2)(179)
assign WrMem_size_2_default = RdInstr_2_i[14:12];
//Logic - ValidMuxStrategy (WrMem_size_2)(91)
always_comb begin 
    case(1'b1)
        default: WrMem_size_2_s = WrMem_size_2_default;
    endcase
end
//Logic - SCALInputOutputStrategy (WrMem_size_2)(44)
assign WrMem_size_2_o = WrMem_size_2_s;
//Logic - StallFlushDeqStrategy (RdStall_STORE_XOR_SW_2)(81)
assign RdStall_STORE_XOR_SW_2_s = (RdStall_2_i);
//Logic - SCALInputOutputStrategy (RdStall_STORE_XOR_SW_2)(45)
assign RdStall_STORE_XOR_SW_2_o = RdStall_STORE_XOR_SW_2_s;
//Logic - StallFlushDeqStrategy (RdStall_STORE_XOR_SH_2)(83)
assign RdStall_STORE_XOR_SH_2_s = (RdStall_2_i);
//Logic - SCALInputOutputStrategy (RdStall_STORE_XOR_SH_2)(46)
assign RdStall_STORE_XOR_SH_2_o = RdStall_STORE_XOR_SH_2_s;
//Logic - StallFlushDeqStrategy (RdStall_STORE_XOR_SB_2)(85)
assign RdStall_STORE_XOR_SB_2_s = (RdStall_2_i);
//Logic - SCALInputOutputStrategy (RdStall_STORE_XOR_SB_2)(47)
assign RdStall_STORE_XOR_SB_2_o = RdStall_STORE_XOR_SB_2_s;
//Logic - SCALInputOutputStrategy (RdRS1_2)(49)
assign RdRS1_2_o = RdRS1_2_i;
//Logic - SCALInputOutputStrategy (RdRS2_2)(51)
assign RdRS2_2_o = RdRS2_2_i;
//Logic - SCALInputOutputStrategy (RdIValid_STORE_XOR_SW_2)(53)
assign RdIValid_STORE_XOR_SW_2_o = RdIValid_STORE_XOR_SW_2_s;
//Logic - SCALInputOutputStrategy (RdIValid_STORE_XOR_SH_2)(54)
assign RdIValid_STORE_XOR_SH_2_o = RdIValid_STORE_XOR_SH_2_s;
//Logic - SCALInputOutputStrategy (RdIValid_STORE_XOR_SB_2)(55)
assign RdIValid_STORE_XOR_SB_2_o = RdIValid_STORE_XOR_SB_2_s;


endmodule





