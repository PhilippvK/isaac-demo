 
  package vexriscv.plugin
  import vexriscv._
  import spinal.core._
  import spinal.lib._
  import scala.collection.mutable.ArrayBuffer
  import scala.collection.mutable
  import scala.collection.JavaConverters._

object DEMO {
    object IS_ISAX extends Stageable(Bool)
}
class DEMO(writeRfInMemoryStage: Boolean = false)extends Plugin[VexRiscv] {
    import DEMO._
    var dBusAccess : DBusAccess = null
    
    // Setup phase.
    override def setup(pipeline: VexRiscv): Unit = {
    import pipeline._
        import pipeline.config._
        val decoderService = pipeline.service(classOf[DecoderService])
        decoderService.addDefault(IS_ISAX, False)
        
                decoderService.add(
                    key = M"10---------------100-----0001011",
                    List(
                        IS_ISAX                  -> True,
                        SRC1_CTRL                -> Src1CtrlEnum.RS,
                        SRC2_CTRL                -> Src2CtrlEnum.RS,
                        REGFILE_WRITE_VALID      -> True,
                        RS1_USE                  -> True,
                        RS2_USE                  -> True                ,
                        BYPASSABLE_EXECUTE_STAGE  -> True,
                        BYPASSABLE_MEMORY_STAGE  -> True
                    )
                )
        
                decoderService.add(
                    key = M"011000-----------000-----0001011",
                    List(
                        IS_ISAX                  -> True,
                        SRC1_CTRL                -> Src1CtrlEnum.RS,
                        SRC2_CTRL                -> Src2CtrlEnum.RS,
                        REGFILE_WRITE_VALID      -> True,
                        RS1_USE                  -> True,
                        RS2_USE                  -> True                ,
                        BYPASSABLE_EXECUTE_STAGE  -> True,
                        BYPASSABLE_MEMORY_STAGE  -> True
                    )
                )
        
                decoderService.add(
                    key = M"0111100----------000-----0001011",
                    List(
                        IS_ISAX                  -> True,
                        SRC1_CTRL                -> Src1CtrlEnum.RS,
                        SRC2_CTRL                -> Src2CtrlEnum.RS,
                        REGFILE_WRITE_VALID      -> True,
                        RS1_USE                  -> True,
                        RS2_USE                  -> True                ,
                        BYPASSABLE_EXECUTE_STAGE  -> True,
                        BYPASSABLE_MEMORY_STAGE  -> True
                    )
                )
        
                decoderService.add(
                    key = M"0100000----------010-----0001011",
                    List(
                        IS_ISAX                  -> True,
                        SRC1_CTRL                -> Src1CtrlEnum.RS,
                        SRC2_CTRL                -> Src2CtrlEnum.RS,
                        REGFILE_WRITE_VALID      -> True,
                        RS1_USE                  -> True,
                        RS2_USE                  -> True                ,
                        BYPASSABLE_EXECUTE_STAGE  -> False,
                        BYPASSABLE_MEMORY_STAGE  -> True
                    )
                )
        
                decoderService.add(
                    key = M"1000000----------010-----0001011",
                    List(
                        IS_ISAX                  -> True,
                        SRC1_CTRL                -> Src1CtrlEnum.RS,
                        SRC2_CTRL                -> Src2CtrlEnum.RS,
                        REGFILE_WRITE_VALID      -> True,
                        RS1_USE                  -> True,
                        RS2_USE                  -> True                ,
                        BYPASSABLE_EXECUTE_STAGE  -> False,
                        BYPASSABLE_MEMORY_STAGE  -> True
                    )
                )
        
                decoderService.add(
                    key = M"0011100----------000-----0001011",
                    List(
                        IS_ISAX                  -> True,
                        SRC1_CTRL                -> Src1CtrlEnum.RS,
                        SRC2_CTRL                -> Src2CtrlEnum.RS,
                        REGFILE_WRITE_VALID      -> True,
                        RS1_USE                  -> True,
                        RS2_USE                  -> True                ,
                        BYPASSABLE_EXECUTE_STAGE  -> True,
                        BYPASSABLE_MEMORY_STAGE  -> True
                    )
                )
        
                decoderService.add(
                    key = M"10---------------000-----0001011",
                    List(
                        IS_ISAX                  -> True,
                        SRC1_CTRL                -> Src1CtrlEnum.RS,
                        SRC2_CTRL                -> Src2CtrlEnum.RS,
                        REGFILE_WRITE_VALID      -> True,
                        RS1_USE                  -> True,
                        RS2_USE                  -> True                ,
                        BYPASSABLE_EXECUTE_STAGE  -> True,
                        BYPASSABLE_MEMORY_STAGE  -> True
                    )
                )
        
                decoderService.add(
                    key = M"000000-----------000-----0001011",
                    List(
                        IS_ISAX                  -> True,
                        SRC1_CTRL                -> Src1CtrlEnum.RS,
                        SRC2_CTRL                -> Src2CtrlEnum.RS,
                        REGFILE_WRITE_VALID      -> True,
                        RS1_USE                  -> True,
                        RS2_USE                  -> True                ,
                        BYPASSABLE_EXECUTE_STAGE  -> True,
                        BYPASSABLE_MEMORY_STAGE  -> True
                    )
                )
        
                decoderService.add(
                    key = M"0001100----------000-----0001011",
                    List(
                        IS_ISAX                  -> True,
                        SRC1_CTRL                -> Src1CtrlEnum.RS,
                        SRC2_CTRL                -> Src2CtrlEnum.RS,
                        REGFILE_WRITE_VALID      -> True,
                        RS1_USE                  -> True,
                        RS2_USE                  -> True                ,
                        BYPASSABLE_EXECUTE_STAGE  -> True,
                        BYPASSABLE_MEMORY_STAGE  -> True
                    )
                )
        
                decoderService.add(
                    key = M"0110100----------000-----0001011",
                    List(
                        IS_ISAX                  -> True,
                        SRC1_CTRL                -> Src1CtrlEnum.RS,
                        SRC2_CTRL                -> Src2CtrlEnum.RS,
                        REGFILE_WRITE_VALID      -> True,
                        RS1_USE                  -> True,
                        RS2_USE                  -> True                ,
                        BYPASSABLE_EXECUTE_STAGE  -> True,
                        BYPASSABLE_MEMORY_STAGE  -> True
                    )
                )
        
                decoderService.add(
                    key = M"0000000----------010-----0001011",
                    List(
                        IS_ISAX                  -> True,
                        SRC1_CTRL                -> Src1CtrlEnum.RS,
                        SRC2_CTRL                -> Src2CtrlEnum.RS,
                        REGFILE_WRITE_VALID      -> True,
                        RS1_USE                  -> True,
                        RS2_USE                  -> True                ,
                        BYPASSABLE_EXECUTE_STAGE  -> False,
                        BYPASSABLE_MEMORY_STAGE  -> True
                    )
                )
        
                decoderService.add(
                    key = M"0000010----------000-----0001011",
                    List(
                        IS_ISAX                  -> True,
                        SRC1_CTRL                -> Src1CtrlEnum.RS,
                        SRC2_CTRL                -> Src2CtrlEnum.RS,
                        REGFILE_WRITE_VALID      -> True,
                        RS1_USE                  -> True,
                        RS2_USE                  -> True                ,
                        BYPASSABLE_EXECUTE_STAGE  -> True,
                        BYPASSABLE_MEMORY_STAGE  -> True
                    )
                )
        
                decoderService.add(
                    key = M"0001110----------000-----0001011",
                    List(
                        IS_ISAX                  -> True,
                        SRC1_CTRL                -> Src1CtrlEnum.RS,
                        SRC2_CTRL                -> Src2CtrlEnum.RS,
                        REGFILE_WRITE_VALID      -> True,
                        RS1_USE                  -> True,
                        RS2_USE                  -> False                ,
                        BYPASSABLE_EXECUTE_STAGE  -> True,
                        BYPASSABLE_MEMORY_STAGE  -> True
                    )
                )
        
                decoderService.add(
                    key = M"01---------------100-----0001011",
                    List(
                        IS_ISAX                  -> True,
                        SRC1_CTRL                -> Src1CtrlEnum.RS,
                        SRC2_CTRL                -> Src2CtrlEnum.RS,
                        REGFILE_WRITE_VALID      -> True,
                        RS1_USE                  -> True,
                        RS2_USE                  -> True                ,
                        BYPASSABLE_EXECUTE_STAGE  -> True,
                        BYPASSABLE_MEMORY_STAGE  -> True
                    )
                )
        
                decoderService.add(
                    key = M"00110------------000-----0001011",
                    List(
                        IS_ISAX                  -> True,
                        SRC1_CTRL                -> Src1CtrlEnum.RS,
                        SRC2_CTRL                -> Src2CtrlEnum.RS,
                        REGFILE_WRITE_VALID      -> True,
                        RS1_USE                  -> True,
                        RS2_USE                  -> True                ,
                        BYPASSABLE_EXECUTE_STAGE  -> True,
                        BYPASSABLE_MEMORY_STAGE  -> True
                    )
                )
        
                decoderService.add(
                    key = M"0010000----------010-----0001011",
                    List(
                        IS_ISAX                  -> True,
                        SRC1_CTRL                -> Src1CtrlEnum.RS,
                        SRC2_CTRL                -> Src2CtrlEnum.RS,
                        REGFILE_WRITE_VALID      -> True,
                        RS1_USE                  -> True,
                        RS2_USE                  -> True                ,
                        BYPASSABLE_EXECUTE_STAGE  -> False,
                        BYPASSABLE_MEMORY_STAGE  -> True
                    )
                )
        
                decoderService.add(
                    key = M"00010------------000-----0001011",
                    List(
                        IS_ISAX                  -> True,
                        SRC1_CTRL                -> Src1CtrlEnum.RS,
                        SRC2_CTRL                -> Src2CtrlEnum.RS,
                        REGFILE_WRITE_VALID      -> True,
                        RS1_USE                  -> True,
                        RS2_USE                  -> True                ,
                        BYPASSABLE_EXECUTE_STAGE  -> True,
                        BYPASSABLE_MEMORY_STAGE  -> True
                    )
                )
        
                decoderService.add(
                    key = M"1100000----------010-----0001011",
                    List(
                        IS_ISAX                  -> True,
                        SRC1_CTRL                -> Src1CtrlEnum.RS,
                        SRC2_CTRL                -> Src2CtrlEnum.RS,
                        REGFILE_WRITE_VALID      -> True,
                        RS1_USE                  -> True,
                        RS2_USE                  -> True                ,
                        BYPASSABLE_EXECUTE_STAGE  -> False,
                        BYPASSABLE_MEMORY_STAGE  -> True
                    )
                )
        
                decoderService.add(
                    key = M"0110110----------000-----0001011",
                    List(
                        IS_ISAX                  -> True,
                        SRC1_CTRL                -> Src1CtrlEnum.RS,
                        SRC2_CTRL                -> Src2CtrlEnum.RS,
                        REGFILE_WRITE_VALID      -> True,
                        RS1_USE                  -> True,
                        RS2_USE                  -> True                ,
                        BYPASSABLE_EXECUTE_STAGE  -> True,
                        BYPASSABLE_MEMORY_STAGE  -> True
                    )
                )
        
                decoderService.add(
                    key = M"0010100----------000-----0001011",
                    List(
                        IS_ISAX                  -> True,
                        SRC1_CTRL                -> Src1CtrlEnum.RS,
                        SRC2_CTRL                -> Src2CtrlEnum.RS,
                        REGFILE_WRITE_VALID      -> True,
                        RS1_USE                  -> True,
                        RS2_USE                  -> True                ,
                        BYPASSABLE_EXECUTE_STAGE  -> True,
                        BYPASSABLE_MEMORY_STAGE  -> True
                    )
                )
        
                decoderService.add(
                    key = M"0110010----------000-----0001011",
                    List(
                        IS_ISAX                  -> True,
                        SRC1_CTRL                -> Src1CtrlEnum.RS,
                        SRC2_CTRL                -> Src2CtrlEnum.RS,
                        REGFILE_WRITE_VALID      -> True,
                        RS1_USE                  -> True,
                        RS2_USE                  -> True                ,
                        BYPASSABLE_EXECUTE_STAGE  -> True,
                        BYPASSABLE_MEMORY_STAGE  -> True
                    )
                )
        
                decoderService.add(
                    key = M"010--------------000-----0001011",
                    List(
                        IS_ISAX                  -> True,
                        SRC1_CTRL                -> Src1CtrlEnum.RS,
                        SRC2_CTRL                -> Src2CtrlEnum.RS,
                        REGFILE_WRITE_VALID      -> True,
                        RS1_USE                  -> True,
                        RS2_USE                  -> True                ,
                        BYPASSABLE_EXECUTE_STAGE  -> True,
                        BYPASSABLE_MEMORY_STAGE  -> True
                    )
                )
        
                decoderService.add(
                    key = M"11---------------100-----0001011",
                    List(
                        IS_ISAX                  -> True,
                        SRC1_CTRL                -> Src1CtrlEnum.RS,
                        SRC2_CTRL                -> Src2CtrlEnum.RS,
                        REGFILE_WRITE_VALID      -> True,
                        RS1_USE                  -> True,
                        RS2_USE                  -> True                ,
                        BYPASSABLE_EXECUTE_STAGE  -> True,
                        BYPASSABLE_MEMORY_STAGE  -> True
                    )
                )
        
                decoderService.add(
                    key = M"0010110----------000-----0001011",
                    List(
                        IS_ISAX                  -> True,
                        SRC1_CTRL                -> Src1CtrlEnum.RS,
                        SRC2_CTRL                -> Src2CtrlEnum.RS,
                        REGFILE_WRITE_VALID      -> True,
                        RS1_USE                  -> True,
                        RS2_USE                  -> True                ,
                        BYPASSABLE_EXECUTE_STAGE  -> True,
                        BYPASSABLE_MEMORY_STAGE  -> True
                    )
                )
        
                decoderService.add(
                    key = M"0000110----------000-----0001011",
                    List(
                        IS_ISAX                  -> True,
                        SRC1_CTRL                -> Src1CtrlEnum.RS,
                        SRC2_CTRL                -> Src2CtrlEnum.RS,
                        REGFILE_WRITE_VALID      -> True,
                        RS1_USE                  -> True,
                        RS2_USE                  -> True                ,
                        BYPASSABLE_EXECUTE_STAGE  -> False,
                        BYPASSABLE_MEMORY_STAGE  -> True
                    )
                )
        
                decoderService.add(
                    key = M"0111010----------000-----0001011",
                    List(
                        IS_ISAX                  -> True,
                        SRC1_CTRL                -> Src1CtrlEnum.RS,
                        SRC2_CTRL                -> Src2CtrlEnum.RS,
                        REGFILE_WRITE_VALID      -> True,
                        RS1_USE                  -> True,
                        RS2_USE                  -> True                ,
                        BYPASSABLE_EXECUTE_STAGE  -> True,
                        BYPASSABLE_MEMORY_STAGE  -> True
                    )
                )
        
                decoderService.add(
                    key = M"00---------------100-----0001011",
                    List(
                        IS_ISAX                  -> True,
                        SRC1_CTRL                -> Src1CtrlEnum.RS,
                        SRC2_CTRL                -> Src2CtrlEnum.RS,
                        REGFILE_WRITE_VALID      -> True,
                        RS1_USE                  -> True,
                        RS2_USE                  -> True                ,
                        BYPASSABLE_EXECUTE_STAGE  -> True,
                        BYPASSABLE_MEMORY_STAGE  -> True
                    )
                )
        
                decoderService.add(
                    key = M"00100------------000-----0001011",
                    List(
                        IS_ISAX                  -> True,
                        SRC1_CTRL                -> Src1CtrlEnum.RS,
                        SRC2_CTRL                -> Src2CtrlEnum.RS,
                        REGFILE_WRITE_VALID      -> True,
                        RS1_USE                  -> True,
                        RS2_USE                  -> True                ,
                        BYPASSABLE_EXECUTE_STAGE  -> True,
                        BYPASSABLE_MEMORY_STAGE  -> True
                    )
                )
        
                decoderService.add(
                    key = M"0000100----------000-----0001011",
                    List(
                        IS_ISAX                  -> True,
                        SRC1_CTRL                -> Src1CtrlEnum.RS,
                        SRC2_CTRL                -> Src2CtrlEnum.RS,
                        REGFILE_WRITE_VALID      -> True,
                        RS1_USE                  -> True,
                        RS2_USE                  -> False                ,
                        BYPASSABLE_EXECUTE_STAGE  -> True,
                        BYPASSABLE_MEMORY_STAGE  -> True
                    )
                )
        
                decoderService.add(
                    key = M"0111000----------000-----0001011",
                    List(
                        IS_ISAX                  -> True,
                        SRC1_CTRL                -> Src1CtrlEnum.RS,
                        SRC2_CTRL                -> Src2CtrlEnum.RS,
                        REGFILE_WRITE_VALID      -> True,
                        RS1_USE                  -> True,
                        RS2_USE                  -> False                ,
                        BYPASSABLE_EXECUTE_STAGE  -> True,
                        BYPASSABLE_MEMORY_STAGE  -> True
                    )
                )
        
                decoderService.add(
                    key = M"11---------------000-----0001011",
                    List(
                        IS_ISAX                  -> True,
                        SRC1_CTRL                -> Src1CtrlEnum.RS,
                        SRC2_CTRL                -> Src2CtrlEnum.RS,
                        REGFILE_WRITE_VALID      -> True,
                        RS1_USE                  -> True,
                        RS2_USE                  -> True                ,
                        BYPASSABLE_EXECUTE_STAGE  -> True,
                        BYPASSABLE_MEMORY_STAGE  -> True
                    )
                )
        
                decoderService.add(
                    key = M"0011110----------000-----0001011",
                    List(
                        IS_ISAX                  -> True,
                        SRC1_CTRL                -> Src1CtrlEnum.RS,
                        SRC2_CTRL                -> Src2CtrlEnum.RS,
                        REGFILE_WRITE_VALID      -> True,
                        RS1_USE                  -> True,
                        RS2_USE                  -> False                ,
                        BYPASSABLE_EXECUTE_STAGE  -> True,
                        BYPASSABLE_MEMORY_STAGE  -> True
                    )
                )
        
        // Get service for memory transfers
        dBusAccess = pipeline.service(classOf[DBusAccessService]).newDBusAccess();
        
    }
    
    // Build phase.
    override def build(pipeline: VexRiscv): Unit = {
        import pipeline._
        import pipeline.config._
        val writeStage = if (writeRfInMemoryStage) pipeline.memory else pipeline.stages.last 
         
        decode plug new Area {
        import decode._
            val io = new Bundle {
                val RdFlush_1_o = out Bool()
                RdFlush_1_o.setName("RdFlush_1_o")
                val RdStall_1_o = out Bool()
                RdStall_1_o.setName("RdStall_1_o")
                val RdInstr_1_o = out Bits(32 bits)
                RdInstr_1_o.setName("RdInstr_1_o")
                val RdInStageValid_1_o = out Bool()
                RdInStageValid_1_o.setName("RdInStageValid_1_o")
                
            }
            io.RdFlush_1_o := decode.arbitration.isFlushedNonSV;
            io.RdStall_1_o := decode.arbitration.isStuck || (!decode.arbitration.isValid);
            io.RdInstr_1_o := decode.input(INSTRUCTION);
            io.RdInStageValid_1_o := decode.arbitration.isValid;
            
            
            
            
        }
         
        execute plug new Area {
        import execute._
            val io = new Bundle {
                val RdFlush_2_o = out Bool()
                RdFlush_2_o.setName("RdFlush_2_o")
                val WrRD_2_i = in Bits(32 bits)
                WrRD_2_i.setName("WrRD_2_i")
                val WrRD_validReq_2_i = in Bool()
                WrRD_validReq_2_i.setName("WrRD_validReq_2_i")
                val RdStall_2_o = out Bool()
                RdStall_2_o.setName("RdStall_2_o")
                val RdInstr_2_o = out Bits(32 bits)
                RdInstr_2_o.setName("RdInstr_2_o")
                val RdRS1_2_o = out Bits(32 bits)
                RdRS1_2_o.setName("RdRS1_2_o")
                val RdRS2_2_o = out Bits(32 bits)
                RdRS2_2_o.setName("RdRS2_2_o")
                val RdMem_2_o = out Bits(32 bits)
                RdMem_2_o.setName("RdMem_2_o")
                val RdMem_validReq_2_i = in Bool()
                RdMem_validReq_2_i.setName("RdMem_validReq_2_i")
                val RdMem_addr_2_i = in UInt(32 bits)
                RdMem_addr_2_i.setName("RdMem_addr_2_i")
                val RdMem_addr_valid_2_i = in Bool()
                RdMem_addr_valid_2_i.setName("RdMem_addr_valid_2_i")
                val RdMem_size_2_i = in UInt(3 bits)
                RdMem_size_2_i.setName("RdMem_size_2_i")
                val RdInStageValid_2_o = out Bool()
                RdInStageValid_2_o.setName("RdInStageValid_2_o")
                val RdMem_validReq_1_i = in Bool()
                RdMem_validReq_1_i.setName("RdMem_validReq_1_i")
                
            }
            io.RdFlush_2_o := execute.arbitration.isFlushedNonSV;
            io.RdStall_2_o := execute.arbitration.isStuck || (!execute.arbitration.isValid);
            io.RdInstr_2_o := execute.input(INSTRUCTION);
            io.RdRS1_2_o := execute.input(RS1);
            io.RdRS2_2_o := execute.input(RS2);
            io.RdInStageValid_2_o := execute.arbitration.isValid;
            
            
            
            
            when(io.WrRD_validReq_2_i) {
            
                execute.output(REGFILE_WRITE_DATA) := io.WrRD_2_i;
                
            }
            
            when(!io.WrRD_validReq_2_i && execute.input(BYPASSABLE_EXECUTE_STAGE) && execute.input(IS_ISAX) ) {
            
                execute.output(REGFILE_WRITE_VALID) := False;
                
            }
            
                        val State = new SpinalEnum{
                            val IDLE, CMD , RESPONSE = newElement()
                        }
                        val state = RegInit(State.IDLE)
                        
            	          io.RdMem_2_o := 0
                        // Define some default values for memory FSM
                        dBusAccess.cmd.valid := False
                        dBusAccess.cmd.write := False
                        dBusAccess.cmd.size := 0 
                        dBusAccess.cmd.address.assignDontCare() 
                        dBusAccess.cmd.data.assignDontCare() 
                        dBusAccess.cmd.writeMask.assignDontCare()
                        
                        val ldst_in_decode = Bool()		    
                        when(state !==  State.IDLE) {
                            when(ldst_in_decode) {
                                decode.arbitration.haltItself := True;
                            }
                        }
                        ldst_in_decode := ((False  ||  io.RdMem_validReq_1_i) && decode.input(IS_ISAX))
                        switch(state){
                            is(State.IDLE){
                                when(ldst_in_decode && decode.arbitration.isFiring ) { 
                                    state := State.CMD
                                }
                            }
                            is(State.CMD){
                                when(~(io.RdMem_validReq_2_i)) {
                                        state := State.IDLE
                                }.otherwise {
                                 when(execute.arbitration.isValid ) {
                                    dBusAccess.cmd.valid   := True 
                                    dBusAccess.cmd.size    := execute.input(INSTRUCTION)(13 downto 12).asUInt	
            
                                    dBusAccess.cmd.data   := 0 ;
            
                                    dBusAccess.cmd.write   := False
                                    dBusAccess.cmd.address := execute.input(SRC_ADD).asUInt  
            			               when(io.RdMem_addr_valid_2_i) { // set to 0 if no ISAX needs it and removed by synth tool 
            			                  dBusAccess.cmd.address := io.RdMem_addr_2_i
            			               }
                                    when(dBusAccess.cmd.ready) {// Next state 
            
                                        when (io.RdMem_validReq_2_i) {
                                            state := State.RESPONSE
                                        }
                                    }.otherwise {
                                        execute.arbitration.haltItself := True
                                    }
                                 }
                                }
                            }
                            is(State.RESPONSE){  
                                when(dBusAccess.rsp.valid){ 
                                    state := State.IDLE
                                    io.RdMem_2_o := dBusAccess.rsp.data;  
                                } .otherwise {
                                    memory.arbitration.haltItself := True
                                }
                            }
                        }
            
        }
         
        memory plug new Area {
        import memory._
            val io = new Bundle {
                val RdFlush_3_o = out Bool()
                RdFlush_3_o.setName("RdFlush_3_o")
                val WrRD_3_i = in Bits(32 bits)
                WrRD_3_i.setName("WrRD_3_i")
                val WrRD_validReq_3_i = in Bool()
                WrRD_validReq_3_i.setName("WrRD_validReq_3_i")
                val RdStall_3_o = out Bool()
                RdStall_3_o.setName("RdStall_3_o")
                val RdRS2_3_o = out Bits(32 bits)
                RdRS2_3_o.setName("RdRS2_3_o")
                val RdInStageValid_3_o = out Bool()
                RdInStageValid_3_o.setName("RdInStageValid_3_o")
                
            }
            io.RdFlush_3_o := memory.arbitration.isFlushedNonSV;
            io.RdStall_3_o := memory.arbitration.isStuck || (!memory.arbitration.isValid);
            io.RdRS2_3_o := memory.input(RS2);
            io.RdInStageValid_3_o := memory.arbitration.isValid;
            
            
            
            
            when(io.WrRD_validReq_3_i) {
            
                memory.output(REGFILE_WRITE_DATA) := io.WrRD_3_i;
                
            }
            
            when(!io.WrRD_validReq_3_i && memory.input(BYPASSABLE_MEMORY_STAGE) && !memory.input(BYPASSABLE_EXECUTE_STAGE) && memory.input(IS_ISAX) ) {
            
                memory.output(REGFILE_WRITE_VALID) := False;
                
            }
            
        }
    }
}
