module top( 
	input         		clk,
    input         		rst,
	input               debug_bus_cmd_valid,
	output reg          debug_bus_cmd_ready,
	input               debug_bus_cmd_payload_wr,
	input      [7:0]    debug_bus_cmd_payload_address,
	input      [31:0]   debug_bus_cmd_payload_data,
	output reg [31:0]   debug_bus_rsp_data,
	output              debug_resetOut,
	input               timerInterrupt,
	input               externalInterrupt,
	input               softwareInterrupt,
	output     [31:0]   iBusAhbLite3_HADDR,
	output              iBusAhbLite3_HWRITE,
	output     [2:0]    iBusAhbLite3_HSIZE,
	output     [2:0]    iBusAhbLite3_HBURST,
	output     [3:0]    iBusAhbLite3_HPROT,
	output     [1:0]    iBusAhbLite3_HTRANS,
	output              iBusAhbLite3_HMASTLOCK,
	output     [31:0]   iBusAhbLite3_HWDATA,
	input      [31:0]   iBusAhbLite3_HRDATA,
	input               iBusAhbLite3_HREADY,
	input               iBusAhbLite3_HRESP,
	output     [31:0]   dBusAhbLite3_HADDR,
	output              dBusAhbLite3_HWRITE,
	output     [2:0]    dBusAhbLite3_HSIZE,
	output     [2:0]    dBusAhbLite3_HBURST,
	output     [3:0]    dBusAhbLite3_HPROT,
	output reg [1:0]    dBusAhbLite3_HTRANS,
	output              dBusAhbLite3_HMASTLOCK,
	output     [31:0]   dBusAhbLite3_HWDATA,
	input      [31:0]   dBusAhbLite3_HRDATA,
	input               dBusAhbLite3_HREADY,
	input               dBusAhbLite3_HRESP, 
	input				debugReset);

    wire [32-1:0] core_RdRS2_2_to_scal;
    wire [32-1:0] core_RdMem_addr_2_from_scal;
    wire [32-1:0] core_RdMem_2_to_scal;
    wire core_WrRD_validReq_2_from_scal;
    wire core_RdStall_2_to_scal;
    wire [3-1:0] core_RdMem_size_2_from_scal;
    wire [32-1:0] core_RdRS1_2_to_scal;
    wire core_RdStall_3_to_scal;
    wire core_RdFlush_2_to_scal;
    wire [32-1:0] core_RdInstr_1_to_scal;
    wire core_RdInStageValid_2_to_scal;
    wire [32-1:0] core_RdRS2_3_to_scal;
    wire core_RdMem_validReq_1_from_scal;
    wire core_RdInStageValid_3_to_scal;
    wire core_RdStall_1_to_scal;
    wire core_RdFlush_3_to_scal;
    wire [32-1:0] core_WrRD_2_from_scal;
    wire core_RdMem_validReq_2_from_scal;
    wire core_RdInStageValid_1_to_scal;
    wire [32-1:0] core_RdInstr_2_to_scal;
    wire core_RdMem_addr_valid_2_from_scal;
    wire [32-1:0] core_WrRD_3_from_scal;
    wire core_WrRD_validReq_3_from_scal;
    wire core_RdFlush_1_to_scal;
    
    VexRiscv VexRiscv_inst(
        .debug_bus_cmd_valid(debug_bus_cmd_valid),
        .debug_bus_cmd_ready(debug_bus_cmd_ready),
        .debug_bus_cmd_payload_wr(debug_bus_cmd_payload_wr),
        .debug_bus_cmd_payload_address(debug_bus_cmd_payload_address),
        .debug_bus_cmd_payload_data(debug_bus_cmd_payload_data),
        .debug_bus_rsp_data(debug_bus_rsp_data),
        .debug_resetOut(debug_resetOut),
        .timerInterrupt(timerInterrupt),
        .externalInterrupt(externalInterrupt),
        .softwareInterrupt(softwareInterrupt),

        .iBusAhbLite3_HADDR        (iBusAhbLite3_HADDR     ),
        .iBusAhbLite3_HWRITE       (iBusAhbLite3_HWRITE    ),
        .iBusAhbLite3_HSIZE        (iBusAhbLite3_HSIZE     ),
        .iBusAhbLite3_HBURST       (iBusAhbLite3_HBURST    ),
        .iBusAhbLite3_HPROT        (iBusAhbLite3_HPROT     ),
        .iBusAhbLite3_HTRANS       (iBusAhbLite3_HTRANS    ),
        .iBusAhbLite3_HMASTLOCK    (iBusAhbLite3_HMASTLOCK ),
        .iBusAhbLite3_HWDATA       (iBusAhbLite3_HWDATA    ),
        .iBusAhbLite3_HRDATA       (iBusAhbLite3_HRDATA    ),
        .iBusAhbLite3_HREADY       (iBusAhbLite3_HREADY    ),
        .iBusAhbLite3_HRESP        (iBusAhbLite3_HRESP     ),
        .dBusAhbLite3_HADDR        (dBusAhbLite3_HADDR     ),
        .dBusAhbLite3_HWRITE       (dBusAhbLite3_HWRITE    ),
        .dBusAhbLite3_HSIZE        (dBusAhbLite3_HSIZE     ),
        .dBusAhbLite3_HBURST       (dBusAhbLite3_HBURST    ),
        .dBusAhbLite3_HPROT        (dBusAhbLite3_HPROT     ),
        .dBusAhbLite3_HTRANS       (dBusAhbLite3_HTRANS    ),
        .dBusAhbLite3_HMASTLOCK    (dBusAhbLite3_HMASTLOCK ),
        .dBusAhbLite3_HWDATA       (dBusAhbLite3_HWDATA    ),
        .dBusAhbLite3_HRDATA       (dBusAhbLite3_HRDATA    ),
        .dBusAhbLite3_HREADY       (dBusAhbLite3_HREADY    ),
        .dBusAhbLite3_HRESP        (dBusAhbLite3_HRESP     ),
        .clk                       (clk),
        .reset                     (rst),
        .debugReset                (debugReset)
        ,.RdRS2_2_o(core_RdRS2_2_to_scal)
        ,.RdMem_addr_2_i(core_RdMem_addr_2_from_scal)
        ,.RdMem_2_o(core_RdMem_2_to_scal)
        ,.WrRD_validReq_2_i(core_WrRD_validReq_2_from_scal)
        ,.RdStall_2_o(core_RdStall_2_to_scal)
        ,.RdMem_size_2_i(core_RdMem_size_2_from_scal)
        ,.RdRS1_2_o(core_RdRS1_2_to_scal)
        ,.RdStall_3_o(core_RdStall_3_to_scal)
        ,.RdFlush_2_o(core_RdFlush_2_to_scal)
        ,.RdInstr_1_o(core_RdInstr_1_to_scal)
        ,.RdInStageValid_2_o(core_RdInStageValid_2_to_scal)
        ,.RdRS2_3_o(core_RdRS2_3_to_scal)
        ,.RdMem_validReq_1_i(core_RdMem_validReq_1_from_scal)
        ,.RdInStageValid_3_o(core_RdInStageValid_3_to_scal)
        ,.RdStall_1_o(core_RdStall_1_to_scal)
        ,.RdFlush_3_o(core_RdFlush_3_to_scal)
        ,.WrRD_2_i(core_WrRD_2_from_scal)
        ,.RdMem_validReq_2_i(core_RdMem_validReq_2_from_scal)
        ,.RdInStageValid_1_o(core_RdInStageValid_1_to_scal)
        ,.RdInstr_2_o(core_RdInstr_2_to_scal)
        ,.RdMem_addr_valid_2_i(core_RdMem_addr_valid_2_from_scal)
        ,.WrRD_3_i(core_WrRD_3_from_scal)
        ,.WrRD_validReq_3_i(core_WrRD_validReq_3_from_scal)
        ,.RdFlush_1_o(core_RdFlush_1_to_scal)
    );

    wire [32-1:0] isax_RdRS1_2_from_scal;
    wire isax_RdIValid_CUSTOM18_2_from_scal;
    wire isax_RdIValid_CUSTOM19_2_from_scal;
    wire [32-1:0] isax_WrRD_CUSTOM8_2_to_scal;
    wire isax_RdIValid_CUSTOM13_2_from_scal;
    wire isax_RdIValid_CUSTOM12_2_from_scal;
    wire isax_RdIValid_CUSTOM14_2_from_scal;
    wire isax_RdIValid_CUSTOM17_2_from_scal;
    wire isax_RdIValid_CUSTOM16_2_from_scal;
    wire isax_RdIValid_CUSTOM15_2_from_scal;
    wire [32-1:0] isax_WrRD_CUSTOM7_2_to_scal;
    wire [32-1:0] isax_RdMem_addr_CUSTOM0_2_to_scal;
    wire isax_RdIValid_CUSTOM16_3_from_scal;
    wire isax_RdIValid_CUSTOM15_3_from_scal;
    wire [32-1:0] isax_RdMem_addr_CUSTOM3_2_to_scal;
    wire [32-1:0] isax_WrRD_CUSTOM16_3_to_scal;
    wire [32-1:0] isax_WrRD_CUSTOM0_3_to_scal;
    wire [32-1:0] isax_WrRD_CUSTOM29_2_to_scal;
    wire isax_RdIValid_CUSTOM10_2_from_scal;
    wire [32-1:0] isax_WrRD_CUSTOM20_2_to_scal;
    wire isax_RdMem_validReq_CUSTOM3_2_to_scal;
    wire isax_RdIValid_CUSTOM11_2_from_scal;
    wire isax_RdIValid_CUSTOM31_2_from_scal;
    wire isax_RdIValid_CUSTOM30_2_from_scal;
    wire [32-1:0] isax_WrRD_CUSTOM10_2_to_scal;
    wire [32-1:0] isax_WrRD_CUSTOM13_2_to_scal;
    wire isax_RdMem_validReq_CUSTOM0_2_to_scal;
    wire isax_RdStall_CUSTOM0_3_from_scal;
    wire isax_RdIValid_CUSTOM0_3_from_scal;
    wire isax_RdIValid_CUSTOM7_2_from_scal;
    wire isax_RdStall_CUSTOM9_2_from_scal;
    wire [32-1:0] isax_WrRD_CUSTOM3_3_to_scal;
    wire isax_RdIValid_CUSTOM9_2_from_scal;
    wire isax_RdStall_CUSTOM7_2_from_scal;
    wire [32-1:0] isax_RdRS2_2_from_scal;
    wire isax_RdIValid_CUSTOM1_2_from_scal;
    wire [32-1:0] isax_WrRD_CUSTOM21_2_to_scal;
    wire isax_RdIValid_CUSTOM5_2_from_scal;
    wire [32-1:0] isax_WrRD_CUSTOM28_2_to_scal;
    wire isax_RdIValid_CUSTOM3_2_from_scal;
    wire isax_RdStall_CUSTOM11_2_from_scal;
    wire isax_RdIValid_CUSTOM28_2_from_scal;
    wire isax_RdStall_CUSTOM13_2_from_scal;
    wire isax_RdStall_CUSTOM19_2_from_scal;
    wire isax_RdMem_validReq_CUSTOM5_2_to_scal;
    wire isax_RdIValid_CUSTOM24_2_from_scal;
    wire isax_RdStall_CUSTOM15_2_from_scal;
    wire isax_RdStall_CUSTOM17_2_from_scal;
    wire [32-1:0] isax_WrRD_CUSTOM22_2_to_scal;
    wire isax_RdIValid_CUSTOM26_2_from_scal;
    wire [32-1:0] isax_RdRS2_3_from_scal;
    wire [32-1:0] isax_WrRD_CUSTOM14_2_to_scal;
    wire isax_RdIValid_CUSTOM22_2_from_scal;
    wire isax_RdIValid_CUSTOM20_2_from_scal;
    wire [32-1:0] isax_WrRD_CUSTOM6_2_to_scal;
    wire isax_RdStall_CUSTOM22_2_from_scal;
    wire isax_RdStall_CUSTOM21_2_from_scal;
    wire [32-1:0] isax_RdInstr_2_from_scal;
    wire isax_RdMem_validReq_CUSTOM15_2_to_scal;
    wire isax_RdStall_CUSTOM25_2_from_scal;
    wire [32-1:0] isax_WrRD_CUSTOM24_2_to_scal;
    wire isax_RdStall_CUSTOM23_2_from_scal;
    wire isax_RdStall_CUSTOM24_2_from_scal;
    wire isax_RdStall_CUSTOM29_2_from_scal;
    wire isax_RdStall_CUSTOM26_2_from_scal;
    wire isax_RdStall_CUSTOM27_2_from_scal;
    wire isax_RdStall_CUSTOM28_2_from_scal;
    wire [32-1:0] isax_WrRD_CUSTOM31_2_to_scal;
    wire [32-1:0] isax_WrRD_CUSTOM25_2_to_scal;
    wire [32-1:0] isax_RdMem_2_from_scal;
    wire [32-1:0] isax_RdMem_addr_CUSTOM15_2_to_scal;
    wire [32-1:0] isax_WrRD_CUSTOM1_2_to_scal;
    wire isax_RdStall_CUSTOM20_2_from_scal;
    wire isax_RdStall_CUSTOM30_2_from_scal;
    wire isax_RdStall_CUSTOM31_2_from_scal;
    wire [32-1:0] isax_WrRD_CUSTOM26_2_to_scal;
    wire [32-1:0] isax_WrRD_CUSTOM18_2_to_scal;
    wire [32-1:0] isax_RdMem_addr_CUSTOM16_2_to_scal;
    wire [32-1:0] isax_WrRD_CUSTOM19_2_to_scal;
    wire [32-1:0] isax_WrRD_CUSTOM30_2_to_scal;
    wire [32-1:0] isax_WrRD_CUSTOM5_3_to_scal;
    wire [32-1:0] isax_WrRD_CUSTOM27_3_to_scal;
    wire isax_RdStall_CUSTOM3_2_from_scal;
    wire isax_RdStall_CUSTOM2_2_from_scal;
    wire isax_RdStall_CUSTOM4_2_from_scal;
    wire isax_RdStall_CUSTOM1_2_from_scal;
    wire isax_RdStall_CUSTOM5_2_from_scal;
    wire [32-1:0] isax_WrRD_CUSTOM2_2_to_scal;
    wire [32-1:0] isax_WrRD_CUSTOM23_2_to_scal;
    wire isax_RdStall_CUSTOM0_2_from_scal;
    wire isax_RdStall_CUSTOM15_3_from_scal;
    wire isax_RdStall_CUSTOM16_3_from_scal;
    wire isax_RdStall_CUSTOM3_3_from_scal;
    wire isax_RdIValid_CUSTOM8_2_from_scal;
    wire isax_RdIValid_CUSTOM3_3_from_scal;
    wire isax_RdIValid_CUSTOM5_3_from_scal;
    wire [32-1:0] isax_RdMem_addr_CUSTOM5_2_to_scal;
    wire isax_RdStall_CUSTOM6_2_from_scal;
    wire isax_RdStall_CUSTOM8_2_from_scal;
    wire isax_RdIValid_CUSTOM27_3_from_scal;
    wire isax_RdIValid_CUSTOM0_2_from_scal;
    wire [32-1:0] isax_WrRD_CUSTOM12_2_to_scal;
    wire isax_RdIValid_CUSTOM6_2_from_scal;
    wire [32-1:0] isax_WrRD_CUSTOM4_2_to_scal;
    wire isax_RdIValid_CUSTOM2_2_from_scal;
    wire isax_RdStall_CUSTOM5_3_from_scal;
    wire isax_RdIValid_CUSTOM4_2_from_scal;
    wire isax_RdStall_CUSTOM10_2_from_scal;
    wire isax_RdStall_CUSTOM12_2_from_scal;
    wire [32-1:0] isax_WrRD_CUSTOM11_2_to_scal;
    wire isax_RdStall_CUSTOM14_2_from_scal;
    wire isax_RdIValid_CUSTOM29_2_from_scal;
    wire isax_RdStall_CUSTOM18_2_from_scal;
    wire isax_RdIValid_CUSTOM23_2_from_scal;
    wire isax_RdIValid_CUSTOM25_2_from_scal;
    wire isax_RdStall_CUSTOM16_2_from_scal;
    wire isax_RdIValid_CUSTOM27_2_from_scal;
    wire [32-1:0] isax_WrRD_CUSTOM9_2_to_scal;
    wire isax_RdIValid_CUSTOM21_2_from_scal;
    wire isax_RdStall_CUSTOM27_3_from_scal;
    wire [32-1:0] isax_WrRD_CUSTOM17_2_to_scal;
    wire [32-1:0] isax_WrRD_CUSTOM15_3_to_scal;
    wire isax_RdMem_validReq_CUSTOM16_2_to_scal;
    
    SCAL scal (
        .clk_i(clk)
        ,.rst_i(rst)
        ,.RdRS1_2_o(isax_RdRS1_2_from_scal)
        ,.RdIValid_CUSTOM18_2_o(isax_RdIValid_CUSTOM18_2_from_scal)
        ,.RdIValid_CUSTOM19_2_o(isax_RdIValid_CUSTOM19_2_from_scal)
        ,.WrRD_CUSTOM8_2_i(isax_WrRD_CUSTOM8_2_to_scal)
        ,.RdIValid_CUSTOM13_2_o(isax_RdIValid_CUSTOM13_2_from_scal)
        ,.RdIValid_CUSTOM12_2_o(isax_RdIValid_CUSTOM12_2_from_scal)
        ,.RdIValid_CUSTOM14_2_o(isax_RdIValid_CUSTOM14_2_from_scal)
        ,.RdIValid_CUSTOM17_2_o(isax_RdIValid_CUSTOM17_2_from_scal)
        ,.RdIValid_CUSTOM16_2_o(isax_RdIValid_CUSTOM16_2_from_scal)
        ,.RdIValid_CUSTOM15_2_o(isax_RdIValid_CUSTOM15_2_from_scal)
        ,.WrRD_CUSTOM7_2_i(isax_WrRD_CUSTOM7_2_to_scal)
        ,.RdMem_addr_CUSTOM0_2_i(isax_RdMem_addr_CUSTOM0_2_to_scal)
        ,.RdIValid_CUSTOM16_3_o(isax_RdIValid_CUSTOM16_3_from_scal)
        ,.RdIValid_CUSTOM15_3_o(isax_RdIValid_CUSTOM15_3_from_scal)
        ,.RdRS2_2_i(core_RdRS2_2_to_scal)
        ,.RdMem_addr_2_o(core_RdMem_addr_2_from_scal)
        ,.RdMem_addr_CUSTOM3_2_i(isax_RdMem_addr_CUSTOM3_2_to_scal)
        ,.RdMem_2_i(core_RdMem_2_to_scal)
        ,.WrRD_validReq_2_o(core_WrRD_validReq_2_from_scal)
        ,.WrRD_CUSTOM16_3_i(isax_WrRD_CUSTOM16_3_to_scal)
        ,.WrRD_CUSTOM0_3_i(isax_WrRD_CUSTOM0_3_to_scal)
        ,.WrRD_CUSTOM29_2_i(isax_WrRD_CUSTOM29_2_to_scal)
        ,.RdIValid_CUSTOM10_2_o(isax_RdIValid_CUSTOM10_2_from_scal)
        ,.RdStall_2_i(core_RdStall_2_to_scal)
        ,.WrRD_CUSTOM20_2_i(isax_WrRD_CUSTOM20_2_to_scal)
        ,.RdMem_validReq_CUSTOM3_2_i(isax_RdMem_validReq_CUSTOM3_2_to_scal)
        ,.RdIValid_CUSTOM11_2_o(isax_RdIValid_CUSTOM11_2_from_scal)
        ,.RdMem_size_2_o(core_RdMem_size_2_from_scal)
        ,.RdIValid_CUSTOM31_2_o(isax_RdIValid_CUSTOM31_2_from_scal)
        ,.RdIValid_CUSTOM30_2_o(isax_RdIValid_CUSTOM30_2_from_scal)
        ,.WrRD_CUSTOM10_2_i(isax_WrRD_CUSTOM10_2_to_scal)
        ,.WrRD_CUSTOM13_2_i(isax_WrRD_CUSTOM13_2_to_scal)
        ,.RdMem_validReq_CUSTOM0_2_i(isax_RdMem_validReq_CUSTOM0_2_to_scal)
        ,.RdStall_CUSTOM0_3_o(isax_RdStall_CUSTOM0_3_from_scal)
        ,.RdIValid_CUSTOM0_3_o(isax_RdIValid_CUSTOM0_3_from_scal)
        ,.RdIValid_CUSTOM7_2_o(isax_RdIValid_CUSTOM7_2_from_scal)
        ,.RdStall_CUSTOM9_2_o(isax_RdStall_CUSTOM9_2_from_scal)
        ,.WrRD_CUSTOM3_3_i(isax_WrRD_CUSTOM3_3_to_scal)
        ,.RdIValid_CUSTOM9_2_o(isax_RdIValid_CUSTOM9_2_from_scal)
        ,.RdStall_CUSTOM7_2_o(isax_RdStall_CUSTOM7_2_from_scal)
        ,.RdRS1_2_i(core_RdRS1_2_to_scal)
        ,.RdRS2_2_o(isax_RdRS2_2_from_scal)
        ,.RdIValid_CUSTOM1_2_o(isax_RdIValid_CUSTOM1_2_from_scal)
        ,.RdStall_3_i(core_RdStall_3_to_scal)
        ,.WrRD_CUSTOM21_2_i(isax_WrRD_CUSTOM21_2_to_scal)
        ,.RdIValid_CUSTOM5_2_o(isax_RdIValid_CUSTOM5_2_from_scal)
        ,.RdFlush_2_i(core_RdFlush_2_to_scal)
        ,.WrRD_CUSTOM28_2_i(isax_WrRD_CUSTOM28_2_to_scal)
        ,.RdIValid_CUSTOM3_2_o(isax_RdIValid_CUSTOM3_2_from_scal)
        ,.RdStall_CUSTOM11_2_o(isax_RdStall_CUSTOM11_2_from_scal)
        ,.RdIValid_CUSTOM28_2_o(isax_RdIValid_CUSTOM28_2_from_scal)
        ,.RdStall_CUSTOM13_2_o(isax_RdStall_CUSTOM13_2_from_scal)
        ,.RdInstr_1_i(core_RdInstr_1_to_scal)
        ,.RdStall_CUSTOM19_2_o(isax_RdStall_CUSTOM19_2_from_scal)
        ,.RdMem_validReq_CUSTOM5_2_i(isax_RdMem_validReq_CUSTOM5_2_to_scal)
        ,.RdIValid_CUSTOM24_2_o(isax_RdIValid_CUSTOM24_2_from_scal)
        ,.RdStall_CUSTOM15_2_o(isax_RdStall_CUSTOM15_2_from_scal)
        ,.RdInStageValid_2_i(core_RdInStageValid_2_to_scal)
        ,.RdStall_CUSTOM17_2_o(isax_RdStall_CUSTOM17_2_from_scal)
        ,.WrRD_CUSTOM22_2_i(isax_WrRD_CUSTOM22_2_to_scal)
        ,.RdIValid_CUSTOM26_2_o(isax_RdIValid_CUSTOM26_2_from_scal)
        ,.RdRS2_3_o(isax_RdRS2_3_from_scal)
        ,.WrRD_CUSTOM14_2_i(isax_WrRD_CUSTOM14_2_to_scal)
        ,.RdIValid_CUSTOM22_2_o(isax_RdIValid_CUSTOM22_2_from_scal)
        ,.RdIValid_CUSTOM20_2_o(isax_RdIValid_CUSTOM20_2_from_scal)
        ,.WrRD_CUSTOM6_2_i(isax_WrRD_CUSTOM6_2_to_scal)
        ,.RdStall_CUSTOM22_2_o(isax_RdStall_CUSTOM22_2_from_scal)
        ,.RdStall_CUSTOM21_2_o(isax_RdStall_CUSTOM21_2_from_scal)
        ,.RdInstr_2_o(isax_RdInstr_2_from_scal)
        ,.RdMem_validReq_CUSTOM15_2_i(isax_RdMem_validReq_CUSTOM15_2_to_scal)
        ,.RdStall_CUSTOM25_2_o(isax_RdStall_CUSTOM25_2_from_scal)
        ,.WrRD_CUSTOM24_2_i(isax_WrRD_CUSTOM24_2_to_scal)
        ,.RdRS2_3_i(core_RdRS2_3_to_scal)
        ,.RdStall_CUSTOM23_2_o(isax_RdStall_CUSTOM23_2_from_scal)
        ,.RdStall_CUSTOM24_2_o(isax_RdStall_CUSTOM24_2_from_scal)
        ,.RdStall_CUSTOM29_2_o(isax_RdStall_CUSTOM29_2_from_scal)
        ,.RdMem_validReq_1_o(core_RdMem_validReq_1_from_scal)
        ,.RdStall_CUSTOM26_2_o(isax_RdStall_CUSTOM26_2_from_scal)
        ,.RdStall_CUSTOM27_2_o(isax_RdStall_CUSTOM27_2_from_scal)
        ,.RdStall_CUSTOM28_2_o(isax_RdStall_CUSTOM28_2_from_scal)
        ,.RdInStageValid_3_i(core_RdInStageValid_3_to_scal)
        ,.WrRD_CUSTOM31_2_i(isax_WrRD_CUSTOM31_2_to_scal)
        ,.RdStall_1_i(core_RdStall_1_to_scal)
        ,.WrRD_CUSTOM25_2_i(isax_WrRD_CUSTOM25_2_to_scal)
        ,.RdMem_2_o(isax_RdMem_2_from_scal)
        ,.RdMem_addr_CUSTOM15_2_i(isax_RdMem_addr_CUSTOM15_2_to_scal)
        ,.WrRD_CUSTOM1_2_i(isax_WrRD_CUSTOM1_2_to_scal)
        ,.RdStall_CUSTOM20_2_o(isax_RdStall_CUSTOM20_2_from_scal)
        ,.RdStall_CUSTOM30_2_o(isax_RdStall_CUSTOM30_2_from_scal)
        ,.RdStall_CUSTOM31_2_o(isax_RdStall_CUSTOM31_2_from_scal)
        ,.RdFlush_3_i(core_RdFlush_3_to_scal)
        ,.WrRD_CUSTOM26_2_i(isax_WrRD_CUSTOM26_2_to_scal)
        ,.WrRD_CUSTOM18_2_i(isax_WrRD_CUSTOM18_2_to_scal)
        ,.RdMem_addr_CUSTOM16_2_i(isax_RdMem_addr_CUSTOM16_2_to_scal)
        ,.WrRD_CUSTOM19_2_i(isax_WrRD_CUSTOM19_2_to_scal)
        ,.WrRD_CUSTOM30_2_i(isax_WrRD_CUSTOM30_2_to_scal)
        ,.WrRD_CUSTOM5_3_i(isax_WrRD_CUSTOM5_3_to_scal)
        ,.WrRD_CUSTOM27_3_i(isax_WrRD_CUSTOM27_3_to_scal)
        ,.RdStall_CUSTOM3_2_o(isax_RdStall_CUSTOM3_2_from_scal)
        ,.WrRD_2_o(core_WrRD_2_from_scal)
        ,.RdStall_CUSTOM2_2_o(isax_RdStall_CUSTOM2_2_from_scal)
        ,.RdStall_CUSTOM4_2_o(isax_RdStall_CUSTOM4_2_from_scal)
        ,.RdStall_CUSTOM1_2_o(isax_RdStall_CUSTOM1_2_from_scal)
        ,.RdStall_CUSTOM5_2_o(isax_RdStall_CUSTOM5_2_from_scal)
        ,.WrRD_CUSTOM2_2_i(isax_WrRD_CUSTOM2_2_to_scal)
        ,.WrRD_CUSTOM23_2_i(isax_WrRD_CUSTOM23_2_to_scal)
        ,.RdMem_validReq_2_o(core_RdMem_validReq_2_from_scal)
        ,.RdStall_CUSTOM0_2_o(isax_RdStall_CUSTOM0_2_from_scal)
        ,.RdStall_CUSTOM15_3_o(isax_RdStall_CUSTOM15_3_from_scal)
        ,.RdStall_CUSTOM16_3_o(isax_RdStall_CUSTOM16_3_from_scal)
        ,.RdStall_CUSTOM3_3_o(isax_RdStall_CUSTOM3_3_from_scal)
        ,.RdInStageValid_1_i(core_RdInStageValid_1_to_scal)
        ,.RdInstr_2_i(core_RdInstr_2_to_scal)
        ,.RdIValid_CUSTOM8_2_o(isax_RdIValid_CUSTOM8_2_from_scal)
        ,.RdIValid_CUSTOM3_3_o(isax_RdIValid_CUSTOM3_3_from_scal)
        ,.RdIValid_CUSTOM5_3_o(isax_RdIValid_CUSTOM5_3_from_scal)
        ,.RdMem_addr_CUSTOM5_2_i(isax_RdMem_addr_CUSTOM5_2_to_scal)
        ,.RdStall_CUSTOM6_2_o(isax_RdStall_CUSTOM6_2_from_scal)
        ,.RdStall_CUSTOM8_2_o(isax_RdStall_CUSTOM8_2_from_scal)
        ,.RdIValid_CUSTOM27_3_o(isax_RdIValid_CUSTOM27_3_from_scal)
        ,.RdIValid_CUSTOM0_2_o(isax_RdIValid_CUSTOM0_2_from_scal)
        ,.WrRD_CUSTOM12_2_i(isax_WrRD_CUSTOM12_2_to_scal)
        ,.RdIValid_CUSTOM6_2_o(isax_RdIValid_CUSTOM6_2_from_scal)
        ,.WrRD_CUSTOM4_2_i(isax_WrRD_CUSTOM4_2_to_scal)
        ,.RdMem_addr_valid_2_o(core_RdMem_addr_valid_2_from_scal)
        ,.RdIValid_CUSTOM2_2_o(isax_RdIValid_CUSTOM2_2_from_scal)
        ,.RdStall_CUSTOM5_3_o(isax_RdStall_CUSTOM5_3_from_scal)
        ,.RdIValid_CUSTOM4_2_o(isax_RdIValid_CUSTOM4_2_from_scal)
        ,.RdStall_CUSTOM10_2_o(isax_RdStall_CUSTOM10_2_from_scal)
        ,.RdStall_CUSTOM12_2_o(isax_RdStall_CUSTOM12_2_from_scal)
        ,.WrRD_3_o(core_WrRD_3_from_scal)
        ,.WrRD_CUSTOM11_2_i(isax_WrRD_CUSTOM11_2_to_scal)
        ,.RdStall_CUSTOM14_2_o(isax_RdStall_CUSTOM14_2_from_scal)
        ,.RdIValid_CUSTOM29_2_o(isax_RdIValid_CUSTOM29_2_from_scal)
        ,.RdStall_CUSTOM18_2_o(isax_RdStall_CUSTOM18_2_from_scal)
        ,.RdIValid_CUSTOM23_2_o(isax_RdIValid_CUSTOM23_2_from_scal)
        ,.RdIValid_CUSTOM25_2_o(isax_RdIValid_CUSTOM25_2_from_scal)
        ,.RdStall_CUSTOM16_2_o(isax_RdStall_CUSTOM16_2_from_scal)
        ,.RdIValid_CUSTOM27_2_o(isax_RdIValid_CUSTOM27_2_from_scal)
        ,.WrRD_CUSTOM9_2_i(isax_WrRD_CUSTOM9_2_to_scal)
        ,.RdIValid_CUSTOM21_2_o(isax_RdIValid_CUSTOM21_2_from_scal)
        ,.RdStall_CUSTOM27_3_o(isax_RdStall_CUSTOM27_3_from_scal)
        ,.WrRD_CUSTOM17_2_i(isax_WrRD_CUSTOM17_2_to_scal)
        ,.WrRD_validReq_3_o(core_WrRD_validReq_3_from_scal)
        ,.WrRD_CUSTOM15_3_i(isax_WrRD_CUSTOM15_3_to_scal)
        ,.RdMem_validReq_CUSTOM16_2_i(isax_RdMem_validReq_CUSTOM16_2_to_scal)
        ,.RdFlush_1_i(core_RdFlush_1_to_scal)
    );
    
    ISAX_XIsaac isax_xisaac (
        .clk_i(clk)
        ,.rst_i(rst)
        ,.RdRS1_CUSTOM10_2_i(isax_RdRS1_2_from_scal)
        ,.RdRS1_CUSTOM11_2_i(isax_RdRS1_2_from_scal)
        ,.RdRS1_CUSTOM12_2_i(isax_RdRS1_2_from_scal)
        ,.RdRS1_CUSTOM13_2_i(isax_RdRS1_2_from_scal)
        ,.RdIValid_CUSTOM18_2_i(isax_RdIValid_CUSTOM18_2_from_scal)
        ,.RdIValid_CUSTOM19_2_i(isax_RdIValid_CUSTOM19_2_from_scal)
        ,.WrRD_CUSTOM8_2_o(isax_WrRD_CUSTOM8_2_to_scal)
        ,.RdIValid_CUSTOM13_2_i(isax_RdIValid_CUSTOM13_2_from_scal)
        ,.RdIValid_CUSTOM12_2_i(isax_RdIValid_CUSTOM12_2_from_scal)
        ,.RdIValid_CUSTOM14_2_i(isax_RdIValid_CUSTOM14_2_from_scal)
        ,.RdIValid_CUSTOM17_2_i(isax_RdIValid_CUSTOM17_2_from_scal)
        ,.RdRS1_CUSTOM14_2_i(isax_RdRS1_2_from_scal)
        ,.RdRS1_CUSTOM15_2_i(isax_RdRS1_2_from_scal)
        ,.RdIValid_CUSTOM16_2_i(isax_RdIValid_CUSTOM16_2_from_scal)
        ,.RdRS1_CUSTOM16_2_i(isax_RdRS1_2_from_scal)
        ,.RdRS1_CUSTOM17_2_i(isax_RdRS1_2_from_scal)
        ,.RdIValid_CUSTOM15_2_i(isax_RdIValid_CUSTOM15_2_from_scal)
        ,.RdRS1_CUSTOM18_2_i(isax_RdRS1_2_from_scal)
        ,.RdRS1_CUSTOM19_2_i(isax_RdRS1_2_from_scal)
        ,.WrRD_CUSTOM7_2_o(isax_WrRD_CUSTOM7_2_to_scal)
        ,.RdMem_addr_CUSTOM0_2_o(isax_RdMem_addr_CUSTOM0_2_to_scal)
        ,.RdIValid_CUSTOM16_3_i(isax_RdIValid_CUSTOM16_3_from_scal)
        ,.RdIValid_CUSTOM15_3_i(isax_RdIValid_CUSTOM15_3_from_scal)
        ,.RdMem_addr_CUSTOM3_2_o(isax_RdMem_addr_CUSTOM3_2_to_scal)
        ,.RdRS1_CUSTOM0_2_i(isax_RdRS1_2_from_scal)
        ,.WrRD_CUSTOM16_3_o(isax_WrRD_CUSTOM16_3_to_scal)
        ,.RdRS1_CUSTOM4_2_i(isax_RdRS1_2_from_scal)
        ,.RdRS1_CUSTOM3_2_i(isax_RdRS1_2_from_scal)
        ,.RdRS1_CUSTOM2_2_i(isax_RdRS1_2_from_scal)
        ,.RdRS1_CUSTOM1_2_i(isax_RdRS1_2_from_scal)
        ,.WrRD_CUSTOM0_3_o(isax_WrRD_CUSTOM0_3_to_scal)
        ,.RdRS1_CUSTOM8_2_i(isax_RdRS1_2_from_scal)
        ,.WrRD_CUSTOM29_2_o(isax_WrRD_CUSTOM29_2_to_scal)
        ,.RdRS1_CUSTOM7_2_i(isax_RdRS1_2_from_scal)
        ,.RdRS1_CUSTOM6_2_i(isax_RdRS1_2_from_scal)
        ,.RdRS1_CUSTOM5_2_i(isax_RdRS1_2_from_scal)
        ,.RdRS1_CUSTOM9_2_i(isax_RdRS1_2_from_scal)
        ,.RdIValid_CUSTOM10_2_i(isax_RdIValid_CUSTOM10_2_from_scal)
        ,.WrRD_CUSTOM20_2_o(isax_WrRD_CUSTOM20_2_to_scal)
        ,.RdMem_validReq_CUSTOM3_2_o(isax_RdMem_validReq_CUSTOM3_2_to_scal)
        ,.RdIValid_CUSTOM11_2_i(isax_RdIValid_CUSTOM11_2_from_scal)
        ,.RdIValid_CUSTOM31_2_i(isax_RdIValid_CUSTOM31_2_from_scal)
        ,.RdIValid_CUSTOM30_2_i(isax_RdIValid_CUSTOM30_2_from_scal)
        ,.WrRD_CUSTOM10_2_o(isax_WrRD_CUSTOM10_2_to_scal)
        ,.WrRD_CUSTOM13_2_o(isax_WrRD_CUSTOM13_2_to_scal)
        ,.RdMem_validReq_CUSTOM0_2_o(isax_RdMem_validReq_CUSTOM0_2_to_scal)
        ,.RdStall_CUSTOM0_3_i(isax_RdStall_CUSTOM0_3_from_scal)
        ,.RdIValid_CUSTOM0_3_i(isax_RdIValid_CUSTOM0_3_from_scal)
        ,.RdIValid_CUSTOM7_2_i(isax_RdIValid_CUSTOM7_2_from_scal)
        ,.RdStall_CUSTOM9_2_i(isax_RdStall_CUSTOM9_2_from_scal)
        ,.WrRD_CUSTOM3_3_o(isax_WrRD_CUSTOM3_3_to_scal)
        ,.RdIValid_CUSTOM9_2_i(isax_RdIValid_CUSTOM9_2_from_scal)
        ,.RdStall_CUSTOM7_2_i(isax_RdStall_CUSTOM7_2_from_scal)
        ,.RdRS2_CUSTOM31_2_i(isax_RdRS2_2_from_scal)
        ,.RdIValid_CUSTOM1_2_i(isax_RdIValid_CUSTOM1_2_from_scal)
        ,.RdRS2_CUSTOM30_2_i(isax_RdRS2_2_from_scal)
        ,.WrRD_CUSTOM21_2_o(isax_WrRD_CUSTOM21_2_to_scal)
        ,.RdIValid_CUSTOM5_2_i(isax_RdIValid_CUSTOM5_2_from_scal)
        ,.WrRD_CUSTOM28_2_o(isax_WrRD_CUSTOM28_2_to_scal)
        ,.RdIValid_CUSTOM3_2_i(isax_RdIValid_CUSTOM3_2_from_scal)
        ,.RdRS2_CUSTOM24_2_i(isax_RdRS2_2_from_scal)
        ,.RdStall_CUSTOM11_2_i(isax_RdStall_CUSTOM11_2_from_scal)
        ,.RdRS2_CUSTOM25_2_i(isax_RdRS2_2_from_scal)
        ,.RdRS2_CUSTOM20_2_i(isax_RdRS2_2_from_scal)
        ,.RdRS2_CUSTOM21_2_i(isax_RdRS2_2_from_scal)
        ,.RdIValid_CUSTOM28_2_i(isax_RdIValid_CUSTOM28_2_from_scal)
        ,.RdStall_CUSTOM13_2_i(isax_RdStall_CUSTOM13_2_from_scal)
        ,.RdStall_CUSTOM19_2_i(isax_RdStall_CUSTOM19_2_from_scal)
        ,.RdMem_validReq_CUSTOM5_2_o(isax_RdMem_validReq_CUSTOM5_2_to_scal)
        ,.RdIValid_CUSTOM24_2_i(isax_RdIValid_CUSTOM24_2_from_scal)
        ,.RdStall_CUSTOM15_2_i(isax_RdStall_CUSTOM15_2_from_scal)
        ,.RdRS2_CUSTOM28_2_i(isax_RdRS2_2_from_scal)
        ,.RdStall_CUSTOM17_2_i(isax_RdStall_CUSTOM17_2_from_scal)
        ,.RdRS2_CUSTOM26_2_i(isax_RdRS2_2_from_scal)
        ,.WrRD_CUSTOM22_2_o(isax_WrRD_CUSTOM22_2_to_scal)
        ,.RdIValid_CUSTOM26_2_i(isax_RdIValid_CUSTOM26_2_from_scal)
        ,.RdRS2_CUSTOM27_2_i(isax_RdRS2_2_from_scal)
        ,.RdRS2_CUSTOM3_3_i(isax_RdRS2_3_from_scal)
        ,.RdRS2_CUSTOM13_2_i(isax_RdRS2_2_from_scal)
        ,.RdRS2_CUSTOM16_3_i(isax_RdRS2_3_from_scal)
        ,.RdRS2_CUSTOM14_2_i(isax_RdRS2_2_from_scal)
        ,.RdRS2_CUSTOM11_2_i(isax_RdRS2_2_from_scal)
        ,.RdRS2_CUSTOM12_2_i(isax_RdRS2_2_from_scal)
        ,.RdRS2_CUSTOM10_2_i(isax_RdRS2_2_from_scal)
        ,.WrRD_CUSTOM14_2_o(isax_WrRD_CUSTOM14_2_to_scal)
        ,.RdIValid_CUSTOM22_2_i(isax_RdIValid_CUSTOM22_2_from_scal)
        ,.RdIValid_CUSTOM20_2_i(isax_RdIValid_CUSTOM20_2_from_scal)
        ,.RdRS2_CUSTOM19_2_i(isax_RdRS2_2_from_scal)
        ,.WrRD_CUSTOM6_2_o(isax_WrRD_CUSTOM6_2_to_scal)
        ,.RdRS2_CUSTOM17_2_i(isax_RdRS2_2_from_scal)
        ,.RdRS2_CUSTOM15_2_i(isax_RdRS2_2_from_scal)
        ,.RdStall_CUSTOM22_2_i(isax_RdStall_CUSTOM22_2_from_scal)
        ,.RdStall_CUSTOM21_2_i(isax_RdStall_CUSTOM21_2_from_scal)
        ,.RdInstr_CUSTOM8_2_i(isax_RdInstr_2_from_scal)
        ,.RdInstr_CUSTOM7_2_i(isax_RdInstr_2_from_scal)
        ,.RdInstr_CUSTOM6_2_i(isax_RdInstr_2_from_scal)
        ,.RdMem_validReq_CUSTOM15_2_o(isax_RdMem_validReq_CUSTOM15_2_to_scal)
        ,.RdStall_CUSTOM25_2_i(isax_RdStall_CUSTOM25_2_from_scal)
        ,.RdInstr_CUSTOM30_2_i(isax_RdInstr_2_from_scal)
        ,.WrRD_CUSTOM24_2_o(isax_WrRD_CUSTOM24_2_to_scal)
        ,.RdInstr_CUSTOM9_2_i(isax_RdInstr_2_from_scal)
        ,.RdInstr_CUSTOM31_2_i(isax_RdInstr_2_from_scal)
        ,.RdStall_CUSTOM23_2_i(isax_RdStall_CUSTOM23_2_from_scal)
        ,.RdStall_CUSTOM24_2_i(isax_RdStall_CUSTOM24_2_from_scal)
        ,.RdStall_CUSTOM29_2_i(isax_RdStall_CUSTOM29_2_from_scal)
        ,.RdStall_CUSTOM26_2_i(isax_RdStall_CUSTOM26_2_from_scal)
        ,.RdStall_CUSTOM27_2_i(isax_RdStall_CUSTOM27_2_from_scal)
        ,.RdStall_CUSTOM28_2_i(isax_RdStall_CUSTOM28_2_from_scal)
        ,.WrRD_CUSTOM31_2_o(isax_WrRD_CUSTOM31_2_to_scal)
        ,.RdInstr_CUSTOM20_2_i(isax_RdInstr_2_from_scal)
        ,.WrRD_CUSTOM25_2_o(isax_WrRD_CUSTOM25_2_to_scal)
        ,.RdInstr_CUSTOM25_2_i(isax_RdInstr_2_from_scal)
        ,.RdMem_CUSTOM5_2_i(isax_RdMem_2_from_scal)
        ,.RdMem_addr_CUSTOM15_2_o(isax_RdMem_addr_CUSTOM15_2_to_scal)
        ,.RdInstr_CUSTOM21_2_i(isax_RdInstr_2_from_scal)
        ,.RdMem_CUSTOM0_2_i(isax_RdMem_2_from_scal)
        ,.RdInstr_CUSTOM22_2_i(isax_RdInstr_2_from_scal)
        ,.RdInstr_CUSTOM23_2_i(isax_RdInstr_2_from_scal)
        ,.RdInstr_CUSTOM24_2_i(isax_RdInstr_2_from_scal)
        ,.WrRD_CUSTOM1_2_o(isax_WrRD_CUSTOM1_2_to_scal)
        ,.RdMem_CUSTOM3_2_i(isax_RdMem_2_from_scal)
        ,.RdStall_CUSTOM20_2_i(isax_RdStall_CUSTOM20_2_from_scal)
        ,.RdStall_CUSTOM30_2_i(isax_RdStall_CUSTOM30_2_from_scal)
        ,.RdStall_CUSTOM31_2_i(isax_RdStall_CUSTOM31_2_from_scal)
        ,.WrRD_CUSTOM26_2_o(isax_WrRD_CUSTOM26_2_to_scal)
        ,.WrRD_CUSTOM18_2_o(isax_WrRD_CUSTOM18_2_to_scal)
        ,.RdMem_addr_CUSTOM16_2_o(isax_RdMem_addr_CUSTOM16_2_to_scal)
        ,.RdInstr_CUSTOM12_2_i(isax_RdInstr_2_from_scal)
        ,.WrRD_CUSTOM19_2_o(isax_WrRD_CUSTOM19_2_to_scal)
        ,.RdInstr_CUSTOM13_2_i(isax_RdInstr_2_from_scal)
        ,.WrRD_CUSTOM30_2_o(isax_WrRD_CUSTOM30_2_to_scal)
        ,.WrRD_CUSTOM5_3_o(isax_WrRD_CUSTOM5_3_to_scal)
        ,.WrRD_CUSTOM27_3_o(isax_WrRD_CUSTOM27_3_to_scal)
        ,.RdRS2_CUSTOM8_2_i(isax_RdRS2_2_from_scal)
        ,.RdStall_CUSTOM3_2_i(isax_RdStall_CUSTOM3_2_from_scal)
        ,.RdRS2_CUSTOM9_2_i(isax_RdRS2_2_from_scal)
        ,.RdStall_CUSTOM2_2_i(isax_RdStall_CUSTOM2_2_from_scal)
        ,.RdStall_CUSTOM4_2_i(isax_RdStall_CUSTOM4_2_from_scal)
        ,.RdRS2_CUSTOM4_2_i(isax_RdRS2_2_from_scal)
        ,.RdStall_CUSTOM1_2_i(isax_RdStall_CUSTOM1_2_from_scal)
        ,.RdStall_CUSTOM5_2_i(isax_RdStall_CUSTOM5_2_from_scal)
        ,.RdRS2_CUSTOM5_2_i(isax_RdRS2_2_from_scal)
        ,.RdRS2_CUSTOM6_2_i(isax_RdRS2_2_from_scal)
        ,.RdRS2_CUSTOM7_2_i(isax_RdRS2_2_from_scal)
        ,.RdRS2_CUSTOM0_2_i(isax_RdRS2_2_from_scal)
        ,.RdRS2_CUSTOM1_2_i(isax_RdRS2_2_from_scal)
        ,.RdRS2_CUSTOM2_2_i(isax_RdRS2_2_from_scal)
        ,.WrRD_CUSTOM2_2_o(isax_WrRD_CUSTOM2_2_to_scal)
        ,.WrRD_CUSTOM23_2_o(isax_WrRD_CUSTOM23_2_to_scal)
        ,.RdStall_CUSTOM0_2_i(isax_RdStall_CUSTOM0_2_from_scal)
        ,.RdStall_CUSTOM15_3_i(isax_RdStall_CUSTOM15_3_from_scal)
        ,.RdStall_CUSTOM16_3_i(isax_RdStall_CUSTOM16_3_from_scal)
        ,.RdStall_CUSTOM3_3_i(isax_RdStall_CUSTOM3_3_from_scal)
        ,.RdIValid_CUSTOM8_2_i(isax_RdIValid_CUSTOM8_2_from_scal)
        ,.RdIValid_CUSTOM3_3_i(isax_RdIValid_CUSTOM3_3_from_scal)
        ,.RdIValid_CUSTOM5_3_i(isax_RdIValid_CUSTOM5_3_from_scal)
        ,.RdMem_addr_CUSTOM5_2_o(isax_RdMem_addr_CUSTOM5_2_to_scal)
        ,.RdStall_CUSTOM6_2_i(isax_RdStall_CUSTOM6_2_from_scal)
        ,.RdStall_CUSTOM8_2_i(isax_RdStall_CUSTOM8_2_from_scal)
        ,.RdIValid_CUSTOM27_3_i(isax_RdIValid_CUSTOM27_3_from_scal)
        ,.RdIValid_CUSTOM0_2_i(isax_RdIValid_CUSTOM0_2_from_scal)
        ,.WrRD_CUSTOM12_2_o(isax_WrRD_CUSTOM12_2_to_scal)
        ,.RdIValid_CUSTOM6_2_i(isax_RdIValid_CUSTOM6_2_from_scal)
        ,.WrRD_CUSTOM4_2_o(isax_WrRD_CUSTOM4_2_to_scal)
        ,.RdIValid_CUSTOM2_2_i(isax_RdIValid_CUSTOM2_2_from_scal)
        ,.RdStall_CUSTOM5_3_i(isax_RdStall_CUSTOM5_3_from_scal)
        ,.RdIValid_CUSTOM4_2_i(isax_RdIValid_CUSTOM4_2_from_scal)
        ,.RdRS1_CUSTOM30_2_i(isax_RdRS1_2_from_scal)
        ,.RdStall_CUSTOM10_2_i(isax_RdStall_CUSTOM10_2_from_scal)
        ,.RdStall_CUSTOM12_2_i(isax_RdStall_CUSTOM12_2_from_scal)
        ,.RdRS1_CUSTOM31_2_i(isax_RdRS1_2_from_scal)
        ,.WrRD_CUSTOM11_2_o(isax_WrRD_CUSTOM11_2_to_scal)
        ,.RdStall_CUSTOM14_2_i(isax_RdStall_CUSTOM14_2_from_scal)
        ,.RdIValid_CUSTOM29_2_i(isax_RdIValid_CUSTOM29_2_from_scal)
        ,.RdStall_CUSTOM18_2_i(isax_RdStall_CUSTOM18_2_from_scal)
        ,.RdIValid_CUSTOM23_2_i(isax_RdIValid_CUSTOM23_2_from_scal)
        ,.RdIValid_CUSTOM25_2_i(isax_RdIValid_CUSTOM25_2_from_scal)
        ,.RdMem_CUSTOM16_2_i(isax_RdMem_2_from_scal)
        ,.RdMem_CUSTOM15_2_i(isax_RdMem_2_from_scal)
        ,.RdStall_CUSTOM16_2_i(isax_RdStall_CUSTOM16_2_from_scal)
        ,.RdIValid_CUSTOM27_2_i(isax_RdIValid_CUSTOM27_2_from_scal)
        ,.RdRS1_CUSTOM20_2_i(isax_RdRS1_2_from_scal)
        ,.RdRS1_CUSTOM21_2_i(isax_RdRS1_2_from_scal)
        ,.RdRS1_CUSTOM22_2_i(isax_RdRS1_2_from_scal)
        ,.RdRS1_CUSTOM23_2_i(isax_RdRS1_2_from_scal)
        ,.RdRS1_CUSTOM24_2_i(isax_RdRS1_2_from_scal)
        ,.WrRD_CUSTOM9_2_o(isax_WrRD_CUSTOM9_2_to_scal)
        ,.RdIValid_CUSTOM21_2_i(isax_RdIValid_CUSTOM21_2_from_scal)
        ,.RdStall_CUSTOM27_3_i(isax_RdStall_CUSTOM27_3_from_scal)
        ,.WrRD_CUSTOM17_2_o(isax_WrRD_CUSTOM17_2_to_scal)
        ,.RdRS1_CUSTOM25_2_i(isax_RdRS1_2_from_scal)
        ,.RdRS1_CUSTOM26_2_i(isax_RdRS1_2_from_scal)
        ,.RdRS1_CUSTOM27_2_i(isax_RdRS1_2_from_scal)
        ,.WrRD_CUSTOM15_3_o(isax_WrRD_CUSTOM15_3_to_scal)
        ,.RdRS1_CUSTOM28_2_i(isax_RdRS1_2_from_scal)
        ,.RdRS1_CUSTOM29_2_i(isax_RdRS1_2_from_scal)
        ,.RdMem_validReq_CUSTOM16_2_o(isax_RdMem_validReq_CUSTOM16_2_to_scal)
    );

    	
endmodule
